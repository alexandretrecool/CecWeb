#!/bin/bash
MEU_IP=$REMOTE_ADDR

if [ -f ip_aut.cfg ]
    then
    IP=`cat ip_aut.cfg`
    IP=`echo $IP |sed -s 's/,/ /g'`

    OK=0
    for i in $IP
	do
        if [[ "${MEU_IP}" =~ ^"${i}" ]]
    	    then
            OK=1
        fi    
    done
    if [ "${OK}" != "1" ]
	then
	sleep 5
        echo "Content-type: text/html"
	echo
	echo '{"dataret": "'`date +"%Y-%m-%d %H:%M:%S"`'","erro": 87,"cerro": "Ip do solicitante nao aceito => '${MEU_IP}'"}'
	exit
    fi
fi

echo "Content-type: text/plain"
echo

echo The date is: `date` 
echo 
VER=`grep MED_VER ./medweb.cgi|awk -F"=" '{print $2}'`
QUERY_STRING=medmostra=1
VAR=`./medweb.cgi`
echo $VAR|awk -F"{"  '{print $2}'|awk -F"," '{print $1}' 
echo $VAR|awk -F"{"  '{print $2}'|awk -F"," '{print $2}' 
echo $VAR|awk -F"{"  '{print $2}'|awk -F"," '{print $3}' 
echo $VAR|awk -F"{"  '{print $2}'|awk -F"," '{print $4}' 
echo $VAR|awk -F"{"  '{print $2}'|awk -F"," '{print $11}'|awk -F"}" '{print $1}' 
echo $VAR|awk -F"{"  '{print $2}'|awk -F"," '{print $12}'|awk -F"}" '{print $1}' 
VAR=`echo $VAR|awk -F"["  '{print $2}'`
VAR=`echo '"Medlogin"': $VER,$VAR`
echo $VAR|awk -F"]" '{print $1}'

