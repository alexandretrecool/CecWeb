#!/bin/sh

export MED_VER=15
export LD_LIBRARY_PATH=/var/www/cgi-bin

MEU_IP=$REMOTE_ADDR

if [ -f ip_aut.cfg ]
    then
    IP=`cat ip_aut.cfg`
    IP=`echo $IP |sed -s 's/,/ /g'`

    OK=0
    for i in $IP
	do
        if [[ "${MEU_IP}" =~ ^"${i}" ]]
    	    then
            OK=1
        fi    
    done
    if [ "${OK}" != "1" ]
	then
	sleep 5
        echo "Content-type: text/html"
	echo
	echo '{"dataret": "'`date +"%Y-%m-%d %H:%M:%S"`'","erro": 87,"cerro": "Ip do solicitante nao aceito => '${MEU_IP}'"}'
	log=`sed -n '2p' log.cfg`
	if [ "${log}x" != "x" ] && [ `echo ${log}|awk '{print substr($1,1,1)}'` != "#" ];then
    	    echo 'Data": "'`date +"%Y-%m-%d %H:%M:%S"`'" "Ip do solicitante nao aceito => '${MEU_IP}'"}' >> ${log}
	fi
	exit
    fi
fi
./medweb.${MED_VER}

