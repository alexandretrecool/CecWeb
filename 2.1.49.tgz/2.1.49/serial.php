<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";
if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}

$target_dir = "uploads/"; // Specify the directory where files will be stored
$cfrente = basename($_FILES["formFileF"]["name"]);
$cverso = basename($_FILES["formFileV"]["name"]);
$FType = strtolower(pathinfo($cfrente, PATHINFO_EXTENSION));
$VType = strtolower(pathinfo($cverso, PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if ($FType !== "pdf") {
    $check = getimagesize($_FILES["formFileF"]["tmp_name"]);
    if ($check == false) {
        $aret["erro"] = 2;
        $aret["cerro"] = "Imagem de frente inválida - " . $check["mime"];
        echo json_encode($aret);
        return;
    }
}
if ($cverso && $FType !== "pdf") {
    $check = getimagesize($_FILES["formFileV"]["tmp_name"]);
    if ($check == false) {
        $aret["erro"] = 2;
        $aret["cerro"] = "Imagem de verso inválida - " . $check["mime"];
        echo json_encode($aret);
        return;
    }
}
