<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

session_start();

require_once 'inc/config.php';
$ncli = pegavar("cod");
$cven = pegavar("ven");
$cope = pegavar("ope");
$cced = pegavar("ced");
$cnom = pegavar("nom");

if (!$ncli) {
    return;
}

if (!$db){
    $db = conecta();
}
if (!$db) {
    echo "99-"._tr("Erro acessando SQL");
    return;
}
$olincli = mysqi_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI where is_deleted='N' and codcli=$ncli"));

mysqli_query($db, "update CEDULA_CLI SET 
    cedula='" . $olincli["RUCCLI"] . "'
    ,nome='" . limpachar($olincli["NOMCLI"]) . "'
        ,operador='" . VeSession("usuario") . "'
            ,vendedor='" . VeSession("vendedor") . "'
                ,data=now() 
                where IS_DELETED='N' and CODIGO=$ncli ");



mysqli_close($db);

return;

