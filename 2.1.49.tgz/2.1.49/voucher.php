<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";
if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}
$modo = PegaVar("modo");
$vendedor = PegaVar("vendedor");
if (!$vendedor) {
    $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
}

$nserie = pegavar('serie') + 0;
$nvendedor = $vendedor;

require_once 'inc/sid.php';

if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("Erro acessando servidor") . ".\n" . $caux;
    echo json_encode($aret);
    return;
}

require_once 'voucher_engine.php';

if ($modo == 1 || $modo = 'ANALISA') {
    $nper = 0;
    $nvalor = 0;
    $cerro = "";
    $nerro=AnalisaVoucher($nvendedor, $nserie, $lweb, $nper, $nvalor, $cerro);
    $aret["per"]=$nper;
    $aret["val"]=$nvalor;
    if ($nerro){
        $aret["erro"]=$nerro;
        $aret["cerro"]=$cerro;
    }
    echo json_encode($aret);
    return;
    
}

echo json_encode($aret);
return;

