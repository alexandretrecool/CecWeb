<?php

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$cuser = strtoupper(trim(PegaVar("user")));
$csid = pegavar("sid");
$loja = PegaVar("loja");
$vendedor = pegavar("vendedor");
$moeda = pegavar("moeda");
$cambio = pegavar("cambio");
$modo = pegavar("modo");

if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}

require_once 'inc/sid.php';

if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("Erro acessando servidor") . ".\n.\n" . $caux;
    echo json_encode($aret);
    return;
}


$cliente = pegavar("cliente");
$fantasia = pegavar("fantasia");
$rg = pegavar("rg");
$cpf = pegavar("cpf");
$mail = pegavar("mail");
$nome = pegavar("nome");
$cmodo = PegaVar("modo");

if ($cmodo == "VEDIVIDA") {
    if (!$cliente) {
        $aret["erro"] = "97";
        $aret["cerro"] = _tr("Erros de parâmetros");
        echo json_encode($aret);
        return;
    }
    $csql = "select left(d.numedup,7) as CNUMEDUP,d.NUMEDUP,digito(left(d.numedup,7)) AS DIGITO,right(d.numedup,2) as ORDEM,d.EMISDUP,d.VENCDUP,d.RECEDUP,d.CHEQDUP,d.MOEDUP,d.VALODUP,DATEDIFF(d.VENCDUP,CURRENT_DATE) AS DIF
        ,d.NUMEDUPA,d.CHEQDUP,d.BANCDUP,b.NOMBAN FROM DUPLICAT_CLI d LEFT JOIN BANCOS_BAN b ON b.IS_DELETED='N' AND b.CODBAN=d.BANCDUP 
        WHERE d.IS_DELETED='N' and d.RECEDUP<='1000-01-01' AND d.CLIEDUP=$cliente order by d.vencdup";
    $otabrec = mysqli_query($db, $csql);
    $arec = array();
    $ctabela = '<table class="table table-striped"><tr>
        <th>Doc</th>
        <th>Emissão</th>
        <th>Vence</th>
        <th>Dd</th>
        <th>Moe</th>
        <th>Valor</th>
        <th>Banco</th>
        </tr>
        ';
    $olmoe = mysqli_fetch_row(mysqli_query($db, "select '' AS SIMB0,SIMB1,SIMB2,SIMB3,SIMB4,DECI1,DECI2,DECI3,DECI4 from CAMBIO_NOM where recno=1"));
    $aTotal = array(0, 0, 0, 0, 0);
    $aAtrasado = array(0, 0, 0, 0, 0);
    while ($olinrec = mysqli_fetch_array($otabrec)) {

        $ctabela .= '<tr>';
        $ctabela .= "<td>" . $olinrec["NUMEDUP"] . "</td>";
        $ctabela .= "<td>" . sql2data($olinrec["EMISDUP"]) . "</td>";
        $ctabela .= '<td ' . ($olinrec["DIF"] <= 0 ? ' class="text-danger" style="font-weight: bold"' : '') . '>' . sql2data($olinrec["VENCDUP"]) . "</td>";
        $ctabela .= '<td ' . ($olinrec["DIF"] <= 0 ? ' class="text-danger" style="font-weight: bold"' : '') . '>' . $olinrec["DIF"] . "</td>";
        $ctabela .= "<td>" . $olmoe[$olinrec["MOEDUP"]] . "</td>";
        $ctabela .= "<td>" . number_format($olinrec["VALODUP"], $olmoe[$olinrec["MOEDUP"] + 4] == "S" ? 2 : 0) . "</td>";
        $ctabela .= "<td>" . $olinrec["BANCDUP"] . "</td>";

        $aTotal[$olinrec["MOEDUP"]] += $olinrec["VALODUP"];
        if ($olinrec["DIF"] < 0) {
            $aAtrasado[$olinrec["MOEDUP"]] += $olinrec["VALODUP"];
        }
        $arec[] = $olinrec;
    }
    $i = 0;
    foreach ($aTotal as $value) {
        if ($value > 0) {
            $ctabela .= '<tr><td class="bg-info text-right" colspan="2">Total ' . $olmoe[$i] . ' </td><td class="bg-primary text-right" colspan="3"> ' . number_format($value, $olmoe[$i + 4] == "S" ? 2 : 0) . '</td><td class="bg-primary text-right" colspan="2"></td></tr>';
        }
        $i++;
    }
    $i = 0;
    foreach ($aAtrasado as $value) {
        if ($value > 0) {
            $ctabela .= '<tr><td class="bg-warning text-right" colspan="2">Atrasado ' . $olmoe[$i] . ' </td><td class="bg-danger text-right" colspan="3"> ' . number_format($value, $olmoe[$i + 4] == "S" ? 2 : 0) . '</td><td class="bg-danger text-right" colspan="2"></td></tr>';
        }
        $i++;
    }
    $ctabela .= "</table>";
    $aret["tabela"] = $ctabela;
    $aret["rec"] = $arec;

    echo json_encode($aret);
    return;
}

if ($cliente || $rg || $mail || $nome || $cpf || $fantasia) {
    $ncod = $cliente;
    $crg = LimpaRg(strtoupper(pegavar("rg")));
    $ccpf = LimpaRg(strtoupper(pegavar("cpf")));

    // verificar auto-cadastro

    if ($crg && mysqli_num_rows(mysqli_query($db, "show tables like 'CLIENTE_PGY_web'")) > 0 && ($curl = mysqli_fetch_row(mysqli_query($db, "select AUTOCAD FROM CONFIG WHERE RECNO=1"))[0]) !== '') {

        $nCodCli = mysqli_fetch_array(mysqli_query($db, "select codcli from CLIENTE_CLI where is_deleted='N' and rucres=" . AsSql($crg)))[0];

        if (mysqli_num_rows(mysqli_query($db, "select cedula from CLIENTE_PGY_web where cedula=" . AsSql($crg))) > 0) {
            $aret["erro"] = 77;
            if ($nCodCli) {
                $aret["cerro"] = "Este cliente já está cadastrado na base de dados principal,\n\nporém ele fez um AUTO-CADASTRO atualizando seus dados.\n\nPor favor confirme os dados para atualizar o cliente.";
            } else {
                $aret["cerro"] = "Este cliente Não está cadastrado na base de dados principal.\n\nEle(a) fez um AUTO-CADASTRO atualizando seus dados.\n\nPor favor confirme os dados para atualizar o cliente.";
            }
            $aret["cerro"] .= "\n\nFaça a confirmação pelo browser ou feche-o para abandonar o processo";
            $aret["url"] = $curl."ver_apk.php?cedula=$crg&key=".crypt($crg,"FDsdf4543kfkRErccP034r2");
            mysqli_query($db, "update CLIENTE_PGY_web SET ESTADO=1 WHERE cedula=" . AsSql($crg));
            echo json_encode($aret);
            return;
        }
    }

    $crank = " 1 ";

    if ($ncod) {
        $cwhere = " and c.codcli=$ncod";
    } elseif ($crg) {
        $cwhere = " and (c.ruccli='$crg' or c.rucres='$crg' ";
        $cwhere .= " )";
    } elseif ($ccpf) {
        $cwhere = " and (c.cpfcli='$ccpf'";

        $cwhere .= " )";
    } elseif ($mail) {
        $cwhere = " and c.e_mail='$mail'";
    } elseif ($fantasia) {
        $cwhere = " and c.fancli='$fantasia'";
    } elseif (strlen($nome) < 6) {
        $cwhere = " and c.nomcli like '%$nome%'";
    } else {
        /*
          $aaux = explode(" ", $nome);
          foreach ($aaux as $value) {
          if ($value){
          $cstr .= " AND c.nomcli like '%$value%'";
          }
          }
         */
        $cwhere = " AND MATCH(NOMCLI) AGAINST('$nome') ";
        $crank = " (MATCH(NOMCLI) AGAINST('$nome')) ";
    }


    $cstr = "select 
 c.ruccli as rg
,c.codcli as codigo
,c.e_mail as mail
,c.fancli as fantasia
,c.nomcli as nome
,if(isnull(p.nascimento) OR p.nascimento='1000-01-01',c.nascli,p.nascimento) as nasc
,if(isnull(p.sexo),1,p.sexo)   as sexo
,if(isnull(p.tipocli),1,p.tipocli) as tipo

,c.paiscli as paiscli
,trim(c.regicli) as regicli
,c.vencto_reg as vencto_reg
,c.vencto_reg<current_date as vencido
,current_date as hoje

,if(isnull(p.pais),if(c.paiscli=1,'PRY','BRA'),p.pais)   as pais
,if(isnull(p.cep),c.cepcli,p.cep)	  as cep
,if(!isnull(p.codigo) and p.endereco!='',p.endereco,c.endcli) as endereco
,if(isnull(p.codigo),'',p.complemen) as complemen
,if(!isnull(p.bairro) and p.bairro!='',p.bairro,c.baicli) as bairro
,if(c.paiscli=1,'',c.ufcli) as uf
,if(!isnull(p.cidade) and p.cidade!='',p.cidade,c.cidcli) as cidade
,if(isnull(p.aceitamail),'N', p.aceitamail) as aceitamail
,if(!isnull(p.telefone) and p.telefone!='',p.telefone,c.foncli) as telefone
,if(!isnull(p.celular) and p.celular!='',p.celular,c.celcli) as celular
,if(isnull(p.codigo),'',if(p.whatsapp,p.whatsapp,c.web1)) as whatsapp
,convert(if(isnull(i1.codigo),'0','1'),decimal(2,0)) as imagem1
,convert(if(isnull(i2.codigo),'0','1'),decimal(2,0)) as imagem2
,$crank as rank
,c.blkcli as blocli  
,c.przcli
,convert(if(isnull(p.marca),'',p.marca),CHAR) as marca
,convert(if(isnull(p.categoria),'',p.categoria),CHAR) as grupo
,c.zoncli as zona
,c.cpfcli as cpf
,if(isnull(y.pais_num),0,y.pais_num) as pais_num

from CLIENTE_CLI c
left join CLIENTE_PFC p on p.is_deleted='N' and p.codigo=c.codcli
left join CEDULA_CLI  i1 on i1.is_deleted='N' and i1.codigo=c.codcli and i1.ordem=1
left join CEDULA_CLI  i2 on i2.is_deleted='N' and i2.codigo=c.codcli and i2.ordem=2
left join CLIENTE_PGY y on y.is_deleted='N' and y.codigo=c.codcli
where c.is_deleted='N'  AND c.codcli!=0
$cwhere ";
    $cstr .= " group by c.codcli order by rank desc,c.nomcli limit 200 ";
    $otabcli = mysqli_query($db, $cstr);

    if (mysqli_num_rows($otabcli) == 0) {
        $aret["erro"] = "1";
        $aret["cerro"] = _tr("Cliente não localizado");
        echo json_encode($aret);
        return;
    }
    if (mysqli_num_rows($otabcli) == 1) {
        $olincli = mysqli_fetch_array($otabcli);
        if ($olincli["paiscli"] == 1 && $olincli["regicli"] != '' && $olincli["vencto_reg"] < $olincli["hoje"]) {
            $aret["erro"] = "98";
            $aret["cerro"] = _tr("Este cliente") . ": " . $olincab["cliente"] . "-" . $olincli["NOMCLI"] . "\n " . _tr("É distribuidor e seu registro está vencido. \nVenceu em") . " " . $olincli["VENCTO_REG"];
//            echo json_encode($aret);
//            return;
        }

        foreach ($olincli as $key => $value) {
            $aret[$key] = iconv('cp850', 'utf8', $value);
        }
    } else {
        $aclientes = array();
        while ($olincli = mysqli_fetch_array($otabcli)) {
            $aclientes[] = array($olincli["codigo"], iconv('cp850', 'utf8', $olincli["nome"]), $olincli["rg"],$olincli["paiscli"],$olincli["pais_num"]);
        }
        $aret["erro"] = 2;
        $aret["nomes"] = $aclientes;
    }
    $nCliente = $olincli["codigo"];
    $cRefGuia = "";
    $nRefGuia = 0;
    $aret["cguia"] = '';
    $aret["nguia"] = 0;
    
    if (VeListaGuiaCli($nCliente, $cRefGuia, $nRefGuia)) {
        $aret["cguia"] = iconv("cp850","utf8",$cRefGuia);
        $aret["nguia"] = $nRefGuia;
    }
    $olcfg=mysqli_fetch_array(mysqli_query($db,"select * from CONFIG where recno=1"));
    $aret["clientepyfull"]=$olincli["paiscli"]==1 && !$olincli["regicli"] && $olcfg["MODPEDI"]==6 && $olcfg["TARJ_VDAS"]=='N';
    echo json_encode($aret);
    return;
}

$aret["erro"] = "98";
$aret["cerro"] = _tr("Erros de parâmetros");
echo json_encode($aret);
return;

function VeListaGuiaCli($nCliente, &$cRefGuia = '', &$nRefGuia = 0, &$nRefLista = 0) {
    global $db;
    $nRefGuia = 0;
    $cRefGuia = '';
    $nRefLista = 0;
    if (!$nCliente) {
        return 0;
    }
    $olcli = mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI WHERE IS_DELETED='N' AND CODCLI=$nCliente"));
    if (!$olcli) {
        return 0;
    }

    $crg = $olcli["RUCCLI"];
    $crg = LimpaRg($crg);

    $nDiasAnteriores = mysqli_fetch_row(mysqli_query($db, "select guia_d_ant from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];
    $nDiasPosteriores = mysqli_fetch_row(mysqli_query($db, "select guia_d_pos from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];

    $nDiasAnteriores += 0;
    $nDiasPosteriores += 0;
    $dData = mysqli_fetch_row(mysqli_query($db, "select current_date()"))[0];

    $cRefErro = "";
    $nRefGuia = 0;
    $nRefLista = 0;

    //$nCliente = $olnot["CLIESAI"];


    $cRg = strtoupper(LimpaRg($olcli["RUCCLI"]));

    if (!$cRg) {
        $cRefErro = _tr("Cliente sem RUC/RG");
        return 0;
    }

    $dIni = date2unix($dData, "00:00:00", TRUE) - ($nDiasAnteriores * 24 * 60 * 60);
    $dFim = date2unix($dData, "23:59:59", TRUE) + ($nDiasPosteriores * 24 * 60 * 60);

    $cSql = "Select d.rg,d.nome,d.codigo AS lista,l.guia,d.recno as reg,d.presente 
     from LISTADET_GUI d 
     inner join LISTA_GUI l ON l.is_deleted='N' and l.codigo=d.codigo 
     where d.is_deleted='N' and d.rg='$cRg' 
     and l.data>=$dIni and l.data<=$dFim
     order by d.data";

    $otab = mysqli_query($db, $cSql);
    if (mysqli_num_rows($otab) == 0) {
        $cRefErro = _tr("Nada presente na lista");
        return 0;
    }
    $olis = mysqli_fetch_array($otab);

    $nRefGuia = $olis["guia"];
    $nRefLista = $olis["lista"];

    $cRefGuia = mysqli_fetch_row(mysqli_query($db, "select nomfor from FORNEC_FOR where is_deleted='N' and  codfor=$nRefGuia"))[0];

    return $nRefGuia;
}
