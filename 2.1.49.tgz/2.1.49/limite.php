<?php

session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL | E_STRICT);

require_once 'inc/config.php';


$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$modo = pegavar("modo");

if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}

require_once 'inc/sid.php';

define("CLIENTE_DIV", 227);

$ndias = 0;
$nlinite = 0;
$naberto = 0;
$nusuario = 199;
$ncliente = 693051;
$nvendedor = 1;
$cerro = '';
AchaSalVal($ncliente, $nusuario, $nvendedor, $cerro, $ndias, $nlimite, $naberto);
echo "Erro: " . $cerro . "<br>";
echo "Dias: " . $ndias . "<br>";
echo "Limite: " . $nlimite . "<br>";
echo "Aberto: " . $naberto . "<br>";
echo "<br><br>";

return;

function VeAut($nOperador, $nNivel) {
    global $db;
    $ocfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG where recno=1"));
    $aope = mysqli_fetch_array(mysqli_query($db, "select * from OPERADOR_OPE where is_deleted='N' and codigo=$nOperador"));
    $nGrupo = cifra($aope["GRUPO"]) + 0;
    $nGrau = VeConfSen($nNivel)["NIVEL"];

    if (cifra($aope["NIVEL"]) >= $nGrau) {
        $lPode = true;
    }
    if ($ocfg["GRUPOPE"] == "S") {
        $lPode = "N";
        $cstr = "select * from OPEGRUPO_OPE g WHERE g.IS_DELETED='N' AND g.opeopg=" . $nNivel . " AND g.codopg=" . $nGrupo;
        $otab = mysqli_query($db, $cstr);

        if (mysqli_num_rows($otab) == 0) {
            $lPode = false;
            return $lPode;
        }

    $olin = mysqli_fetch_row($otab);

    if ($olin["SITOPG"] == "X") {
        $VGRAU = 9;
    }


        $xope = '';
        $XGRAU = vesenhax($nGrupo, $xope, $nUsuario);
        if ($XGRAU == 9) {
            $WPODE = "S";
        }
    }
    echo $nGrupo . "<BR>" . $XGRAU . "<BR>";
}

function vesenhax($V, &$XOPE = '', $noperador = 0) {
    global $db;
    $VGRAU = 0;
    $cstr = "select * from OPEGRUPO_OPE g
      WHERE g.IS_DELETED='N' AND g.opeopg=" . $V . " AND g.codopg=";
    if ($XOPE) {
        $cstr .= $XOPE;
    } else {
        $cstr .= cifra(mysqli_fetch_row(mysqli_query($db, "select grupo from OPERADOR_OPE WHERE IS_DELETED='N' AND CODIGO=$noperador "))[0]);
    }

    $otab = mysqli_query($db, $cstr);

    if (mysqli_num_rows($otab) == 0) {
        return 0;
    }

    $olin = mysqli_fetch_row($otab);

    if ($olin["SITOPG"] == "X") {
        $VGRAU = 9;
    }

    // feito para o usuario que nao fazer autorizacao remota (obs: mas podera fazer autorizacao local)
    if (!$XOPE && $olin["SENOPG"] == "N") {
        $VGRAU = 0;
    }
    return $VGRAU;
}

function AchaSalVal($nCliente, $nUsuario = 0, $nVendedor = 0, &$cErro = '', &$nDias = 0, &$nLimite, &$nAberto) {
    global $db;

    $ocfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG where recno=1"));
    $ocli = mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI where IS_DELETED='N' AND CODCLI=" . $nCliente));
    $oven = mysqli_fetch_array(mysqli_query($db, "select * from VENDEDOR_VEN where IS_DELETED='N' AND CODVEN=" . $nVendedor));

    $asen = mysqli_fetch_array(mysqli_query($db, "select * from CONFSEN_SEN WHERE RECNO=" . $nCliente));

    $WPODE = 'N';
    $nGrupo = 0;
    if ($nUsuario) {
        $XGRAU = VeConfSen(CLIENTE_DIV)["NIVEL"];
        $aope = mysqli_fetch_array(mysqli_query($db, "select * from OPERADOR_OPE where is_deleted='N' and codigo=$nUsuario"));
        $nGrupo = cifra($aope["GRUPO"]) + 0;
        if (cifra($aope["NIVEL"]) >= $XGRAU) {
            $WPODE = "S";
        }
    }
    if ($ocfg["GRUPOPE"] == "S") {
        $WPODE = "N";
        $xope = '';
        $XGRAU = vesenhax($nGrupo, $xope, $nUsuario);
        if ($XGRAU == 9) {
            $WPODE = "S";
        }
    }
    echo $nGrupo . "<BR>" . $XGRAU . "<BR>";
    /*
      if ($VVP <> "A" && $ocfg["MODPEDI"] <> 13 && $ocfg["TUDPRAZ"] == "N" ){
      if ($ocfg["CONTPLZ"] == "S") {  // || ( M->FAT == "F" ) // .AND. M->IDIOMA=="E")
      if ($VCONCRE == 2 && $VVP !== "P" ){
      $cerro="CAMBIAR P/ PLAZO !!";
      return false;
      }

      if ($VCONCRE == 1 && $VVP !== "C"){
      $cerro= "CAMBIAR P/ CONTADO !!" ;
      return false;
      }
      }
      }

      if ($VVP == "V"){
      return true;
      }

      if ( $VDIAS > 0 &&  $ocli["PRZCLI"] < $VDIAS){
      $caux = "** Venta Mayor que Limite de Dias **"  . Chr( 13 ) . Chr( 10 ) ;
      $caux .= "Vended. : " . $nvendedor. "-" . $oven["NOMVEN"]. Chr( 13 ) . Chr( 10 );
      $caux .= "Cliente : " . $ncliente. "-" . $ocli["NOMCLI"]. Chr( 13 ) . Chr( 10 ) ;
      $caux .= "Dias perm.:" . $ocli["PRZCLI"]. Chr( 13 ) . Chr( 10 ) ;
      $caux .= "Dias ped..:" . $VDIAS;

      $NREGISTRO = 1;
      IF ! ped_geral( aux, ID( "Venda Acima do Limite de Dias", "Ventas Mayor que Limite de Dias" ), IF( M->FAT <> "F", SAIDAS_DIA, SAIDAS_DI1 ), M->USUMOM, @nregistro, "OPER_TERM", SaveScreen( 0, 0, m->max_row - 1, m->max_col - 1 ) )
      RETURN .F.
      ENDIF
      TelaSalva()
      SalvaTela( nRegistro,,, "CLI" + AllTrim( Transform( CLI->CODCLI, "9999999" ) ) )
      TelaSalva( "LIMPA" )
      ENDIF


      VSALDO := 0

      DUP->( DBSetOrder( "CLIREC" ) )

      DUP->( DBSeek( Str( VCLIESAI, 7 ), .T. ) )

      WATZ := "N"
      WNDZ := "N"
      WNDI := 0
      WNTO := Space( 9 )
      WVCT := Date()

      DO WHILE VCLIESAI == DUP->CLIEDUP

      IF ! Empty( DUP->RECEDUP )
      EXIT
      ENDIF

      //IF Date() - DUP->EMISDUP > IF( M->TOLERPZ == "S", CLI->TOLPRZ, CLI->PRZCLI )
      IF Date() - DUP->VENCDUP > IF( M->TOLERPZ == "S", CLI->TOLPRZ, CLI->PRZCLI )
      WNDZ := "S"

      IF WNDI < Date() - DUP->VENCDUP
      WNDI := Date() - DUP->VENCDUP
      WNTO := DUP->NUMEDUP
      WVCT := DUP->VENCDUP
      ENDIF
      ENDIF

      IF M->TOLERPZ == "N"
      IF DUP->VENCDUP < Date()
      WATZ := "S"
      ENDIF
      ENDIF

      IF M->TOLERPZ == "S"
      //IF Date() - DUP->EMISDUP > CLI->TOLPRZ
      IF Date() - DUP->VENCDUP > CLI->TOLPRZ
      WATZ := "S"
      ENDIF
      ENDIF

      VSALDO := VSALDO + ( DUP->VALODUP / tipcam[ dup->moedup ] * tipcam[ 1 ] )
      DUP->( DBSkip() )

      ENDDO



      IF LMEDIATOR
      VALPEN := selval( "select sum(s.VALOSAI/s.CAMBSAI*s.BASESAI) from " + IF( M->FAT <> "F", "SAIDAS_SAI", "FISCAL_SAI" ) + " s where s.TIPOSAI='P' and s.sitsai<>'S' and s.is_deleted='N' and cliesai=" + nTrim( VCLIESAI ) , "N" )
      IF Empty( VALPEN )
      VALPEN := 0
      ENDIF

      VALCHQ := selval( "select sum(c.valolote/c.camblote*c.baselote) from " + IF( M->FAT <> "F", "LOTESDOC_CLI", "LOTESDOF_CLI" ) + " c where c.RECLOTE='1000-01-01' and c.is_deleted='N' and c.clielote=" + nTrim( VCLIESAI ) , "N" )

      IF Empty( VALCHQ )
      VALCHQ := 0
      ENDIF


      //AQUI LIMITE
      ENDIF

      IF WNDZ == "S"
      CLI->( RegLock() )
      _FIELD->CLI->SITCLI := "S"
      CLI->( DBCommit() )
      CLI->( DBUnlock() )
      aux := ID( "** Cliente com faturas vencidas   **", "** Clientes con Facturas vencidas **" ) + Chr( 13 ) + Chr( 10 )
      aux += "Vended. : " + nTrim( ven->codven ) + "-" + ven->nomven + Chr( 13 ) + Chr( 10 )
      aux += "Cliente : " + nTrim( cli->codcli ) + "-" + cli->nomcli + Chr( 13 ) + Chr( 10 )
      aux += "Dias perm.:" + nTrim( cli->przcli ) + Chr( 13 ) + Chr( 10 )
      IF M->TOLERPZ=="S"
      aux += "Tolerancia:" + nTrim( cli->tolprz )+" dias" + Chr( 13 ) + Chr( 10 )
      ENDIF
      aux += "Pedido....:" + wnto + Space( 3 ) + "Vencto:" + DToC( wvct ) + Space( 3 ) + "Dias Atz..:" + nTrim( wndi )

      NREGISTRO := 1
      IF ! ped_geral( aux, ID( "Cliente com faturas vencidas ", "Cliente con facturas vencidas" ), SAIDAS_ATZ, M->USUMOM, @nregistro, "OPER_TERM", SaveScreen( 0, 0, m->max_row - 1, m->max_col - 1 ) )
      RETURN .F.
      ENDIF
      TelaSalva()
      SalvaTela( nRegistro,,, "CLI" + AllTrim( Transform( CLI->CODCLI, "9999999" ) ) )
      TelaSalva( "LIMPA" )
      ELSE
      CLI->( RegLock() )
      _FIELD->CLI->SITCLI := " "
      CLI->( DBCommit() )
      CLI->( DBUnlock() )
      ENDIF

      IF WATZ == "S" .AND. M->AVISVCT == "S"
      AL := Alerta( Chr( 2 ) + "   CLIENTE COM NOTAS VENCIDAS;CONSULTE GERENCIA", { "VISUALISAR", "CONTINUAR" }, 2,, 10 )
      IF AL == 1
      Amb := Amb()
      VELIMITE( VCLIESAI, "CLI" )
      Amb( Amb )
      ENDIF

      ENDIF

      DUP->( DBSetOrder( "DUPNUME" ) )

      IF m->WPODE == "S"
      @ Row(), Col() + 10 say tipsim[ 1 ] + "->" + Transform( VSALDO, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) Color "GR+/B"
      ENDIF



      IF M->LIMITGRU == 0 .AND. M->LIMCRE_FI == "N"  // QUANDO FOR LIMITE POR GRUPO - SOMENTE NA FINALIZACAO DA VENDA SERA PEDIDA AUTORIZACAO
      IF VSALDO + VALPEN + VALCHQ > CLI->LIMCLI .OR. ( CLI->LIMCLI == 0 .AND. M->CAXRAP == "S" )
      //aux:="P/Operador:"+ntrim(M->USUMOM)+"-"+ALLTRIM(USUARIO[2])+;
      cDesc := ""
      aux := ID( "** Vender Acima do Limite de Credito **", "** Venta Mayor que Limite de Credito **" ) + Chr( 13 ) + Chr( 10 )
      aux += "Vended. : " + nTrim( ven->codven ) + "-" + ven->nomven + Chr( 13 ) + Chr( 10 )
      aux += "Cliente : " + nTrim( cli->codcli ) + "-" + cli->nomcli + Chr( 13 ) + Chr( 10 )
      aux += "Nr de dias:" + nTrim( VDIAS ) + Chr( 13 ) + Chr( 10 )
      aux += "Limite Credito..:<#7>" + TIPSIM[ 1 ] + Transform( cli->LIMCLI, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + "<#1>" + Chr( 13 ) + Chr( 10 )
      aux += "Vendas nao Fatur:" + TIPSIM[ 1 ] + Transform( VALPEN, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + " Nao Passadas pelo Financeiro" + Chr( 13 ) + Chr( 10 )
      aux += "Divida Atual Chq:" + TIPSIM[ 1 ] + Transform( VALCHQ, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + " A Receber " + Chr( 13 ) + Chr( 10 )
      aux += "Divida Atual Pgr:" + TIPSIM[ 1 ] + Transform( VSALDO, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + " Vda Atual+A Receber " + Chr( 13 ) + Chr( 10 )
      aux += "Div. Final Prev.:<#7>" + TIPSIM[ 1 ] + Transform( VSALDO + VALPEN + VALCHQ, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + "<#1>"

      Alerta( "Cliente excedeu limite de credito !!" )

      cCor := VERM + ",W+/B,W+/BG"

      NREGISTRO := 1
      IF ! ped_geral( aux, ID( "Venda Acima do Limite de Credito", "Ventas Mayor que Limite de Credito" ), IF( M->FAT <> "F", LIMITE_CRE, LIMIT1_CRE ), M->USUMOM, @nregistro, "OPER_TERM", SaveScreen( 0, 0, m->max_row - 1, m->max_col - 1 ), cDesc, cCor )
      RETURN .F.
      ENDIF
      TelaSalva()
      SalvaTela( @nRegistro,,, "CLI" + AllTrim( Transform( CLI->CODCLI, "9999999" ) ) )
      //LOGLIM(NREGISTRO,CLI->LIMCLI,VSALDO,0,"ACIMA LIMITE CREDITO",VDIAS,1)
      TelaSalva( "LIMPA" )
      ENDIF
      ENDIF

      RETURN .T.
     */
}
