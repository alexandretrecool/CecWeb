<?php

session_start();

require_once 'inc/config.php';

$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$codigo = trim(strtoupper(PegaVar("codigo")));
$loja = PegaVar("loja");
$vendedor = PegaVar("vendedor");
if (!$vendedor) {
    $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
}
$modo = PegaVar("modo");
$semsaldo = PegaVar("saldo");
$nserie = pegavar('serie') + 0;

$nvendedor = $vendedor;
$lorc = PegaVar("orcamento") == "true";
$nlojapre = pegavar("lj_preco");

if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}




$nlojapre = pegavar("lj_preco");

require_once 'inc/sid.php';

$nlimiteconsulta = 200;

if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("Erro acessando servidor") . ".\n" . $caux;
    echo json_encode($aret);
    return;
}


if ($modo == "SEG_PITZI_CPF") {
    $ncliente = pegavar("cliente");

    $lCpf = false;
    $lCep = false;
    $lMail = false;

    $cCpf = trim(mysqli_fetch_array(mysqli_query($db, "select cpf from CLIENTE_PGY where is_deleted='N' and codigo='$ncliente'"))[0]);
    if ($cCpf) {
        $lCpf = true;
    } else {
        $cCpf = trim(mysqli_fetch_array(mysqli_query($db, "select cpfcli from CLIENTE_CLI where is_deleted='N' and codcli='$ncliente'"))[0]);
        if ($cCpf) {
            $lCpf = true;
            mysqli_query($db, "update CLIENTE_PGY SET CPF='$cCpf' where codigo='$ncliente'");
        }
    }

    $cCep = trim(mysqli_fetch_array(mysqli_query($db, "select cep from CLIENTE_PGY where is_deleted='N' and codigo='$ncliente'"))[0]);
    if ($cCep) {
        $lCep = true;
    } else {
        $cCep = trim(mysqli_fetch_array(mysqli_query($db, "select cepcli from CLIENTE_CLI where is_deleted='N' and codcli='$ncliente'"))[0]);
        if ($cCep) {
            $lCep = true;
            mysqli_query($db, "update CLIENTE_PGY SET CEP='$cCep' where codigo='$ncliente'");
        }
    }
    $cMail = trim(mysqli_fetch_array(mysqli_query($db, "select email from CLIENTE_PGY where is_deleted='N' and codigo='$ncliente'"))[0]);
    if ($cMail) {
        $lMail = true;
    } else {
        $cMail = trim(mysqli_fetch_array(mysqli_query($db, "select e_mail from CLIENTE_CLI where is_deleted='N' and codcli='$ncliente'"))[0]);
        if ($cMail) {
            $lMail = true;
            mysqli_query($db, "update CLIENTE_PGY SET email='$cMail' where codigo='$ncliente'");
        }
    }

    $aret["cerro"] = "";
    if (!$lCpf) {
        $aret["cerro"] .= "-CPF ausente";
    }
    if (!$lCep) {
        $aret["cerro"] .= "-CEP ausente";
    }
    if (!$lMail) {
        $aret["cerro"] .= "-MAIL ausente";
    }

    if ($aret["cerro"]) {
        $aret["cerro"] = substr($aret["cerro"], 1);
        $aret["erro"] = 10;
    }
    echo json_encode($aret);
    return;
}
if ($modo == "SEG_PITZI") {
    //$aret["cerro"]=pegavar("codigo")."-". pegavar("valor")."-". pegavar("quant")."-". pegavar("cliente")."-". pegavar("loja")."-". pegavar("moeda");
    require_once 'pitzi.php';

    $aret["gar"] = VeGarantiaExtendida(pegavar("codigo"), pegavar("valor"), pegavar("quant"), pegavar("cliente"), pegavar("loja"), pegavar("moeda"));
    echo json_encode($aret);
    return;
}
if ($modo == "SEG_PITZI_REM") {
    //$aret["cerro"]=pegavar("codigo")."-". pegavar("valor")."-". pegavar("quant")."-". pegavar("cliente")."-". pegavar("loja")."-". pegavar("moeda");
    //require_once 'pitzi.php';

    $nproduto = PegaVar("produto");
    $ncliente = PegaVar("cliente");
    $nloja = PegaVar("loja");
    $nmoeda = pegavar("moeda");

    $nvendedor = pegavar("vendedor");
    $nserie = PegaVar("serie");
    $lorc = pegavar("orcamento") == "true";

    $cstr = "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set seg_pitd=0 where serie='$nserie' and vendedor='$vendedor' and codigo='$nproduto'";
    mysqli_query($db, $cstr);
    $cstr = "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where seg_pito=$nproduto and serie='$nserie' and vendedor='$vendedor' ";
    mysqli_query($db, $cstr);

    echo json_encode($aret);
    return;
}
if ($modo == "SEG_PITZI_ADD") {
    //$aret["cerro"]=pegavar("codigo")."-". pegavar("valor")."-". pegavar("quant")."-". pegavar("cliente")."-". pegavar("loja")."-". pegavar("moeda");
    require_once 'pitzi.php';

    $nproduto = PegaVar("produto");
    $nquant = pegavar("quant");
    $ncliente = PegaVar("cliente");
    $nloja = PegaVar("loja");
    $nmoeda = pegavar("moeda");
    $ncodigogar = pegavar("codigogar");
    $nvalor = pegavar("valor");

    $nvendedor = pegavar("vendedor");
    $nserie = PegaVar("serie");
    $lorc = pegavar("orcamento") == "true";

    $agar = VeGarantiaExtendida($nproduto, $nvalor, $nquant, $ncliente, $nloja, $nmoeda);

    foreach ($agar as $value) {
        if ($value["codigo"] == $ncodigogar) {
            $agar = $value;
            break;
        }
    }

    $cstr = "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set seg_pitd=" . $agar["prodcec"] . " where serie='$nserie' and vendedor='$vendedor' and codigo='$nproduto'";
    mysqli_query($db, $cstr);
    $cstr = "insert tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set seg_pito=$nproduto,serie='$nserie',loja='$nloja',vendedor='$vendedor',codigo='" . $agar["prodcec"] . "',quant='$nquant',valor=" . $agar["valgar"];
    mysqli_query($db, $cstr);

    echo json_encode($aret);
    return;
}

if ($modo == "ADD_SEG") {
    $nvalor = pegavar("valor");
    $ncodigo = pegavar("ncodigo");
    $nloja = pegavar("loja");

    $ncod_seg = VeConfigCec("CODSEG_PG");

    $cstr = "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set seg_cod=$ncod_seg where serie='$nserie' and vendedor='$vendedor' and codigo='$ncodigo'";
    //$aret["erro"]=99;
    //$aret["cerro"]="$cstr <br>";
    mysqli_query($db, $cstr);
    $cstr = "insert tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set seg_pro=$ncodigo,serie='$nserie',vendedor='$vendedor',codigo='$ncod_seg',quant=1,valor=$nvalor";
    mysqli_query($db, $cstr);
    //$aret["cerro"].="<br> $cstr <br>";



    echo json_encode($aret);
    return;
}

if ($modo == "REM_SEG") {
    //$nvalor = pegavar("valor");
    $ncodigo = pegavar("ncodigo");
    $nloja = pegavar("loja");

    $ncod_seg = VeConfigCec("CODSEG_PG");

    $cstr = "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where seg_pro=$ncodigo and serie='$nserie' and vendedor='$vendedor' and codigo='$ncod_seg'";
//$aret["cerro"]=$cstr;
    mysqli_query($db, $cstr);
//$aret["cerro"].="<br><br>". mysqli_error($db);
    $cstr = "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set seg_cod=0 where serie='$nserie' and vendedor='$vendedor' and codigo='$ncodigo'";
//$aret["cerro"].="<br><br>". $cstr;
    mysqli_query($db, $cstr);
//$aret["cerro"].="<br><br>". mysqli_error($db);
//    $aret["erro"]=99;

    echo json_encode($aret);
    return;
}






//RESTOCK
$CQUALOC = "l.qualoc";
$INNERQUALOC = "";
if (VeConfigCec("MINMAX") == "S") {
    $CQUALOC = "if(isnull(r.prores) or r.minimo=0 or r.minimo>l.qualoc, l.qualoc, r.minimo ) ";
    $INNERQUALOC = "left join RESTOCK_PRO r on r.is_deleted='N' and r.lojres=l.locloc and r.prores=l.proloc";
}

$olcfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG"));

if ($modo == 77) {
    $nloja = PegaVar("loja");
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar("serie");
    $ncodigo = pegavar("codigo");
    $nquant = pegavar("quant");
    $nvendedor = pegavar("vendedor");

    $lkit = (mysqli_fetch_row(mysqli_query($db, "select kitpro FROM PRODUTO_PRO where is_deleted='N' and codpro=$ncodigo"))[0] == "S");

    if (!$lkit) {
        //$cstr = "select " . ($olcfg["SEMEGER"] == "N" ? "p.estoque" : "sum($CQUALOC)") . " as geral,sum(if(l.locloc=$nloja,$CQUALOC,0)) as loja,p.grupro,p.estoque as estgeral
        $cstr = "select sum($CQUALOC) as geral,sum(if(l.locloc=$nloja,$CQUALOC,0)) as loja,p.grupro,p.estoque as estgeral,gp.vende_neg
from PRODUTO_PRO p
inner join GRUPO_GRU gp on gp.is_deleted='N' and gp.codgru=p.grupro
inner join EMPRESA_EMP c on c.is_deleted='N' and c.codEMP=$nloja
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',',')  )) or l.locloc=$nloja)
$INNERQUALOC    
where p.is_deleted='N' and p.codpro=$ncodigo";
        $otab = mysqli_query($db, $cstr);
        $olin = mysqli_fetch_array($otab);
        if ($olcfg["GRUSES"] == $olin["grupro"] || $olin["vende_neg"] == "S") {
            //if ($olcfg["GRUSES"] == $olin["grupro"]) {
            $aret["loja"] = 9999;
            $aret["geral"] = 9999;
        } else {
            $aret["loja"] = round($olin["loja"]);
            $aret["geral"] = round($olin["geral"]);
        }
    } else {
        //$cstr .= "select " . ($olcfg["SEMEGER"] == "N" ? "p.estoque" : "sum($CQUALOC)") . " as geral,sum(if(l.locloc=$nloja,$CQUALOC,0)) as loja,k.quakit,p.grupro
        $cstr .= "select sum($CQUALOC) as geral,sum(if(l.locloc=$nloja,$CQUALOC,0)) as loja,k.quakit,p.grupro,gp.vende_neg
from PRODUTO_PRO p
inner join GRUPO_GRU gp on gp.is_deleted='N' and gp.codgru=p.grupro
inner join PROKIT_PRO k on k.is_deleted='N' and k.codkit=$ncodigo and k.prokit=p.codpro
inner join EMPRESA_EMP c on c.is_deleted='N' and c.codEMP=$nloja
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',',')  )) or l.locloc=$nloja)
$INNERQUALOC
where p.is_deleted='N' group by p.codpro";
        $otab = mysqli_query($db, $cstr);
        $nsaldo = 9999999999;
        while ($olin = mysqli_fetch_array($otab)) {
            $nquant = $olin["loja"] / $olin["quakit"];
            $nquantt = $olin["geral"] / $olin["quakit"];
            if ($nquant < $nsaldo) {
                $aret["loja"] = round($nquant);
                $aret["geral"] = round($nquantt);
            }
            $nsaldo = $nquant;

            if ($olcfg["GRUSES"] == $olin["grupro"] || $olin["vende_neg"] == "S") {
//            if ($olcfg["GRUSES"] == $olin["grupro"]) {
                $aret["loja"] = 9999;
                $aret["geral"] = 9999;
                $nsaldo = 9999;
            }
        }
    }
   
    echo json_encode($aret);
    return;
}

if ($modo == 71) {
    $npromo = pegavar("promo");
    $ncodigo = pegavar("codigo");
    $nloja = pegavar("loja");

    $cstr = "select gq.perqua1,gq.perqua2,gq.perqua3,gq.perqua4,gq.perqua5,gq.perqua6,gq.perqua7,gq.perqua8
,gq.perqua9,gq.perqua10,gq.perqua11,gq.perqua12,gq.perqm10 as perqua13
,concat(if(gq.marca>0  ,'/MARCA','') 
  ,if(gq.grupo>0    ,'/GRUPO','') 
  ,if(gq.sgrupo>0   ,'/SUBGRUPO' ,'') 
  ,if(gq.produto>0  ,'/PRODUTO' ,'') 
  ,if(gq.gruesp>0  ,'/GRPESP' ,'') 
) as nome ";

    if (!$nlojapre) {
        $cstr .= " ,if(gp.tipogpm=1,p.preven,if(gp.tipogpm=2,p.preco3,if(gp.tipogpm=3,p.premin,p.preatac))) as tabela
from PRODUTO_PRO p , GRUPROMO_GPM gp ";
    } else {
        $cstr .= " ,if(gp.tipogpm=1,if(isnull(lc.proloc) or lc.preven=0,p.preven,lc.preven) ,if(gp.tipogpm=2,if(isnull(lc.preco3) or lc.preco3=0,p.preco3,lc.preco3),if(gp.tipogpm=3,if(isnull(lc.proloc) or lc.premin=0,p.premin,lc.premin),if(isnull(lc.proloc) or lc.preatac=0,p.preatac,lc.preatac)))) as tabela
from PRODUTO_PRO p , GRUPROMO_GPM gp 
left join LOCAL_LOC lc on lc.is_deleted='N' and lc.locloc=$nlojapre and proloc=p.codpro";
    }
    $cstr .= " inner join PROMOQUA_PRO gq on gq.is_deleted='N' and gq.grugpm=gp.codgpm

where p.is_deleted='N' and p.codpro=$ncodigo and gp.codgpm=$npromo

and gp.is_deleted='N' and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set($nloja,replace(gp.excljgpm,'-',','))
and 
(     if(gq.grupo>0  ,gq.grupo  =p.grupro ,1) 
  and if(gq.marca>0  ,gq.marca  =p.marcpro,1) 
  and if(gq.produto>0,gq.produto=p.codpro ,1) 
  and if(gq.sgrupo>0 ,gq.sgrupo =p.sgrupro,1) 
  and if(gq.gruesp>0 ,gq.gruesp =p.gruesp,1) 
)
and p.kitpro!='S'
";
    $otab = mysqli_query($db, $cstr);
    $aret["cerro"] = mysqli_error($db);
    $olin = mysqli_fetch_array($otab);
    $aret["tabela"] = $olin["tabela"];
    for ($i = 1; $i <= 13; $i++) {
        $aret["p$i"] = $olin["tabela"] * (1 - ($olin["perqua$i"] / 100));
    }


    echo json_encode($aret);
    return;
}


if ($modo == 61 || $modo == "VE_GRADE") {
    $codigo = pegavar("codigo");
    $lorc = (pegavar("orcamento") == "true");
    $nserie = pegavar('serie') + 0;
    $cstr = "select 
p.codpro as codigo        
,g.lojgrade as loja,l.nomemp as cloja
,g1.tipogrd as val1
,if(g.seqgrade1=g.seqgrade2,'',g2.tipogrd) as val2
,g.estoque,g.fpgloc as falta
,g.seqgrade1 as seq1,g.seqgrade2 as seq2,p.blocopro
";

    $cSql = "select if(f.PERAUM_TJ=0 or t.nacional!=1 or c.regicli!='',0,f.PERAUM_TJ) AS indice from CLIENTE_CLI c 
        inner join tablet" . $lweb . "_cab t on t.vendedor=$nvendedor and t.serie=$nserie and if(t.cliente=0,9999999999,t.cliente)=c.codcli
        inner join CONFIG f on f.recno=1
        where c.is_deleted='N' AND c.codcli!=0
            ";
    /*
      $cSql = "select if(f.PERAUM_TJ=0 or c.PAISCLI!=1 or c.regicli!='',0,f.PERAUM_TJ) AS indice from CLIENTE_CLI c
      inner join tablet".$lweb."_cab t on t.vendedor=$nvendedor and t.serie=$nserie and t.cliente=c.codcli
      inner join CONFIG f on f.recno=1
      where c.is_deleted='N' AND c.codcli!=0
      ";

     */

    $nindex = mysqli_fetch_row(mysqli_query($db, $cSql))[0];

    //ver se é contribuinte
    $csql = "select natureza from CLIENTE_PGY c 
    inner join tablet" . $lweb . "_cab t on t.vendedor=$nvendedor and t.serie=$nserie and if(t.cliente=0,9999999999,t.cliente)=c.codigo
        where c.is_deleted='N' AND c.codigo!=0
        ";
    $ocontrib = mysqli_fetch_array(mysqli_query($db, $csql));
    if ($ocontrib && $ocontrib[0] == 1) {
        $nindex = "";
    }
    if ($nindex > 0) {
        $nindex = "*" . (1 + ($nindex / 100));
    } else {
        $nindex = "";
    }


    if (!$nlojapre) {
        $cstr .= "
            ,p.preven$nindex  as venda
            ,p.premin$nindex  as minimo
            ,p.preven$nindex  as precoa
            ,p.preco3$nindex  as precob
            ,p.premin$nindex  as precoc
            ,p.preatac$nindex as precot


from ESTLJGRA_PRO g
inner join PRODUTO_PRO p on p.is_deleted='N' and  p.codpro=g.prograde
";
    } else {
        //if(isnull(lc.proloc) or lc.preven=0,p.preven,lc.preven)    
        $cstr .= " 
        ,if(isnull(lc.proloc) or lc.preven=0,p.preven,lc.preven)  as venda
        ,if(isnull(lc.proloc) or lc.premin=0,p.premin,lc.premin)  as minimo
        ,if(isnull(lc.proloc) or lc.preven=0,p.preven,lc.preven)  as precoa
        ,if(isnull(lc.proloc) or lc.preco3=0,p.preco3,lc.preco3)  as precob
        ,if(isnull(lc.proloc) or lc.premin=0,p.premin,lc.premin)  as precoc
        ,if(isnull(lc.proloc) or lc.preatac=0,p.preatac,lc.preatac) as precot
    
from ESTLJGRA_PRO g
inner join PRODUTO_PRO p on p.is_deleted='N' and  p.codpro=g.prograde 
left join LOCAL_LOC lc on lc.is_deleted='N' and lc.locloc=$nlojapre and lc.proloc=p.codpro ";
    }
    $cstr .= " inner join EMPRESA_EMP l on l.is_deleted='N' and l.codemp=g.lojgrade
inner join GRADESEQ_PRO g1 on g1.recno=g.seqgrade1
inner join GRADESEQ_PRO g2 on g2.recno=g.seqgrade2
where g.is_deleted='N' 
and g.prograde=$codigo
and g.estoque>0
order by val1,val2,g.lojgrade";
    $otab = mysqli_query($db, "select loja,cloja from ($cstr) l group by loja");
    $alojas = array();
    $cstr1 = "select val1,val2,seq1,seq2,minimo,venda ";

    $aretc = array('', '');
    while ($olin = mysqli_fetch_array($otab)) {
        $alojas[$olin["loja"]] = array($olin["loja"], $olin["cloja"]);
        $cstr1 .= ",sum(if(loja='" . $olin["loja"] . "',estoque,0)) as s" . $olin["loja"];
        $cstr1 .= ",sum(if(loja='" . $olin["loja"] . "',falta,0))   as p" . $olin["loja"];
        $aretc[] = "Loja " . $olin["loja"];
    }
    $cstr1 .= " from ( $cstr ) l group by val1,val2 order by val1,val2 ";

    $otab = mysqli_query($db, $cstr1);
    $aretp = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $aaux = array($olin["val1"], $olin["val2"], $olin["seq1"], $olin["seq2"], $olin["minimo"], $olin["venda"]);
        $otabtem = mysqli_query($db, "select quant from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor and codigo=$codigo and seq1='" . $olin["val1"] . "' and seq2='" . $olin["val2"] . "'");
        $aaux[] = mysqli_num_rows($otabtem);
        foreach ($alojas as $key => $value) {
            $nsal = round($olin["s" . $key], 0);
            $npen = round($olin["p" . $key], 0);
            $aaux[] = ($nsal ? $nsal : "") . ($npen ? "/$npen" : "");
        }
        $aretp[] = $aaux;
    }
    $olinpro = mysqli_fetch_array(mysqli_query($db, "select if(nomelong='',nompro,nomelong) as nompro,gradepro,blocopro from PRODUTO_PRO where is_deleted='N' and codpro=$codigo"));
    $aret["nome"] = limpachar($olinpro[0]);
    $aaux = explode("-", $olinpro[1]);
    if (trim($aaux[0])) {
        $aretc[0] = mysqli_fetch_row(mysqli_query($db, "select nomgrade from GRADE_PRO where is_deleted='N' and codgrade=" . $aaux[0]))[0];
    }
    if (trim($aaux[1])) {
        $aretc[1] = mysqli_fetch_row(mysqli_query($db, "select nomgrade from GRADE_PRO where is_deleted='N' and codgrade=" . $aaux[1]))[0];
    }
    //$aretc[1]=$aaux[1];
    $aret["cab"] = $aretc;
    $aret["pro"] = $aretp;
    $aret["blocopro"] = $olinpro["blocopro"];
    echo json_encode($aret);
    return;
}

if ($modo == 62) {
    $codigo = pegavar("codigo");
    $cstr = "
select p.codpro as codigo,if(p.nomelong='',p.nompro,p.nomelong) as nome,sum(if(isnull(l.locloc) or l.locloc!=$loja,0,
    $CQUALOC
    )) as saldo,sum(if(isnull(l.locloc) or l.locloc!=$loja,0,l.fpgloc)) as psaldo,sum(if(isnull(l.locloc),0,
        $CQUALOC
        )) as saldot,sum(if(isnull(l.locloc),0,l.fpgloc)) as psaldot,k.quakit
from PROKIT_PRO k 
inner join PRODUTO_PRO p on p.is_deleted='N' and k.prokit=p.codpro
inner join EMPRESA_EMP c on c.is_deleted='N' and c.codEMP=$loja
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',',')  )) or l.locloc=$loja)
$INNERQUALOC
where k.is_deleted='N' and k.codkit=$codigo
group by k.prokit
";
    $otab = mysqli_query($db, $cstr);
    $aretp = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $aretp[] = $olin;
    }
    $olinpro = mysqli_fetch_array(mysqli_query($db, "select if(nomelong='',nompro,nomelong) as nome from PRODUTO_PRO where is_deleted='N' and codpro=$codigo"));
    $aret["nome"] = LimpaChar($olinpro[0]);

    $aret["pro"] = $aretp;
    echo json_encode($aret);
    return;
}

if ($modo == 63) {
    /*
      $cstr = "
      select c.codcli,c.nomcli,d.recno,concat(date_format(d.datasai,'%d/%m'),'<br>',left(d.horasai,5)) as datasai,d.quansai,d.valosai,d.moeda
      from SAIDAS_SAI d
      inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=d.cliesai AND c.codcli!=0
      where d.is_deleted='N' and d.sitsai!='S' and d.datasai>=date_sub(current_date,interval 2 day)
      and d.lojasai=$loja and d.opesai=$vendedor
      " . (pegavar("cliente") ? " and d.cliesai=" . pegavar("cliente") : "") . " order by d.recno desc";
     * 
     */
    $cstr = "
        select c.codcli,c.nomcli,d.recno,concat(date_format(d.datasai,'%d/%m'),'<br>',left(d.horasai,5)) as datasai,d.quansai,d.valosai,d.moeda
        from SAIDAS_SAI d
        inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=d.cliesai AND c.codcli!=0
        where d.is_deleted='N' and d.sitsai!='S' and d.datasai>=date_sub(current_date,interval 2 day)
        and d.lojasai=$loja " . (PegaVar("venalteracliente") ? "" : " and d.vendsai=$vendedor " )
            . (pegavar("cliente") ? " and d.cliesai=" . pegavar("cliente") : "") . " order by d.recno desc";

    $otab = mysqli_query($db, $cstr);

    $aretn = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $olin["nomcli"] = LimpaChar($olin["nomcli"]);
        $aretn[] = $olin;
    }
    $aret["not"] = $aretn;
    $aret["erro"] = 1;
    $aret["cerro"] = mysqli_error($db);
    echo json_encode($cstr);
    return;
}

if ($modo == 18) {

    $cstr .= "select l.locloc as codigo,e.nomemp as nome,l.qualoc as saldo,l.fpgloc as falta from ( select l.locloc,$CQUALOC as qualoc,l.fpgloc 
from PRODUTO_PRO p
inner join EMPRESA_EMP c on c.is_deleted='N' and c.codEMP=$loja
inner join CONFIG cf on cf.recno=1
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',',')  )) or l.locloc=$loja)
$INNERQUALOC
where p.is_deleted='N' and p.codpro=$codigo
             group by l.locloc) l
            inner join EMPRESA_EMP e on e.is_deleted='N' and e.codemp=l.locloc
            where (l.qualoc!=0 or l.fpgloc!=0)
            ";
    $otab = mysqli_query($db, $cstr);
    $nsize = ".9";
    $corpo = '<table class="table trable-bordered" style="font-size: ' . $nsize . 'em"><tr><th>' . _tr('Loja') . '</th><th  class="text-right">' . _tr('Saldo') . '</th><th  class="text-right">' . _tr('Pend') . '.</th></tr>';
    $nqua = 0;
    $npen = 0;
    while ($olin = mysqli_fetch_array($otab)) {
        $nqua += $olin["saldo"];
        $npen += $olin["falta"];
        $corpo .= "<tr><td>" . $olin["codigo"] . "-" . $olin["nome"] . '</td><td class="text-right">' . my_number_format($olin["saldo"], 0) . '</td><td class="text-right">' . my_number_format($olin["falta"], 0) . "</td></tr>";
    }
    $corpo .= '<tr><th class="text-right">' . _tr('Total') . ':</th><th class="text-right">' . my_number_format($nqua, 0) . '</th><th class="text-right">' . my_number_format($npen, 0) . "</th></tr>";

//    $olocal=mysqli_fetch_row(mysqli_query($db,"select corredor,pratelera,box FROM LOCALIZA_PRO WHERE IS_DELETED='N' AND PROLCZ=$codigo and (loja=0 or loja=".pegavar("loja").") order by loja desc " ));
    $olocal = mysqli_fetch_row(mysqli_query($db, "select corredor,pratelera,box FROM LOCALIZA_PRO WHERE IS_DELETED='N' AND PROLCZ=$codigo order by loja desc "));
    if ($olocal) {
        $corpo .= '<tr><th class="text-right">Local:</th><td colspan="2" class="text-left">' . trim($olocal[0]) . "-" . trim($olocal[1]) . "-" . trim($olocal[2]) . '</td></tr>';
    }

    $corpo .= "</table>";
    $aret["corpo"] = $corpo;
    echo json_encode($aret);
    return;
}


if ($modo == "CONSULTA_PRO" || $modo == 1) {
    /*
    $lfulltext = true;
    $lpromo = pegavar("promo");
    if (pegavar("exato")) {
        $lfulltext = false;
    }
     * 
     */
    $lfulltext=PegaVar("ckcodigo")=="DA";
    if (!$loja || $loja == 0) {
        $loja = 1;
    }
    $ncodigo = pegavar("ncodigo");
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar('serie') + 0;
    if (!$codigo && !$ncodigo) {
        $aret["tabela"] = '';
        echo json_encode($aret);
        return;
    }

    //leitura do qrcode
    if (strlen($codigo) == 8 && substr($codigo, 0, 1) == "*" && substr($codigo, -1) == "*") {
        $cetq = substr($codigo, 1);
        $cetq = substr($cetq, 0, strlen($cetq) - 1);
        $otabetq = mysqli_query($db, "select proetq as codigo from LOCALETQ_PRO WHERE IS_DELETED='N' AND REFER='$cetq'");
        if (mysqli_num_rows($otabetq) == 0) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Etiqueta não localizada");
            echo json_encode($aret);
            return;
        }
        $ncodigo = mysqli_fetch_row($otabetq)[0];
    }
    if (!pegavar("altera")) {
        $olint = mysqli_fetch_array(mysqli_query($db, "select count(*) as total from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor='$vendedor' and codigo='$codigo'"));
        if ($olint[0] > 0) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Produto já lançado nesta Venda");
            echo json_encode($aret);
            return;
        }
    }
    //grade
    //1216943-1031-1032
    IF (PegaVar("ckcodigo") !== "R") {
        $aret["grade"] = 0;
        $aaux = explode("-", $codigo);
        $lgrade1 = '';
        $lgrade2 = '';
        if (count($aaux) > 1) {
            $lgrade1 = $aaux[1] > 0;
        }
        if (count($aaux) > 2) {
            $lgrade2 = $aaux[2] > 0;
        }
        if ($lgrade1 || $lgrade2) {
            if ($lgrade1) {
                $ncodigo = $aaux[0];
                if (!vedigito($ncodigo)) {
                    $aret["erro"] = "99";
                    $aret["cerro"] = _tr("Código inválido na grade") . " . $ncodigo";
                    echo json_encode($aret);
                    return;
                }
                $nseq1 = $aaux[1];
                $nseq2 = $aaux[2];
            } else {
                $ncodigo = $aaux[0];
                if (!vedigito($ncodigo)) {
                    $aret["erro"] = "99";
                    $aret["cerro"] = _tr("Código inválido na grade") . " . $ncodigo";
                    echo json_encode($aret);
                    return;
                }
                $nseq1 = $aaux[1];
                $nseq2 = $aaux[2];
            }
        } else {
            $lgrade1 = (strlen($codigo) == 17 && substr($codigo, 0, 1) == "#" && substr($codigo, -1) == "#");
            $lgrade2 = ( strlen($codigo) == 17 && substr($codigo, 7, 1) == "-" && substr($codigo, 12, 1) == "-" );

            if ($lgrade1 || $lgrade2) {
                if ($lgrade1) {
                    $ncodigo = substr($codigo, 1, 9);
                    if (!vedigito($ncodigo)) {
                        $aret["erro"] = "99";
                        $aret["cerro"] = _tr("Código inválido na grade") . " . $ncodigo";
                        echo json_encode($aret);
                        return;
                    }
                    $nseq1 = substr($codigo, 1 + 9, 3);
                    $nseq2 = substr($codigo, 1 + 9 + 3, 3);
                } else {
                    $ncodigo = substr($codigo, 0, 7);
                    if (!vedigito($ncodigo)) {
                        $aret["erro"] = "99";
                        $aret["cerro"] = _tr("Código inválido na grade") . " . $ncodigo";
                        echo json_encode($aret);
                        return;
                    }
                    $nseq1 = substr($codigo, 8, 4);
                    $nseq2 = substr($codigo, 13, 4);
                }
            }
        }
    }

    if ($lgrade1 || $lgrade2) {
        $ncodigo = tiradigito($ncodigo);
        $cstr2 = "select sum(estoque) as saldot,sum(if(loja='$loja',estoque,0)) as saldo,val1,val2 from (
            select 
            g.lojgrade as loja,l.nomemp as cloja
            ,g1.tipogrd as val1
            ,if(g.seqgrade1=g.seqgrade2,'',g2.tipogrd) as val2
            ,g.estoque,g.fpgloc as falta
            from ESTLJGRA_PRO g
            inner join EMPRESA_EMP l on l.is_deleted='N' and l.codemp=g.lojgrade
            inner join GRADESEQ_PRO g1 on g1.recno=g.seqgrade1
            inner join GRADESEQ_PRO g2 on g2.recno=g.seqgrade2
            where g.is_deleted='N' 
            and g.prograde=$ncodigo
            and g.seqgrade1='$nseq1'
            and g.seqgrade2='$nseq2'
            and g.estoque>0
            order by val1,val2,g.lojgrade
            ) l"
        ;
        $otab = mysqli_query($db, $cstr2);
        $olin = mysqli_fetch_row($otab);
        if (mysqli_num_rows($otab) == 0 || $olin[0] == 0) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("GRADE Inválida ou sem saldo");
            echo json_encode($aret);
            return;
        }
        $aret["grade"] = 1;
        $aret["seq1"] = $nseq1;
        $aret["seq2"] = $nseq2;
        $aret["codigo"] = $ncodigo;
        $aret["gsaldo"] = $olin[1];
        $aret["gsaldot"] = $olin[0];
        $aret["val1"] = $olin[2];
        $aret["val2"] = $olin[3];
    }

    $acodigos = explode(" ", $codigo);
    $cstr = "";
//    $cstr .= "select p.*,if(isnull(gp1.codgpm),0,gp1.codgpm) as proquant from ( ";
    $cstr .= "select p.*,if(isnull(gq.grugpm),0,gq.grugpm) as proquant from ( ";
    $cstr .= "select * from ( ";
    /*
      IF VQUATPO>PRO->MAXIQVEN .AND. (M->MAXIQVDA=="S" .OR. pro->promo_p="S") .AND. pro->maxiqven>0

      aux       := "* Venda acima da quantidade Maxima Permitida *"+chr(13)+chr(10)
      aux       += "Pedido. : "+ntrim(tmp1->notatemp)+space(5)+dtoc(tmp1->datatemp)+chr(13)+chr(10)
      aux       += "Cliente : "+ntrim(tmp1->clietemp)+"-"+cli->nomcli+chr(13)+chr(10)
      aux       += "Vended. : "+ntrim(tmp1->vendtemp)+"-"+ven->nomven+chr(13)+chr(10)
      aux       += "Produto : "+transform(POE_DIGITO(vcodtpo),"@R 99999999-9")+space(2)+pro->nompro+chr(13)+chr(10)
      aux       += "Quant...:"+transform(vquatpo,"999999")+space(2)+"Quant Maxima:"+transform(pro->maxiqven,"999999")
      NREGISTRO := 1

      TelaSalva()
      if !ped_geral(aux,"Venda acima da quantidade maxima permitida",SAIDAS_MAQ,M->USUMOM,@NREGISTRO,"OPER_TERM",savescreen(0,0,24,79))
      TELASALVA("LIMPA")
      return .F.
      endif

      SalvaTela(nRegistro,,,"PRQMX"+ALLTRIM(TRANSFORM(PRO->CODPRO,"999999")+STR(DIGITO(PRO->CODPRO),1)))
      TELASALVA("LIMPA")

      ENDIF
     */
    $cstr .= "select
 p.codpro as codigo
,IF(p.maxiqven=0,999999,p.maxiqven) as quantmax
,if(p.nomelong='',p.nompro,p.nomelong) as nome
";
//,if(cf.maxiqvda!='S' or p.promo_p!='S' or p.maxiqven=0,9999999,p.maxiqven) as quantmax
    // $olcfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG"));
    $olistcli = mysqli_fetch_array(mysqli_query($db, "select c.listcli,t.loja from CLIENTE_CLI c 
        inner join  tablet" . $lweb . "_cab t on t.serie='$nserie' and t.vendedor=$vendedor and if(t.cliente=0,9999999999,t.cliente)=c.codcli
        where c.is_deleted='N' AND c.codcli!=0"));

    $clistcli = $olistcli[0];
    if ($olcfg["LISABCCL"] != 'S') {
        $clistcli = '';
    }
    if ($nlojapre) {
        $nloja_precos = $nlojapre;
    } else {
        $nloja_precos = $olistcli[1];
    }

    /*
      $nindex=1+($olcfg["PERAUM_TJ"]/100);
      if ($nindex>1){
      $nindex="*".$nindex;
      }else{
      $nindex="";
      }
     */
    $nindex = "";
    $acli = mysqli_fetch_row(mysqli_query($db, "select nacional,cliente from tablet" . $lweb . "_cab t where t.vendedor=$nvendedor and t.serie=$nserie"));
    /*
      $aret["erro"]="99";
      $aret['cerro']=var_export($acli,true);
      echo json_encode($aret);
      return;
     */
    if ($olcfg["PERAUM_TJ"] > 0 && $acli[0] == 1) {
        $nindex = "*" . (1 + ($olcfg["PERAUM_TJ"] / 100));
        if ($acli[1] && mysqli_num_rows(mysqli_query($db, "select regicli from CLIENTE_CLI where is_deleted='N' and regicli!='' AND codcli=" . $acli[1])) > 0) {
            $nindex = "";
        }
        //ver se é contribuinte
        $csql = "select natureza from CLIENTE_PGY c 
    inner join tablet" . $lweb . "_cab t on t.vendedor=$nvendedor and t.serie=$nserie and if(t.cliente=0,9999999999,t.cliente)=c.codigo
        where c.is_deleted='N' AND c.codigo!=0
        ";
        $ocontrib = mysqli_fetch_array(mysqli_query($db, $csql));
        if ($ocontrib && $ocontrib[0] == 1) {
            $nindex = "";
        }
    }

    $lcontribuinte = mysqli_fetch_row(mysqli_query($db, "select c.natureza=1 and f.num_nfcfg=6 as contrib from CLIENTE_PGY c 
    inner join tablet" . $lweb . "_cab t on t.vendedor=$nvendedor and t.serie=$nserie and if(t.cliente=0,9999999999,t.cliente)=c.codigo
        inner join CONFIG f on f.recno=1
        where c.is_deleted='N' AND c.codigo!=0
        "))[0];
    if ($nindex || $lcontribuinte) {
        $cprecoa = "preven$nindex";
        $cprecob = "preven$nindex";
        $cprecoc = "preven$nindex";
        $cprecot = "preven$nindex";
    } else {
        $cprecoa = "preven$nindex";
        $cprecob = "preco3$nindex";
        $cprecoc = "premin$nindex";
        $cprecot = "preatac$nindex";
    }
    $cpreven = $cprecoa;
    $cpremin = $cprecoc;
    if ($clistcli == "A") {
        $cpreven = $cprecoa;
        $cpremin = $cprecoa;
    } else if ($clistcli == "B") {
        $cpreven = $cprecob;
        $cpremin = $cprecob;
    } else if ($clistcli == "C") {
        $cpreven = $cprecoc;
        $cpremin = $cprecoc;
    } else if ($clistcli == "D") {
        $cpreven = $cprecot;
        $cpremin = $cprecot;
    }



    if (!$nlojapre) {
        //,if(cf.MODPEDI=556,p.$cpreven,p.$cpremin) as minimo
        //,if(cf.NUM_NFCFG=6 AND !ISNULL(cly.codigo) and cly.natureza=1,p.$cpreven  ,  if(cf.MODPEDI=556,p.$cpreven,p.$cpremin)) as minimo
        $cstr .= " 
            ,if(cf.MODPEDI=556,p.$cpreven,p.$cpremin) as minimo
            ,p.$cpreven as venda
            ,p.$cprecoa as precoa
            ,p.$cprecob as precob
            ,if(cf.modpedi=556,p.$cpreven,p.$cprecoc) as precoc
            ,if(cf.modpedi=556,p.$cpreven,p.$cprecot) as precot ";
    } else {
        //,if(cf.modpedi=556,if(isnull(lc.proloc) or lc.$cpreven=0,p.$cpreven,lc.$cpreven),if(isnull(lc.proloc) or lc.$cpremin=0,p.$cpremin,lc.$cpremin)) as minimo
        //    ,if(cf.NUM_NFCFG=6 AND !ISNULL(cly.codigo) and cly.natureza=1,      if(isnull(lc.proloc) or lc.$cpreven=0,p.$cpreven,lc.$cpreven)  ,   if(cf.modpedi=556,if(isnull(lc.proloc) or lc.$cpreven=0,p.$cpreven,lc.$cpreven),if(isnull(lc.proloc) or lc.$cpremin=0,p.$cpremin,lc.$cpremin))) as minimo
        $cstr .= " 
            ,if(cf.modpedi=556,if(isnull(lc.proloc) or lc.$cpreven=0,p.$cpreven,lc.$cpreven),if(isnull(lc.proloc) or lc.$cpremin=0,p.$cpremin,lc.$cpremin)) as minimo
            ,if(isnull(lc.proloc) or lc.$cpreven=0,p.$cpreven,lc.$cpreven) as venda
            ,if(isnull(lc.proloc) or lc.$cprecoa=0,p.$cprecoa,lc.$cprecoa) as precoa
            ,if(isnull(lc.proloc) or lc.$cprecob=0,p.$cprecob,lc.$cprecob) as precob
            ,if(cf.modpedi=556,if(isnull(lc.proloc) or lc.$cprecoa=0,p.$cprecoa,lc.$cprecoa),if(isnull(lc.proloc) or lc.$cprecoc=0,p.$cprecoc,lc.$cprecoc)) as precoc
            ,if(cf.modpedi=556,if(isnull(lc.proloc) or lc.$cprecoa=0,p.$cprecoa,lc.$cprecoa),if(isnull(lc.proloc) or lc.$cprecot=0,p.$cprecot,lc.$cprecot)) as precot ";
    }

    $cstr .= " ,p.grupro,p.sgrupro,p.marcpro,p.gruesp
,if(isnull(w.codigo),0,w.nimagem) as nimagem
,if(isnull(w.codigo) or w.nomeweb='' ,0,1) as detalhe
,sum(if(isnull(l.locloc) or l.locloc!=$loja,0,$CQUALOC)) as saldo
,sum(if(isnull(l.locloc) or l.locloc!=$loja,0,l.fpgloc)) as psaldo
,sum(if(isnull(l.locloc),0,$CQUALOC)) as saldot
,sum(if(isnull(l.locloc),0,l.fpgloc)) as psaldot
,if(isnull(t.codigo),0,1) as ltem
,p.gradepro as gradepro
,if(p.promo_p='S' and p.preco5>0 and cf.regra_prm='S' and !isnull(gp.codgpm) ,p.preco5,0) as preco5
,p.codpromo
,p.kitpro
,p.corpro
,if((p.estoque<0 AND cf.CORNEG='S') or (p.estoque<p.estomin AND p.ESTOMIN<>0),9
   ,IF(p.MTJPRO='S' OR p.KITPRO='S',7
   ,IF(p.CORPRO=2 and p.promo_p<>'S',3
   ,IF(p.CORPRO=3 and p.promo_p<>'S',4
   ,IF(p.CORPRO=4 and p.promo_p<>'S',8
   ,if(p.decreto='N' and cf.connot='S' and cf.cadcli1='N' and p.promo_p<>'S',6
   ,if(p.CORPRO=5 and p.promo_p<>'S',18
   ,if(p.corpro=6 and p.promo_p<>'S',15
   ,IF(p.corpro=7 and p.promo_p<>'S',16
   ,if(p.corpro=8 and p.promo_p<>'S',21
   ,if(p.promo_p='S',19
   ,1))))))))))) as corpro1
   
,if(!isnull(cl.codcli) and cl.codcli!=0, 1+(if(cf.ivamas='N' or (p.decreto!='S' or (tc.nacional=2 OR (cl.regicli!='' and cl.vencto_reg>=current_date))),0,p.iva )/100),
 1+(if(cf.ivamas='N' or (p.decreto!='S' or (tc.nacional='2')),0,p.iva )/100)  ) as iva
,if(p.cusmed=0,p.ultcus,p.cusmed)$nindex as custo
,p.ativo,convert(p.refer,char) as refer,p.blocopro,gg.vende_neg ";
    if ($lfulltext) {
        $cstr .= ", MATCH(nomelong) AGAINST ('" . implode(" ", $acodigos) . "') AS ranking ";
    }
    $cstr .= " from PRODUTO_PRO p 
        inner join GRUPO_GRU gg on gg.is_deleted='N' and gg.codgru=p.grupro
        ";

    if ($nlojapre) {
        $cstr .= " left join LOCAL_LOC lc on lc.is_deleted='N' and lc.locloc=$nlojapre and lc.proloc=p.codpro ";
    }
    $cstr .= " inner join EMPRESA_EMP c on c.is_deleted='N' and c.codEMP=$loja
inner join CONFIG cf on cf.recno=1
left join PRODUTOS_WEB w on w.is_deleted='N' and w.codigo=p.codpro
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',',')  )) or l.locloc=$loja)
$INNERQUALOC
left join tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro t on t.vendedor=$vendedor and t.codigo=p.codpro and t.serie='$nserie'
left join GRUPROMO_GPM gp on gp.is_deleted='N' and p.codpromo=gp.codgpm and !find_in_set($loja,replace(gp.excljgpm,'-',',') ) and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' 

left join tablet" . $lweb . "_cab tc on tc.vendedor=$vendedor and tc.serie='$nserie'
left join CLIENTE_CLI cl on cl.is_deleted='N' and cl.codcli=if(tc.cliente=0,9999999999,tc.cliente) AND cl.codcli!=0

where p.is_deleted='N' ";
//left join CLIENTE_PGY cly on cly.is_deleted='N' and cly.codigo=cl.codcli
    //garantia
    if (mysqli_num_rows(mysqli_query($db, "show tables like 'GARANTIA_GAR'")) > 0) {
        $cgar = "select PRODCEC FROM GARANTIA_GAR WHERE IS_DELETED='N' ";
        $otgar = mysqli_query($db, $cgar);
        if (mysqli_num_rows($otgar) > 0) {
            $caux = "";
            while ($olgar = mysqli_fetch_row($otgar)) {
                $caux .= "," . $olgar[0];
            }
            $cstr .= " and p.codpro not in (" . substr($caux, 1) . ") ";
        }
    }

    if ($ncodigo) {
        $cstr .= " and p.codpro=$ncodigo";
        $cstr .= ' group by p.codpro ) p ';
        $cstr .= " where if(p.ativo='N',if(p.saldo>0,1,0),1) ";
    } else if (PegaVar("ckcodigo") == "C") {
        if (!vedigito(PegaVar("codigo"))) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Digito verificador inválido");
            echo json_encode($aret);
            return;
        }
        $cstr .= " and (p.codpro=" . tiradigito(pegavar("codigo"));
        $cstr .= " or p.barra=" . pegavar("codigo");
        $cstr .= ') group by p.codpro ) p ';
        $cstr .= " where if(p.ativo='N',if(p.saldo>0,1,0),1) ";
    } else if (PegaVar("ckcodigo") == "R") {
        $cstr .= " and (p.refer LIKE '" . trim(strtoupper(pegavar("codigo"))) . "%'";
        $cstr .= ') group by p.codpro ) p ';
    } else if (PegaVar("ckcodigo") == "DA") {
        if (!$lfulltext) { 
            foreach ($acodigos as $value) {
                $cstr .= " and (0 ";
                $caux = str_replace(range(0, 9), "", $value);
                if (strlen($caux) == 0) {
                    $cstr .= " or p.codpro='$value' or p.barra='$value' ";
                }
                $cstr .= " or p.nomelong like '%$value%' ";
                $cstr .= ") ";
            }
        } else {
            $cstr .= " and     MATCH(nomelong) AGAINST ('" . implode(" ", $acodigos) . "')";
        }
        $cstr .= " group by p.codpro) p ";
        if ($semsaldo !== "true") {
            $cstr .= " where p.saldo>0 or p.saldot>0 or p.grupro=" . $olcfg["GRUSES"] . " or p.vende_neg='S' or p.kitpro='S'";
        } else {
            $cstr .= " where if(p.ativo='N',if(p.saldo>0,1,0),1) ";
        }
    } else if (PegaVar("ckcodigo") == "DC") {
        foreach ($acodigos as $value) {
            $cstr .= " and (0 ";
            $caux = str_replace(range(0, 9), "", $value);
            if (strlen($caux) == 0) {
                $cstr .= " or p.codpro='$value' or p.barra='$value' ";
            }
            $cstr .= " or p.nomelong like '%$value%' ";
            $cstr .= ") ";
        }
        $cstr .= " group by p.codpro) p ";
        if ($semsaldo !== "true") {
            $cstr .= " where p.saldo>0 or p.saldot>0 or p.grupro=" . $olcfg["GRUSES"] . " or p.vende_neg='S' or p.kitpro='S'";
        } else {
            $cstr .= " where if(p.ativo='N',if(p.saldo>0,1,0),1) ";
        }
    } else if (PegaVar("ckcodigo") == "D") {
        $cstr.=" and p.nomelong like '".strtoupper(trim($codigo))."%'";
        $cstr .= " group by p.codpro) p ";
        if ($semsaldo !== "true") {
            $cstr .= " where p.saldo>0 or p.saldot>0 or p.grupro=" . $olcfg["GRUSES"] . " or p.vende_neg='S' or p.kitpro='S'";
        } else {
            $cstr .= " where if(p.ativo='N',if(p.saldo>0,1,0),1) ";
        }
    }
    file_put_contents("saida.txt", $cstr);
    if (PegaVar("quant_con")) {
        $naux = pegavar("quant_con") + 0;
    } else {
        $naux = $nlimiteconsulta;
    }

    if (!$lfulltext) {
        $cstr .= " order by " . ($lpromo ? "if(p.preco5>0,0,1)," : "") . "p.nome ";
    } else {
        $cstr .= " order by " . ($lpromo ? "if(p.preco5>0,0,1)," : "") . "ranking desc,p.nome ";
    }
    $cstr .= " limit $naux ) p ";
    $cstr .= "
left join
(select gq.* from 
PROMOQUA_PRO gq 
inner join GRUPROMO_GPM gp1 on gq.grugpm=gp1.codgpm and gp1.is_deleted='N' and current_date()>=gp1.inigpm and current_date()<=gp1.fimgpm and gp1.ativa='S' and !find_in_set(1,replace(gp1.excljgpm,'-',','))

where gq.is_deleted='N' 
) gq on (     if(gq.grupo>0  ,gq.grupo  =p.grupro ,1) 
  and if(gq.marca>0  ,gq.marca  =p.marcpro,1) 
  and if(gq.produto>0,gq.produto=p.codigo ,1) 
  and if(gq.sgrupo>0 ,gq.sgrupo =p.sgrupro,1) 
  and if(gq.gruesp>0 ,gq.gruesp =p.gruesp,1) 
	)

group by p.codigo ";
    if (!$lfulltext) {
        $cstr .= " order by " . ($lpromo ? "if(p.preco5>0,0,1)," : "") . "p.nome ";
    } else {
        $cstr .= " order by " . ($lpromo ? "if(p.preco5>0,0,1)," : "") . "p.ranking desc,p.nome ";
    }

//order by p.nome
//";

    $otabpro = mysqli_query($db, $cstr);
    if (mysqli_error($db)) {
        $aret["erro"] = "99";
        $aret["cerro"] = mysqli_error($db);
        echo json_encode($aret);
        return;
    }
    $aprod = array();

    while ($olinpro = mysqli_fetch_array($otabpro)) {
        $olinpro["nome"] = LimpaChar($olinpro["nome"]);
        $olinpro["refer"] = LimpaChar($olinpro["refer"]);
        if ($olinpro["preco5"] > 0) {
            $olinpro["minimo"] = $olinpro["preco5"];
            $olinpro["venda"] = $olinpro["preco5"];
        }
        //kit
        if ($olinpro["kitpro"] == "S") {
            $cstr = "SELECT min(saldo) saldo,min(psaldo) psaldo,min(saldot) saldot,min(psaldot) psaldot from (
SELECT codpro,floor(saldo/quakit) AS saldo,floor(psaldo/quakit) AS psaldo,floor(saldot/quakit) AS saldot,floor(psaldot/quakit) AS psaldot from (
select p.codpro,sum(if(isnull(l.locloc) or l.locloc!=$loja,0,$CQUALOC)) as saldo,sum(if(isnull(l.locloc) or l.locloc!=$loja,0,l.fpgloc)) as psaldo,sum(if(isnull(l.locloc),0,$CQUALOC)) as saldot,sum(if(isnull(l.locloc),0,l.fpgloc)) as psaldot,k.quakit
,gp.vende_neg
from PROKIT_PRO k 
inner join PRODUTO_PRO p on p.is_deleted='N' and k.prokit=p.codpro
inner join GRUPO_GRU gp on gp.is_deleted='N' and gp.codgru=p.grupro
inner join EMPRESA_EMP c on c.is_deleted='N' and c.codEMP=$loja
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',',')  )) or l.locloc=$loja)
$INNERQUALOC    
where k.is_deleted='N' and k.codkit=" . $olinpro["codigo"] . "
group by k.prokit
) k
) k ";
            $olink = mysqli_fetch_array(mysqli_query($db, $cstr));
            $olinpro["saldo"] = $olink["saldo"];
            $olinpro["psaldo"] = $olink["psaldo"];
            $olinpro["saldot"] = $olink["saldot"];
            $olinpro["psaldot"] = $olink["psaldot"];
        }

        $aaux = array();
        $i = 0;
        foreach ($olinpro as $key => $value) {
            $i++;
            if ($i % 2 == 1) {
                continue;
            }
            if ($olcfg["GRUSES"] == $olinpro["grupro"] || $olinpro["vende_neg"] == "S") {
                $aaux["saldo"] = 9999;
                $aaux["saldot"] = 9999;
                $aaux["psaldo"] = 0;
                $aaux["psaldot"] = 0;
            }
            $aaux[$key] = $value;
        }
        $aprod[] = $aaux;
    }
    $aret["quant"] = mysqli_num_rows($otabpro);

    $aret["prod"] = $aprod;
    $aret["vda_sstk"] = mysqli_fetch_row(mysqli_query($db, "select vda_sstk from EMPRESA_EMP WHERE IS_DELETED='N' AND CODEMP=$loja"))[0];

    //$aret["erro"] = 99;
    //$aret['cerro'] =  var_export($aprod[0]["minimo"],true)."-".var_export($aprod[0]["venda"],true);
    //$aret['cerro'] =  var_export($cpremin,true)."-".var_export($cpreven,true);
    echo json_encode($aret);
    return;
}
$aret["erro"] = "98";
$aret["cerro"] = _tr("Erros de parametros");
echo json_encode($aret);
return;

