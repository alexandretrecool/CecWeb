<?php

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$ncod = PegaVar("cod");
if (!$db){
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}
$loja = PegaVar("loja");
$vendedor = PegaVar("vendedor");
if (!$vendedor) {
    $vendedor = VeSession("vendedor");//$_SESSION["vendedor"];
}

$nserie = pegavar('serie') + 0;

$nvendedor = $vendedor;
$lorc = PegaVar("orcamento") == "true";
$nlojapre = pegavar("lj_preco");



/*
  $nlojapre = "";
  $otimp = mysqli_query($db, "select loja_pre from CONFIMP_IMP where is_deleted='N' and terminal=998");
  if (mysqli_num_rows($otimp) > 0) {
  $nlojapre = mysqli_fetch_row($otimp)[0];
  if ($nlojapre == "" || $nlojapre == "NULL" || $nlojapre == "NUL" || $nlojapre == "NIL" || substr($nlojapre, 0, 3) == "LPT") {
  $nlojapre = "";
  }
  }
 */
$nlojapre = pegavar("lj_preco");



require_once 'inc/sid.php';

if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = "Erro acessando servidor.\n" . $caux;
    echo json_encode($aret);
    return;
}
$aret["preco3"] = 0;
$aret["premin"] = 0;
$aret["preven"] = 0;
$aret["nome"] = "";
$aret["nomeweb"] = "";
$aret["breve"] = "";
$aret["desc"] = "";
$aret["det"] = array();


$olcfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG"));
$olistcli = mysqli_fetch_array(mysqli_query($db, "select c.listcli,t.loja from CLIENTE_CLI c 
        inner join  tablet".$lweb."_cab t on t.serie='$nserie' and t.vendedor=$vendedor and t.cliente=c.codcli
        where c.is_deleted='N' AND c.codcli!=0"));

$clistcli = $olistcli[0];
if ($nlojapre) {
    $nloja_precos = $nlojapre;
} else {
    $nloja_precos = $olistcli[1];
}
$cprecoa = "preven";
$cprecob = "preco3";
$cprecoc = "premin";
$cprecot = "preatac";
if ($clistcli == "A") {
    $cprecob = $cprecoa;
    $cprecoc = $cprecoa;
    $cprecot = $cprecoa;
} else if ($clistcli == "B") {
    $cprecoa = $cprecob;
    $cprecoc = $cprecob;
    $cprecot = $cprecob;
} else if ($clistcli == "C") {
    $cprecoa = $cprecoc;
    $cprecob = $cprecoc;
    $cprecot = $cprecoc;
} else if ($clistcli == "D") {
    $cprecoa = $cprecot;
    $cprecob = $cprecot;
    $cprecoc = $cprecot;
}

$cstr = "select p.codpro as codigo,if(p.nomelong!='',p.nomelong,p.nompro) as nome ";
if ($nlojapre) {
    $cstr .= "  , if(isnull(lc.proloc) or lc.$cprecoa=0,p.$cprecoa,lc.$cprecoa) as preven"
            . ",if(isnull(lc.proloc) or lc.$cprecoc=0,p.$cprecoc,lc.$cprecoc) as premin"
            . ",if(isnull(lc.proloc) or lc.$cprecob=0,p.$cprecob,lc.$cprecob) as preco3";
} else {
    $cstr .= " ,p.$cprecoa,p.$cprecoc,p.$cprecob ";
}
$cstr .= " ,concat(m.codmarc,'-',m.nommarc) as marca
,w.nomeweb as nomeweb
,w.nimagem as nimagem
,convert(m1.memo,char) as texto
,convert(m2.memo,char) as minidesc
,p.kitpro
from PRODUTO_PRO p ";
if ($nlojapre) {
    $cstr .= " left join LOCAL_LOC lc on lc.is_deleted='N' and locloc=$nlojapre and lc.proloc=p.codpro ";
}
$cstr .= " left join MARCAS_MAR m on m.is_deleted='N' and m.codmarc=p.marcpro
left join PRODUTOS_WEB w on w.is_deleted='N' and w.codigo=p.codpro
left join PRODUTOS_WEB_MEMO m1 on w.recno=m1.recno and m1.col_name='TEXTO'
left join PRODUTOS_WEB_MEMO m2 on w.recno=m2.recno and m2.col_name='MINIDESC'
where p.is_deleted='N' and p.codpro=$ncod 
    GROUP BY p.codpro
";

$otable = mysqli_query($db, $cstr);
if (mysqli_num_rows($otable) == 0) {
    //$aret["nome"]= mysqli_error($db);
    echo json_encode($aret);
    return;
}
$olinha = mysqli_fetch_array($otable);
$aret["nome"] = iconv("ISO-8859-1", "UTF-8", $olinha["nome"]);
$aret["nomeweb"] = iconv("ISO-8859-1", "UTF-8", $olinha["nomeweb"]);
$aret["preco"] = $olinha["preco"];
$aret["premin"] = $olinha["premin"];
$aret["preven"] = $olinha["preven"];

$caux = str_replace("\n", "<br>", $olinha["minidesc"]);
if (str_replace(" ", "", str_replace("<br>", "", $caux))) {
    $aret["breve"] = iconv("ISO-8859-1", "UTF-8", $caux);
}
$caux = str_replace("\n", "<br />", $olinha["texto"]);
$caux = str_replace("div", "ul", $olinha["texto"]);
$caux = iconv("ISO-8859-1", "UTF-8", $caux);
$aret["desc"] = "<blockquote>" .
        str_replace("- ", "<br /><strong>»</strong>&nbsp;&nbsp;", $caux) .
        "</blockquote>";

$cstr = "select 
 e.codigo
,e.nome as nome_pt
,e.nome2 as nome_es
,e.id_parent
,v.valor as valor_pt
,v.valor2 as valor_es
from CATVALOR_WEB v
left join CATEGORI_WEB e on e.is_deleted='N' and e.codigo=v.categoria
where v.is_deleted='N' and v.codigo=" . $olinha["codigo"] . " and (v.valor!='' or v.valor2!='') 
order by e.ordem,e.nome
";
$otab = mysqli_query($db, $cstr);
$adet = array();
if (mysqli_num_rows($otab) > 0) {
    while ($olin = mysqli_fetch_array($otab)) {
        $adet[] = array(iconv("ISO-8859-1", "UTF-8", $olin["nome_pt"]), iconv("ISO-8859-1", "UTF-8", $olin["valor_pt"]));
    }
}
$aret["det"] = $adet;
echo json_encode($aret);
return;
