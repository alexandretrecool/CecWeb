<?php

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$cuser = strtoupper(trim(PegaVar("user")));
$csid = pegavar("sid");
$loja = PegaVar("loja");
$vendedor = pegavar("vendedor");
$moeda = pegavar("moeda");
$cambio = pegavar("cambio");
$cidade = pegavar("cidade");

if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}

define("CEP_SERVER", "https://viacep.com.br/ws/[[CEP]]/");

require_once 'inc/sid.php';

if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("Erro acessando servidor") . ".\n" . $caux;
    echo json_encode($aret);
    return;
}

$cliente = pegavar("cliente");
$rg = pegavar("rg");
$mail = pegavar("mail");
$nome = pegavar("nome");
$ruc = pegavar("ruc");
$cep = pegavar("cep");
$cmodo = PegaVar("modo");

if ($cmodo == "PAIS") {
    $apais = array(array(76, "Brasil"), array(600, "Paraguay"), array(32, "Argentina"));
    $otabpais = mysqli_query($db, "select codigo,nome from PAIS_PGY WHERE IS_DELETED='N' AND !FIND_IN_SET(CODIGO,'32,76,600') order by nome");
    while ($olinpais = mysqli_fetch_array($otabpais)) {
        $apais[] = array($olinpais["codigo"], iconv('cp850', 'utf8', $olinpais["nome"]));
    }
    $aret["pais"] = $apais;
    echo json_encode($aret);
    return;
}
if ($cmodo == "CELULAR") {

    $aret["celular"] = mysqli_fetch_row(mysqli_query($db, "select celular from CLIENTE_PGY where is_deleted='N' and codigo='" . pegavar("cliente") . "'"))[0];
    echo json_encode($aret);
    return;
}
if ($cmodo == "DECLIENTE") {
    $otabcli = mysqli_query($db, "select * from CLIENTE_PGY where is_deleted='N' and codigo=$cliente");
    $acli = array();

    if (mysqli_num_rows($otabcli) == 0) {
        $aret["erro"] = "10";
        $aret["cerro"] = _tr("Não cadastrado");
        $olincli = mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI where is_deleted='N' and codcli=$cliente"));
        $acli = array();
        $acli["codigo"] = $olincli["CODCLI"];
        if ($olincli["PAISCLI"] == 1) {
            $acli["pais_num"] = 600;
            $acli["doc_tipo"] = 1;
            $acli["ruc"] = LimpaRg($olincli["RUCCLI"]);
        } else {
            $acli["pais_num"] = 76;
            $acli["doc_tipo"] = 3;
            $acli["ruc"] = '';
        }
        $acli["natureza"] = 2;
        $acli["ope_tipo"] = 2;
        $acli["ruc_dv"] = "";
        $acli["cont_tipo"] = 1;
        $acli["iden_num"] = LimpaRg($olincli["RUCCLI"]);
        $acli["nome"] = iconv("cp850", "utf8", $olincli["NOMCLI"]);
        $acli["fantasia"] = $olincli["FANCLI"];
        $acli["endereco"] = $olincli["ENDCLI"];
        $acli["telefone"] = LIMPARG($olincli["FONCLI"]);
        $acli["celular"] = LIMPARG($olincli["CELCLI"]);
        $acli["email"] = $olincli["E_MAIL"];
        $acli["cpf"] = $olincli["CPFCLI"];
        $acli["emitir"] = 'Y';
        $acli["bairro"] = $olincli["BAICLI"];
        $acli["cep"] = LIMPARG($olincli["CEPCLI"]);
        $acli["cidade"] = iconv("cp850", "utf8", $olincli["CIDCLI"]);
        $acli["estado"] = $olincli["UFCLI"];
        $acli["numero"] = '';
        $acli["codcid"] = 0;
        $acli["codest"] = 0;
        $acli["rucc"] = LIMPARG($olincli["RUCCCLI"]);
    } else {
        $olincli = mysqli_fetch_array($otabcli);
        $acli = array();
        $acli["codigo"] = $olincli["CODIGO"];
        $acli["natureza"] = $olincli["NATUREZA"];
        $acli["ope_tipo"] = $olincli["OPE_TIPO"];
        $acli["pais_num"] = $olincli["PAIS_NUM"];
        $acli["ruc"] = $olincli["RUCC"] . $olincli["RUC_DV"];
        $acli["ruc_dv"] = $olincli["RUC_DV"];
        $acli["cont_tipo"] = $olincli["CONT_TIPO"];
        $acli["doc_tipo"] = $olincli["DOC_TIPO"];
        $acli["iden_num"] = $olincli["IDEN_NUM"];
        $acli["nome"] = iconv("cp850", "utf8", $olincli["NOME"]);
        $acli["fantasia"] = $olincli["FANTASIA"];
        $acli["endereco"] = $olincli["ENDERECO"];
        $acli["telefone"] = $olincli["TELEFONE"];
        $acli["celular"] = $olincli["CELULAR"];
        $acli["email"] = $olincli["EMAIL"];
        $acli["cpf"] = $olincli["CPF"];
        $acli["emitir"] = $olincli["EMITIR"];
        $acli["bairro"] = $olincli["BAIRRO"];
        $acli["cep"] = $olincli["CEP"];
        $acli["cidade"] = iconv("cp850", "utf8", $olincli["CIDADE"]);
        $acli["cidade_num"] = $olincli["CODCID"];
        $acli["estado"] = $olincli["ESTADO"];
        $acli["numero"] = $olincli["NUMERO"];
        $acli["codcid"] = $olincli["CODCID"];
        $acli["codest"] = $olincli["CODEST"];
        $acli["rucc"] = $olincli["RUCC"];
    }
    foreach ($acli as $key => $value) {
        $acli[$key] = iconv('cp850', 'utf8', $value);
    }
    $aret["cli"] = $acli;
    echo json_encode($aret);
    return;
}
if ($cmodo == "RUCSIFEN") {

    $nTimbrado = mysqli_fetch_row(mysqli_query($db, "select codigo from TIMBRADO_PGY WHERE IS_DELETED='N' and final>=current_Date() and inicio<=current_Date() ORDER BY CODIGO LIMIT 1"))[0];

    $cUrl = mysqli_fetch_row(mysqli_query($db, "select certificad from TIMBRADO_PGY where is_deleted='N' and codigo=$nTimbrado"))[0];

    if (!$cUrl) {
        $aret["erro"] = "22";
        $aret["cerro"] = _tr("Erro parametros SIFEN");
        echo json_encode($aret);
        return;
    }

    $cUrl = explode("assina.php", $cUrl)[0];
    $cUrl .= "sifen/consulta_ruc.php?ruc=" . trim($ruc);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $cUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $cHtml = curl_exec($ch);
    curl_close($ch);

    if (!$cHtml || substr($cHtml, 0, 4) == "ERRO") {
        $aret["erro"] = "23";
        $aret["cerro"] = _tr("Sem resposta sifen");
        echo json_encode($aret);
        return;
    }

    $aret["ruc"] = explode("</ns2:dRUCCons>", explode("<ns2:dRUCCons>", $cHtml)[1])[0];
    $aret["ncodres"] = explode("</ns2:dCodRes>", explode("<ns2:dCodRes>", $cHtml)[1])[0];
    $aret["ccodres"] = explode("</ns2:dMsgRes>", explode("<ns2:dMsgRes>", $cHtml)[1])[0];
    $aret["razao"] = explode("</ns2:dRazCons>", explode("<ns2:dRazCons>", $cHtml)[1])[0];
    $aret["ativo"] = (explode("</ns2:dCodEstCons>", explode("<ns2:dCodEstCons>", $cHtml)[1])[0]) == "ACT";

    echo json_encode($aret);
    return;
}
if ($cmodo == "CEP") {
    $cServer = CEP_SERVER . "xml/";

    $cServer = str_replace("[[CEP]]", $cep, $cServer);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $cServer);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $cHtml = curl_exec($ch);
    curl_close($ch);
    $oxml = simplexml_load_string($cHtml);
    $aret["existe"] = $oxml->cep ? true : false;
    $aret["cep"] = str_replace("-", "", $oxml->cep . '');
    $aret["logradouro"] = $oxml->logradouro . '';
    $aret["complemento"] = $oxml->complemento . '';
    $aret["bairro"] = $oxml->bairro . '';
    $aret["localidade"] = $oxml->localidade . '';
    $aret["uf"] = $oxml->uf . '';
    $aret["ibge"] = $oxml->ibge . '';
    echo json_encode($aret);
    return;
}
if ($cmodo == "CIDADEPY") {
    $acid = array();
    $cstr = "select c.codcid,c.nomcid,c.codest,e.nomest from CIDADE_PGY c inner join ESTADO_PGY e on e.is_deleted='N'  and e.codest=c.codest where c.is_deleted='N' and (1";
    $aaux = explode(" ", $cidade);
    foreach ($aaux as $value) {
        $cstr .= " and c.nomcid like '%$value%'";
    }
    $cstr .= ")";
    $otab = mysqli_query($db, $cstr);
    while ($olin = mysqli_fetch_array($otab)) {
        $acid[] = array($olin["codcid"], iconv("utf8", "cp850", $olin["nomcid"]), $olin["codest"], iconv("utf8", "cp850", $olin["nomest"]));
    }
    $aret["cidade"] = $acid;
    echo json_encode($aret);
    return;
}
if ($cmodo == "INCLUICLI") {
    $ncliente = pegavar("codigo");
    $nrecno = (mysqli_fetch_row(mysqli_query($db, "select recno from CLIENTE_PGY WHERE is_deleted='N' and codigo=$ncliente"))[0]) + 0;

    $linc = false;

    if ($nrecno == 0) {
        $linc = true;
        if ($lCfRdd) {
            $omed = new Mediator4("CLIENTE.PGY", W_CRIAR, '', '', $db);
        } else {
            $omed = new Mediator3("CLIENTE.PGY", W_CRIAR, '', '', $db);
        }
        $omed->aadd("CODIGO", $ncliente);
    } else {
        if ($lCfRdd) {
            $omed = new Mediator4("CLIENTE.PGY", W_ALTERAR, '', $nrecno, $db);
        } else {
            $omed = new Mediator3("CLIENTE.PGY", W_ALTERAR, '', $nrecno, $db);
        }
    }
    $omed->aadd("NATUREZA", PegaVar("nat"));
    $omed->aadd("OPE_TIPO", PegaVar("tipo_ope"));
    $omed->aadd("PAIS_NUM", PegaVar("pais"));
    $omed->aadd("PAIS_NOM", mysqli_fetch_row(mysqli_query($db, "select nome from PAIS_PGY WHERE IS_DELETED='N' AND CODIGO=" . pegavar("pais")))[0]);
    $cruc = pegavar("ruc");
    $omed->aadd("RUC", substr($cruc, 0, strlen($cruc) - 1));
    $omed->aadd("RUC_DV", substr($cruc, -1));
    $omed->aadd("CONT_TIPO", PegaVar("con"));
    $omed->aadd("DOC_TIPO", PegaVar("tip_doc"));
    $omed->aadd("IDEN_NUM", PegaVar("documento"));
    $omed->aadd("NOME", iconv("utf8", "cp850", PegaVar("nome")));
    $omed->aadd("FANTASIA", iconv("utf8", "cp850", PegaVar("fantasia")));
    $omed->aadd("ENDERECO", iconv("utf8", "cp850", PegaVar("endereco")));
    $omed->aadd("TELEFONE", PegaVar("telefone"));
    $omed->aadd("CELULAR", PegaVar("celular"));
    $cmail = strtolower(trim(PegaVar("mail")));
    if ($cmail == "cliente no tiene correo electronico") {
        $cmail = "";
    }
    $omed->aadd("EMAIL", $cmail);
    $omed->aadd("EMITIR", TRUE);
    $omed->aadd("CPF", pegavar("cpf"));
    $omed->aadd("BAIRRO", iconv("utf8", "cp850", PegaVar("bairro")));
    $omed->aadd("ESTADO", iconv("utf8", "cp850", PegaVar("estado")));
    $omed->aadd("NUMERO", PegaVar("numero"));
    $omed->aadd("CEP", PegaVar("cep"));
    $omed->aadd("RUCC", substr($cruc, 0, strlen($cruc) - 1));
    $ncid = Pegavar("cidade_num");
    if ($ncid) {
        $olin = mysqli_fetch_array(mysqli_query($db, "SELECT CODEST,NOMCID FROM CIDADE_PGY where is_deleted='N' and codcid=$ncid"));
        $omed->aadd("CODCID", $ncid);
        $omed->aadd("CODEST", $olin["CODEST"]);
        $omed->aadd("CIDADE", iconv("utf8", "cp850", $olin["NOMCID"]));
    } else {
        $omed->aadd("CIDADE", iconv("utf8", "cp850", PegaVar("cidade")));
    }
    if ($linc) {
        $omed->aadd("ORI_CAD", "APK");
        $omed->aadd("DAT_CAD", Date2Unix());
    } else {
        $omed->aadd("ORI_ALT", "APK");
        $omed->aadd("DAT_ALT", Date2Unix());
    }

    if (!$omed->grava()) {
        $aret["erro"] = "97";
        $aret["cerro"] = "Erros adicionando registro" . " CLIENTE.PGY ";
        echo json_encode($aret);
        return;
    }
    if (pegavar("cpf") && mysqli_fetch_row(mysqli_query($db, "select cpfcli from CLIENTE_CLI WHERE IS_DELETED='N' AND CODCLI=$ncliente"))[0] !== pegavar("cpf")) {
        mysqli_query($db, "update CLIENTE_CLI set cpfcli='" . pegavar("cpf") . "' where is_deleted='N' and codcli=$ncliente ");
    }
    if (pegavar("atualizacec")=="true"){
        $cstr="update CLIENTE_CLI c, CLIENTE_PGY f set c.nomcli=f.nome,c.e_mail=f.email,c.paiscli=if(f.pais_num=600,1,2)
            ,c.ruccli=if(f.natureza=1,concat(f.ruc,f.ruc_dv),f.iden_num)
            ,c.fancli=f.fantasia,c.endcli=concat(f.endereco,'-',f.numero),c.foncli=f.telefone,c.celcli=f.celular,c.cpfcli=f.cpf,c.baicli=f.bairro
            ,c.ufcli=f.estado,c.cepcli=f.cep,c.rucres=if(f.natureza=1,concat(f.ruc,f.ruc_dv),f.iden_num),c.cidcli=f.cidade,c.data_alt=now()
            where c.codcli=f.codigo and f.codigo=$ncliente and c.is_deleted='N' and f.is_deleted='N'
            ";
        
        mysqli_query($db,$cstr);
        
    }
    echo json_encode($aret);
    return;
}
if ($cmodo == "CLIFATURA") {
    if ($lNaoValidaClienteFatura) { //em inc/mysql.php ou inc/connect.php
        echo json_encode($aret);
        return;
    }
    if (mysqli_fetch_row(mysqli_query($db, "select CLIECON2 FROM CONFIG where recno=1"))[0] == $cliente) {
        echo json_encode($aret);
        return;
    }

    $otab = mysqli_query($db, "select * from CLIENTE_PGY where is_deleted='N' and codigo=$cliente");
    if (mysqli_num_rows($otab) == 0) {
        $aret["erro"] = "01";
        $aret["cerro"] = "Cliente no cadastrado para emitir DE";
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);

    if ($olin["EMITIR"] != "Y") {
        $aret["erro"] = "02";
        $aret["cerro"] = "Cliente no AUTORIZADO a emitir DE";
        echo json_encode($aret);
        return;
    }

    if ($olin["PAIS_NUM"] == 0) {
        $cerro .= "\nPaís no es valido";
    }
    if (trim($olin["IDEN_NUM"]) !== LimpaRg($olin["IDEN_NUM"])) {
        $cerro .= "\nCaracteres no validos en la CEDULA  ".$olin["IDEN_NUM"]."|". LimpaRg($olin["IDEN_NUM"]);
    }
    if (trim($olin["EMAIL"]) && !filter_var(trim($olin["EMAIL"]), FILTER_VALIDATE_EMAIL)) {
        $cerro .= "\nEmail no es valido";
    }
    if (strlen($olin["NOME"]) < 4) {
        $cerro .= "\nNombre no es valido";
    }
    if (strlen(trim($olin["FANTASIA"])) > 0 && strlen($olin["FANTASIA"]) < 4) {
        $cerro .= "\nFantasia no es valida";
    }
    if (trim($olin["TELEFONE"])) {
        if (strlen($olin["TELEFONE"]) < 9) {
            $cerro .= "\nTelefono debe ser mas que 9 digitos ";
        } else {
            $cerro .= VeTelefone($olin["TELEFONE"], $olin["PAIS_NUM"], false);
        }
    }
    if (trim($olin["CELULAR"])) {
        if (strlen($olin["CELULAR"]) < 9) {
            $cerro .= "\nCelular debe ser mas que 9 digitos ";
        } else {
            $cerro .= VeTelefone($olin["CELULAR"], $olin["PAIS_NUM"], true);
        }
    }
    if ($olin["PAIS_NUM"] == 600) {
        if ($olin["NATUREZA"] < 1 || $olin["NATUREZA"] > 2) {
            $cerro .= "\nNATUREZA no es valida";
        }
        if ($olin["OPE_TIPO"] < 1 || $olin["OPE_TIPO"] > 3) {
            $cerro .= "\nTIPO DE OPERACIÓN no es valida";
        }
        if ($olin["CONT_TIPO"] < 1 || $olin["CONT_TIPO"] > 2) {
            $cerro .= "\nTIPO DE CONTRIBUYENTE no es valido";
        }
        if ($olin["CONT_TIPO"] == 2 && !trim($olin["RUCC"])) {
            $cerro .= "\nRUC VACIO para persona juridica.";
        }
        /*
          if ($olin["RUCC"]) {
          $cerro .= "\nRUC VACIO para persona juridica..";
          }
         */
        if ($olin["NATUREZA"] == 1 && $olin["CODCID"] == 0) {
            $cerro .= "\nCiudad no es valida";
        }
        //if ($olin["NATUREZA"] == 1 && (!$olin["ENDERECO"] || !$olin["NUMERO"] )) {
        if ($olin["NATUREZA"] == 1 && (!$olin["ENDERECO"]  )) {
            $cerro .= "\nDireccion no es valida";
        }
    } else {
        if ($olin["OPE_TIPO"] != 4) {
            $cerro .= "\nOPERACION incorrecta para Extrangero";
        }
        if ($olin["NATUREZA"] == 1) {
            $cerro .= "\nNATURALEZA incorrecta para Extrangero";
        }
        if (strlen($olin["CIDADE"]) < 3) {
            $cerro .= "\nCIUDAD no es valida";
        }
        if ($olin["PAIS_NUM"] == 76 && strlen($olin["ESTADO"]) < 2) {
            $cerro .= "\nESTADO no es valido";
        }
        if (!$olin["ENDERECO"]) {
            $cerro .= "\nDIRECCIÓN no es valida";
        }
        if (!($olin["DOC_TIPO"] == 2 || $olin["DOC_TIPO"] == 3 || $olin["DOC_TIPO"] == 5 || $olin["DOC_TIPO"] == 6)) {
            $cerro .= "\nTIPO DE DOCUMENTO no es valido";
        }
        if (strlen($olin["IDEN_NUM"]) < 6) {
            $cerro .= "\nDOCUMENTO no es valido";
        }
    }
    if ($cerro) {
        $aret["erro"] = "31";
        $aret["cerro"] = $cerro;
    }
    echo json_encode($aret);
    return;
}



$aret["erro"] = "01";
$aret["cerro"] = _tr("Parametros inválidos");
echo json_encode($aret);
return;

function ExtraiTag($cstr, $cini, $cfim) {
    $nini = strpos($cstr, $cini) + strlen($cini);
    $nfim = strpos($cstr, $cfim) - $nini;
    return substr($cstr, $nini, $nfim);
}

function VeTelefone($cFone, $npais, $lCelular) {
    if ($cFone == "") {
        return "";
    }
    if ($npais == 76) {
        $cMenCel = "Informe o telefone celular no formato: dd 9XXXX XXXX";
        $cMenFix = "Informe o telefone fixo no formato: dd XXXX XXXX, não iniciando o numero com 9";
        $cFone = Trim($cFone);

        if ($lCelular) {
            //45998313601
            if (strlen($cFone) != 11 ||
                    SubStr($cFone, 0, 1) == "0" ||
                    SubStr($cFone, 1, 1) == "0" ||
                    SubStr($cFone, 2, 1) != "9" ||
                    SubStr($cFone, 3, 1) == "0" ||
                    strlen(LimpaRg($cFone)) != strLen($cFone)) {

                return $cMenCel;
            }
        } else {
            //4530282650
            if (strLen($cFone) != 10 ||
                    SubStr($cFone, 0, 1) == "0" ||
                    SubStr($cFone, 1, 1) == "0" ||
                    SubStr($cFone, 2, 1) == "0" ||
                    SubStr($cFone, 2, 1) == "9" ||
                    SubStr($cFone, 2, 1) == "8" ||
                    SubStr($cFone, 2, 1) == "7" ||
                    strLen(limparg($cFone)) != strLen($cFone)) {

                return $cMenFix;
            }
        }
    } else if ($npais == 600) {
        $cMenCel = "Informe o telefone celular no formato: 09DDnnnnnn";
        $cMenFix = "Informe o telefone fixo no formato: 0DDnnnnnn";
        $cFone = Trim($cFone);
        if ($lCelular) {
            //0983507657
            if (strlen($cFone) !== 10 ||
                    SubStr($cFone, 0, 2) !== "09" ||
                    strlen(LimpaRg($cFone)) != strLen($cFone)) {
                return $cMenCel;
            }
        } else {
            //061509315
            if (SubStr($cFone, 0, 2) == "09" ||
                    strLen(limparg($cFone)) != strLen($cFone)) {
                return $cMenFix;
            }
        }
    }
    return "";
}
