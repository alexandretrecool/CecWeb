<?php

session_start();
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

require_once 'inc/config.php';

$modo = pegavar("modo");

if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}

if ($modo == "LOCAL") {
    $vendedor = pegavar("vendedor");
    $nserie = pegavar('serie') + 0;
    $clocal = pegavar("local");
    $lfinal = pegavar("final");
    $cstr = "update tablet" . $lweb . "_cab set loc_" . ($lfinal == "true" ? "fin" : "ini") . "='$clocal' where serie=$nserie and vendedor=$vendedor " . ($lfinal == "true" ? "" : " and loc_ini=''");

    mysqli_query($db, $cstr);
    $cstr="desc tablet_location 'nota'";
    if (mysqli_num_rows(mysqli_query($db,$cstr))==0){
        $cstr="alter table tablet_location add nota int(10) not null default '0'";
        mysqli_query($db, $cstr);
    }

    //$aret["cerro"]=$cstr."\n\n".mysqli_error($db);
    echo json_encode($aret);
    return;
}
$csql = "create table if not exists tablet" . $lweb . "_location 
        (vendedor int(4) not null default 0
        ,data int(10) not null default 0
        ,log int(1) not null default 0
        ,pos varchar(100) not null default ''
        ,index vendedor (vendedor)
        ,index data (data)
        )";
mysqli_query($db, $csql);
if ($modo == "LOCAL_TEMP") {

    $cbuffer = pegavar("buffer");
    if (!$cbuffer) {
        $vendedor = pegavar("vendedor");
        $nserie = pegavar('serie') + 0;
        $clocal = pegavar("local");
        $lfinal = pegavar("final");
        $nlog = pegavar("log");
        mysqli_query($db, "insert tablet" . $lweb . "_location set pos='$clocal',vendedor='$vendedor',data=date2unix(now()),log='$nlog'");
    } else {
        $aaux = explode("\n", $cbuffer);
        foreach ($aaux as $value) {
            $aaux1 = explode("|", $value);
            if (!$aaux1) {
                continue;
            }
            $vendedor = $aaux1[0];
            $nlog = $aaux1[1];
            $nhora = $aaux1[2];
            $clocal = $aaux1[3];
            mysqli_query($db, "insert tablet" . $lweb . "_location set pos='$clocal',vendedor='$vendedor',data='$nhora',log='$nlog'");
        }
    }
    echo json_encode($aret);
    return;
}

$aret["erro"] = "98";
$aret["cerro"] = _tr("Erros de parâmetros");
echo json_encode($aret);
return;
