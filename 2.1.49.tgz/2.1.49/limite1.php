<?php
session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";


if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}


define("CLIENTE_DIV", 227);

$aConfigCec=array();

echo "X".vesenhax(CLIENTE_DIV,3)."X<BR>";
echo "z".veconfsen(CLIENTE_DIV)["NIVEL"]."z<br>";
return;


function vesenhax( $nSenha, $nOperador=0,$nGrupo=0,&$cErro='' ) {
    global $db;
    $nGrau = 0;
    $cErro='';
    
    if (!$olin=mysqli_fetch_array(mysqli_query($db, "select * from OPEGRUPO_OPE where is_deleted='N' and codopg=".($nOperador?$nOperador:$nGrupo )))){
        $cErro="Operador não possui grupo de senhas";
        return $nGrau;
    }
    if ($olin["SITOPG"]=="X"){
        $nGrau=9;
    }
    if ($olin["SENOPG"]=="N"){
        $nGrau=0;
    }
    return $nGrau;
}

function ACHAVALSAL($lOrc=false,$nOperador,$nCliente, $lPrazo, $nDias, $nConCre,&$cErro='' ){
    global $db;
    $aAutNeed=array(true,true);

    if ($lPrazo == "V" ){
        $aAutNeed=array(true,true);
        return $aAutNeed;
    }

    if ($lOrc){
        $aAutNeed=array(true,true);
        return true;
    }

    
    $nConCre=(VeConfigCec("NOME_VIPR")=="V"?1:2);    
    $nGrau = 0;
    $nValPen = 0;
    $nValChq = 0 ;
    $cWpode = 'N';
    $aOperador=VeOperador($noperador);
    
    $nGrau = VeConfSen(CLIENTE_DIV)["NIVEL"];

    if ($aOperador["NIVEL"]>=$nGrau){
        $cWpode='S';
    }

    if (VeConfigCec("GRUPOOPE")=="S"){
        $cWpode = "N";
        $nGrau=vesenhax(CLIENTE_DIV,0,$aOperador["GRUPO"]);
        if ($nGrau == 9) {
            $cWpode = "S";
        }
    }

    if ( $lPrazo !== "A" && VeConfigCec("MODPEDI")!==13 && VeConfigCec("TUDPRAZ")!== "N"){

        if (VeConfigCec("CONTPLZ") == "S") { // || ( M->FAT == "F" ) // .AND. M->IDIOMA=="E")
            if ($nConCre == 2 && $lPrazo !== "P" ){
                $cErro="CAMBIAR P/ PLAZO !!";
                return $aAutNeed;
            }

            if ($nConCre == 1 && $lPrazo !== "C" ){
                $cErro="CAMBIAR P/ CONTADO !!" ;
                return $aAutNeed;
            }
        }
    }
/*
    IF $lPrazo <> "A" .AND. M->MODPEDI <> 13 .AND. M->TUDPRAZ == "N"

        IF M->CONTPLZ == "S" .OR. ( M->FAT == "F" ) // .AND. M->IDIOMA=="E")
            IF $nConCre == 2 .AND. $lPrazo <> "P"
                Erro( "CAMBIAR P/ PLAZO !!" )
                RETURN .F.
            ENDIF

            IF $nConCre == 1 .AND. $lPrazo <> "C"
                Erro( "CAMBIAR P/ CONTADO !!" )
                RETURN .F.
            ENDIF
        ENDIF
    ENDIF
*/
    $olcli=mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI where is_deleted='N' and codcli=$nCliente"));
    
    if (!($nDias > 0 && $olcli["PRZCLI"] < $nDias)) {
        $aAutNeed[0]=false;
        /*
        $cAux = "** Vender Acima do Limite de Dias **\r\n" ;
        $cAux .= "Vended. : " .VeSession("vendedor").'-'.mysqli_fetch_row(mysqli_query($db,"select nomven from VENDEDOR_VEN where is_deleted='N' and codven=".VeSession("vendedor")))[0]."\r\n";
        $cAux .= "Cliente : " .$nCliente. "-" . mysqli_fetch_row(mysqli_query($db,"select nomcli from CLIENTE_CLI where is_deleted='N' and codcli=$nCliente"))[0]."\r\n";
        $cAux.="Dias perm.:" . $olcli["PRZCLI"]."\r\n";
        $cAux.= "Dias ped..:".$nDias ."\r\n";

        NREGISTRO := 1
        IF ! ped_geral( $cAux, "Venda Acima do Limite de Dias", SAIDAS_DIA , M->USUMOM, @nregistro, "OPER_TERM", SaveScreen( 0, 0, m->max_row - 1, m->max_col - 1 ) )
            RETURN .F.
        ENDIF
        TelaSalva()
        SalvaTela( nRegistro,,, "CLI" + AllTrim( Transform( CLI->CODCLI, "9999999" ) ) )
        TelaSalva( "LIMPA" )
        
         */
        
}
/*
    IF $nDias > 0 .AND. CLI->PRZCLI < $nDias //.AND. CLI->PRZCLI<>0
        aux := ID( "** Vender Acima do Limite de Dias **", "** Venta Mayor que Limite de Dias **" ) + Chr( 13 ) + Chr( 10 )
        aux += "Vended. : " + nTrim( ven->codven ) + "-" + ven->nomven + Chr( 13 ) + Chr( 10 )
        aux += "Cliente : " + nTrim( cli->codcli ) + "-" + cli->nomcli + Chr( 13 ) + Chr( 10 )
        aux += "Dias perm.:" + nTrim( cli->przcli ) + Chr( 13 ) + Chr( 10 )
        aux += "Dias ped..:" + nTrim( $nDias )

        NREGISTRO := 1
        IF ! ped_geral( aux, ID( "Venda Acima do Limite de Dias", "Ventas Mayor que Limite de Dias" ), IF( M->FAT <> "F", SAIDAS_DIA, SAIDAS_DI1 ), M->USUMOM, @nregistro, "OPER_TERM", SaveScreen( 0, 0, m->max_row - 1, m->max_col - 1 ) )
            RETURN .F.
        ENDIF
        TelaSalva()
        SalvaTela( nRegistro,,, "CLI" + AllTrim( Transform( CLI->CODCLI, "9999999" ) ) )
        TelaSalva( "LIMPA" )
    ENDIF
*/

    $nSaldo = 0;

    //DUP->( DBSetOrder( "CLIREC" ) )

    //DUP->( DBSeek( Str( $nCliente, 7 ), .T. ) )

    WATZ := "N"
    WNDZ := "N"
    WNDI := 0
    WNTO := Space( 9 )
    WVCT := Date()
            
    $orec= mysqli_query($db, "select * from DUPLICAT_CLI WHERE IS_DELETED='N' AND CLIEDUP=$nCliente");
    
            DO WHILE $nCliente == DUP->CLIEDUP

        IF ! Empty( DUP->RECEDUP )
            EXIT
        ENDIF

        //IF Date() - DUP->EMISDUP > IF( M->TOLERPZ == "S", CLI->TOLPRZ, CLI->PRZCLI )


        IF M->TOLERPZ == "S"
         IF Date() - DUP->VENCDUP > CLI->TOLPRZ
            WNDZ := "S"

            IF WNDI < Date() - DUP->VENCDUP
                WNDI := Date() - DUP->VENCDUP
                WNTO := DUP->NUMEDUP
                WVCT := DUP->VENCDUP
            ENDIF
         ENDIF
        ENDIF


        IF M->TOLERPZ == "N"
         IF Date() - DUP->VENCDUP > 0 //IF( M->TOLERPZ == "S", CLI->TOLPRZ, CLI->PRZCLI )
            WNDZ := "S"

            IF WNDI < Date() - DUP->VENCDUP
                WNDI := Date() - DUP->VENCDUP
                WNTO := DUP->NUMEDUP
                WVCT := DUP->VENCDUP
            ENDIF
         ENDIF
        ENDIF

        IF M->TOLERPZ == "N"
            IF DUP->VENCDUP < Date()
                WATZ := "S"
            ENDIF
        ENDIF

        IF M->TOLERPZ == "S"
            //IF Date() - DUP->EMISDUP > CLI->TOLPRZ
            IF Date() - DUP->VENCDUP > CLI->TOLPRZ
                WATZ := "S"
            ENDIF
        ENDIF

        $nSaldo := $nSaldo + ( DUP->VALODUP / tipcam[ dup->moedup ] * tipcam[ 1 ] )
        DUP->( DBSkip() )

    ENDDO



    IF LMEDIATOR
        $nValPen := selval( "select sum(s.VALOSAI/s.CAMBSAI*s.BASESAI) from " + IF( M->FAT <> "F", "SAIDAS_SAI", "FISCAL_SAI" ) + " s where s.TIPOSAI='P' and s.sitsai<>'S' and s.is_deleted='N' and cliesai=" + nTrim( $nCliente ) , "N" )
        IF Empty( $nValPen )
            $nValPen := 0
        ENDIF

        $nValChq := selval( "select sum(c.valolote/c.camblote*c.baselote) from " + IF( M->FAT <> "F", "LOTESDOC_CLI", "LOTESDOF_CLI" ) + " c where c.RECLOTE='1000-01-01' and c.is_deleted='N' and c.clielote=" + nTrim( $nCliente ) , "N" )

        IF Empty( $nValChq )
            $nValChq := 0
        ENDIF


        //AQUI LIMITE
    ENDIF

    IF WNDZ == "S"
        CLI->( RegLock() )
        _FIELD->CLI->SITCLI := "S"
        CLI->( DBCommit() )
        CLI->( DBUnlock() )
        aux := ID( "** Cliente com faturas vencidas   **", "** Clientes con Facturas vencidas **" ) + Chr( 13 ) + Chr( 10 )
        aux += "Vended. : " + nTrim( ven->codven ) + "-" + ven->nomven + Chr( 13 ) + Chr( 10 )
        aux += "Cliente : " + nTrim( cli->codcli ) + "-" + cli->nomcli + Chr( 13 ) + Chr( 10 )
        aux += "Dias perm.:" + nTrim( cli->przcli ) + Chr( 13 ) + Chr( 10 )
        IF M->TOLERPZ=="S"
           aux += "Tolerancia:" + nTrim( cli->tolprz )+" dias" + Chr( 13 ) + Chr( 10 )
        ENDIF
        aux += "Pedido....:" + wnto + Space( 3 ) + "Vencto:" + DToC( wvct ) + Space( 3 ) + "Dias Atz..:" + nTrim( wndi )

        NREGISTRO := 1
        IF ! ped_geral( aux, ID( "Cliente com faturas vencidas ", "Cliente con facturas vencidas" ), SAIDAS_ATZ, M->USUMOM, @nregistro, "OPER_TERM", SaveScreen( 0, 0, m->max_row - 1, m->max_col - 1 ) )
            RETURN .F.
        ENDIF
        TelaSalva()
        SalvaTela( nRegistro,,, "CLI" + AllTrim( Transform( CLI->CODCLI, "9999999" ) ) )
        TelaSalva( "LIMPA" )
    ELSE
        CLI->( RegLock() )
        _FIELD->CLI->SITCLI := " "
        CLI->( DBCommit() )
        CLI->( DBUnlock() )
    ENDIF

    IF WATZ == "S" .AND. M->AVISVCT == "S"
        AL := Alerta( Chr( 2 ) + "   CLIENTE COM NOTAS VENCIDAS;CONSULTE GERENCIA", { "VISUALISAR", "CONTINUAR" }, 2,, 10 )
        IF AL == 1
            Amb := Amb()
            VELIMITE( $nCliente, "CLI" )
            Amb( Amb )
        ENDIF

    ENDIF

    DUP->( DBSetOrder( "DUPNUME" ) )

    IF $cWpode == "S"
        @ Row(), Col() + 10 say tipsim[ 1 ] + "->" + Transform( $nSaldo, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) Color "GR+/B"
    ENDIF



    IF M->LIMITGRU == 0 .AND. M->LIMCRE_FI == "N"  // QUANDO FOR LIMITE POR GRUPO - SOMENTE NA FINALIZACAO DA VENDA SERA PEDIDA AUTORIZACAO
        IF $nSaldo + $nValPen + $nValChq > CLI->LIMCLI .OR. ( CLI->LIMCLI == 0 .AND. M->CAXRAP == "S" )
            //aux:="P/Operador:"+ntrim(M->USUMOM)+"-"+ALLTRIM(USUARIO[2])+;
            cDesc := ""
            aux := ID( "** Vender Acima do Limite de Credito **", "** Venta Mayor que Limite de Credito **" ) + Chr( 13 ) + Chr( 10 )
            aux += "Vended. : " + nTrim( ven->codven ) + "-" + ven->nomven + Chr( 13 ) + Chr( 10 )
            aux += "Cliente : " + nTrim( cli->codcli ) + "-" + cli->nomcli + Chr( 13 ) + Chr( 10 )
            aux += "Nr de dias:" + nTrim( $nDias ) + Chr( 13 ) + Chr( 10 )
            aux += "Limite Credito..:<#7>" + TIPSIM[ 1 ] + Transform( cli->LIMCLI, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + "<#1>" + Chr( 13 ) + Chr( 10 )
            aux += "Vendas nao Fatur:" + TIPSIM[ 1 ] + Transform( $nValPen, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + " Nao Passadas pelo Financeiro" + Chr( 13 ) + Chr( 10 )
            aux += "Divida Atual Chq:" + TIPSIM[ 1 ] + Transform( $nValChq, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + " A Receber " + Chr( 13 ) + Chr( 10 )
            aux += "Divida Atual Pgr:" + TIPSIM[ 1 ] + Transform( $nSaldo, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + " Vda Atual+A Receber " + Chr( 13 ) + Chr( 10 )
            aux += "Div. Final Prev.:<#7>" + TIPSIM[ 1 ] + Transform( $nSaldo + $nValPen + $nValChq, IF( TIPMOE[ 1 ] == "S", "999,999,999.99", "99,999,999,999" ) ) + "<#1>"

            Alerta( "Cliente excedeu limite de credito !!" )

            cCor := VERM + ",W+/B,W+/BG"

            NREGISTRO := 1
            IF ! ped_geral( aux, ID( "Venda Acima do Limite de Credito", "Ventas Mayor que Limite de Credito" ), IF( M->FAT <> "F", LIMITE_CRE, LIMIT1_CRE ), M->USUMOM, @nregistro, "OPER_TERM", SaveScreen( 0, 0, m->max_row - 1, m->max_col - 1 ), cDesc, cCor )
                RETURN .F.
            ENDIF
            TelaSalva()
            SalvaTela( @nRegistro,,, "CLI" + AllTrim( Transform( CLI->CODCLI, "9999999" ) ) )
            //LOGLIM(NREGISTRO,CLI->LIMCLI,$nSaldo,0,"ACIMA LIMITE CREDITO",$nDias,1)
            TelaSalva( "LIMPA" )
        ENDIF
    ENDIF

    RETURN .T.
}
 * 
 */