<?php

function AnalisaVoucher($nvendedor, $nserie, $lweb, &$nrefper = 0, &$nrefval = 0, &$creferro = '') {
    global $db;
    global $lCfRdd;
    if (!$nvendedor) {
        //NOTA VAZIA
        $creferro = "Vendedor não Informado";
        return 1;
    }

    if (!$nserie) {
        $nserie = 0;
    }
    if (!$lweb) {
        $lweb = '';
    } else {
        $lweb = "1";
    }
    $cerro = "";
    $onot = mysqli_fetch_array(mysqli_query($db, "select * from tablet" . $lweb . "_cab where vendedor=$nvendedor and serie=$nserie"));
    if (!$onot) {
        $creferro = "Nota não existe";
        return 7;
    }
    if (!$onot["loja"]) {
        $creferro = "Loja não informada";
        return 14;
    }

    if (!$onot["cliente"]) {
        $creferro = "Cliente não informado";
        return 8;
    }


    $cserie = $onot["voucher"];
    if (!$cserie) {
        //NOTA VAZIA
        $creferro = "Voucher não Informado";
        return 1;
    }

    $cserie = strtoupper(Trim($cserie));

    $odet = mysqli_fetch_array(mysqli_query($db, "select * from VOUCHER_DET where is_deleted='N' and serie='$cserie'"));
    if (!$odet) {
        $creferro = "Série não existe";
        return 2;
    }
    $ovou = mysqli_fetch_array(mysqli_query($db, "select * from VOUCHER_PRM where is_deleted='N' and codigo=" . $odet["CODIGO"]));
    if (!$ovou) {
        $creferro = "Promoção não existe";
        return 3;
    }

    if ($odet["NOTAD"] > 0) {
        // ja usado
        $creferro = "Série já usada";
        return 4;
    }

    if ($ovou["DIAS"] == 0) {
        if (Date2Unix() < $ovou["INICIOV"]) {
            // Ainda não vigente
            $creferro = "Data de inicio de uso é maior que a atual";
            return 5;
        }

        if (Date2Unix() > $ovou["FINALV"]) {
            $creferro = "Data de fim de uso menor que a atual";
            return 6;
        }
    } else {
        if (date("d/m/Y") > DateAddDays($odet["DATA"], $ovou["DIAS"], true)) {
            $creferro = "Data de fim de uso menor que a atual";
            return 6;
        }
    }

//    $onot = mysqli_fetch_array(mysqli_query($db, "select * from SAIDAS_SAI where is_deleted='N' and NOTASAI='$nnota'"));
    $caux = TRIM($ovou["LOJAS"]);
    $aaux = explode("-", $caux);
    $cBus = $onot["loja"];
    if ($caux && array_search($cBus, $aaux) === false) {
        $creferro = "Voucher não pode ser usado nesta loja";
        return 9;
    }

//    $otsai = mysqli_query($db, "select * from PROSAI_SAI where is_deleted='N' and nfsai=$nnota");
    $otsai = mysqli_query($db, "select codigo as PRSAI,quant as QUANT,valor as CUSAI from tablet" . $lweb . "_pro where vendedor=$vendedor and serie=$nserie");
    $aproduto = array();
    while ($olsai = mysqli_fetch_array($otsai)) {
        $olpro = mysqli_fetch_array(mysqli_query($db, "select * from PRODUTO_PRO where is_deleted='N' and codpro=" . $olsai["PRSAI"]));

        if (!array_key_exists($olsai["PRSAI"], $aproduto)) {
            $aproduto[$olsai["PRSAI"]] = array("GRUPOS" => $olpro["GRUPRO"], "SGRUPOS" => $olpro["SGRUPRO"], "MARCAS" => $olpro["MARCPRO"], "FORNECS" => $olpro["FORPRO"], "QUANT" => 0, "VALOR" => 0);
        }

        $aproduto[$olsai["PRSAI"]]["QUANT"] += $olsai["QUSAI"];
        $aproduto[$olsai["PRSAI"]]["VALOR"] += $olsai["QUSAI"] * $olsai["CUSAI"];
    }
    //produto existe
    $aaux = explode("-", trim($ovou["PRODUTOS"]));
    $aqua = explode("-", trim($ovou["PRODUTOQS"]));

    if (trim($ovou["PRODUTOS"]) && COUNT($aaux) > 0) {
        $aaux1 = array(0, 0);
        $k = 0;
        foreach ($aaux as $value) {
            if (array_key_exists($value, $aproduto)) {
                $aaux1[0] += $aproduto[$value]["QUANT"];
                $aaux1[1] += $aproduto[$value]["VALOR"];
                $aaux1[2] += (!$aqua[$k] ? 1 : $aqua[$k]);
                if ($aaux1[2] > $aaux1[0]) {
                    $creferro = "Quantidade do Produto obrigatório não existe";
                    return 10;
                }
                $k++;
            }
        }
        if ($k == 0) {
            $creferro = "Produto obrigatório não existe";
            return 10;
        }


        if (
                ( $ovou["ACIMA"] && $ovou["ACIMA"] > $aaux1[1] ) ||
                ( $ovou["QUANTMIN"] && $ovou["QUANTMIN"] > $aaux1[0] )
        ) {
            $creferro = "Valor/Quantidade do produto ‚ inferior ao exigido";
            return 11;
        }
        if (
                ( $ovou["QUANTMAX"] && $ovou["QUANTMAX"] < $aaux1[0])
        ) {
            $creferro = "Quantidade MÁXIMA do produto superiror ao permitido ";
            return 11;
        }
    }

    //grupo,sgrupo,marca,fornec
    $aaux1 = array("GRUPOS", "SGRUPOS", "MARCAS", "FORNECS");
    foreach ($aaux1 as $value) {
        $agrupo = array(FALSE, 0, 0);
        $aaux = explode("-", trim($ovou[$value]));
        if (trim($ovou[$value]) && count($aaux) > 0) {
            $agrupo[0] = count($aaux) > 0;
            foreach ($aproduto as $key => $apro) {
                if (array_search($apro[$value], $aaux) !== false) {
                    $agrupo[1] += $apro["QUANT"];
                    $agrupo[2] += $apro["VALOR"];
                }
            }
            if ($agrupo[1] == 0) {
                $creferro = "Sem item vendido em  " . $value . " requeridos";
                return 12;
            }
            if (
                    ( $ovou["ACIMA"] && $ovou["ACIMA"] > $agrupo[2] ) ||
                    ( $ovou["QUANTMIN"] && $ovou["QUANTMIN"] > $agrupo[1] )
            ) {

                $creferro = "Valor/Quantidade do " . $value . " é inferior ao exigido";
                return 13;
            }
            if (
                    ( $ovou["QUANTMAX"] && $ovou["QUANTMAX"] < $agrupo[1])
            ) {
                $creferro = "Quantidade MÁXIMA do produto superiror ao permitido ";
                return 11;
            }
        }
    }

    $ntotal = 0;
    $nvalosai = mysqli_fetch_row(mysqli_query($db, "select sum(quant*valor) from tablet" . $lweb . "_pro where vendedor=$nvendedor and serie=$nserie"))[0];
    if ($ovou["DESCONTO"] > 0) {
        $ntotal = $nvalosai * ( $ovou["DESCONTO"] / 100 );
    } else {
        $ntotal = $ovou["VALOR"];
    }


    $ntotal1 = $nvalosai;

    $nrefval = $ntotal;
    $nrefper = $ntotal / $ntotal1 * 100;

    return 0;
}

function UsaVoucherNota($nnota, $cserie, &$nrefper = 0, &$nrefval = 0, &$creferro = '', $lanaliza = false) {
    global $db;
    global $lCfRdd;
    if (!$nnota || !$cserie) {
        //NOTA VAZIA
        $creferro = "Nota Vazia";
        return 1;
    }

    $cserie = strtoupper(Trim($cserie));

    $odet = mysqli_fetch_array(mysqli_query($db, "select * from VOUCHER_DET where is_deleted='N' and serie='$cserie'"));
    if (!$odet) {
        $creferro = "Série não existe";
        return 2;
    }
    $ovou = mysqli_fetch_array(mysqli_query($db, "select * from VOUCHER_PRM where is_deleted='N' and codigo=" . $odet["CODIGO"]));
    if (!$ovou) {
        $creferro = "Promoção não existe";
        return 3;
    }

    if ($odet["NOTAD"] > 0) {
        // ja usado
        $creferro = "Série já usada";
        return 4;
    }


    if ($ovou["DIAS"] == 0) {
        if (Date2Unix() < $ovou["INICIOV"]) {
            // Ainda não vigente
            $creferro = "Data de inicio de uso é maior que a atual";
            return 5;
        }

        if (Date2Unix() > $ovou["FINALV"]) {
            $creferro = "Data de fim de uso menor que a atual";
            return 6;
        }
    } else {
        if (date("d/m/Y") > DateAddDays($odet["DATA"], $ovou["DIAS"], true)) {
            $creferro = "Data de fim de uso menor que a atual";
            return 6;
        }
    }

    $onot = mysqli_fetch_array(mysqli_query($db, "select * from SAIDAS_SAI where is_deleted='N' and NOTASAI='$nnota'"));
    if (!$onot) {
        $creferro = "Nota não existe";
        return 7;
    }
    if ($onot["SITSAI"] == "S") {
        $creferro = "Nota já paga";
        return 14;
    }

    if ($onot["PONTOS"] > 0) {
        $creferro = "Nota é de resgate";
        return 8;
    }

    if ($onot["BYDUBAI"] > 0) {
        $creferro = "Nota é do BYDubai";
        return 15;
    }

    $caux = TRIM($ovou["LOJAS"]);
    $aaux = explode("-", $caux);
    $cBus = $onot["LOJASAI"];
    if ($caux && array_search($cBus, $aaux) === false) {
        $creferro = "Voucher não pode ser usado nesta loja";
        return 9;
    }

    $otsai = mysqli_query($db, "select * from PROSAI_SAI where is_deleted='N' and nfsai=$nnota");
    $aproduto = array();
    while ($olsai = mysqli_fetch_array($otsai)) {
        $olpro = mysqli_fetch_array(mysqli_query($db, "select * from PRODUTO_PRO where is_deleted='N' and codpro=" . $olsai["PRSAI"]));

        if (!array_key_exists($olsai["PRSAI"], $aproduto)) {
            $aproduto[$olsai["PRSAI"]] = array("GRUPOS" => $olpro["GRUPRO"], "SGRUPOS" => $olpro["SGRUPRO"], "MARCAS" => $olpro["MARCPRO"], "FORNECS" => $olpro["FORPRO"], "QUANT" => 0, "VALOR" => 0);
        }

        $aproduto[$olsai["PRSAI"]]["QUANT"] += $olsai["QUSAI"];
        $aproduto[$olsai["PRSAI"]]["VALOR"] += $olsai["QUSAI"] * $olsai["CUSAI"];
    }
    //produto existe
    $aaux = explode("-", trim($ovou["PRODUTOS"]));
    $aqua = explode("-", trim($ovou["PRODUTOQS"]));

    if (trim($ovou["PRODUTOS"]) && COUNT($aaux) > 0) {
        $aaux1 = array(0, 0);
        $k = 0;
        foreach ($aaux as $value) {
            if (array_key_exists($value, $aproduto)) {
                $aaux1[0] += $aproduto[$value]["QUANT"];
                $aaux1[1] += $aproduto[$value]["VALOR"];
                $aaux1[2] += (!$aqua[$k] ? 1 : $aqua[$k]);
                if ($aaux1[2] > $aaux1[0]) {
                    $creferro = "Quantidade do Produto obrigatório não existe";
                    return 10;
                }
                $k++;
            }
        }
        if ($k == 0) {
            $creferro = "Produto obrigatório não existe";
            return 10;
        }


        if (
                ( $ovou["ACIMA"] && $ovou["ACIMA"] > $aaux1[1] ) ||
                ( $ovou["QUANTMIN"] && $ovou["QUANTMIN"] > $aaux1[0] )
        ) {
            $creferro = "Valor/Quantidade do produto ‚ inferior ao exigido";
            return 11;
        }
        if (
                ( $ovou["QUANTMAX"] && $ovou["QUANTMAX"] < $aaux1[0])
        ) {
            $creferro = "Quantidade MÁXIMA do produto superiror ao permitido ";
            return 11;
        }
    }

    //grupo,sgrupo,marca,fornec
    $aaux1 = array("GRUPOS", "SGRUPOS", "MARCAS", "FORNECS");
    foreach ($aaux1 as $value) {
        $agrupo = array(FALSE, 0, 0);
        $aaux = explode("-", trim($ovou[$value]));
        if (trim($ovou[$value]) && count($aaux) > 0) {
            $agrupo[0] = count($aaux) > 0;
            foreach ($aproduto as $key => $apro) {
                if (array_search($apro[$value], $aaux) !== false) {
                    $agrupo[1] += $apro["QUANT"];
                    $agrupo[2] += $apro["VALOR"];
                }
            }
            if ($agrupo[1] == 0) {
                $creferro = "Sem item vendido em  " . $value . " requeridos";
                return 12;
            }
            if (
                    ( $ovou["ACIMA"] && $ovou["ACIMA"] > $agrupo[2] ) ||
                    ( $ovou["QUANTMIN"] && $ovou["QUANTMIN"] > $agrupo[1] )
            ) {

                $creferro = "Valor/Quantidade do " . $value . " é inferior ao exigido";
                return 13;
            }
            if (
                    ( $ovou["QUANTMAX"] && $ovou["QUANTMAX"] < $agrupo[1])
            ) {
                $creferro = "Quantidade MÁXIMA do produto superiror ao permitido ";
                return 11;
            }
        }
    }

    $ntotal = 0;
    if ($ovou["DESCONTO"] > 0) {
        $ntotal = $onot["VALOSAI"] * ( $ovou["DESCONTO"] / 100 );
    } else {
        $ntotal = $ovou["VALOR"];
    }


    $ntotal1 = $onot["VALOSAI"];

    $nrefval = $ntotal;
    $nrefper = $ntotal / $ntotal1 * 100;
    if (!$lanaliza && $ntotal) {
        $cstr = "update SAIDAS_SAI set DESCSAI=$ntotal,DESCO=" . ($ntotal / $ntotal1 * 100) . ",VALOSAI=VALOSAI-$ntotal
            where is_deleted='N' and notasai=$nnota
            ";
        mysqli_query($db, $cstr);

        $cstr = "UPDATE VOUCHER_DET SET DESCONTO=$ntotal,CLIENTE=" . $onot["CLIESAI"] . ",NOTAD=$nnota,USUARIOD=1,DATAD=DATE2UNIX(NOW()),VALORD=" . ($onot["VALOSAI"] - $ntotal) . " 
            where IS_DELETED='N' AND SERIE='$cserie'";
        mysqli_query($db, $cstr);
    }

    return 0;
}

function GeraVoucherNota($annota, &$aVoucherRef = array(), &$creferro) {
    global $db;
    global $lCfRdd;
    $aVoucherRef = [];

    if (!$annota) {
        //NOTA VAZIA
        $creferro = "nota vazia";
        return 1;
    }

    $anota = [];
    if (!is_array($annota)) {
        $anota[] = $annota;
    } else {
        foreach ($annota as $value) {
            $anota[] = $value;
        }
    }


//    if (SelVal( "select count(*) from VOUCHER_DET WHERE IS_DELETED='N' AND NOTA=" + AsSql( nNota ), "N" ) > 0
    $cstr = "select count(*) from VOUCHER_DET WHERE IS_DELETED='N' AND (0 ";
    foreach ($anota as $value) {
        $cstr .= " or nota=" . $value . " or find_in_set(" . $value . ",notas) ";
    }
    $cstr .= ") ";

    if (mysqli_fetch_row(mysqli_query($db, $cstr))[0] > 0) {
        $creferro = "Nota já gerou voucher";
        return 2;
    }

    $cstr = "select p.codpro  as codigo,sum(s.qusai) as quant,sum(s.cusai*s.qusai) as preco,p.grupro  as grupo,p.sgrupro as sgrupo,p.forpro  as fornecedor,p.marcpro as marca 
        from PROSAI_SAI s inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai 
         where s.is_deleted='N' and (0";
    $alojas = [];
    foreach ($anota as $value) {
        $lnota = mysqli_fetch_array(mysqli_query($db, "select SITSAI,IS_DELETED,LOJASAI,VOUCHER FROM SAIDAS_SAI WHERE NOTASAI=$value"));
        if (!$lnota) {
            $creferro = "$value Nota não existe";
            return 4;
        }
        if ($lnota["IS_DELETED"] == "Y") {
            $creferro = "$value Nota deletada";
            return 4;
        }
        if ($lnota["SITSAI"] !== "S") {
            $creferro = "$value Nota não paga";
            return 4;
        }
        if (trim($lnota["VOUCHER"])) {
            $creferro = "$value Nota ESTÁ usando voucher";
            return 4;
        }
        $alojas[] = $lnota["LOJASAI"];
        $cstr .= " or s.nfsai=$value";
    }

    $cstr .= ") group by codpro";
    $cstr = "select codigo
        ,quant
        ,preco/quant as preco
        ,preco as total
        ,grupo
        ,sgrupo
        ,fornecedor as fornec
        ,marca 
        from (" . $cstr . ") p 
            order by codigo ";

    //PRODUTOS VENDIDOS
    $aproven = mysqli_fetch_all(mysqli_query($db, $cstr), MYSQLI_ASSOC);

    $cstr = "select * from VOUCHER_PRM 
             where inicio<=" . Date2Unix() . " and final>=" . Date2Unix() . " and suspenso='N' and is_deleted='N' 
             and (loja='' ";
    foreach ($alojas as $value) {
        $cstr .= " or locate('-" . $value . "-',concat('-',loja,'-'))>0 ";
    }
    $cstr .= ") and modo=0 and quantidemi < quantidade";
    $avouprm = mysqli_fetch_all(mysqli_query($db, $cstr), MYSQLI_ASSOC);
    if (!$avouprm) {
        $creferro = "Sem voucher a aplicar";
        return 5;
    }

    $aVoucher = [];

    foreach ($avouprm as $value) {
        $aVoucher[$value["CODIGO"]] = [FALSE, FALSE, FALSE, FALSE, FALSE];
    }


    //produto
    foreach ($aproven as $apro) {
        foreach ($avouprm as $avou) {
            if (!trim($avou[$value])) {
                $aVoucher[$avou["CODIGO"]][0] = TRUE;
                continue;
            }
            if (trim($avou["PRODUTO"]) && ($npos = array_search($apro["codigo"], explode(",", TRIM($avou["PRODUTO"])))) !== false) {
                $aaux = explode("-", trim($avou["PRODUTOQ"]));
                $nqua = $aaux[$npos];
                if ($apro["quant"] >= $nqua && $apro["total"] >= $avou["MINIMO"]) {
                    $aVoucher[$avou["CODIGO"]] = [TRUE, TRUE, TRUE, TRUE, true];
                }
            }
        }
    }

    //GRUPO
    $acampos = ["GRUPO", "SGRUPO", "MARCA", "FORNEC"];
    $i = 0;
    foreach ($acampos as $value) {
        $i++;
        foreach ($aproven as $apro) {
            foreach ($avouprm as $avou) {
                if (!trim($avou[$value])) {
                    $aVoucher[$avou["CODIGO"]][$i] = TRUE;
                    continue;
                }
                if (trim($avou[$value]) && ($npos = array_search($apro[strtolower($value)], explode(",", TRIM($avou[$value])))) !== false) {
                    if ($apro["total"] >= $avou["MINIMO"]) {
                        $aVoucher[$avou["CODIGO"]][$i] = TRUE;
                    }
                }
            }
        }
    }



    foreach ($aVoucher as $nvou => $value) {
        if (!($value[0] && $value[1] && $value[2] && $value[3] && $value[4])) {
            continue;
        }
        while (true) {
            $cvoucher = $caux = substr(num2base(rand(1000000000000, 9999999999999), 35), -8);
            if (mysqli_num_rows(mysqli_query($db, "select recno from VOUCHER_DET where serie=$cvoucher")) == 0) {
                break;
            }
        }
        if ($lCfRdd) {
            $omed = new Mediator4("VOUCHER.PRM", W_ALTERAR, '', "CODIGO=$nvou", $db);
        } else {
            $omed = new Mediator3("VOUCHER.PRM", W_ALTERAR, '', "CODIGO=$nvou", $db);
        }
        $omed->aadd("QUANTIDEMI", "QUANTIDEMI+1", true);
        $omed->grava();
        if ($lCfRdd) {
            $omed = new Mediator4("VOUCHER.DET", W_CRIAR, '', '', $db);
        } else {
            $omed = new Mediator3("VOUCHER.DET", W_CRIAR, '', '', $db);
        }
        $omed->aadd("CODIGO", $nvou);
        $omed->aadd("SERIE", $cvoucher);
        $omed->aadd("NOTA", $anota[0]);
        $omed->aadd("NOTAS", implode(",", $anota));
        $omed->aadd("USUARIO", $_SESSION["usuario"] + 0);
        $omed->aadd("DATA", Date2Unix());
        $omed->grava();
        $aVoucherRef[] = $cvoucher;
    }


    if (count($aVoucherRef) == 0) {
        $creferro = "NENHUM VOUCHER ATIVO";
        return 5;
    }
    return 0;
}
