<?php

session_start();

//$sid = $_SESSION["sid"];
$ausuario = VeSession("usuario");//$_SESSION["usuario"];
$ntempo = VeSession("tempo");//$_SESSION["tempo"];

require_once '../inc/config.php';

$ntempo = 60 * 60 * 12;  //12 horas para timeout

$operador = $ausuario;
$terminal = 800 + $ausuario;

$aret["erro"] = "00";
$aret["cerro"] = "";
$aret["tempo"] = date("H:i:s");

if (!($db = conecta())) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Erro conectando à base de dados";
    echo json_encode($aret);
    return;
//    echo "00-Erro interno no servidor";
//    return;
}

$sid = pegavar("sid");
$otable = mysqli_query($db, "select usuario,terminal,time_to_sec(timediff(now(),concat(data_atu,' ',hora_atu) )) as tempo from autoriza_sid where sid='$sid'");
if (mysqli_num_rows($otable) == 0 || !$sid) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário ingressou em outro local\nou\nDesconectado pelo servidor";
    echo json_encode($aret);
    return;
//    echo "01-Identificador de operação inválido";
//    return;
}
$olinha = mysqli_fetch_array($otable);
if ($olinha["tempo"] > $ntempo) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Tempo expirado. Sem uso";
    echo json_encode($aret);
    return;
//    echo "02-Tempo expirado sem uso";
//    return;
}
$operador = $olinha["usuario"];
$terminal = $olinha["terminal"];

$otable = mysqli_query($db, "select * from autoriza1_ope where usuario=$operador");
$olinha = mysqli_fetch_array($otable);

if (mysqli_num_rows($otable) == 0 || $olinha["geral"] > 0) {
    $otable = mysqli_query($db, "select * from autoriza1_ope where usuario=0");
    $olinha = mysqli_fetch_array($otable);
    /*
      $aret["erro"] = "80";
      $aret["cerro"] = "Usuário sem acesso configurado";
      echo json_encode($aret);
      return;
     */
}

if ($olinha["bloqueado"]) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário está Bloqueado";
    echo json_encode($aret);
    return;
}
if (date("H:i:s") < $olinha["horai"] || date("H:i:s") > $olinha["horaf"]) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário sem acesso permitido neste horário";
    echo json_encode($aret);
    return;
//    echo "04-usuário sem acesso permitido neste horário";
//    return;
}

if (strpos($olinha["semanas"], (date("w") + 1) . "") === false) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário dem acesso permitido neste dia";
    echo json_encode($aret);
    return;
//    echo "05-Usuário sem acesso permitido neste dia";
//    return;
}

$aret["consulta"]=$olinha["consulta"];
$aret["con_u"]=$olinha["con_u"];
$aret["con_a"]=$olinha["con_a"];
$aret["con_b"]=$olinha["con_b"];
$aret["con_c"]=$olinha["con_c"];
$aret["con_t"]=$olinha["con_t"];

mysqli_query($db, "update autoriza_sid set data_atu=current_date(),hora_atu=current_time() where sid='$sid'");

$aaut = array();

if (pegavar("atualiza") == 1) {
    $cterminal = str_pad($terminal, 3, '0', STR_PAD_LEFT) . "-";
    $coperador = str_pad($operador, 3, '0', STR_PAD_LEFT) . "-";

    $caux = "select a.recno,a.motivo_sol,date_format(concat(a.data_sol,' ',a.hora_sol),'%d/%m %H:%i:%s') as data_sol,a.hora_sol,a.term_sol,a.oper_sol,o.nome as coperador
,CONVERT(a1.MEMO,char) AS complement
,CONVERT(a2.MEMO,char) AS texto
FROM AUTORIZA_AUT a 
inner join OPERADOR_OPE o on o.is_deleted='N' and a.OPER_SOL=o.CODIGO
left join AUTORIZA_AUT_MEMO a1 ON a1.recno=a.recno and a1.COL_NAME='COMPLEMENT'
left join AUTORIZA_AUT_MEMO a2 ON a2.recno=a.recno and a2.COL_NAME='TEXTO'

where a.is_deleted='N'
        and a.ter_autznd=0
        and (
	
	     (
		(TRIM(a.term_ped)='' and TRIM(a.oper_ped)='')
		or a.term_ped like '%$cterminal%' 
		or a.oper_ped like '%$coperador%'
	     )
	     and (a.ter_autznd=0 or  a.ter_autznd=79)
	     and a.autorizado=''
	) ";
//inner join OPERADOR_OPE o on o.bloq_vdas!='S' and o.is_deleted='N' and a.OPER_SOL=o.CODIGO
//	     and a.term_sol!=79
    if (pegavar("recno")) {
        $caux .= " and a.recno=" . pegavar("recno");
    }

    $caux .= " order by a.data_sol,a.hora_sol ";

    $otable = mysqli_query($db, $caux);
    if (mysqli_num_rows($otable) == 0) {
        $aret["aut"] = $aaut;
        echo json_encode($aret);
        return;
//        echo ""99"-";
//        return;
    }
//    $caux = "";
    while ($olinha = mysqli_fetch_array($otable)) {
        /*
          $caux = $caux . $olinha["data_sol"] . "|" . $olinha["hora_sol"] . "|" .
          $olinha["motivo_sol"] . "|" .
          $olinha["oper_sol"] . "|" .
          FirstUpper($olinha["coperador"]) . "|" .
          $olinha["term_sol"] . "|" .
          base64_encode($olinha["complement"]) . "|" .
          base64_encode($olinha["texto"]) . "|" .
          $olinha["recno"] .
          "}";
         */
        $ccom = str_replace(chr(13) . chr(10), "<br>", iconv("cp850", "utf8", $olinha["complement"]));
        $ccom = str_replace(chr(10), "<br>", $ccom);
        $ccom = str_replace(chr(141), "<br>", $ccom);
        $ccom = LimpaChar($ccom);
        $ccom = str_replace("__", "_", $ccom);
        $ccom = str_replace("--", "-", $ccom);

        $ctex = str_replace(chr(13) . chr(10), "<br>", $olinha["texto"]);
        $ctex = str_replace(chr(10), "<br>", $ctex);
        $ctex = str_replace(chr(141), "<br>", $ctex);
        $ctex = LimpaChar($ctex);
        $ctex = str_replace("__", "_", $ctex);
        $ctex = str_replace("--", "-", $ctex);

        $aaut[] = array("data_sol" => $olinha["data_sol"], "hora_sol" => $olinha["hora_sol"]
            , "motivo_sol" => iconv("cp850", "utf8", $olinha["motivo_sol"]), "oper_sol" => $olinha["oper_sol"]
            , "coperador" => iconv("cp850", "utf8", FirstUpper($olinha["coperador"])), "term_sol" => $olinha["term_sol"]
            , "complement" => iconv("cp850", "utf8", $ccom), "texto" => iconv("cp850", "utf8", $ctex)
            , "recno" => $olinha["recno"]);
    }

    $aret["aut"] = $aaut;
    $aret["tempo"] = date("H:i:s");


    $aaux = array("PRODUTO:", "PRODUTO :", "Produto:", "Produto :");
    $npro = '';
    $ncli = '';
    foreach ($aaux as $value) {
        if (strpos($ccom, $value)) {
            $npro = substr($ccom, strpos($ccom, $value) + strlen($value));
            $npro = substr($npro, 0, strpos($npro, "-"));
            break;
        }
    }
    $aret["historico"]='';
    if ($npro) {
        $aaux = array("CLIENTE:", "CLIENTE :", "Cliente:", "Cliente :");
        $ncli = '';
        foreach ($aaux as $value) {
            if (strpos($ccom, $value)) {
                $ncli = substr($ccom, strpos($ccom, $value) + strlen($value));
                $ncli = substr($ncli, 0, strpos($ncli, "-"));
                break;
            }
        }





        $nproduto = $npro;
        $ncliente = $ncli;
        /*
        define("SAIDAS_COP", 405);
        $csql1 = "select c.SITOPG
FROM OPEGRUPO_OPE c
inner join OPERADOR_OPE o on o.is_deleted='N' and o.codigo=" . $operador . " and c.codopg=(cifra(o.grupo)+0)
where c.is_deleted='N' and opeopg=" . SAIDAS_COP;

        $ltodos = (mysqli_fetch_row(mysqli_query($db, $csql1))[0]) == "X";
         * 
         */
        $csql = "select s.qusai as quant,s.cusai as valor,c.codcli,c.nomcli,n.datasai as data
from PROSAI_SAI s
inner join SAIDAS_SAI n on n.is_deleted='N' and n.recno=s.nfsai
inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai AND c.codcli!=0
where s.is_deleted='N' and s.prsai=$nproduto";
        /*
        if (!$ltodos) {
            $csql .= " and n.vendsai=$vendedor";
        }
         
         */
        $csql .= " order by s.recno desc limit 30";
        $otab = mysqli_query($db, $csql);
        
        
        $cret='<br><table class="table table-striped" style="font-size: .9em;"><tr><th colspan="4" class="text-center bg-primary">Vendas Anteriores</th></tr>
            <tr><th>Qua</th><th>Preço</th><th>Data</th><th>Cliente</tr>';
        
        $aret["preco"] = array();
        while ($olin = mysqli_fetch_array($otab)) {
            $cclass="";
            if ($ncli==$olin["codcli"]){
                $cclass=" bg-success text-success";
            }
            $cret.='<tr><td class="text-center">'.number_format($olin["quant"],0)."</td>";
            $cret.='<td class="text-right '.$cclass.'">'.number_format($olin["valor"],2)."</td>";
            $cret.='<td class="text-center">'.sql2data($olin["data"])."</td>";
            $cret.='<td class="text-left">'.$olin["codcli"]."-".$olin["nomcli"]."</td></tr>";
        }

        $cret.="</table>";

        $aret["historico"] = $cret;
    }

    echo json_encode($aret);

    return;
    /*    if (strlen($caux) == 0) {
      echo ""99"-";
      } else {
      echo "98-" . $caux;
      }
      return;
     */
} else if (pegavar("atualiza") == 2 || pegavar("atualiza") == 3) {
    $recno = pegavar("recno");

    $caux = "select * FROM AUTORIZA_AUT where recno=$recno";
    $otable = mysqli_query($db, $caux);
    if (mysqli_num_rows($otable) == 0) {
        $aret["erro"] = "99";
        $aret["cerro"] = "Autorização realizada por outro terminal";
        echo json_encode($aret);
        return;
//        echo "28-Autorização já realizada em outro terminal ";
//        return;
    }
    $olinha = mysqli_fetch_array($otable);
    if ($olinha["DELETED"] == 'Y' || ($olinha["TER_AUTZND"] > 0 && $olinha["TER_AUTZND"] != $terminal)) {
        $aret["erro"] = "99";
        $aret["cerro"] = "Autorização sendo realizada por aoutro terminal";
        echo json_encode($aret);
        return;
    }
    if ($olinha["DATA_AUT"] > '1000-01-01') {
        $aret["erro"] = "99";
        $aret["cerro"] = "Autorização já realizada.";
        echo json_encode($aret);
        return;
    }
    $nnivel = cifra($olinha["NIVEL"]);
    if (substr($nnivel, 0, 8) != $olinha["HORA_SOL"]) {
//        echo "26-Nível solicitado violado";
        $caux = "update AUTORIZA_AUT set ter_autznd=$terminal,autorizando='Nivel Solicitado Violado',data_aut=current_date(),hora_aut=current_time()
            where recno=" . pegavar("recno");

        mysqli_query($db, $caux);
        $aret["erro"] = "99";
        $aret["cerro"] = "Nível Solicitado Violado";
        echo json_encode($aret);
        return;
        //       return;
    }


    $nnivel = substr($nnivel, 8);

//    $otabope = mysqli_query($db, "select * from OPERADOR_OPE where bloq_vdas!='S' and is_deleted='N' and codigo=$operador ");
    $otabope = mysqli_query($db, "select * from OPERADOR_OPE where is_deleted='N' and codigo=$operador ");
    $olinope = mysqli_fetch_array($otabope);
    $ngrupo = cifra($olinope["GRUPO"]);
    $otabgru = mysqli_query($db, "select * from OPEGRUPO_OPE where is_deleted='N' and codopg=$ngrupo and opeopg=$nnivel");

    $olingru = mysqli_fetch_array($otabgru);
    if ($olingru["SITOPG"] != 'X') {
//        echo "25-Acesso Negado";
//        return;
        $aret["erro"] = "99";
        $aret["cerro"] = "Acesso negado";
        echo json_encode($aret);
        return;
    }
    $chora = date("H:i:s");
    $caux = "update AUTORIZA_AUT set ter_autznd=$terminal,registro=recno,term_aut=$terminal,data_aut=current_date(),hora_aut='$chora',oper_aut=1,autorizado='";
    $caux .= cifra(date(Ymd) . (pegavar("atualiza") - 2) . $chora);
    $caux .= "',motivo_aut='" . pegavar("obs") . "'";

    $caux .= " where recno=$recno";
    mysqli_query($db, $caux);

//    echo "29-Autorização " . (PegaVar("atualiza") == 2 ? "Negada" : "Concedida");
//    return;
    $aret["aut"] = (PegaVar("atualiza") == 2 ? "Negada" : "Concedida");
    $aret["erro"] = "99";
    $aret["cerro"] = "Autorização " . (PegaVar("atualiza") == 2 ? "NEGADA" : "CONCEDIDA");
    echo json_encode($aret);
    return;
}
?>
