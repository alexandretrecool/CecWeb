<?php

session_start();

require_once '../inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";
$aret["tempo"] = date("H:i:s");

$ntempo = 60 * 60 * 12;  //12 horas para timeout

$operador = VeSession("usuario");//$_SESSION["usuario"];
$terminal = 800+$operador;//800 + $_SESSION["usuario"];



$codigo = trim(strtoupper(PegaVar("codigo")));
$modo = PegaVar("modo");
$semsaldo = PegaVar("saldo");

$nserie = pegavar('serie') + 0;
$nvendedor = $vendedor;
$lorc = PegaVar("orcamento") == "true";
$nlojapre = pegavar("lj_preco");

$db = conecta();
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = "Erro acessando servidor";
    echo json_encode($aret);
    return;
}


$sid = pegavar("sid");
$otable = mysqli_query($db, "select usuario,terminal,time_to_sec(timediff(now(),concat(data_atu,' ',hora_atu) )) as tempo from autoriza_sid where sid='$sid'");
if (mysqli_num_rows($otable) == 0 || !$sid) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário ingressou em outro local\nou\nDesconectado pelo servidor";
    echo json_encode($aret);
    return;
//    echo "01-Identificador de operação inválido";
//    return;
}
$olinha = mysqli_fetch_array($otable);
if ($olinha["tempo"] > $ntempo) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Tempo expirado. Sem uso";
    echo json_encode($aret);
    return;
//    echo "02-Tempo expirado sem uso";
//    return;
}
$operador = $olinha["usuario"];
$terminal = $olinha["terminal"];
$otable = mysqli_query($db, "select * from autoriza1_ope where usuario=$operador");
$olinha = mysqli_fetch_array($otable);

if (mysqli_num_rows($otable) == 0 || $olinha["geral"] > 0) {
    $otable = mysqli_query($db, "select * from autoriza1_ope where usuario=0");
    $olinha = mysqli_fetch_array($otable);
    /*
      $aret["erro"] = "80";
      $aret["cerro"] = "Usuário sem acesso configurado";
      echo json_encode($aret);
      return;
     */
}

if ($olinha["bloqueado"]) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário está Bloqueado";
    echo json_encode($aret);
    return;
}
if (date("H:i:s") < $olinha["horai"] || date("H:i:s") > $olinha["horaf"]) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário sem acesso permitido neste horário";
    echo json_encode($aret);
    return;
//    echo "04-usuário sem acesso permitido neste horário";
//    return;
}

if (strpos($olinha["semanas"], (date("w") + 1) . "") === false) {
    $aret["erro"] = "80";
    $aret["cerro"] = "Usuário dem acesso permitido neste dia";
    echo json_encode($aret);
    return;
//    echo "05-Usuário sem acesso permitido neste dia";
//    return;
}


mysqli_query($db, "update autoriza_sid set data_atu=current_date(),hora_atu=current_time() where sid='$sid'");

$aaut = array();

if ($modo == "CONSULTA_PRO") {
    $nlimiteconsulta = 200;


    $ncodigo = pegavar("ncodigo");
    if (!$codigo && !$ncodigo) {
        $aret["tabela"] = '';
        echo json_encode($aret);
        return;
    }
//leitura do qrcode
    if (strlen($codigo) == 8 && substr($codigo, 0, 1) == "*" && substr($codigo, -1) == "*") {
        $cetq = substr($codigo, 1);
        $cetq = substr($cetq, 0, strlen($cetq) - 1);
        $otabetq = mysqli_query($db, "select proetq as codigo from LOCALETQ_PRO WHERE IS_DELETED='N' AND REFER='$cetq'");
        if (mysqli_num_rows($otabetq) == 0) {
            $aret["erro"] = "99";
            $aret["cerro"] = "Etiqueta não localizada";
            echo json_encode($aret);
            return;
        }
        $ncodigo = mysqli_fetch_row($otabetq)[0];
    }
//grade
//1216943-1031-1032
    $aret["grade"] = 0;
    $aaux = explode("-", $codigo);

    $lgrade1 = $aaux[1] > 0;
    $lgrade2 = $aaux[2] > 0;

    if ($lgrade1 || $lgrade2) {
        if ($lgrade1) {
            $ncodigo = $aaux[0];
            if (!vedigito($ncodigo)) {
                $aret["erro"] = "99";
                $aret["cerro"] = "Código inválido na grade. $ncodigo";
                echo json_encode($aret);
                return;
            }
            $nseq1 = $aaux[1];
            $nseq2 = $aaux[2];
        } else {
            $ncodigo = $aaux[0];
            if (!vedigito($ncodigo)) {
                $aret["erro"] = "99";
                $aret["cerro"] = "Código inválido na grade. $ncodigo";
                echo json_encode($aret);
                return;
            }
            $nseq1 = $aaux[1];
            $nseq2 = $aaux[2];
        }
    } else {
        $lgrade1 = (strlen($codigo) == 17 && substr($codigo, 0, 1) == "#" && substr($codigo, -1) == "#");
        $lgrade2 = ( strlen($codigo) == 17 && substr($codigo, 7, 1) == "-" && substr($codigo, 12, 1) == "-" );

        if ($lgrade1 || $lgrade2) {
            if ($lgrade1) {
                $ncodigo = substr($codigo, 1, 9);
                if (!vedigito($ncodigo)) {
                    $aret["erro"] = "99";
                    $aret["cerro"] = "Código inválido na grade. $ncodigo";
                    echo json_encode($aret);
                    return;
                }
                $nseq1 = substr($codigo, 1 + 9, 3);
                $nseq2 = substr($codigo, 1 + 9 + 3, 3);
            } else {
                $ncodigo = substr($codigo, 0, 7);
                if (!vedigito($ncodigo)) {
                    $aret["erro"] = "99";
                    $aret["cerro"] = "Código inválido na grade. $ncodigo";
                    echo json_encode($aret);
                    return;
                }
                $nseq1 = substr($codigo, 8, 4);
                $nseq2 = substr($codigo, 13, 4);
            }
        }
    }

    if ($lgrade1 || $lgrade2) {
        $ncodigo = tiradigito($ncodigo);
        $cstr2 = "select sum(estoque) as saldot,sum(if(loja='$loja',estoque,0)) as saldo,val1,val2 from (
            select 
            g.lojgrade as loja,l.nomemp as cloja
            ,g1.tipogrd as val1
            ,if(g.seqgrade1=g.seqgrade2,'',g2.tipogrd) as val2
            ,g.estoque,g.fpgloc as falta
            from ESTLJGRA_PRO g
            inner join EMPRESA_EMP l on l.is_deleted='N' and l.codemp=g.lojgrade
            inner join GRADESEQ_PRO g1 on g1.recno=g.seqgrade1
            inner join GRADESEQ_PRO g2 on g2.recno=g.seqgrade2
            where g.is_deleted='N' 
            and g.prograde=$ncodigo
            and g.seqgrade1='$nseq1'
            and g.seqgrade2='$nseq2'
            and g.estoque>0
            order by val1,val2,g.lojgrade
            ) l"
        ;
        $otab = mysqli_query($db, $cstr2);
        $olin = mysqli_fetch_row($otab);
        if (mysqli_num_rows($otab) == 0 || $olin[0] == 0) {
            $aret["erro"] = "99";
            $aret["cerro"] = "GRADE Inválida ou sem saldo";
            echo json_encode($aret);
            return;
        }
        $aret["grade"] = 1;
        $aret["seq1"] = $nseq1;
        $aret["seq2"] = $nseq2;
        $aret["codigo"] = $ncodigo;
        $aret["gsaldo"] = $olin[1];
        $aret["gsaldot"] = $olin[0];
        $aret["val1"] = $olin[2];
        $aret["val2"] = $olin[3];
    }

    $acodigos = explode(" ", $codigo);
    $cstr = "";
//    $cstr .= "select p.*,if(isnull(gp1.codgpm),0,gp1.codgpm) as proquant from ( ";
    $cstr .= "select p.*,if(isnull(gq.grugpm),0,gq.grugpm) as proquant from ( ";
    $cstr .= "select * from ( ";

    $olcfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG"));
    $olistcli = mysqli_fetch_array(mysqli_query($db, "select c.listcli,t.loja from CLIENTE_CLI c 
        inner join  tablet_cab t on t.serie='$nserie' and t.vendedor=$vendedor and t.cliente=c.codcli
        where c.is_deleted='N'"));
    
    $aret["erro"]=99;
    $aret["cerro"]= mysqli_error($db);
    echo json_encode($aret);
    return;
    $clistcli = $olistcli[0];
    if ($nlojapre){
        $nloja_precos=$nlojapre;
    }else{
        $nloja_precos=$olistcli[1];
    }
    $cprecoa = "preven";
    $cprecob = "preco3";
    $cprecoc = "premin";
    $cprecot = "preatac";
    if ($clistcli == "A") {
        $cprecob = $cprecoa;
        $cprecoc = $cprecoa;
        $cprecot = $cprecoa;
    } else if ($clistcli == "B") {
        $cprecoa = $cprecob;
        $cprecoc = $cprecob;
        $cprecot = $cprecob;
    } else if ($clistcli == "C") {
        $cprecoa = $cprecoc;
        $cprecob = $cprecoc;
        $cprecot = $cprecoc;
    } else if ($clistcli == "D") {
        $cprecoa = $cprecot;
        $cprecob = $cprecot;
        $cprecoc = $cprecot;
    }
    if ($olcfg["PROPOST"] != 'S') { // nao pegar do local_loc
        $cstr .= "select
 p.codpro as codigo
,if(cf.maxiqvda!='S' or p.promo_p!='S' or p.maxiqven=0,9999999,p.maxiqven) as quantmax
,if(p.nomelong='',p.nompro,p.nomelong) as nome
,p.$cprecoc as minimo
,p.$cprecoa as venda

,p.cusmed as custo
,p.$cprecoa  as precoa
,p.$cprecob  as precob
,p.$cprecoc  as precoc
,p.$cprecot as precot

,p.grupro,p.sgrupro,p.marcpro,p.gruesp
,if(isnull(w.codigo),0,w.nimagem) as nimagem
,if(isnull(w.codigo) or w.nomeweb='' ,0,1) as detalhe
,p.estoque as estoque
,p.fpgpro as falta
,p.gradepro as gradepro
,if(p.promo_p='S' and p.preco5>0 and cf.regra_prm='S' and !isnull(gp.codgpm) ,p.preco5,0) as preco5
,p.codpromo
,p.kitpro
,p.corpro
,if((p.estoque<0 AND cf.CORNEG='S') or (p.estoque<p.estomin AND p.ESTOMIN<>0),9
   ,IF(p.MTJPRO='S' OR p.KITPRO='S',7
   ,IF(p.CORPRO=2 and p.promo_p<>'S',3
   ,IF(p.CORPRO=3 and p.promo_p<>'S',4
   ,IF(p.CORPRO=4 and p.promo_p<>'S',8
   ,if(p.decreto='N' and cf.connot='S' and cf.cadcli1='N' and p.promo_p<>'S',6
   ,if(p.CORPRO=5 and p.promo_p<>'S',18
   ,if(p.corpro=6 and p.promo_p<>'S',15
   ,IF(p.corpro=7 and p.promo_p<>'S',16
   ,if(p.corpro=8 and p.promo_p<>'S',21
   ,if(p.promo_p='S',19
   ,1))))))))))) as corpro1

from PRODUTO_PRO p
inner join CONFIG cf on cf.recno=1
left join PRODUTOS_WEB w on w.is_deleted='N' and w.codigo=p.codpro
left join GRUPROMO_GPM gp on gp.is_deleted='N' and p.codpromo=gp.codgpm  and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' 

where p.is_deleted='N' and p.ativo='S' ";
    } else {
        $cstr .= "select
 p.codpro as codigo
,if(cf.maxiqvda!='S' or p.promo_p!='S' or p.maxiqven=0,9999999,p.maxiqven) as quantmax
,if(p.nomelong='',p.nompro,p.nomelong) as nome

,if(isnull(l.locloc) or l.$cprecoc=0,p.$cprecoc,l.$cprecoc)  as minimo
,if(isnull(l.locloc) or l.$cprecoa=0,p.$cprecoa,l.$cprecoa)  as venda

,p.cusmed as custo
,if(isnull(l.locloc) or l.$cprecoa=0,p.$cprecoa,l.$cprecoa)  as precoa
,if(isnull(l.locloc) or l.$cprecob=0,p.$cprecob,l.$cprecob)  as precob
,if(isnull(l.locloc) or l.$cprecoc=0,p.$cprecoc,l.$cprecoc)  as precoc
,if(isnull(l.locloc) or l.$cprecot=0,p.$cprecot,l.$cprecot)  as precot

,p.grupro,p.sgrupro,p.marcpro,p.gruesp
,if(isnull(w.codigo),0,w.nimagem) as nimagem
,if(isnull(w.codigo) or w.nomeweb='' ,0,1) as detalhe
,p.estoque as estoque
,p.fpgpro as falta
,p.gradepro as gradepro
,if(p.promo_p='S' and p.preco5>0 and cf.regra_prm='S' and !isnull(gp.codgpm) ,p.preco5,0) as preco5
,p.codpromo
,p.kitpro
,p.corpro
,if((p.estoque<0 AND cf.CORNEG='S') or (p.estoque<p.estomin AND p.ESTOMIN<>0),9
   ,IF(p.MTJPRO='S' OR p.KITPRO='S',7
   ,IF(p.CORPRO=2 and p.promo_p<>'S',3
   ,IF(p.CORPRO=3 and p.promo_p<>'S',4
   ,IF(p.CORPRO=4 and p.promo_p<>'S',8
   ,if(p.decreto='N' and cf.connot='S' and cf.cadcli1='N' and p.promo_p<>'S',6
   ,if(p.CORPRO=5 and p.promo_p<>'S',18
   ,if(p.corpro=6 and p.promo_p<>'S',15
   ,IF(p.corpro=7 and p.promo_p<>'S',16
   ,if(p.corpro=8 and p.promo_p<>'S',21
   ,if(p.promo_p='S',19
   ,1))))))))))) as corpro1

from PRODUTO_PRO p
inner join CONFIG cf on cf.recno=1
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro and l.locloc=$nloja_precos
left join PRODUTOS_WEB w on w.is_deleted='N' and w.codigo=p.codpro
left join GRUPROMO_GPM gp on gp.is_deleted='N' and p.codpromo=gp.codgpm  and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' 

where p.is_deleted='N' and p.ativo='S' ";
        
    }
    if ($ncodigo) {

        $cstr .= " and p.codpro=$ncodigo";
        $cstr .= ' group by p.codpro ) p ';
    } else if (PegaVar("ckcodigo") == "true") {
        if (!vedigito(PegaVar("codigo"))) {
            $aret["erro"] = "99";
            $aret["cerro"] = "Digito verificador inválido";
            echo json_encode($aret);
            return;
        }
        $cstr .= " and (p.codpro=" . tiradigito(pegavar("codigo"));
        $cstr .= " or p.barra=" . pegavar("codigo");
        $cstr .= ') group by p.codpro ) p ';
    } else {
        foreach ($acodigos as $value) {
            $cstr .= " and (0 ";
            $caux = str_replace(range(0, 9), "", $value);
            if (strlen($caux) == 0) {
                $cstr .= " or p.codpro='$value' or p.barra='$value' ";
            }
            $cstr .= " or p.nompro like '%$value%'  or p.nomelong like '%$value%' ";
            $cstr .= ") ";
        }
        $cstr .= " group by p.codpro) p ";
        if ($semsaldo !== "true") {
            $cstr .= " where p.estoque>0  ";
        }
    }

    $cstr .= " order by p.nome  limit $nlimiteconsulta ) p ";
    $cstr .= "
left join
(select gq.* from 
PROMOQUA_PRO gq 
inner join GRUPROMO_GPM gp1 on gq.grugpm=gp1.codgpm and gp1.is_deleted='N' and current_date()>=gp1.inigpm and current_date()<=gp1.fimgpm and gp1.ativa='S' and !find_in_set(1,replace(gp1.excljgpm,'-',','))

where gq.is_deleted='N' 
) gq on (     if(gq.grupo>0  ,gq.grupo  =p.grupro ,1) 
  and if(gq.marca>0  ,gq.marca  =p.marcpro,1) 
  and if(gq.produto>0,gq.produto=p.codigo ,1) 
  and if(gq.sgrupo>0 ,gq.sgrupo =p.sgrupro,1) 
  and if(gq.gruesp>0 ,gq.gruesp =p.gruesp,1) 
	)

group by p.codigo
order by p.nome
        
";
    $otabpro = mysqli_query($db, $cstr);

    /*
      $aret["erro"] = 99;
      $aret["cerro"] = mysqli_num_rows($otabpro);

      echo json_encode($aret);
      return;
     */

    $aprod = array();

    while ($olinpro = mysqli_fetch_array($otabpro)) {
        $olinpro["nome"] = LimpaChar($olinpro["nome"]);
        if ($olinpro["preco5"] > 0) {
            $olinpro["minimo"] = $olinpro["preco5"];
            $olinpro["venda"] = $olinpro["preco5"];
        }
        //kit
        if ($olinpro["kitpro"] == "S") {
            $cstr = "
        SELECT min(estoque) as estoque from (
            SELECT codpro,floor(estoque/quakit) AS estoque from (
                select p.codpro,p.estoque,k.quakit
                from PROKIT_PRO k 
                inner join PRODUTO_PRO p on p.is_deleted='N' and k.prokit=p.codpro
                where k.is_deleted='N' and k.codkit=" . $olinpro["codigo"] . "
                group by k.prokit
            ) k
        ) k ";
            $olink = mysqli_fetch_array(mysqli_query($db, $cstr));
            $olinpro["estoque"] = $olink["estoque"];
        }

        $aaux = array();
        $i = 0;
        foreach ($olinpro as $key => $value) {
            $i++;
            if ($i % 2 == 1) {
                continue;
            }
            $aaux[$key] = $value;
        }
        $aprod[] = $aaux;
    }
    $aret["quant"] = mysqli_num_rows($otabpro);


    $aret["prod"] = $aprod;
}
if ($modo == "SALDO_LOJA") {
    $codigo = PEGAVAR("codigo");
    $cstr .= "select l.locloc as codigo,e.nomemp as nome,l.qualoc as saldo,l.fpgloc as falta from ( select l.locloc,l.qualoc,l.fpgloc 
from PRODUTO_PRO p
inner join CONFIG cf on cf.recno=1
left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
where p.is_deleted='N' and p.codpro=$codigo
             group by l.locloc) l
            inner join EMPRESA_EMP e on e.is_deleted='N' and e.codemp=l.locloc
            where (l.qualoc!=0 or l.fpgloc!=0)
            ";

    $otab = mysqli_query($db, $cstr);
    $nsize = ".9";
    $corpo = '<table class="table trable-bordered" style="font-size: ' . $nsize . 'em"><tr><th>Loja</th><th  class="text-right">Saldo</th><th  class="text-right">Pend.</th></tr>';
    $nqua = 0;
    $npen = 0;
    while ($olin = mysqli_fetch_array($otab)) {
        $nqua += $olin["saldo"];
        $npen += $olin["falta"];
        $corpo .= "<tr><td>" . $olin["codigo"] . "-" . $olin["nome"] . '</td><td class="text-right">' . my_number_format($olin["saldo"], 0) . '</td><td class="text-right">' . my_number_format($olin["falta"], 0) . "</td></tr>";
    }
    $corpo .= '<tr><th class="text-right">Total:</th><th class="text-right">' . my_number_format($nqua, 0) . '</th><th class="text-right">' . my_number_format($npen, 0) . "</th></tr>";
    $corpo .= "</table>";
    $aret["corpo"] = $corpo;
    echo json_encode($aret);
    return;
}

if ($modo == "VE_GRADE") {
    $codigo = pegavar("codigo");
    $cstr = "select 
p.codpro as codigo        
,g.lojgrade as loja,l.nomemp as cloja
,g1.tipogrd as val1
,if(g.seqgrade1=g.seqgrade2,'',g2.tipogrd) as val2
,g.estoque,g.fpgloc as falta
,g.seqgrade1 as seq1,g.seqgrade2 as seq2,p.preven as venda,p.premin as minimo

,p.preven  as precoa
,p.preco3  as precob
,p.premin  as precoc
,p.preatac as precot


from ESTLJGRA_PRO g
inner join PRODUTO_PRO p on p.is_deleted='N' and  p.codpro=g.prograde
inner join EMPRESA_EMP l on l.is_deleted='N' and l.codemp=g.lojgrade
inner join GRADESEQ_PRO g1 on g1.recno=g.seqgrade1
inner join GRADESEQ_PRO g2 on g2.recno=g.seqgrade2
where g.is_deleted='N' 
and g.prograde=$codigo
and g.estoque>0
order by val1,val2,g.lojgrade";
    $otab = mysqli_query($db, "select loja,cloja from ($cstr) l group by loja");
    $alojas = array();
    $cstr1 = "select val1,val2,seq1,seq2,minimo,venda ";

    $aretc = array('', '');
    while ($olin = mysqli_fetch_array($otab)) {
        $alojas[$olin["loja"]] = array($olin["loja"], $olin["cloja"]);
        $cstr1 .= ",sum(if(loja='" . $olin["loja"] . "',estoque,0)) as s" . $olin["loja"];
        $cstr1 .= ",sum(if(loja='" . $olin["loja"] . "',falta,0))   as p" . $olin["loja"];
        $aretc[] = "Loja " . $olin["loja"];
    }
    $cstr1 .= " from ( $cstr ) l group by val1,val2 order by val1,val2 ";


    $otab = mysqli_query($db, $cstr1);
    $aretp = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $aaux = array($olin["val1"], $olin["val2"], $olin["seq1"], $olin["seq2"], $olin["minimo"], $olin["venda"]);
        //$otabtem = mysqli_query($db, "select quant from tablet" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor and codigo=$codigo and seq1='" . $olin["val1"] . "' and seq2='" . $olin["val2"] . "'");
        //$aaux[] = mysqli_num_rows($otabtem);
        $aaux[] = 0;

        foreach ($alojas as $key => $value) {
            $nsal = round($olin["s" . $key], 0);
            $npen = round($olin["p" . $key], 0);
            $aaux[] = ($nsal ? $nsal : "") . ($npen ? "/$npen" : "");
        }
        $aretp[] = $aaux;
    }
    $olinpro = mysqli_fetch_array(mysqli_query($db, "select if(nomelong='',nompro,nomelong) as nompro,gradepro from PRODUTO_PRO where is_deleted='N' and codpro=$codigo"));
    $aret["nome"] = limpachar($olinpro[0]);
    $aaux = explode("-", $olinpro[1]);
    if (trim($aaux[0])) {
        $aretc[0] = mysqli_fetch_row(mysqli_query($db, "select nomgrade from GRADE_PRO where is_deleted='N' and codgrade=" . $aaux[0]))[0];
    }
    if (trim($aaux[1])) {
        $aretc[1] = mysqli_fetch_row(mysqli_query($db, "select nomgrade from GRADE_PRO where is_deleted='N' and codgrade=" . $aaux[1]))[0];
    }
    //$aretc[1]=$aaux[1];
    $aret["cab"] = $aretc;
    $aret["pro"] = $aretp;
    echo json_encode($aret);
    return;
}
if ($modo == "VE_KIT") {
    $codigo = pegavar("codigo");
    $cstr = "
select p.codpro as codigo,if(p.nomelong='',p.nompro,p.nomelong) as nome,p.estoque as saldo,p.fpgpro as psaldo,p.estoque as saldot,p.fpgpro as psaldot,k.quakit
from PROKIT_PRO k 
inner join PRODUTO_PRO p on p.is_deleted='N' and k.prokit=p.codpro
where k.is_deleted='N' and k.codkit=$codigo
group by k.prokit
";


    $otab = mysqli_query($db, $cstr);
    $aretp = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $aretp[] = $olin;
    }
    $olinpro = mysqli_fetch_array(mysqli_query($db, "select if(nomelong='',nompro,nomelong) as nome from PRODUTO_PRO where is_deleted='N' and codpro=$codigo"));
    $aret["nome"] = LimpaChar($olinpro[0]);

    $aret["pro"] = $aretp;
    /*
      $aret["erro"]=99;
      $aret["cerro"]=$cstr;
     */
    echo json_encode($aret);
    return;
}
if ($modo == "VE_VENDA") {
    $codigo = pegavar("codigo");
    $nlimiteconsulta = 100;
    $cstr = "select s.cuSATU as custo
,s.cusai as venda
,s.qusai as quant
,n.datasai as data
,concat(c.codcli,'-',c.nomcli) as cliente
from PROSAI_SAI s
inner join SAIDAS_SAI  n on n.is_deleted='N' and n.recno=s.nfsai
inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai
where s.prsai=$codigo
order by s.recno desc limit $nlimiteconsulta;
";


    $otab = mysqli_query($db, $cstr);
    $aretp = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $olin["cliente"] = iconv("cp850", "utf8", $olin["cliente"]);
        $aretp[] = $olin;
    }
    $olinpro = mysqli_fetch_array(mysqli_query($db, "select if(nomelong='',nompro,nomelong) as nome from PRODUTO_PRO where is_deleted='N' and codpro=$codigo"));
    $aret["nome"] = iconv("cp850", "utf8", LimpaChar($olinpro[0]));
    $aret["limite"] = $nlimiteconsulta;

    $aret["pro"] = $aretp;
    /*
      $aret["erro"]=99;
      $aret["cerro"]=$cstr;
     */
    echo json_encode($aret);
    return;
}

echo json_encode($aret);
return;
