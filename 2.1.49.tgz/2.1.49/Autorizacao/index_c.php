<?php

session_start();

require_once '../inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";
$aret["sid"] = "";

$cuser = strtoupper(PegaVar("user"));
$csenha = strtoupper(PegaVar("senha"));
$modo = pegavar("modo");

if ($modo == 3) {
    $sid = PegaVar("sid");
    mysqli_query($db, "delete from autoriza_sid where sid='$sid'");
    return;
}

if ($modo == 1 && $cuser) {
    $db = conecta();

    $aret["numero"] = "";

    $otable = mysqli_query($db, "select codigo,num_sem from OPERADOR_OPE WHERE is_deleted='N' and (NOME='$cuser' or codigo='$cuser') ");
    if (mysqli_num_rows($otable) == 0) {
        echo json_encode($aret);
        return;
    }
    $olinha = mysqli_fetch_row($otable);
    $nnumero = $olinha[0] == 1 && $olinha[1] == 0 ? 10 : $olinha[1];
    if ($nnumero) {
        $aret["numero"] = $nnumero;
    }
    echo json_encode($aret);
    return;
}
if ($modo == 2 && $csenha) {
    $db = conecta();

    $otable = mysqli_query($db, "select * from OPERADOR_OPE WHERE is_deleted='N' and (NOME='$cuser' or codigo='$cuser') ");
//    $otable = mysqli_query($db, "select * from OPERADOR_OPE WHERE bloq_vdas!='S' and is_deleted='N' and (NOME='$cuser' or codigo='$cuser') ");
    if (mysqli_num_rows($otable) == 0) {
        $aret["erro"] = "98";
        $aret["cerro"] = "Senha inválida..";
        echo json_encode($aret);
        return;
    }
    $olinha = mysqli_fetch_array($otable);

    if (!(trim(cifra($olinha["SENHA"])) == $csenha)) {
        $aret["erro"] = "97";
        $aret["cerro"] = "Senha inválida... ";
        echo json_encode($aret);
        return;
    }
    VeSession("usuario",$olinha["CODIGO"]);//$_SESSION["usuario"] = $olinha["CODIGO"];
    VeSession("cusuario",$olinha["NOME"]);//$_SESSION["cusuario"] = $olinha["NOME"];
    VeSession("terminal",800+$olinha["CODIGO"]);//$_SESSION["terminal"] = 800 + $olinha["CODIGO"];

    $csid = "OK";

    for ($i = 0; $i < 140; $i++) {
        $csid .= substr("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz", rand(0, 61), 1);
    }
    mysqli_query($db, "delete from autoriza_sid where usuario=" . $olinha["CODIGO"]);

    $cstr = "insert autoriza_sid (usuario,cusuario,data,hora,data_atu,hora_atu,sid,terminal) 
        values (" . $olinha["CODIGO"] . ",'" . $olinha["NOME"] . "',current_date(),current_time(),current_date(),current_time(),'$csid'," . (800 + $olinha["CODIGO"]) . ")";
    mysqli_query($db, $cstr);
    VeSession("sid",$csid);//$_SESSION["sid"] = $csid;
    VeSession("tempo",30*60);//$_SESSION["tempo"] = 30 * 60;
    $aret["sid"] = $csid;
    echo json_encode($aret);
    return;
}


if ($modo == 6 || $modo == "SALVAR") {

    $db = conecta();

    $otab = mysqli_query($db, "select * FROM autoriza1_ope where usuario=" . pegavar("usuario"));

    $csql = "replace autoriza1_ope set usuario=" . pegavar("usuario") . ",horai='" . pegavar("horai") . "',horaf='" . pegavar("horaf") . "'
        ,bloqueado=" . (pegavar("bloqueado") == "true" ? "1" : "0") . "
        ,semanas='";
    for ($i = 1; $i <= 7; $i++) {
        if (pegavar("s$i") == "true") {
            $csql .= "$i";
        }
    }
    $csql .= "',geral=" . (pegavar("geral") == "true" ? "1" : "0");

    $csql .= ",consulta=" . (PegaVar("consulta") == "true" ? "1" : "0");
    $csql .= ",con_u=" . (PegaVar("con_u") == "true" ? "1" : "0");
    $csql .= ",con_a=" . (PegaVar("con_a") == "true" ? "1" : "0");
    $csql .= ",con_b=" . (PegaVar("con_b") == "true" ? "1" : "0");
    $csql .= ",con_c=" . (PegaVar("con_c") == "true" ? "1" : "0");
    $csql .= ",con_t=" . (PegaVar("con_t") == "true" ? "1" : "0");

    mysqli_query($db, $csql);
    $aret["cerro"] = mysqli_error($db);
    echo json_encode($aret);

    return;
}
if ($modo == 5 || $modo=="LE_CONFIG") {

    $db = conecta();

    $lgeral = 0;

    $otab = mysqli_query($db, "select * FROM autoriza1_ope where usuario=" . pegavar("usuario"));

    $olin = mysqli_fetch_array($otab);

    if (mysqli_num_rows($otab) == 0 || $olin["geral"]) {
        $lgeral = 1;
        $otab = mysqli_query($db, "select * FROM autoriza1_ope where usuario=0");
        $olin = mysqli_fetch_array($otab);
    }
    if (mysqli_num_rows($otab)) {
        $aret["horai"] = $olin["horai"];
        $aret["horaf"] = $olin["horaf"];
        $aret["bloqueado"] = $olin["bloqueado"];
        $aret["semanas"] = $olin["semanas"];
        $aret["geral"] = $lgeral;
        $aret["consulta"]=$olin["consulta"];
        $aret["con_u"]=$olin["con_u"];
        $aret["con_a"]=$olin["con_a"];
        $aret["con_b"]=$olin["con_b"];
        $aret["con_c"]=$olin["con_c"];
        $aret["con_t"]=$olin["con_t"];
    } else {
        $aret["horai"] = "07:00:00";
        $aret["horaf"] = "17:00:00";
        $aret["bloqueado"] = 0;
        $aret["semanas"] = "1234567";
        $aret["geral"] = 1;

        $aret["consulta"]=1;
        $aret["con_u"]=0;
        $aret["con_a"]=1;
        $aret["con_b"]=1;
        $aret["con_c"]=0;
        $aret["con_t"]=0;
    }

    
    echo json_encode($aret);
    return;
}
if ($modo == 4) {

    $db = conecta();
    mysqli_query($db, "create table if not exists autoriza1_ope (
        usuario int(10) not null default 0
        ,horai time,horaf time
        ,geral int(1) not null default 1
        ,bloqueado int(1) not null default 0
        ,terminal int(4) not null default 0
        ,semanas varchar(20) not null default ''
        ,primary key (usuario)
        )");

    if (mysqli_num_rows(mysqli_query($db, "desc autoriza1_ope 'consulta' ")) == 0) {
        mysqli_query($db, "alter table autoriza1_ope add consulta int(1) not null default '0'");
        mysqli_query($db, "alter table autoriza1_ope add con_u int(1) not null default '0'");
        mysqli_query($db, "alter table autoriza1_ope add con_a int(1) not null default '0'");
        mysqli_query($db, "alter table autoriza1_ope add con_b int(1) not null default '0'");
        mysqli_query($db, "alter table autoriza1_ope add con_c int(1) not null default '0'");
        mysqli_query($db, "alter table autoriza1_ope add con_t int(1) not null default '0'");
    }
/*
    $nusuario = pegavar("usuario");
    if (mysqli_num_rows(mysqli_query($db, "select * from autoriza1_ope where usuario=$nusuario")) == 0) {
        mysqli_query($db, "replace autoriza1_ope (usuario)
            values ($nusuario)
            ");
    }
*/
    if (mysqli_num_rows(mysqli_query($db, "select * from autoriza1_ope")) == 0) {
        mysqli_query($db, "replace autoriza1_ope (usuario,horai,horaf,semanas,bloqueado,geral)
            values (0,'07:00:00','17:00:00','1234567',0,1)
            ");
    }
    mysqli_query($db, "create table if not exists autoriza_sid (
        sid varchar(150)
        ,usuario int(10) not null default 0
        ,cusuario varchar(40)
        ,data date
        ,hora time
        ,data_atu date
        ,hora_atu time
        ,terminal int(4) not null default 0
        )");


    $auser = array();
//    $otab = mysqli_query($db, "select codigo,nome from OPERADOR_OPE WHERE bloq_vdas!='S' and IS_DELETED='N' AND CODIGO!=999 ORDER BY CODIGO");
    $otab = mysqli_query($db, "select codigo,nome from OPERADOR_OPE WHERE IS_DELETED='N' AND CODIGO!=999 ORDER BY CODIGO");

    while ($olin = mysqli_fetch_row($otab)) {
        $auser[] = array($olin[0], $olin[0] . "-" . iconv("cp850", "utf-8", $olin[1]));
    }

    $aret["auser"] = $auser;
    echo json_encode($aret);
    return;
}
if ($modo == 7) {

    $db = conecta();
    /*
      mysqli_query($db, "create table if not exists autoriza1_ope (
      usuario int(10) not null default 0
      ,horai time,horaf time
      ,geral int(1) not null default 1
      ,bloqueado int(1) not null default 0
      ,terminal int(4) not null default 0
      ,semanas varchar(20) not null default ''
      ,consulta int(1) not null default '0'
      ,con_u int(1) not null default '0'
      ,con_a int(1) not null default '0'
      ,con_b int(1) not null default '0'
      ,con_c int(1) not null default '0'
      ,con_t int(1) not null default '0'
      ,primary key (usuario)
      )");
     */

    $olin = mysqli_fetch_array(mysqli_query($db, "select consulta,con_u,con_a,con_b,con_c,con_t from autoriza1_ope where usuario=$nusuario"));
    $aret["consulta"] = $olin["consulta"];
    $aret["con_u"] = $olin["con_u"];
    $aret["con_a"] = $olin["con_a"];
    $aret["con_b"] = $olin["con_b"];
    $aret["con_c"] = $olin["con_c"];
    $aret["con_t"] = $olin["con_t"];

    $aret["auser"] = $auser;
    echo json_encode($aret);
    return;
}



$aret["erro"] = "99";
$aret["cerro"] = "Sem Parâmetros";
echo json_encode($aret);

VeSession("sid","null");//$_SESSION["sid"] = "";
VeSession("usurio","null");//$_SESSION["usuario"] = "";
VeSession("usuario","null");//$_SESSION["cusuario"] = "";
return;
