<?php

function VeGarantiaExtendida( $nCodigo, $nPreco, $nQuant=1, $nCliente=0, $nLoja=1, $nMoeda=1){
        global $db;

    if (!ExisteSql("GARANTIA.GAR",$db)){
        return array();
    }

    $cStr = "select g.codigo,g.nome,g.valor,g.percentual,g.tmin,g.tmax,g.prodcec,p.pacote from GARANTIA_GAR g 
             inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=" . AsSql( $nCodigo ) ." 
             inner join CLIENTE_PGY c on c.is_deleted='N' and c.codigo=" . AsSql( $nCliente ) ." 
             inner join CLIENTE_CLI cl on cl.is_deleted='N' and cl.codcli=" . AsSql( $nCliente ) ." 
             where g.is_deleted='N'  and g.ativo='Y' and g.datai<=date2unix(now()) and dataf>=date2unix(now()) and 
              (find_in_set(".AsSql($nCodigo).",g.np)  or 
                  ( 
                      if(g.ng='',1,find_in_set(p.grupro,g.ng)) and 
                      if(g.ns='',1,find_in_set(p.sgrupro,g.ns)) and 
                      if(g.nm='',1,find_in_set(p.marcpro,g.nm)) and 
                      if(g.nf='',1,find_in_set(p.forpro,g.nf)) and  
                      if(g.ne='',1,find_in_set(p.gruesp,g.ne)) and  
                      if(g.ni='',1,find_in_set(c.pais_num,g.ni)) and 
                      if(g.nt='',1,find_in_set(cl.grucli,g.nt)) and 
                      if(g.nl='',1,find_in_set(". AsSql( $nLoja ) . ",g.nl)) 
                      ) 
                  ) order by nome ";
    $otab=mysqli_query($db,$cStr );
    if (mysqli_num_rows( $otab ) == 0){
        return array();
    }
    $aret=array();
    while ($olin=mysqli_fetch_array($otab)){
        $aret[]=array("codigo" => $olin["codigo"]
                ,"nome" => iconv("ISO-8859-1","utf8",$olin["nome"])
                ,"quant" => $nQuant
                ,"valor" => $nQuant*$nPreco
                ,"tmax" => $olin["tmax"]
                ,"prodcec" => $olin["prodcec"]
                ,"pacote" => $olin["pacote"]
                ,"valgar" => ($olin["valor"]>0?$olin["valor"]:($nPreco*$olin["percentual"]/100))*$nQuant //   IF( ! Empty( aAux[ i, 3 ] ), aAux[ i, 3 ], nPreco * aAux[ i, 4 ] / 100 ) * nQuant
                );
    }
    return $aret;
    /*
    aCampos := { { "codigo", "n", 10, 0 }, { "nome", "c", 60, 0 }, { "quant", "n", 10, 0 }, { "valor", "n", 15, 2 }, { "valgar", "n", 15, 2 }, { "tmax", "n", 10, 0 }, { "pacote", "n", 10, 0 }, { "prodcec", "n", 10, 0 }, { "ok", "l", 1, 0 } }
    DBCreate( "GARVEN.GAR", aCampos, "ARRAYRDD" )
    AbreArq( "GARVEN.GAR", cApe, TRUE,,,,, "ARRAYRDD" )

    FOR i := 1 TO Len( aAux )
        ( cApe ) ->( DBAppend() )
        ( cApe ) ->codigo  := aAux[ i, 1 ]
        ( cApe ) ->nome    := aAux[ i, 2 ]
        ( cApe ) ->quant   := nQuant
        ( cApe ) ->Valor   := nQuant * nPreco
        ( cApe ) ->tmax    := aAux[ i, 6 ]
        ( cApe ) ->prodcec := aAux[ i, 7 ]
        ( cApe ) ->pacote  := aAux[ i, 8 ]
        ( cApe ) ->valgar  := IF( ! Empty( aAux[ i, 3 ] ), aAux[ i, 3 ], nPreco * aAux[ i, 4 ] / 100 ) * nQuant
    NEXT
    ( cApe ) ->( DBGoTop() )
    aAmb := { Wselect(), Amb(), ( Wselect( 0 ), Amb() ) }

    aCam := { "codigo", "left(nome,40)", "quant", "valor", "valgar", "tmax" }
    aNom := { "Cod.", "Seguro", "Quant", "Valor Prod.", "Valor Gar", "Validade" }
    aPic := { "9999", "", "9999", VeMoeMasc( nMoeda ), VeMoeMasc( nMoeda ), "9999" }
    aFun := { { "<ESC>", "Sair sem Seguro", K_ESC }, { "<F4>", "Escolher o Seguro", K_F4 } }
    NewTela( 0, 0, 20, 100, MAGE, " Seguro ", 0, @nli, @nci,, @nlf, @ncf, TRUE, B_SINGLE )
    MyDbEdit( nli + 2, nci, nlf + 1, ncf, aCam, "_gar_ext", aPic, aNom, 2,,,,,,,, aFun )

    IF ( cApe ) ->ok .AND. VeCliCpfGarantia()
        aREt := { ( cApe ) ->codigo, ( cApe ) ->nome, nQuant, ( cApe ) ->valgar, ( cApe ) ->prodcec }


        m->NUMITEM := m->NUMITEM + 1
        m->VTOTAL  := m->VTOTAL + ( cApe ) ->valgar
        m->VQUANTI := m->VQUANTI + nQuant

        ( cTmp ) ->( ApLock() )

        ( cTmp ) -> COD2TPO := nCodigo
        ( cTmp ) -> CUSTPO := ( cApe ) ->valgar / nQuant
        ( cTmp ) -> QUATPO := nQuant
        ( cTmp ) -> CODTPO := ( cApe ) ->prodcec
        ( cTmp ) ->  KITTPO := "N"
        ( cTmp ) -> pacotpo := IF( EMP->PACOEMP <> 0, EMP->PACOEMP, ( cApe ) ->PACOTE )
        ( cTmp ) ->( CHK_OK( .T. ) )
        ( cTmp ) ->( DBCommit() )

    ENDIF





    ( cApe ) ->( DBCloseArea() )



    Amb( aAmb[ 3 ] )
    Wselect( aAmb[ 1 ] )
    Amb( aAmb[ 2 ] )
    DBSelectArea( nArea )
    RETURN aREt
*/
}