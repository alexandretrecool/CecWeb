<?php
error_reporting(E_ALL);
ini_set('display_errors',0);
ini_set('display_startup_erros',0);

session_start();

require_once 'inc/config.php';
if (0 < $_FILES['file']['error']) {
    echo '99-Error: ' . $_FILES['file']['error'] . '<br>';
    return;
}

$cstr = file_get_contents($_FILES['file']['tmp_name'], FILE_BINARY);

$aaux1 = array();
$aaux1[] = "\\";
$aaux1[] = chr(0);
$aaux1[] = chr(13);
$aaux1[] = chr(10);
$aaux1[] = '"';
$aaux1[] = "'";
$aaux1[] = "`";
$aaux1[] = chr(9);
$aaux1[] = chr(141);
$aaux1[] = chr(8);
$aaux1[] = chr(26);
$aaux1[] = "%";
$aaux1[] = "_";



$aaux = array();

$i = 0;
while (true) {
    $caux = substr($cstr, $i, 50000);
    if (strlen($caux) == 0) {
        break;
    }
    for ($k = 0; $k < count($aaux1); $k++) {
        $caux = str_replace($aaux1[$k], "/chr" . ($k + 1) . "/", $caux);
    }

    $aaux[] = $caux;
    $i+=50000;
}



$caux = $_FILES['file']['name'];
$caux = explode("_", $caux);
$ncli = $caux[0];
$nord = $caux[1];


if (!$db){
    $db = conecta();
}
if (!$db) {
    echo "99-Erro acessando SQL ";
    return;
}
mysqli_query($db,"update CEDULA_CLI SET IS_DELETED='Y' WHERE CODIGO=$ncli and ordem=$nord");
for ($i = 0; $i < count($aaux); $i++) {
    $agrava = array();
    $agrava[] = array("CODIGO", $ncli);
    $agrava[] = array("ORDEM", $nord);
    $agrava[] = array("PARTE", $i + 1);
    $agrava[] = array("FOTO", $aaux[$i], '', true);
    GravaSqlMed("CEDULA.CLI", $agrava);
}
$otabcli=mysqli_query($db,"SHOW TABLES LIKE 'CLIENTE_CLI'");
if (mysqli_num_rows($otabcli)>0){
    mysqlI_query($db,"update CLIENTE_CLI SET FOTO_CLI='S' WHERE IS_DELETED='N' AND CODCLI=$ncli");
}
mysqli_close($db);

echo "00-Cliente: $ncli \nOrdem: $nord \nArray: " . count($aaux);
return;
