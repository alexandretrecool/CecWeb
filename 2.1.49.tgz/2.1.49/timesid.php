<?php

session_start();
if (!isset($_SESSION["sid"])){
    return;
}
$lweb=$_SESSION["web"];
require_once 'inc/config.php';
$db = conecta();

if (pegavar("modo")=="REFRESH"){
    require_once 'inc/sid.php';
    VeSidVendas();
}
$tempolimite = $_SESSION["ntempolimite"] ; //$_SESSION["tempolimite"] * 60;
$sid = $_SESSION["sid"]; //$_SESSION["sid"];
$carq = "vendas";
$otab = mysqli_query($db, "select v.*,date2unix(now()) as agora from " . $carq . "tablet" . $lweb . "_sid v where v.sid='$sid'");
if (mysqli_num_rows($otab) == 0) {
    echo "0";
    return ;
}
$olin = mysqli_fetch_array($otab);
if ($olin["data_sai"] > 0) {
    echo "0";
    return ;
}
//echo var_export($_SESSION,true);
echo $olin["data_atu"]+$tempolimite-$olin["agora"];
return;

