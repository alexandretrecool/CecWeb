<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_erros', 1);

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}


mysqli_query($db, "create table if not exists tablet" . $lweb . "_not (
         ordem int(10) not null primary key auto_increment
        ,nota int(10) not null default 0
        ,corpo mediumblob
        ,cridata int(10) not null default 0
        ,impdata int(10) not null default 0
        ,impressora int(3) not null default 1
        ,key cridata (cridata)
        ,key impdata (impdata)
        )");

$nota = PegaVar("nota");
$lorc = PegaVar("orcamento") == "true";
$nvias = PegaVar("vias");
$nimp = trim(pegavar("impressora"));
$nmnt_imp = pegavar("nmnt_imp");
$nomeemp = pegavar("nomeemp");
$cnomeimp = pegavar("cnomeimp");
$lreimp = pegavar("lreimp") == "true";

DEFINE("BEMA_LINHAS_FINAL", 15);

if (!$nota || !vedigito($nota)) {
    $aret["erro"] = "97";
    $aret["cerro"] = _tr("Nota inválida");
    echo json_encode($aret);
    return;
}
$nota = tiradigito($nota);
if (!$nvias) {
    $nvias = 1;
}
if (!$nimp) {
    $nimp = explode(",", $cnomeimp)[0];
}
if (!$nimp) {
    $nimp = 1;
}
$nimp = $nimp + 0;

//    $aret["erro"] = $nerro;
//    $aret["cerro"] = $nota."|".$lorc."|". $nvias."|". $nerro."|". $cerro."|". $nmnt_imp."|". $nomeemp."|". $cnomeimp."|".$lreimp;
//    echo json_encode($aret);
//    return;


$cret = nota_bema($nota, $lorc = false, $nvias, $nerro, $cerro, $nmnt_imp, $nomeemp, $cnomeimp, $lreimp);
if ($nerro) {
    $aret["erro"] = $nerro;
    $aret["cerro"] = $cerro;
    echo json_encode($aret);
    return;
}
if (pegavar("ctipo") == "auto") {
    if ($lCfRdd) {
        $omedn = new Mediator4("LISTA.IMP", W_CRIAR_DEL, '', '', $db);
    } else {
        $omedn = new Mediator3("LISTA.IMP", W_CRIAR_DEL, '', '', $db);
    }
    $omedn->aadd("DATA", Date2Unix());
    $omedn->aadd("TEXTO", $cret);
    $omedn->aadd("IMPRESSORA", $nimp);
    $omedn->aadd("COPIAS", 1);
    $omedn->aadd("TERMINAL", "WEB0");
    $omedn->aadd("RAW", TRUE);
    if (!$omedn->grava()) {
        $aret["erro"] = "93";
        $aret["cerro"] = _tr("Erro gravando nota a imprimir");
        echo json_encode($aret);
        return;
    }
    mysqli_query($db, "update LISTA_IMP SET is_deleted='N' where recno=" . $omedn->nrecno);
} else {
    mysqli_query($db, "insert tablet" . $lweb . "_not set nota=$nota,cridata=unix_timestamp(),impressora=$nimp,corpo=" . assql(base64_encode($cret)));
}
echo json_encode($aret);
return;

function nota_bema($nota, $lorc = false, $nvias = 1, &$nerro = 0, &$cerro = "", $nmnt_imp, $nomeemp, $cnomeimp = '', $lreimp = false) {
    global $db;
    $lepson = !(strpos(strtoupper($cnomeimp), "EPSON") === false);
    if ($lepson) {
        define("P_INIT", Chr(27) . "@");
        define("P_NEG", Chr(27) . "E" . "1");
        define("P_DNEG", Chr(27) . "E" . "0");
        define("P_DOUBLE", chr(29) . "!" . chr(48));
        define("P_DDOUBLE", chr(29) . "!" . chr(0));
        define("P_EXP", chr(29) . "!" . chr(16));
        define("P_DEXP", chr(29) . "!" . chr(0));
        define("P_CR", chr(13) . chr(10));
    } else {
        define("P_INIT", Chr(29) . Chr(249) . Chr(53) . Chr(0) . Chr(27) . "@");
        define("P_NEG", Chr(27) . "E");
        define("P_DNEG", Chr(27) . "F");
        define("P_DOUBLE", Chr(27) . Chr(100) . Chr(1));
        define("P_DDOUBLE", Chr(27) . Chr(100) . Chr(0));
        define("P_EXP", chr(14));
        define("P_DEXP", chr(20));
        define("P_CR", chr(13) . chr(10));
    }

    $otnot = mysqli_query($db, "select * from " . (!$lorc ? "SAIDAS_SAI" : "SAIDA_ORC") . " WHERE RECNO=$nota");
    if (mysqli_num_rows($otnot) == 0) {
        $nerro = 98;
        $cerro = _tr("Nota não existe");
        return "";
    }
    $olsai = mysqli_fetch_array($otnot);
    if ($olsai["IS_DELETED"] == "Y") {
        $nerro = 98;
        $cerro = _tr("Nota está deletada");
        return "";
    }
    $olven = mysqli_fetch_array(mysqli_query($db, "select * from VENDEDOR_VEN WHERE IS_DELETED='N' AND CODVEN=" . $olsai["VENDSAI"]));
    $olcli = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM CLIENTE_CLI  WHERE IS_DELETED='N' AND CODCLI=" . $olsai["CLIESAI"]));
    $olemp = mysqli_fetch_array(mysqli_query($db, "select * from EMPRESA_EMP  WHERE IS_DELETED='N' And 
        codemp=" . ($olsai["LOJACOR"] != 0 ? $olsai["LOJACOR"] : $olsai["LOJASAI"])));
    $olcfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG       WHERE RECNO=1"));
    $olcfg2 = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG2       WHERE RECNO=1"));

    $cimp = P_INIT;
    //$cimp .= chr(29)."!".chr(16)."x $cnomeimp x".P_CR;
    //$cimp .= chr(29)."!".chr(0)."TESTE".P_DDOUBLE.P_CR;
    if ($olcfg["PACOTE_WEB"] == "S") {
        $WNUM_GUICHE = str_pad(substr($nota, -4), 4, " ", STR_PAD_LEFT);
        $cimp .= P_EXP . P_NEG . str_pad(ID(_tr("NUMERO NO PAINEL") . ":") . $WNUM_GUICHE, 26, " ", STR_PAD_BOTH) . P_DNEG . P_DEXP;
        $cimp .= P_CR;
        $cimp .= str_repeat("_", 48);
        $cimp .= P_CR;
    }

    if ($olcfg2["VEICULO"] == "S" && $olsai["PLACASAI"]) {
        $aaux = explode("/", $olsai["PLACASAI"]);
        if (count($aaux) > 1 && $aaux[1] + 0 > 0) {
            $cimp .= P_EXP . P_NEG . str_pad(ID(_tr("PRISMA: ") . ":") . $aaux[1], 26, " ", STR_PAD_BOTH) . P_DNEG . P_DEXP;
            $cimp .= P_CR;
            $cimp .= str_repeat("_", 48);
            $cimp .= P_CR;
        }
    }

    if (!$lorc) {
        $cimp .= Chr(29) . Chr(72) . Chr(0);  // retirar o codigo impresso
        $cimp .= Chr(29) . Chr(104) . Chr(100);  // altura
        $cimp .= Chr(29) . Chr(119) . Chr(4); //largura
        $cimp .= Chr(29) . Chr(107) . Chr(132) . Chr(20) . Chr(0); // margem esquerda
        $cimp .= P_CR . Chr(29) . Chr(107) . Chr(2) . str_pad($nota, 12, "0", STR_PAD_LEFT) . Chr(0);  // imprime o codigo de barra
    }

    $cnomeven = "VENTAS";
    if ($nmnt_imp == "N") {
        $nmnt_imp = "";
    } elseif ($nmnt_imp == "C") {
        $nomeemp = mysqli_fetch_row(mysqli_query($db, "select nome_cli from CONFIG where recno=1"))[0];
    } elseif ($nmnt_imp == "E") {
        //$nomeemp = mysqli_fetch_row(mysqli_query($db, "select if(e.imp_orc='S' and n.sitsai!='S','PRESUPUESTO',e.nomemp) AS nomeemp from SAIDAS_SAI n
        $olemp = mysqli_fetch_row(mysqli_query($db, "select e.nomemp,if(e.imp_orc='S' and n.sitsai!='S','PRESUPUESTO','') AS nomeven from SAIDAS_SAI n
            inner join EMPRESA_EMP e on e.is_deleted='N' and e.codemp=if(n.lojacor,n.lojacor,n.lojasai) 
            where n.recno=$nota"));

        $nomeemp = $olemp[0];
        if ($olemp[1]) {
            $cnomeven = $olemp[1];
        }
    }

    $nomeemp = trim($nomeemp);
    if ($nomeemp) {
        $cimp .= P_CR;
        $cimp .= P_EXP . P_NEG . str_pad($nomeemp, 26, " ", STR_PAD_BOTH) . P_DNEG . P_DEXP;
        $cimp .= P_CR;
    }
    $cimp .= P_CR;
    $cimp .= P_EXP . P_NEG . str_pad($cnomeven, 26, " ", STR_PAD_BOTH) . P_DNEG . P_DEXP;
    $cimp .= P_CR;

    if ($olcfg["ENDEMP"]) {
        $cimp .= str_pad(TRIM($olcfg["ENDEMP"]), 48, " ", STR_PAD_BOTH);
        $cimp .= P_CR;
    }
    if ($olcfg["FONEMP"]) {
        $cimp .= str_pad(trim($olcfg["FONEMP"]), 48, " ", STR_PAD_BOTH);
        $cimp .= P_CR;
    }
    $cimp .= P_CR;

    $cstr = "select p.PACOTE FROM " . (!$lorc ? "PROSAI_SAI" : "PROSAI_ORC") . " s 
    inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai
    where s.nfsai=$nota and s.is_deleted='N'
    limit 1";

    $olpro = mysqli_fetch_array(mysqli_query($db, $cstr));
    $npac = $lemp["PACOEMP"] != 0 ? $olemp["PACOEMP"] : $olpro["PACOTE"];

    if ($npac == "") {
        $PRPACO = "*" . _tr("PACOTE") . " ?*";
    } else {
        $PRPACO = "*" . _tr("PACOTE") . " $npac*";
    }
    $cimp .= str_pad(P_NEG . Trim($olcfg[$lorc ? "NOMORCA" : "NOMVEN"]) . P_DNEG . " - " .
            ($olcfg["DIVPACOTE"] == "S" || $olemp["PACOEMP"] != 0 ? (P_EXP . P_NEG . $PRPACO . P_DEXP . P_DNEG) : ""), 48, " ", STR_PAD_BOTH);

    $cimp .= P_CR;

    $cimp .= str_repeat("=", 48) . P_CR;
    $cimp .= sql2data($olsai["DATASAI"]) .
            " " . $olsai["HORASAI"] . "  " . _tr("Pedido") . ": " . P_EXP . $nota . ($olcfg["DIGIVEN"] == "S" ? ("-" . Digito($nota)) : "") . P_DEXP;
    $cimp .= P_CR;
    $cimp .= id("Cli: ") . P_NEG . $olcli["CODCLI"] . iconv("CP850", "UTF8", " - " . substr(TRIM($olsai["NOMGER"]) ? $olsai["NOMGER"] : $olcli["NOMCLI"], 0, 30)) . P_DNEG;
    $cimp .= P_CR;
    $cimp .= id("Ven: ") . iconv("CP850", "UTF8", $olven["CODVEN"] . " - " . substr($olven["NOMVEN"], 0, 30));
    $cimp .= P_CR;
    $cimp .= id("Dir: ") . iconv("CP850", "UTF8", (trim($olsai["NOMGER"]) ? $olsai["ENDGER"] : $olcli["ENDCLI"]));
    $cimp .= P_CR;
    $cimp .= id("Cid: ") . iconv("CP850", "UTF8", $olcli["CIDCLI"]);
    $cimp .= P_CR;
    $cimp .= id("Num CI:") . P_NEG .
            (TRIM($olsai["RUCGER"]) ? $olsai["RUCGER"] : (trim($olcli["REGICLI"]) ? ($olcli["REGICLI"] . "  ") : $olcli["RUCCLI"]) ) . P_DNEG;
    $cimp .= P_CR;

    if (TRIM($olcli["REGICLI"]) && $olcli["PAISCLI"] == 1) {
        $cimp .= id("Reg. Distribuidor: ") . P_NEG . $olcli["REGICLI"] . P_DNEG;
        $cimp .= P_CR;
    }

    if ($olcfg2["VEICULO"] == "S" && $olsai["PLACASAI"] && substr($olsai["PLACASAI"], 0, 3) !== "TBL") {
        $aaux = explode("/", $olsai["PLACASAI"]);
        $olvei = mysqli_fetch_array(mysqli_query($db, "select * from VEICULO_CAR WHERE IS_DELETED='N' AND PLACA='" . $aaux[0] . "' "));
        $cimp .= str_pad(P_EXP . P_NEG . "** " . id("VEICULO") . " **" . P_DEXP . P_DNEG, 48, " ", STR_PAD_BOTH);
        $cimp .= P_CR;
        $cimp .= id("Placa: ") . P_EXP . P_NEG . $olvei["PLACA"] . P_DNEG . P_DEXP;
        $cimp .= P_CR;
        $cimp .= str_pad(id("Marca : ") . iconv("CP850", "UTF8", $olvei["MARCA"]), 23, " ", STR_PAD_RIGHT);
        $cimp .= str_pad(id(" MOdelo: ") . iconv("CP850", "UTF8", $olvei["MODELO"]), 23, " ", STR_PAD_RIGHT);
        $cimp .= P_CR;
        $cimp .= str_pad(id("Cor...: ") . iconv("CP850", "UTF8", $olvei["COR"]), 23, " ", STR_PAD_RIGHT);
        $cimp .= str_pad(id(" Ano...: ") . iconv("CP850", "UTF8", $olvei["ANO"]), 23, " ", STR_PAD_RIGHT);
        $cimp .= P_CR;
        $aaux1 = ARRAY("", "Passeio", "Camionete", "Caminhao", "Onibus", "SUV", "VAN", "MOTO", "", "OUTROS");
        $cimp .= str_pad(id("Classe: ") . $aaux1[$olvei["CLASSE"]], 23, " ", STR_PAD_RIGHT);
        $cimp .= str_pad(id(" KM....: ") . $olvei["KILOMET"], 23, " ", STR_PAD_RIGHT);
        $cimp .= P_CR;
    }


    if ($olsai["TIPOSAI"] == "P") {
        $cimp .= id("Vencimento.......: ") . sql2data($olsai["VENCSAI"]);
        $cimp .= P_CR;
    }
    $cimp .= P_CR;

    $WCAJA = "0";
    if (!$lorc && $olsai["EXTNOT"] > 0) {
        $WCAJA = mysqli_fetch_row(mysqli_query($db, "SELECT CODCAX FROM CAIXA_CAX WHERE RECNO=" . $olsai["EXTNOT"]))[0];
    }

    $cimp .= id("Condiciones Pago.: ") . P_NEG . ($olsai["TIPOSAI"] == "P" ? id("Plazo") : ($olsai["TIPOSAI"] == "V" ? id("Contado") : "Ajuste")) . P_DNEG .
            ($olsai["SITSAI"]=="S"? "   " . id("Oper: ") . P_NEG . $olsai["OPEREC"] . P_DNEG . "   " . id("Caja: "). P_NEG . $WCAJA:"")  . P_DNEG;
    $cimp .= P_CR;
    if (TRIM($olsai["OBSERV"])) {
        $cimp .= id("Obs: ") . iconv("CP850", "UTF8", substr($olsai["OBSERV"], 0, 43));
        $cimp .= P_CR;
    }
    $cimp .= str_repeat('=', 48);
    $cimp .= P_CR;

    $cimp .= P_NEG . id("   Codigo  Cantidad   P.Unitario     Monto Total") . P_DNEG . Chr(27) . Chr(51) . Chr(18);
    $cimp .= P_CR;
    $cimp .= P_CR;

    if ($olsai["IS_DELETED"] == "Y") {
        $cimp .= P_NEG . P_EXP . id("*** NOTA BORRADA ***") . P_DNEG . P_DEXP;
        $cimp .= P_CR;
    }
    $WTOTQUA = 0;
    $VTOTAL = 0;
    $WDESCPROMO = 0;

    $otblk = mysqli_query($db, "select * from BLACFRID_CFG WHERE IS_DELETED='N'");
    $W_BLACK = "S";
    $W_PROMO = "";

    if (mysqli_num_rows($otblk) != 0) {
        $olblk = mysqli_fetch_array($otblk);
        if (date('Y-m-d') >= $olblk["INI_FRID"] && date('Y-m-d') <= $olblk["FIN_FRID"]) {
            $W_BLACK = "S";
            $W_PROMO = $olblk["NOME_PROM"];
        }
    }


    $cstr = "select * from " . ($lorc ? "PROSAI_ORC" : "PROSAI_SAI") . "
        WHERE IS_DELETED='N' AND NFSAI=$nota
            ORDER BY ";
    if ($olcfg["ORDDIGI"] == "N") {
        $cstr .= " PRSAI ";
    } else {
        $cstr .= " REGSAI ";
    }
    $otpsa = mysqli_query($db, $cstr);

    while ($olpsa = mysqli_fetch_array($otpsa)) {

        $olpro = mysqli_fetch_array(mysqli_query($db, "select * from PRODUTO_PRO WHERE IS_DELETED='N' AND CODPRO=" . $olpsa["PRSAI"]));
        $olgse = mysqli_fetch_array(mysqli_query($db, "select * from GRUESP_GRE  WHERE IS_DELETED='N' AND CODESP=" . $olpro["GRUESP"]));

        $VCOD = poedigito($olpsa["PRSAI"]);

        $WUNIPRE = 0;
        $WUNIPRE = $olpsa["CUMOE"];

        $WVAL_PROMO = 0;

        if ($W_BLACK == "N") {
            if ($olcfg["PROMO_PR"] == "S" && $olpro["PROMOPRO"] == "S" && $olsai["MOEDA"] == 1 && $olpsa["CUMOE"] < $olpro["PREMIN"] && $lorc) {
                $WUNIPRE = $olpro["PREMIN"];
                $WVAL_PROMO = ($olpro["PREMIN"] - $olpsa["CUMOE"]) * $olpsa["QUSAI"];
            }
        }


        if ($W_BLACK == "S") {
            if ($olsai["MOEDA"] == 1 && $olpro["BLACK_FRI"] == "S" && $olpsa["CUMOE"] < $olpro["PREVEN"] && !$lorc) {
                $WUNIPRE = $olpro["PREVEN"];
                if ($olpsa["KITSAI"] <> "K") {
                    $WVAL_PROMO = ($olpro["PREVEN"] - $olpsa["CUMOE"]) * $olpsa["QUSAI"];
                }
            }
        }

        $W_BASE_PRM = 0;
        $W_NOME_PRM = str_repeat(" ", 20);

        $otgpm = mysqli_query($db, "select * from GRUPROMO_GPM WHERE IS_DELETED='N' AND CODGPM=" . $olpro["CODPROMO"]);
        $olgpm = mysqli_fetch_array($otgpm);
        $olmoe = mysqli_fetch_array(mysqli_query($db, "select * from CAMBIO_NOM"));
        $ldecimal = $olmoe["DECI" . $olsai["MOEDA"]] == "S";
        if ($olpro["PROMO_P"] == "S" && $olpro["PRECO5"] <> 0 && $olpro["CODPROMO"] <> 0 && $olpsa["PROMOPSA"] == "S") {
            $W_BASE_PRM = 0;
            $W_NOME_PRM = str_repeat(" ", 20);
//            PEGA_BASE_PROMO(@W_BASE_PRM, @W_NOME_PRM);

            $otgpm = mysqli_query($db, "select * from GRUPROMO_GPM WHERE IS_DELETED='N' AND CODGPM=" . $olpro["CODPROMO"]);
            if (mysqli_num_rows($otgpm) > 0) {
                $olgpm = mysqli_fetch_array($otgpm);
                if ($olgpm["TIPOGPM"] == "1") {
                    $W_BASE_PRM = $olpro["PREVEN"];
                } elseif ($olgpm["TIPOGPM"] == "2") {
                    $W_BASE_PRM = $olpro["PRECO3"];
                } elseif ($olgpm["TIPOGPM"] == "3") {
                    $W_BASE_PRM = $olpro["PREMIN"];
                } elseif ($olgpm["TIPOGPM"] == "4") {
                    $W_BASE_PRM = $olpro["PREATAC"];
                }
                $W_NOME_PRM = $olgpm["NOMGPM"];
            }

            if ($olsai["MOEDA"] == 1 && $olpsa["CUMOE"] < $W_BASE_PRM && !$lorc) {
                $WUNIPRE = $W_BASE_PRM;
                if ($olpsa["KITSAI"] <> "K") {
                    $WVAL_PROMO = ($W_BASE_PRM - $olpsa["CUMOE"]) * $olpsa["QUSAI"];
                }
            }
        }


        if ($olcfg["PROM_QUAN"] == "S" && $olpsa["PERQUA"] <> 0) {
            if ($olsai["MOEDA"] == 1 && $olpsa["CUMOE"] < $olpsa["PRE_TABELA"] && !$lorc) {
                $WUNIPRE = $olpsa["PRE_TABELA"];
                if ($olpsa["KITSAI"] <> "K") {
                    $WVAL_PROMO = ($olpsa["PRE_TABELA"] - $olpsa["CUMOE"]) * $olpsa["QUSAI"];
                }
            }
        }

        if ($WVAL_PROMO <> 0) {
            $WDESCPROMO = $WDESCPROMO + $WVAL_PROMO;
        }


        if ($olpsa["KITSAI"] <> "K") {
            $VTOTAL = $VTOTAL + ($olpsa["QUSAI"] * $WUNIPRE);
        }



        $WDESTACA = "N";
        if ($olpro["PRECO5"] <> 0 && $olpsa["PROMOPSA"] == "S") {
            if (mysqli_num_rows($otgpm) > 0) {
                if ($olgpm["IMPDESTAC"] <> "N") {
                    $WDESTACA = "S";
                }
            }
        }

        $cimp .= str_pad($olpro["CODPRO"], 7, " ", STR_PAD_LEFT) . "-" . digito($olpro["CODPRO"]) . " ";
        if ($olcfg["IMPSVALO"] == "S" && $olsai["SITSAI"] == "N" && !$lorc) {
            $nval = 0;
        } else {
            $nval = $WUNIPRE;
        }


        if ($olcfg["DECQUA"] == "N") {
            $cimp .= str_pad(number_format($olpsa["QUSAI"], 0), 8, " ", STR_PAD_LEFT);
        } else {
            $cimp .= str_pad(number_format(floor($olpsa["QUSAI"]), 0), 5, " ", STR_PAD_LEFT) . ".";
            $cimp .= str_pad(($olpsa["QUSAI"] % 1) * 100, 2, "0", STR_PAD_LEFT) . " ";
        }


        if ($olpsa["KITSAI"] <> "K") {
            if ($olpro["PRECO5"] <> 0 && $olpsa["PROMOPSA"] == "S" && $WDESTACA == "S") {
                if ($olcfg["IMPSVALO"] == "S" && $olsai["SITSAI"] == "N" && !$lorc) {
                    $cimp .= str_repeat(" ", 21) . P_NEG . "$$$$$$$$" . P_DNEG;
                } else {
                    $cimp .= str_pad(number_format($nval, $olmoe["DECI" . $olsai["MOEDA"]] == "S" ? 2 : 0, ".", ","), 13, " ", STR_PAD_LEFT);
                    $cimp .= "   " . P_NEG;
                    $cimp .= str_pad(number_format($olpsa["QUSAI"] * $nval, $olmoe["DECI" . $olsai["MOEDA"]] == "S" ? 2 : 0, ".", ","), 13, " ", STR_PAD_LEFT);
                    $cimp .= P_DNEG;
                }
            } else {
                $cimp .= str_pad(number_format($nval, $olmoe["DECI" . $olsai["MOEDA"]] == "S" ? 2 : 0, ".", ","), 13, " ", STR_PAD_LEFT);
                $cimp .= "   " . P_NEG;
                $cimp .= str_pad(number_format($olpsa["QUSAI"] * $nval, $olmoe["DECI" . $olsai["MOEDA"]] == "S" ? 2 : 0, ".", ","), 13, " ", STR_PAD_LEFT);
                $cimp .= P_DNEG;
            }
        } else {
            $cimp .= "kit,kit,kit.kt" . "  " . "kit,kit,kit.kt";
        }
        $cimp .= P_CR;

        if ($olcfg["REFECOD"] == "N") {
            if ($olcfg["NOMEGRAN"] == "N") {
                $cimp .= (trim($olgse["CARAC_ESP"]) ? P_NEG : "")
                        . $olpro["NOMPRO"]
                        . ($olsai["SEG_SOS"] <> 0 && $olpsa["PRSAI"] == $olcfg["CODSEG_PG"] ? " " . number_format($olsai["SEG_SOS"], 2) . " %" : "")
                        . (trim($olgse["CARAC_ESP"]) ? ("(" . $olgse["CARAC_ESP"] . ")") : "") . P_DNEG;
            } else {
                $cimp .= chr(27) . chr(15) . (trim($olgse["CARAC_ESP"]) ? P_NEG : "")
                        . SUBSTR($olpro["NOMELONG"], 0, 65)
                        . ($olsai["SEG_SOS"] <> 0 && $olpsa["PRSAI"] == $olcfg["CODSEG_PG"] ? " " . number_format($olsai["SEG_SOS"], 2) . " %" : "")
                        . (trim($olgse["CARAC_ESP"]) ? ("(" . $olgse["CARAC_ESP"] . ")") : "") . P_DNEG . chr(27) . chr(18);
            }
        } else {
            if ($olcfg["NOMEGRAN"] == "N") {
                $cimp .= $olpro["REFER"] . "- " . iconv("CP850", "UTF8", substr($olpro["NOMPRO"], 31 + 15 - strlen($olpro["REFER"])));
            } else {
                $cimp .= Chr(27) . Chr(15) . iconv("CP850", "UTF8", $olpro["REFER"] . "- " . substr($olpro["NOMPRO"], 61 + 15 - strLen($olpro["REFER"]))) . Chr(27) . Chr(18);
            }
        }
        $cimp .= P_CR;

        if ($olpsa["SEGURO"] == "S" && $olsai["SEG_SOS"] == 0) {
            $cimp .= P_NEG . "***** Seguro S.O.S. *********" . P_DNEG;
            $cimp .= P_CR;
        }

        if ($olcfg["GRADE_PR"] == "S" && trim($olpro["GRADEPRO"])) {
            if (!$lorc) {
                /*
                  LOCAL WNOM_GRADE:=""
                  GRSA->(DBSeek(Str((SAI)->NOTASAI,7)+Str(PRO->CODPRO,9),.T.))
                  DO WHILE !GRSA->(Eof())
                  IF GRSA->NFSAI<>(SAI)->NOTASAI
                  EXIT
                  ENDIF
                  IF GRSA->PRSAI<>PRO->CODPRO
                  EXIT
                  ENDIF
                  IF GRSA->QUSAI==0
                  GRSA->(DBSkip())
                  LOOP
                  ENDIF
                  CSEQ->(DBGOTO(GRSA->SEQGRADE1))
                  WNOM_GRADE:=WNOM_GRADE+"("+nTrim(GRSA->QUSAI)+") "+Lower(AllTrim(CSEQ->TIPOGRD))+"-"
                  IF GRSA->SEQGRADE1<>GRSA->SEQGRADE2
                  CSEQ->(DBGOTO(GRSA->SEQGRADE2))
                  WNOM_GRADE:=WNOM_GRADE+Lower(AllTrim(CSEQ->TIPOGRD))+"-"
                  ENDIF
                  GRSA->(DBSkip())
                  ENDDO
                  IF !Empty(WNOM_GRADE)
                  @PRow(),00 say WNOM_GRADE
                  ?
                  ENDIF
                 */
                $WNOM_GRADE = "";
                $otgrsa = mysqli_query($db, "select * from GRADESAI_SAI where is_deleted='N' and nfsai=$nota and prsai=" . $olpro["CODPRO"]);
                while ($olgrsa = mysqli_fetch_array($otgrsa)) {
                    if ($olgrsa["QUSAI"] == 0) {
                        continue;
                    }

                    $olcseq = mysqli_fetch_array(mysqli_query($db, "select * from GRADESEQ_PRO where is_deleted='N' and recno=" . $olgrsa["SEQGRADE1"]));

                    $WNOM_GRADE = $WNOM_GRADE . "(" . number_format($olgrsa["QUSAI"], 0) . ") " . strtolower($olcseq["TIPOGRD"]);

                    if (trim($olgrsa["SEQGRADE1"]) !== trim($olgrsa["SEQGRADE2"])) {
                        $olcseq = mysqli_fetch_array(mysqli_query($db, "select * from GRADESEQ_PRO where is_deleted='N' and recno=" . $olgrsa["SEQGRADE2"]));
                        $WNOM_GRADE = $WNOM_GRADE . "-" . strtolower($olcseq["TIPOGRD"]) . "-";
                    }
                }

                if (strlen($WNOM_GRADE) > 0) {
                    $cimp .= $WNOM_GRADE;
                    $cimp .= P_CR;
                }
            }
        }


        if ($W_BLACK == "S") {
            if ($olsai["MOEDA"] == 1 && $olpro["PRE_BLACK"] < $olpro["PREVEN"] && $olpro["BLACK_FRI"] == "S") {
                $cimp .= substr($W_PROMO, 0, 20) . "-> " .
                        substr(number_format($olpro["PREVEN"] - $olpsa["CUMOE"], $olmoe["DECI" . $olsai["MOEDA"]] ? 2 : 0, ".", ","), -13);

                $cimp .= P_CR;
                $TEM_BLA_NT = "S";
            }
        }

        if ($olpro["PROMO_P"] == "S" && $olpro["PRECO5"] <> 0 && $olpro["CODPROMO"] <> 0 && $olpsa["PROMOPSA"] == "S") {
            if ($olsai["MOEDA"] == 1) {
                $cimp .= "Descto " . trim($W_NOME_PRM) . " -> " .
                        substr(number_format(($W_BASE_PRM - $olpsa["CUMOE"]) * $olpsa["QUSAI"], $olmoe["DECI" . $olsai["MOEDA"]] ? 2 : 0, ".", ","), -13);
                $cimp .= P_CR;
                $TEM_BLA_NT = "S";
            }
        }

        if ($olcfg["PROM_QUAN"] == "S" && $olpsa["CUMOE"] < $olpsa["PRE_TABELA"] && !$lorc) {
            if ($olsai["MOEDA"] == 1) {
                $cimp .= "Descto " . $olpsa["AGRU_PROMO"] . "   " . " -> " .
                        substr(number_format(($olpsa["PRE_TABELA"] - $olpsa["CUMOE"]) * $olpsa["QUSAI"], $olmoe["DECI" . $olsai["MOEDA"]] ? 2 : 0, ".", ","), -13);
                $cimp .= P_CR;
                $TEM_BLA_NT = "S";
            }
        }

        $cimp .= str_repeat("-", 48);
        $cimp .= P_CR;

        if ($olpsa["KITSAI"] <> "K") {
            $WTOTQUA = $WTOTQUA + $olpsa["QUSAI"];
        }
    }

    if ($W_BLACK == "N" && $olcfg["PROM_QUAN"] == "N") {
        if ($olsai["DESCSAI"] <> 0 && $olcfg["MOSTDES"] == "S") {
            $cimp .= P_CR;
            $cimp .= "Subtotal: " . xtransform($VTOTAL, 30, $ldecimal);
            $cimp .= P_CR;
            $cimp .= "Desconto: " . xtransform($olsai["DESCSAI"], 40, $ldecimal);
            $cimp .= P_CR;
            $VTOTAL -= $olsai["DESCSAI"];
        }
    }

    if ($W_BLACK == "S" || $olcfg["PROM_QUAN"] == "S" || $olcfg["REGRA_PRM"] == "S") {

        if ($TEM_BLA_NT == "N") {
            $WDESCPROMO = 0;
        }

        if ($WDESCPROMO <> 0) {
            $cimp .= P_CR;
            $cimp .= "Subtotal: " . P_NEG . xtransform($VTOTAL, 30 + 8, $ldecimal) . P_DNEG;
            $cimp .= P_CR;
            $cimp .= "Desconto: " . P_NEG . xtransform($WDESCPROMO, 30 + 8, $ldecimal) . P_DNEG;
            $cimp .= P_CR;
            $VTOTAL -= $WDESCPROMO;
        }
    }


    $cimp .= str_repeat("-", 48);
    $cimp .= P_CR;
    $cimp .= "Itens: " . P_EXP . $WTOTQUA;
    $cimp .= P_CR;
    $cimp .= str_repeat("-", 48);
    $cimp .= P_CR;
    if ($olemp["PERCFAT"] == 0) {
        if ($lepson) {
            $cimp .= "TOTAL  " . P_EXP . $olmoe["SIMB" . $olsai["MOEDA"]] . xtransform($VTOTAL, 14, $ldecimal);
        } else {
            $cimp .= "TOTAL      " . P_EXP . $olmoe["SIMB" . $olsai["MOEDA"]] . xtransform($VTOTAL, 14, $ldecimal);
        }
        $cimp .= P_DEXP . P_CR;
    } else {
        $cimp .= id("AL CONTADO ") . P_EXP . $olmoe["SIMB" . $olsai["MOEDA"]] . xtransform($VTOTAL, 14, $ldecimal);
        $cimp .= xtransform($VTOTAL, 13, $ldecimal);
        $cimp .= P_DEXP . P_CR;
        $XTOTAL = $VTOTAL;
        $XTOTAL = $XTOTAL + ($olemp["PERCFAT"] * $XTOTAL / 100);
        $cimp .= str_repeat("-", 48);
        $cimp .= P_CR;

        $cimp .= str_pad("** OTRAS FORMAS DE PAGO **", 48, " ", STR_PAD_BOTH);

        $cimp .= P_CR;
        $cimp .= "      " . chr(27) . P_EXP . $olmoe["SIMB" . $olsai["MOEDA"]] . xtransform($XTOTAL, 14, $ldecimal);
        $cimp .= P_CR;
        $cimp .= str_repeat("-", 48);
        $cimp .= P_CR;
    }

    $cimp .= str_repeat("-", 48) . Chr(27) . Chr(51) . Chr(25);
    $cimp .= P_CR;
    if (trim(pegavar("mostra_cot"))) {
        $cimp .= iconv("UTF8", "CP850", "Cotizacion en momento: ") . P_CR;
        $ocam = mysqli_fetch_array(mysqli_query($db, "select
 n.simb1,n.simb2,n.simb3,n.simb4
,n.deci1,n.deci2,n.deci3,n.deci4
,c.moeda1,c.moeda2,c.moeda3,c.moeda4
from CAMBIO_CAM c
inner join CAMBIO_NOM n on n.is_deleted='N'
where c.is_deleted='N'
order by c.datcam desc limit 1
;
"));
        for ($i = 1; $i <= 4; $i++) {
            $cimp .= $ocam["simb$i"] . " " . trim(number_format($ocam["moeda$i"], $ocam["deci$i"] == "S" ? 2 : 0, ",", "."));
            if ($i < 4) {
                $cimp .= " = ";
            }
        }
        $cimp .= P_CR;
        $cimp .= P_CR;
    }



    if (trim($olemp["MENS01"])) {
        $cimp .= iconv("CP850", "UTF8", str_pad(trim($olemp["MENS01"]), 63, " ", STR_PAD_BOTH));
        $cimp .= P_CR;
    }

    if (trim($olemp["MENS02"]) && $lorc) {
        $cimp .= iconv("CP850", "UTF8", str_pad(trim($olemp["MENS02"]), 63, " ", STR_PAD_BOTH)) ;
        $cimp .= P_CR;
    }

    $cret = "";
    for ($i = 1; $i <= $nvias; $i++) {
        $cret .= $cimp . P_CR;
        $cpag = '';
        if ($olsai["SITSAI"] == "S") {
            $cpag .= " * PAGADA * ";
        }
        if ($olsai["RETISAI"] == "S") {
            $cpag .= " * RETIRADA * ";
        }
        if ($cpag) {
            $cret .= P_EXP . P_NEG . str_pad($cpag, 24, " ", STR_PAD_BOTH) . P_DEXP;
        }
        $cret .= P_EXP . P_NEG . str_pad("VIA #$i" . ($lreimp ? " REIMPRESION" : ""), 24, " ", STR_PAD_BOTH) . P_DEXP;
        //mega cortar papel
        $cret .= str_repeat(P_CR, BEMA_LINHAS_FINAL);
        $cret .= Chr(27) . "m";
    }
    $cret .= Chr(27) . Chr(118) . Chr(140); //abrir gaveta

    return $cret;
}

function id($cstr) {
    return $cstr;
}

function xtransform($nvalor, $ntam = 13, $ldecimal = true) {
    return substr("                                                  " . number_format($nvalor, $ldecimal ? 2 : 0, ".", ","), $ntam * -1);
}
