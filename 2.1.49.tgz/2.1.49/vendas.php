<?php

//marcara em guarani
//consulta preço apenas cliente
//local

/*
  AUTORIZACAO GERAL
  html=>vd_modal_aut
  js=>vd_modal_aut_sol
  php=>vendas.php modo=PEDE_AUT_TUDO
  js=>AutorizaTotal
  html=>pd_autoriza
  js=>pd_autoriza_inc
  js=>AutorizaIncG
  php=>vendas.php modo=PED_AUT_GERAL_1
  js=>EsperaAutG
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";
if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}
$noperador = VeSession("usuario"); //$_SESSION["usuario"];
$modo = PegaVar("modo");
$vendedor = PegaVar("vendedor");
if (!$vendedor) {
    $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
}

$nserie = pegavar('serie') + 0;
$nvendedor = $vendedor;
$lorc = PegaVar("orcamento") == "true";

$nlojapre = pegavar("lj_preco");
$lveiculo = pegavar("lveiculo");
//RESTOCK
$CQUALOC = "l.qualoc";
$INNERQUALOC = "";
if (VeConfigCec("MINMAX") == "S") {
    $CQUALOC = "if(isnull(r.prores) or r.quares=0 or r.quares>l.qualoc, l.qualoc, r.quares )";
    $INNERQUALOC = "left join RESTOCK_PRO r on r.is_deleted='N' and r.lojres=l.locloc and r.prores=l.proloc";
}


$olcfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG"));
$olistcli = mysqli_fetch_array(mysqli_query($db, "select c.listcli,t.loja from CLIENTE_CLI c 
        inner join  tablet" . $lweb . "_cab t on t.serie='$nserie' and t.vendedor=$vendedor and t.cliente=c.codcli
        where c.is_deleted='N' AND c.codcli!=0"));

$clistcli = $olistcli[0];
if ($olcfg["LISABCCL"] != 'S') {
    $clistcli = '';
}

if ($nlojapre) {
    $nloja_precos = $nlojapre;
} else {
    $nloja_precos = $olistcli[1];
}
$cprecoa = "preven";
$cprecob = "preco3";
$cprecoc = "premin";
$cprecot = "preatac";

$cpreven = $cprecoa;
$cpremin = $cprecoc;
if ($clistcli == "A") {
    $cpreven = $cprecoa;
    $cpremin = $cprecoa;
} else if ($clistcli == "B") {
    $cpreven = $cprecob;
    $cpremin = $cprecob;
} else if ($clistcli == "C") {
    $cpreven = $cprecoc;
    $cpremin = $cprecoc;
} else if ($clistcli == "D") {
    $cpreven = $cprecot;
    $cpremin = $cprecot;
}

if ($modo == "NOTA_SEP") {
    $olin = mysqli_fetch_array(mysqli_query($db, "select * from SAIDAS_SAI WHERE NOTASAI='" . PEGAVAR("nota") . "'"));
    if (!$olin) {
        $aret["erro"] = 01;
        $aret["cerro"] = "Nota não existe ";
        echo json_encode($aret);
        return;
    }
    if ($olin["IS_DELETED"] == "Y") {
        $aret["erro"] = 02;
        $aret["cerro"] = "Nota está deletada";
        echo json_encode($aret);
        return;
    }
    if ($olin["SITSAI"] == "S") {
        $aret["erro"] = 03;
        $aret["cerro"] = "Nota já está paga";
        echo json_encode($aret);
        return;
    }
    $lsepara = pegavar("modo1") == "true";
    if ($lsepara && $olin["SEPSAI"] == "S") {
        $aret["erro"] = 04;
        $aret["cerro"] = "Nota já está em separação";
        echo json_encode($aret);
        return;
    }
    if (!$lsepara && $olin["SEPSAI"] !== "S") {
        $aret["erro"] = 05;
        $aret["cerro"] = "Nota não está em separação";
        echo json_encode($aret);
        return;
    }
    $cstr = "update SAIDAS_SAI SET SEPSAI='" . ($lsepara ? "S" : "N") . "',AUTZSEP=" . ($lsepara ? $noperador : 0) . " WHERE NOTASAI=" . $olin["NOTASAI"];
    if ($lsepara) {
        $cRefErro = '';
        ImprimeSeparacaoBema($olin["NOTASAI"], '', '', $creferro);
    }
    mysqli_query($db, $cstr);
    echo json_encode($aret);
    return;
}
if ($modo == "VECASH") {
    $ncliente = pegavar("cliente");
    $nvendedor = pegavar("vendedor");
    $nserie = pegavar("serie");
    $aret["cashok"] = 0;
    $aret["cashpro"] = array();
    $otab = mysqli_query($db, "select  pais_num from CLIENTE_PGY WHERE IS_DELETED='N' AND CODigo=" . $ncliente . " and pais_num=76");
    if (mysqli_num_rows($otab) == 0) {
        echo json_encode($aret);
        return;
    }
    $otab = mysqli_query($db, "show tables like 'CONFIG_CBK'");
    if (mysqli_num_rows($otab) == 0) {
        echo json_encode($aret);
        return;
    }
    $otab = mysqli_query($db, "select c.codigo,c.nome,c.valor,c.credito,c.produto FROM CONFIG_CBK c 
                WHERE c.IS_DELETED='N' AND c.ATIVO='Y' AND c.INICIO<=" . AsSql(Date2Unix()) . " AND c.FINAL>=" . AsSql(Date2Unix()) . " order by c.codigo");

    if (mysqli_num_rows($otab) == 0) {
        echo json_encode($aret);
        return;
    }
    while ($olin = mysqli_fetch_array($otab)) {
        $aret["cashpro"][] = array($olin["codigo"], $olin["nome"], $olin["valor"], $olin["credito"], $olin["produto"]);
        if (mysqli_num_rows(mysqli_query($db, "select codigo from tablet" . $lweb . "_pro t where t.vendedor=$nvendedor and t.codigo=" . $olin["produto"] . " and t.serie=$nserie ")) > 0) {
            $aret["cashpro"] = array();
            echo json_encode($aret);
            return;
        }
    }
    $aret["cashok"] = 1;
    echo json_encode($aret);
    return;
}

if ($modo == "PEDE_AUT_TUDO") {
    $apro = pegavar("solicita");
    $wvalven = 0;
    $wvalmin = 0;
    if (!PEDE_AUT_TUDO($nvendedor, $apro, $wvalven, $wvalmin)) {
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Erro Gravando dados");
    }
    $aret["wvalven"] = $wvalven;
    $aret["wvalmin"] = $wvalmin;

    echo json_encode($aret);
    return;
}

if ($modo == "PRECO_VENDA") {
    $nproduto = pegavar("ncodigo");
    $ncliente = pegavar("ncliente");
    define("SAIDAS_COP", 405);
    $csql1 = "select c.SITOPG
FROM OPEGRUPO_OPE c
inner join tablet" . $lweb . "_cab t on t.vendedor=$vendedor
inner join OPERADOR_OPE o on o.is_deleted='N' and o.codigo=t.operador and c.codopg=(cifra(o.grupo)+0)
where c.is_deleted='N' and opeopg=" . SAIDAS_COP;
//inner join OPERADOR_OPE o on o.bloq_vdas!='S' and o.is_deleted='N' and o.codigo=t.operador and c.codopg=(cifra(o.grupo)+0)

    $ltodos = (mysqli_fetch_row(mysqli_query($db, $csql1))[0]) == "X";
    $csql = "select s.qusai as quant,s.cusai as valor,c.codcli,c.nomcli,n.datasai as data
from PROSAI_SAI s
inner join SAIDAS_SAI n on n.is_deleted='N' and n.recno=s.nfsai and n.cliesai='$ncliente'
inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai AND c.codcli!=0
where s.is_deleted='N' and s.prsai=$nproduto";
    if (!$ltodos) {
        $csql .= " and n.vendsai=$vendedor";
    }
    $csql .= " order by s.recno desc limit 30";
    $otab = mysqli_query($db, $csql);
    $aret["preco"] = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $aret["preco"][] = array("quant" => $olin["quant"], "valor" => $olin["valor"], "data" => sql2data($olin["data"])
            , "cliente" => $olin["codcli"] . '-' . iconv("cp850", "utf-8", $olin["nomcli"]), "codcli" => $olin["codcli"]);
    }
    echo json_encode($aret);
    return;
}
if ($modo == "NOTA_PDF") {
    $lorc = PegaVar("orcamento") == "true";
    $nnota = pegavar("nota");
    /*
     *         
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
      <link rel="stylesheet" href="assets/components/bootstrap/css/font-awesome.min.css">
      <link rel="stylesheet" href="assets/components/bootstrap/fonts/all.css" >

     */
    $cHtml = '<html><head>

        <link rel="stylesheet" href="assets/components/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/components/bootstrap/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/components/bootstrap/fonts/all.css" >
     <script src="assets/components/bootstrap/js/html2pdf.bundle.min.js"></script>';

    $ajs = array();
    $ajs[] = "assets/components/jquery/jquery.min.js";
    $ajs[] = "assets/components/jquery-mask/jquery.mask.min.js";
    $ajs[] = "assets/components/bootstrap/js/bootstrap.min.js";
    $ajs[] = "assets/components/bootbox/mybootbox.js";
    foreach ($ajs as $value) {
        $cHtml .= '         <script src="' . $value . "?v=" . filemtime($value) . '"></script>' . "\n";
    }

    $cHtml .= '<style>
         .cont{
         width: 600px;
         }
         .fonte {
         font-size: 0.8em;
         }
         </style>
         </head><body>';
    $onot = mysqli_fetch_array(mysqli_query($db, "select 
 n.recno
,date_format(n.datasai,'%d/%m/%Y') as data
,n.horasai as hora
,n.quansai as itens
,n.valosai as valor
,n.nomger as nomegeral
,v.codven as vendedor,v.nomven as cvendedor
,l.codemp as loja,l.nomemp as cloja
,c.codcli as cliente,c.nomcli as ccliente
,n.observ as obs
,convert(if(isnull(m.recno),'',m.memo),char) as obs1
,if(n.moeda=4,b.simb4,if(n.moeda=3,b.simb3,if(n.moeda=2,b.simb2,b.simb1)) ) as simb
,if(n.moeda=4,b.deci4,if(n.moeda=3,b.deci3,if(n.moeda=2,b.deci2,b.deci1)) ) as deci
,n.cambsai,n.basesai

from " . ($lorc ? "SAIDA_ORC" : "SAIDAS_SAI") . " n
inner join CAMBIO_NOM b on b.recno=1
left join " . ($lorc ? "SAIDA_ORC" : "SAIDAS_SAI") . "_MEMO m on m.recno=n.recno and m.col_name='OBSAI'
inner join VENDEDOR_VEN v on v.is_deleted='N' and v.codven=n.vendsai
inner join CLIENTE_CLI  c on c.is_deleted='N' and c.codcli=n.cliesai AND c.codcli!=0
inner join EMPRESA_EMP  l on l.is_deleted='N' and l.codemp=n.lojasai

where n.recno=$nnota
;"));
    $cstyle = "";
    $cHtml .= '<div class="container" id="conteudo" ><div class="row"><table id="tab1" class="table table-bordered" ' . $cstyle . '>';
    $cHtml .= '
        <tr>';
    if (file_exists("img/logo_pdf.png")){
//       $cHtml.='<td class="text-center" colspan="2"><img src="img/logo_pdf.png" class="img-responsive img-rounded" style="max-width: 300px;"></td>';
//       $cHtml.='<td class="text-center" colspan="2" style="vertical-align: middle;"><h3>[[NOMEEMP]] </h3></td><td class="text-center" colspan="2"> <img height="100px" src="[[LOGOEMP]]"></td></tr>';
       $cHtml.='<td class="text-center" colspan="4" style="vertical-align: middle;">
    <div style="display: inline-flex; align-items: center; justify-content: center; gap: 15px;">
        <img src="img/logo_pdf.png" class="img-responsive img-rounded" style="max-width: 200px;">
        <h3  style="margin: 0;">[[NOMEEMP]]</h3>
    </div>
</td>
';
    }else{
       $cHtml.='<td class="text-center" colspan="4">[[NOMEEMP]]  </td>';
    }
    $cHtml.='             <td class="text-center" colspan="2"> <img height="100px" src="[[LOGOEMP]]"></td></tr>
        <th class="text-right">' . ($lorc ? "Orçamento" : "Nota") . ' : </th><td>' . $nnota . '-' . digito($nnota) . '</td>
        <th class="text-right">Emissão: </th><td>' . $onot["data"] . ' ' . $onot["hora"] . ' </td>
        <th class="text-right">Loja: </th><td>' . $onot["loja"] . '-' . $onot["cloja"] . ' </td>
        </tr><tr>    
        <th class="text-right">Cliente: </th><td colspan="2">' . $onot["cliente"] . '-' . iconv("cp850", "utf-8", $onot["ccliente"]) . ' </td>
        <th class="text-right">Vendedor: </th><td colspan="2">' . $onot["vendedor"] . '-' . iconv("cp850", "utf-8", $onot["cvendedor"]) . ' </td>
        </tr><tr>    
        <th class="text-right"><h4>Valor: </h4></th><td colspan="2"><h4>' . $onot["simb"] . ' ' . my_number_format($onot["valor"], $onot["deci"] == 'S' ? 2 : 0) . '</h4> </td>
        <th class="text-right"><h4>Itens:</h4> </th><td colspan="2"><h4>' . my_number_format($onot["itens"], 0) . '</h4> </td>
        </tr>
     </table>';
    $cHtml .= '<table id="tab2" class="table  table-bordered" ' . $cstyle . '>';
    $cHtml .= '<tr><th colspan="2">Produto</th><th>Quant.</th><th>Unitário</th><th>Total</th></tr>';

//    $otab = mysqli_query($db, "select p.codpro as codigo,p.nomelong as nome,s.qusai as quant,s.cusai/n.basesai*n.cambsai as valor,p.gradepro
    $otab = mysqli_query($db, "select p.codpro as codigo,p.nomelong as nome,s.qusai as quant,s.cumoe as valor,p.gradepro
from PROSAI_" . ($lorc ? "ORC" : "SAI") . " s inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai
    inner join " . ($lorc ? "SAIDA_ORC" : "SAIDAS_SAI") . " n on n.recno=$nnota
where s.nfsai=$nnota");
    while ($olin = mysqli_fetch_array($otab)) {
        $WNOM_GRADE = "";
        if (trim($olin["gradepro"])) {
            $otgrsa = mysqli_query($db, "select * from GRADESAI_SAI where is_deleted='N' and nfsai=$nnota and prsai=" . $olin["codigo"]);
            while ($olgrsa = mysqli_fetch_array($otgrsa)) {
                if ($olgrsa["QUSAI"] == 0) {
                    continue;
                }

                $olcseq = mysqli_fetch_array(mysqli_query($db, "select * from GRADESEQ_PRO where is_deleted='N' and recno=" . $olgrsa["SEQGRADE1"]));

                $WNOM_GRADE = $WNOM_GRADE . "(" . number_format($olgrsa["QUSAI"], 0) . ") " . strtolower($olcseq["TIPOGRD"]);

                if (trim($olgrsa["SEQGRADE1"]) !== trim($olgrsa["SEQGRADE2"])) {
                    $olcseq = mysqli_fetch_array(mysqli_query($db, "select * from GRADESEQ_PRO where is_deleted='N' and recno=" . $olgrsa["SEQGRADE2"]));
                    $WNOM_GRADE = $WNOM_GRADE . "-" . strtolower($olcseq["TIPOGRD"]) . "-";
                }
            }
        }
        $cHtml .= '<tr><td class="text-right">' . poedigito($olin["codigo"]) . '</td>
            <td class="text-left">' . iconv("cp850", "utf-8", $olin["nome"]) . (strlen($WNOM_GRADE) > 0 ? " => " . $WNOM_GRADE : "") . '</td> 
            <td class="text-right">' . my_number_format($olin["quant"], 0) . '</td> 
            <td class="text-right">' . my_number_format($olin["valor"], $onot["deci"] == 'S' ? 2 : 0) . '</td> 
            <td class="text-right">' . my_number_format($olin["quant"] * $olin["valor"], $onot["deci"] == 'S' ? 2 : 0) . '</td></tr> 
            ';
    }
    $cHtml .= '</table>';
    if ($onot["obs"] || $onot["obs1"]) {
        $cHtml .= '<hr><table id="tab3" class="table table-bordered"' . $cstyle . '>';
        if ($onot["obs"]) {
            $cHtml .= '<tr><td class="text-left">';
            $cHtml .= str_replace(chr(10), "<br>", $onot["obs"]) . '</td></tr>';
        }
        if (false && $onot["obs1"]) {
            $cHtml .= '<tr><td class="text-left">';
            $cHtml .= str_replace(chr(10), "<br>", $onot["obs1"]) . '</td></tr>';
        }
        $cHtml .= '</table>';
    }
    $cHtml .= '
        <hr>
            </div>
                        <div class="row text-center" id="btpdf">
                            <div class="text-center col-md-6" >
                                <button class="btn btn-primary" type="button"  onclick="javascript:ImprimePdf();">
                                    PDF <i class="fa fa-file-pdf-o" ></i>
                                </button>
                            </div>
                            <div class="text-center col-md6" >
                                <button class="btn btn-success" type="button"  onclick="window.close();">
                                    Fechar <i class="fa fa-close" ></i>
                                </button>
                            </div>
                        </div>
            
            
            </div>        
            <script>
function ImprimePdf() {
    $("#btpdf").addClass("hidden");
    $("#conteudo").addClass("cont");
    $("#tab1").addClass("fonte");
    $("#tab2").addClass("fonte");
    $("#tab3").addClass("fonte");
    
    const elemento = document.getElementById(\'conteudo\');

    const opcoes = {
        margin: 10,
        filename: \'Nota_' . $nnota . digito($nnota) . '.pdf\',
        image: { type: \'jpeg\', quality: 1 },
        html2canvas: {
            scale: 2,
            useCORS: true
        },
        jsPDF: {
            unit: \'mm\',
            format: \'a4\',
            orientation: \'portrait\'
        }
    };

    html2pdf()
        .set(opcoes)
        .from(elemento)
        .save();
        setTimeout(function(){
    $("#btpdf").removeClass("hidden");
    $("#conteudo").removeClass("cont");
    $("#tab1").removeClass("fonte");
    $("#tab2").removeClass("fonte");
    $("#tab3").removeClass("fonte");
},5000);
    }            

            </script>
        </body>
        </html>';
    $aret["html"] = $cHtml;
    echo json_encode($aret);
    return;
}
if ($modo == 77) {
    $aret["vence"] = 0;
    $ncliente = PegaVar("cliente");
    if (!$ncliente) {
        echo json_encode($aret);
        return;
    }
    $otab = mysqli_query($db, "show tables like 'tablet" . $lweb . "_cad'");
    if (mysqli_num_rows($otab) == 0) {
        mysqli_query($db, "create table tablet" . $lweb . "_cad (chave char(23) not null default '' )");
        $caux = str_pad($ncliente, 10, '0', STR_PAD_LEFT);
        $nven = Date2Unix() + (30 * 24 * 60 * 60);
        $caux .= str_pad($nven, 10, '0', STR_PAD_LEFT);
        $caux .= digito($ncliente) . digito($nven) . digito($nven + $ncliente + digito($ncliente) + digito($nven));
        mysqli_query($db, "insert tablet" . $lweb . "_cad set chave='$caux'");
        $aret["vence"] = $nven;
        echo json_encode($aret);
        return;
    }
    $caux = '' . mysqli_fetch_row(mysqli_query($db, "select * from tablet" . $lweb . "_cad"))[0] . '';
    $ncli = substr($caux, 0, 10) + 0;
    $nven = substr($caux, 10, 10) + 0;
    $ndv1 = substr($caux, 20, 1) + 0;
    $ndv2 = substr($caux, 21, 1) + 0;
    $ndv3 = substr($caux, 22, 1) + 0;

    if (!$caux || $ncli != $ncliente || $ndv1 != digito($ncliente) || $ndv2 != digito($nven) || $ndv3 != digito($nven + $ncli + digito($nven) + digito($ncli))) {
        echo json_encode($aret);
        return;
    }
    $aret["vence"] = $nven + 0;
    echo json_encode($aret);
    return;
}

require_once 'inc/sid.php';

define("R_PRO", 1 - 1);
define("R_QUA", 2 - 1);
define("R_COD", 3 - 1);
define("R_NOM", 4 - 1);
define("R_QUAP", 5 - 1);
define("R_DESC", 6 - 1);
define("R_PROMO", 7 - 1);

if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("Erro acessando servidor") . ".\n" . $caux;
    echo json_encode($aret);
    return;
}



if (pegavar("imprimir") == "true") {
    $otab = mysqli_query($db, "select linha from tablet" . $lweb . "_imp where tipo='C' order by ordem");
    $cab = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $cab[] = trim($olin[0]);
    }
    $otab = mysqli_query($db, "select linha from tablet" . $lweb . "_imp where tipo='R' order by ordem");
    $rod = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $rod[] = trim($olin[0]);
    }
    $aret["cab"] = $cab;
    $aret["rod"] = $rod;

    $nnota = pegavar("nota");

    $onot = mysqli_query($db, "select 
 n.recno
,date_format(n.datasai,'%d/%m/%Y') as data
,n.horasai as hora
,n.quansai as itens
,n.valosai as valor
,n.nomger as nomegeral
,v.codven as vendedor,v.nomven as cvendedor
,l.codemp as loja,l.nomemp as cloja
,c.codcli as cliente,c.nomcli as ccliente
,n.observ as obs
,convert(if(isnull(m.recno),'',m.memo),char) as obs1

from SAIDAS_SAI n
left join SAIDAS_SAI_MEMO m on m.recno=n.recno and m.col_name='OBSAI'
inner join VENDEDOR_VEN v on v.is_deleted='N' and v.codven=n.vendsai
inner join CLIENTE_CLI  c on c.is_deleted='N' and c.codcli=n.cliesai AND c.codcli!=0
inner join EMPRESA_EMP  l on l.is_deleted='N' and l.codemp=n.lojasai

where n.recno=$nnota
;
");
    $olnot = mysqli_fetch_array($onot);
    $aret["nota"] = $olnot;
    echo json_encode($aret);
    return;
}
/*
  if ($modo == 41) {
  $nCliente=pegavar("cliente");
  $cRefGuia="";
  $nRefGuia=0;
  $aret["cguia"]='';
  $aret["nguia"]=0;
  if (VeListaGuiaCli($nCliente, $cRefGuia, $nRefGuia)){
  $aret["cguia"]=$cRefGuia;
  $aret["nguia"]=$nRefGuia;
  }
  echo json_encode($aret);
  return;
  }
 */

if ($modo == 82) {
    $nregistro = pegavar("registro");
    $otab = mysqli_query($db, "select * from AUTORIZA_AUT WHERE RECNO='$nregistro'");
    if (mysqli_num_rows($otab) == 0) {
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Registro não encontrado");
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);
    if ($olin["IS_DELETED"] == 'Y') {
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Registro deletado");
        echo json_encode($aret);
        return;
    }
    if ($olin["DATA_AUT"] == '1000-01-01') {
        $aret["erro"] = "50";
        $aret["cerro"] = _tr("Esperando Autorização");
        echo json_encode($aret);
        return;
    }
    $cAux = $olin["AUTORIZADO"];
    /*        $aret["erro"] = "40";
      $aret["cerro"] = "Registro Adulterado \n ".cifra($cAux)."\n". cifra(str_pad($cAux, 100," ",STR_PAD_RIGHT));
      echo json_encode($aret);
      return;
     */
    $cAux = cifra($cAux);

    $lRet = false;
    if (!( str_replace("-", "", $olin["DATA_AUT"]) == substr($cAux, 0, 8) ) ||
            !( $olin["HORA_AUT"] == SubStr($cAux, 9, 8) )) {
        mysqli_query($db, "update AUTORIZA_AUT SET AUTORIZADO='ADULTERADO' WHERE RECNO=$nregistro");
        $aret["erro"] = "99";
        //$caux=     "|".str_replace("-", "", $olin["DATA_AUT"])."|".substr($cAux, 0, 8)  ."|". $olin["HORA_AUT"] ."|".SubStr($cAux, 9, 8) ;
        $aret["cerro"] = _tr("Registro Adulterado");

        echo json_encode($aret);
        return;
    }

    $lRet = SubStr($cAux, 8, 1) == "1";

    if (!$lRet) {
        $aret["cerro"] = _tr("Autorização Negada") . "\n\n" . $olin["MOTIVO_AUT"];
        $aret["erro"] = "40";
    } else {
        $aret["erro"] = "10";
        //atualiza arquivo

        $otab = mysqli_query($db, "select * from AUF_" . ($nvendedor + 1000));
        $aret["cerro"] = _tr("Autorização Concedida") . "<br>" . $olin["MOTIVO_AUT"];
        while ($olin = mysqli_fetch_object($otab)) {
            $cstr = "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set valor=$olin->PRE_LIBER,AUTZ_PRECO=$olin->AUTZ_PRECO,AUTZ_QUANT=$olin->AUTZ_QUANT WHERE vendedor=$vendedor AND serie='$nserie' AND codigo=$olin->CODTPO";
            mysqli_query($db, $cstr);
        }
        $otab = mysqli_query($db, "select codtpo*10+digito(codtpo) as codigo,pre_suger,pre_liber from AUF_" . ($nvendedor + 1000));
        $aret["cerro"] .= '<br><table class="table" ><tr><th class="text-right">Cod.</th><th class="text-right">Ped.</th><th class="text-right">Lib.</th><th class="text-right">Dif.</th></tr>';
        while ($olin = mysqli_fetch_object($otab)) {
            $aret["cerro"] .= '<tr><td class="text-right">' . $olin->codigo . '
                </td><td class="text-right">' . number_format($olin->pre_suger, 2, ".", " ") .
                    '</td><td class="text-right">' . number_format($olin->pre_liber, 2, ".", " ") .
                    '</td><td class="text-right">' . number_format($olin->pre_suger - $olin->pre_liber, 2, ".", " ") .
                    '</td></tr>';
        }
        $aret["cerro"] .= '</table>';
    }

    echo json_encode($aret);
    return;
}


if ($modo == 81 || $modo == "PED_AUT_GERAL_1") {
    $nvendedor = pegavar("vendedor");
    $nsolicita = PegaVar("nsolicita");
    $nusuario = VeSession("usuario"); //$_SESSION["usuario"];
    $cobs = PegaVar("cobs");
    $nserie = pegavar('serie') + 0;
    $wvalven = pegavar("wvalven");
    $wvalmin = pegavar("wvalmin");

    $cstr = "select t.cliente,c.nomcli as ccliente,t.prazo,t.vendedor,v.nomven as cvendedor,t.loja,e.nomemp as cloja 
        from tablet" . $lweb . "_cab t
        inner join CLIENTE_CLI  c on c.is_deleted='N' and c.codcli=t.cliente AND c.codcli!=0
        inner join VENDEDOR_VEN v on v.is_deleted='N' and v.codven=t.vendedor
        inner join EMPRESA_EMP  e on e.is_deleted='N' and e.codemp=t.loja
        where t.vendedor=$nvendedor and t.serie=$nserie
        ";
    $otab = mysqli_query($db, $cstr);
    $olin = mysqli_fetch_object($otab);
    $aux = "** Autoriza Precos Venda Tablet Term " . (1000 + $nvendedor) . ($lorc ? " *PRESUPUESTO* " : "") . " **\r\n";
    $aux .= "Cliente : " . $olin->cliente . "-" .$olin->ccliente . "\r\n";
    $aux .= "Prazo   : " . $olin->prazo . " dias \r\n";
    $aux .= "Vended. : " . $olin->vendedor . "-" . $olin->cvendedor . "\r\n";
    $aux .= "Valor Total Vendido: " . str_pad(number_format($wvalven, 2, ".", " "), 15, " ", STR_PAD_LEFT) . "\r\n";
    $aux .= "Valor Total Minimo.: " . str_pad(number_format($wvalmin, 2, ".", " "), 15, " ", STR_PAD_LEFT) . "\r\n";
    $aux .= "Difer Venda - Minim: " . str_pad(number_format($wvalven - $wvalmin, 2, ".", " "), 15, " ", STR_PAD_LEFT) . "\r\n";
    $aux .= "Loja... : " . $olin->loja . "-" . $olin->cloja . "\r\n";

    $nrecno = mysqli_fetch_row(mysqli_query($db, "select recno from AUTORIZA_AUT WHERE TERM_SOL=" . (1000 + $nvendedor)))[0];
    if ($nrecno) {
        if ($lCfRdd) {
            $omed = new Mediator4("AUTORIZA.AUT", W_ALTERAR, '', $nrecno, $db, '', true);
        } else {
            $omed = new Mediator3("AUTORIZA.AUT", W_ALTERAR, '', $nrecno, $db, '', true);
        }
    } else {
        if ($lCfRdd) {
            $omed = new Mediator4("AUTORIZA.AUT", W_CRIAR, '', '', $db);
        } else {
            $omed = new Mediator3("AUTORIZA.AUT", W_CRIAR, '', '', $db);
        }
    }
    $ddata = date("Y-m-d");
    $hdata = date("H:i:s");
    //SAIDAS_UNI 205
    $nnivel = 205;
    $omed->aadd("DATA_SOL", $ddata);
    $omed->aadd("HORA_SOL", $hdata);
    $omed->aadd("COMPLEMENT", $aux);

    $omed->aadd("cor", "w/r,gr+/bg,,,gr+/r,W+/B,W+/BG");
    $cmot = "Autorizar Precos Tablet Vendedor : $nvendedor ";
    $omed->aadd("MOTIVO_SOL", iconv("utf8", "cp850", $cmot));
    $omed->aadd("nivel", cifra($hdata . str_pad($nnivel, 4, " ", STR_PAD_LEFT)));
    $omed->aadd("OPER_PED", str_pad(!$nsolicita ? 1 : $nsolicita, 3, "0", STR_PAD_LEFT) . "-");
    $omed->aadd("OPER_SOL", $nusuario);
    $omed->aadd("chave", GeraSenha(20));
    $omed->aadd("TERM_SOL", 1000 + $nvendedor);
    $omed->aadd("TEXTO", "finaliza");

    if (!$omed->grava()) {
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Erro Gravando autorização") . ".\n" . $omed->cerro;
        echo json_encode($aret);
        return;
    }
    $aret["registro"] = $omed->nrecno;
    echo json_encode($aret);
    return;
}




if ($modo == "ALTERA_NOTA" || $modo == 51) {
    $nota = tiradigito(PegaVar("nota"));
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar('serie') + 0;

    $cArqSai = $lorc ? "SAIDA.ORC" : "SAIDAS.SAI";
    $cArqPro = $lorc ? "PROSAI.ORC" : "PROSAI.SAI";
    $cArqGra = $lorc ? "GRADESAI.ORC" : "GRADESAI.SAI";

    $cArqSaiS = $lorc ? "SAIDA_ORC" : "SAIDAS_SAI";
    $cArqProS = $lorc ? "PROSAI_ORC" : "PROSAI_SAI";
    $cArqGraS = $lorc ? "GRADESAI_ORC" : "GRADESAI_SAI";

    $cNota = $lorc ? _tr("Orçamento") : _tr("Nota");

    $otab = mysqli_query($db, "Select * from $cArqSaiS WHERE RECNO=$nota");

    if (mysqli_num_rows($otab) == 0) {
        $aret["erro"] = 80;
        $aret["cerro"] = "$cNota " . _tr("não existe");
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);
    if ($olin["IS_DELETED"] == "Y") {
        $aret["erro"] = 81;
        $aret["cerro"] = "$cNota " . _tr("está deletada");
        echo json_encode($aret);
        return;
    }
    if ($olin["SITSAI"] == "S") {
        $aret["erro"] = 81;
        $aret["cerro"] = "$cNota " . _tr("já está paga");
        echo json_encode($aret);
        return;
    }
    /*
      if ($olin["VENDSAI"] !== $vendedor) {
      $aret["erro"] = 82;
      $aret["cerro"] = "$cNota " . _tr("não é deste vendedor");
      echo json_encode($aret);
      return;
      }
     */
    if (!$lweb) {
        if (mysqli_fetch_row(mysqli_query($db, "select venaltcli from CONFIG_TBL LIMIT 1"))[0] !== 'Y') {
            if ($olin["VENDSAI"] !== $vendedor) {
                $aret["erro"] = 82;
                $aret["cerro"] = "$cNota " . _tr("não é deste vendedor");
                echo json_encode($aret);
                return;
            }
        }
    } else {
        if (mysqli_fetch_row(mysqli_query($db, "select venaltcli from CONFIGVG_WEB LIMIT 1"))[0] !== 'Y') {
            if ($olin["VENDSAI"] !== $vendedor) {
                $aret["erro"] = 82;
                $aret["cerro"] = "$cNota " . _tr("não é deste vendedor");
                echo json_encode($aret);
                return;
            }
        }
    }
    //bloquear nota
//    mysqli_query($db, "update $cArqSaiS   SET IS_DELETED='Y' WHERE RECNO=" . $olin["RECNO"]);


    $cloja = trim(mysqli_linha("select lojas_ven as lojas from OPERADOR_OPE where is_deleted='N' and CODIGO=" . VeSession("usuario"))[0]);
//    $cloja = trim(mysqli_linha("select lojas_ven as lojas from OPERADOR_OPE where bloq_vdas!='S' and is_deleted='N' and CODIGO=" . VeSession("usuario"))[0]);
    $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l where l.is_deleted='N' ";
    if ($cloja) {
        $aloja = explode("-", $cloja);
        $lloja = false;
        foreach ($aloja as $value) {
            if ($value == $olin["LOJASAI"]) {
                $lloja = TRUE;
            }
        }
//995654900 fabricio
        if (!$lloja) {
            $aret["erro"] = 83;
            $aret["cerro"] = "$cNota " . _tr("não é da loja que você tem acesso");
            echo json_encode($aret);
            return;
        }
    }

    if ($lCfRdd) {
        $omed = new Mediator4($cArqSai, W_BLOQUEAR, '', $nota);
    } else {
        $omed = new Mediator3($cArqSai, W_BLOQUEAR, '', $nota);
    }
    if (!$omed->grava()) {
        mysqli_query($db, "update $cArqSaiS   SET IS_DELETED='N' WHERE RECNO=" . $olin["RECNO"]);
        $aret["erro"] = $omed->erro;
        $aret["cerro"] = _tr("Erros Bloqueando NOTA") . "<br>" . $omed->cerro;
        echo json_encode($aret);
        return;
    }
    mysqli_query($db, "update $cArqSaiS SET IS_DELETED='Y' WHERE RECNO=$nota");
    //LOGS
    if ($lCfRdd) {
        $omed = new Mediator4("LOG.LOG", W_CRIAR);
    } else {
        $omed = new Mediator3("LOG.LOG", W_CRIAR);
    }
    $omed->aadd("DATA", 'CURRENT_DATE()', TRUE);
    $omed->aadd("HORA", 'CURRENT_TIME()', TRUE);
    $omed->aadd("DOCUMENTO", "SAI" . $nota);
    $omed->aadd("OPERADOR", 1);
    $omed->aadd("SUCESSO", 'Y');
    $omed->aadd("TAREFA", "SALIDAS/ALTERAR         - Alter. " . ($cArqSai == "SAIDAS.SAI" ? "NOTA" : "ORÇAMENTO") . " via Tablet");
    if (!$omed->grava()) {
        mysqli_query($db, "update $cArqSaiS   SET IS_DELETED='N' WHERE RECNO=" . $olin["RECNO"]);
        $aret["erro"] = $omed->erro;
        $aret["cerro"] = _tr("Erros GRAVANDO LOG") . "<br>" . $omed->cerro;
        echo json_encode($aret);
        return;
    }
    //
//CABECALHO
    $olincli = mysqli_fetch_array(mysqli_query($db, "select * FROM CLIENTE_CLI WHERE IS_DELETED='N' AND CODCLI=" . $olin["CLIESAI"]));

    mysqli_query($db, "delete from tablet" . $lweb . "_cab where vendedor=$vendedor");
    $cstr = "insert tablet" . $lweb . "_cab set notaalt=" . $olin["RECNO"] . ",data_ini=date2unix(now()),vendedor=$vendedor,serie='$nserie',cliente=" . $olincli["CODCLI"] . ",nacional=" . $olincli["PAISCLI"] . ",pagament='" . ($olin["TIPOSAI"] == "P" ? 3 : 1) .
            "',loja=" . $olin["LOJASAI"] . ",lojacor=" . $olin["LOJACOR"] . ",moeda=" . $olin["MOEDA"] . ",orcamento=" . ($lorc ? 1 : 0);
    if ($olin["PLACASAI"] && substr($olin["PLACASAI"], 0, 3) !== "TBL") {
        $aaux = explode("/", $olin["PLACASAI"]);
        if (count($aaux) > 1) {
            $cstr .= ",prisma='$aaux[1]'";
        }
        $olinv = mysqli_fetch_array(mysqli_query($db, "select * from VEICULO_CAR WHERE IS_DELETED='N' AND PLACA='$aaux[0]'"));
        $cstr .= ",placa='$aaux[0]'
            ,ano='" . $olinv["ANO"] . "'
            ,classe='" . $olinv["CLASSE"] . "'
            ,cor='" . $olinv["COR"] . "'
            ,kilomet='" . $olinv["KILOMET"] . "'
            ,modelo='" . $olinv["MODELO"] . "'
            ,marca='" . $olinv["MARCA"] . "'
            ,tipo='" . $olinv["TIPO"] . "'
            ";
    }
    mysqli_query($db, $cstr);

//PRODUTOS
    $otabpro = mysqli_query($db, "select d.prsai,d.qusai,d.cusai,p.gradepro,d.kitsai from $cArqProS d 
        inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=d.prsai
        where d.is_deleted='N' and d.nfsai=" . $olin["RECNO"] . " and d.kitsai!='K' ");

    while ($olinpro = mysqli_fetch_array($otabpro)) {
        mysqli_query($db, "insert tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set vendedor=$vendedor,serie='$nserie',codigo=" . $olinpro["prsai"] . ",quant=" . $olinpro["qusai"] . ",valor=" . $olinpro["cusai"] . ",grade=" . ($olinpro["gradepro"] ? 1 : 0) .
                ",kit=" . ($olinpro["KITSAI"] == "S" ? 1 : 0));
        if ($olinpro["gradepro"]) {
            $otabgra = mysqli_query($db, "select * from $cArqGraS where is_deleted='N' and nfsai=" . $olin["RECNO"] . " and PRSAI=" . $olinpro["prsai"]);
            while ($olingra = mysqli_fetch_array($otabgra)) {
                mysqli_query($db, "insert tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra set serie='$nserie',vendedor=$vendedor,codigo=" . $olinpro["prsai"] . ",quant=" . $olingra["QUSAI"] . ",seq1=" . $olingra["SEQGRADE1"] . ",seq2=" . $olingra["SEQGRADE2"]);
            }
        }
    }


    mysqli_query($db, "update $cArqSaiS   SET IS_DELETED='Y' WHERE RECNO=" . $olin["RECNO"]);
    mysqli_query($db, "update $cArqProS   SET IS_DELETED='Y' WHERE NFSAI=" . $olin["RECNO"]);
    mysqli_query($db, "update $cArqGraS   SET IS_DELETED='Y' WHERE NFSAI=" . $olin["RECNO"]);

    echo json_encode($aret);
    return;
}

if ($modo == 57) {
    $otabx = mysqli_query($db, "Select * from tablet" . $lweb . "_cab where vendedor=$vendedor order by serie");

    $aped = array(array(0, 0), array(0, 0), array(0, 0), array(0, 0), array(0, 0), array(0, 0), array(0, 0), array(0, 0), array(0, 0), array(0, 0));
    while ($olin = mysqli_fetch_array($otabx)) {
        $aped[$olin["serie"]][0] = ($olin["cliente"]) + 0;
        $otabp = mysqli_query($db, "select count(*) as total from tablet" . $lweb . "" . ($olin["orcamento"] ? "_orc" : "") . "_pro where vendedor=$vendedor and serie=" . $olin["serie"]);
        $aped[$olin["serie"]][1] = (mysqli_fetch_row($otabp)[0]) + 0;
    }
    $aret["pedido"] = $aped;
    echo json_encode($aret);
    return;
}
if ($modo == 56 || $modo == "EFETIVA_ORC") {
    $nota = PegaVar("nota");
    $nserie = pegavar('serie') + 0;

    $otab = mysqli_query($db, "Select * from SAIDA_ORC WHERE RECNO=$nota");

    if (mysqli_num_rows($otab) == 0) {
        $aret["erro"] = 80;
        $aret["cerro"] = _tr("Orçamento não existe");
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);
    if ($olin["IS_DELETED"] == "Y") {
        $aret["erro"] = 81;
        $aret["cerro"] = _tr("Orçamento está deletado");
        echo json_encode($aret);
        return;
    }
    /*
      if ($olin["SITSAI"] == "S") {
      $aret["erro"] = 81;
      $aret["cerro"] = "Orçamento já está pag";
      echo json_encode($aret);
      return;
      }
     * 
     */
    /*
      if ($olin["VENDSAI"] !== $vendedor) {
      $aret["erro"] = 82;
      $aret["cerro"] = "$cNota não é deste vendedor";
      echo json_encode($aret);
      return;
      }
     */
    $cloja = trim(mysqli_linha("select lojas_ven as lojas from OPERADOR_OPE where is_deleted='N' and CODIGO=" . VeSession("usuario"))[0]);
//    $cloja = trim(mysqli_linha("select lojas_ven as lojas from OPERADOR_OPE where bloq_vdas!='S' and is_deleted='N' and CODIGO=" . VeSession("usuario"))[0]);
    $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l where l.is_deleted='N' ";
    if ($cloja) {
        $aloja = explode("-", $cloja);
        $lloja = false;
        foreach ($aloja as $value) {
            if ($value == $olin["LOJASAI"]) {
                $lloja = TRUE;
            }
        }
        if (!$lloja) {
            $aret["erro"] = 83;
            $aret["cerro"] = _tr("Orçamento não é da loja que você tem acesso");
            echo json_encode($aret);
            return;
        }
    }

//CABECALHO
    $olincli = mysqli_fetch_array(mysqli_query($db, "select * FROM CLIENTE_CLI WHERE IS_DELETED='N' AND CODCLI=" . $olin["CLIESAI"]));


    if (mysqli_num_rows(mysqli_query($db,"select * from tablet" . $lweb . "_pro where vendedor=$vendedor  and serie='$nserie'"))>0){
            $aret["erro"] = 84;
            $aret["cerro"] = _tr("Nota tem produtos. Remova-os antes de efetivar orçamento");
            echo json_encode($aret);
            return;
    }

    mysqli_query($db, "delete from tablet" . $lweb . "_cab where vendedor=$vendedor and serie='$nserie'");
    $cstr = "insert tablet" . $lweb . "_cab set notaalt=0,data_ini=date2unix(now()),vendedor=$vendedor,serie='$nserie',cliente=" . $olincli["CODCLI"] . ",nacional=" . $olincli["PAISCLI"] . ",pagament='" . ($olin["TIPOSAI"] == "P" ? 3 : 1) . "',loja="
            . $olin["LOJASAI"] . ",lojacor=" . $olin["LOJACOR"] . ",moeda=" . $olin["MOEDA"] . ",orcamento=0";
    mysqli_query($db, $cstr);
//PRODUTOS
    $otabpro = mysqli_query($db, "select d.prsai,d.qusai,d.cusai,p.gradepro,d.kitsai,p.estoque,p.nomelong from PROSAI_ORC d 
        inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=d.prsai
        where d.is_deleted='N' and d.nfsai=" . $olin["RECNO"] . " and d.kitsai!='K' ");
    $asemsaldo=array();
    while ($olinpro = mysqli_fetch_array($otabpro)) {
        if ($olinpro["estoque"]<$olinpro["qusai"]){
            $asemsaldo[$olinpro["prsai"]]= array($olinpro["nomelong"],$olinpro["qusai"],$olinpro["estoque"]);
            continue;
        }
        
        $loja = $olin["LOJASAI"];
        $ncodigo = $olinpro["PRSAI"];
        $nquant = $olinpro["QUSAI"];
        $nquantant = 0;
        if (mysqli_num_rows(mysqli_query($db, "select * from LOCAL_LOC WHERE IS_DELETED='N' AND LOCLOC=$nloja and proloc=$ncodigo")) == 0) {
            if ($lCfRdd) {
                $omed = new Mediator4("LOCAL.LOC", W_CRIAR, '', '', $db);
            } else {
                $omed = new Mediator3("LOCAL.LOC", W_CRIAR, '', '', $db);
            }
            $omed->aadd("locloc", $nloja);
            $omed->aadd("proloc", $ncodigo);
            if (!$omed->grava()) {
                $aret["erro"] = "97";
                $aret["cerro"] = _tr("Erros adicionando registro") . " LOCAL.LOC";
                echo json_encode($aret);
                return;
            }
        }

        mysqli_query($db, "update LOCAL_LOC SET QUALOC=QUALOC-$nquant+$nquantant,FPGLOC=FPGLOC+$nquant-$nquantant WHERE IS_DELETED='N' AND LOCLOC=$nloja AND PROLOC=$ncodigo");
        mysqli_query($db, "update PRODUTO_PRO set estoque=estoque-$nquant+$nquantant,fpgpro=fpgpro+$nquant-$nquantant WHERE IS_DELETED='N' AND CODPRO=$ncodigo");

        mysqli_query($db, "insert tablet" . $lweb . "_pro set vendedor=$vendedor,codigo=" . $olinpro["prsai"] . ",quant=" . $olinpro["qusai"] . ",valor=" . $olinpro["cusai"] . ",grade=" . ($olinpro["gradepro"] ? 1 : 0) .
                ",kit=" . ($olinpro["KITSAI"] == "S" ? 1 : 0) . ",serie='$nserie'");
        if ($olinpro["gradepro"]) {
            $otabgra = mysqli_query($db, "select * from GRADESAI_ORC where is_deleted='N' and nfsai=" . $olin["RECNO"] . " and PRSAI=" . $olinpro["prsai"]);
            while ($olingra = mysqli_fetch_array($otabgra)) {
                $nseq1 = $olingra["SEQGRADE1"];
                $seq2 = $olingra["SEQGRADE2"];
                if (mysqli_num_rows(mysqli_query($db, "select * from ESTLJGRA_PRO WHERE IS_DELETED='N' AND LOJGRADE=$nloja and PROGRADE=$ncodigo AND SEQGRADE1=$nseq1 and SEQGRADE2=$nseq2")) == 0) {
                    if ($lCfRdd) {
                        $omed = new Mediator4("ESTLJGRA.PRO", W_CRIAR, '', '', $db);
                    } else {
                        $omed = new Mediator3("ESTLJGRA.PRO", W_CRIAR, '', '', $db);
                    }
                    $omed->aadd("LOJGRADE", $nloja);
                    $omed->aadd("PROGRADE", $ncodigo);
                    $omed->aadd("SEQGRADE1", $nseq1);
                    $omed->aadd("SEQGRADE2", $nseq2);
                    if (!$omed->grava()) {
                        $aret["erro"] = "97";
                        $aret["cerro"] = _tr("Erros adicionando registro") . " GRADE.LOC";
                        echo json_encode($aret);
                        return;
                    }
                }
                mysqli_query($db, "update ESTLJGRA_PRO SET ESTOQUE=ESTOQUE-$nquant+$nquantant,FPGLOC=FPGLOC+$nquant-$nquantant WHERE IS_DELETED='N' AND LOJGRADE=$nloja AND PROGRADE=$ncodigo and seqgrade1=$nseq1 and seqgrade2=$nseq2");
                mysqli_query($db, "update ESTGRADE_PRO set estoque=estoque-$nquant+$nquantant,fpgpro=fpgpro+$nquant-$nquantant WHERE IS_DELETED='N' AND PROGRADE=$ncodigo and seqgrade1=$nseq1 and seqgrade2=$nseq2");

                mysqli_query($db, "insert tablet" . $lweb . "_gra set vendedor=$vendedor,codigo=" . $olinpro["prsai"] . ",quant=" . $olingra["QUSAI"] . ",seq1=" . $olingra["SEQGRADE1"] . ",seq2=" . $olingra["SEQGRADE2"] . ",serie='$nserie'");
            }
        }
    }


    mysqli_query($db, "update SAIDA_ORC   SET EFETIVADO='Y' WHERE RECNO=" . $olin["RECNO"]);
    if ($asemsaldo){
        $caux="Produtos sem saldo, não efetivados:\n\n";
        foreach ($asemsaldo as $key => $value) {
            $caux.= poedigito($key)."-".$value[0]."\n   Vendido:".round($value[1])."   Saldo:".round($value[2])."\n";
        }
        $aret["erro"]=666;
        $aret["cerro"]=$caux;
    }
    echo json_encode($aret);
    return;
}




if ($modo == 55) {
    $nnot = pegavar("nota");
    $csql = "select p.codpro as codigo,p.nomelong as nome,s.qusai as quant,s.cusai as valor
      from PROSAI_ORC s
      left join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai
      where s.is_deleted='N' and  s.nfsai=$nnot order by nome ";

    $otab = mysqli_query($db, $csql);
    /*
      $aret["erro"]=98;
      $aret["cerro"]=$csql;
      echo json_encode($aret);
      return;
     */

    $cret = '<table class="table"  style="font-size: 0.8em;" >';
    $i = 0;
    $ntam = mysqli_num_rows($otab);
    while ($olin = mysqli_fetch_array($otab)) {
        $i++;
        $cret .= '<tr><td>' . poedigito($olin["codigo"]) . "</td>";
        $cret .= '<td class="text-left">' . $olin["nome"] . "</td>";
        $cret .= "<td>" . number_format($olin["quant"], 0) . "</td>";
        $cret .= "<td>" . number_format($olin["valor"], 2) . "</td><tr>";
    }
    $cret .= '</table>';

    $aret["tabela"] = $cret;
    /*
      $aret["erro"]=98;
      $aret["cerro"]=$cret;
      echo json_encode($aret);
      return;
     */

    echo json_encode($aret);
    return;
}
if ($modo == 53) {
    $ncli = pegavar("cliente");
    $ndias = 30;
    $csql = "select n.recno as nota,n.datasai as data, n.horasai as hora,n.cliesai as cliente,c.nomcli as ccliente,n.quansai as itens,n.valosai as valor 
      from SAIDA_ORC n
      left join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai AND c.codcli!=0
      where n.is_deleted='N' and  n.efetivado='N' and n.datasai>=date_sub(current_date,interval $ndias day) 
    ";
    if ($ncli) {
        $csql .= " and n.cliesai=$ncli";
    }
    $csql .= " order by n.datasai desc,n.horasai desc";

    $otab = mysqli_query($db, $csql);
    /*
      $aret["erro"]=98;
      $aret["cerro"]=$csql;
      echo json_encode($aret);
      return;
     */

    $cret = '<table class="table"><tr><th>' . _tr('Orçam') . '</th><th>' . _tr('Emissão') . '</th>' . ($ncli ? '' : '<th>' . _tr('Cliente') . '</th>') . '<th>' . _tr('Itens') . '</th><th>' . _tr('Valor') . '</th></tr>';
    $i = 0;
    $ntam = mysqli_num_rows($otab);
    while ($olin = mysqli_fetch_array($otab)) {
        $i++;
        $cret .= '<tr><td onclick="orc_pro(' . $olin["nota"] . ",$i,$ntam" . ')"><span class="text-info">' . poedigito($olin["nota"]) . '</span>&nbsp;<i style="font-size: 1.5em" class="fa fa-cart-arrow-down text-primary" onclick="orc_efe(' . $olin["nota"] . ')"></i></td>';
        $cret .= '<td>' . substr(sql2data($olin["data"]), 0, 5) . " ";
        $cret .= "" . substr($olin["hora"], 0, 5) . "</td>";
        if (!$ncli) {
            $cret .= "<td>" . $olin["cliente"] . "-" . $olin["ccliente"] . "</td>";
        }
        $cret .= "<td>" . number_format($olin["itens"], 0) . "</td>";
        $cret .= "<td>" . number_format($olin["valor"], 2) . "</td></tr>";

        // $cret.="<tr><td colspan=5></td></tr>";
        //$cret.='<tr style="display: block" id="orc_row_'.$i.'" ><td></td><td colspan="'.($ncli?"3":"4").'"><span id="orc_pro_'.$i.'" ></span></td></tr>';
        $cret .= '<tr><td colspan="' . ($ncli ? "4" : "5") . '"><span id="orc_pro_' . $i . '" ></span></td></tr>';
    }
    $cret .= '</table>';
    /*
      $aret["erro"]=98;
      $aret["cerro"]=$cret;
      echo json_encode($aret);
      return;
     */

    $aret["tabela"] = $cret;

    echo json_encode($aret);
    return;
}
if ($modo == 58 || $modo == "VENOTAV") {
    $csql = "select p.codpro as codigo,p.nomelong as nome,s.qusai as quant,s.cusai as valor
            ,n.moeda
        ,elt(n.moeda,m.deci1,m.deci2,m.deci3,m.deci4) as deci
        ,elt(n.moeda,m.simb1,m.simb2,m.simb3,m.simb4) as simb

from SAIDAS_SAI n
inner join PROSAI_SAI s on s.is_deleted='N' and s.nfsai=n.recno
inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai
inner join CAMBIO_NOM m on m.recno=1

where n.recno=" . pegavar("nota") . "
    order by nome
    ";
    $otab = mysqli_query($db, $csql);

    $ctabela = '<table class="table table-striped" style="font-size: .85em;">
                                <tr>
                                <th class="text-center" colspan="2">Produto</td>
                                <th class="text-center" colspan="1">Quant</td>
                                <th class="text-center" colspan="1">Unitário</td>
                                <th class="text-center" colspan="1">Total</td>
                                </tr>';
    while ($olin = mysqli_fetch_array($otab)) {
        $ctabela .= '<tr>
                <td class="text-right">' . poedigito($olin["codigo"]) . '</td>
                <td class="text-left">' . $olin["nome"] . '</td>
                <td class="text-right">' . my_number_format($olin["quant"], 0) . '</td>
                <td class="text-right">' . my_number_format($olin["valor"], $olin["deci"] == "S" ? 2 : 0) . '</td>
                <td class="text-right">' . my_number_format($olin["quant"] * $olin["valor"], $olin["deci"] == "S" ? 2 : 0) . '</td>
                </tr>
                ';
    }
    $aret["tabela"] = $ctabela . "</table>";

    echo json_encode($aret);
    return;
}
if ($modo == 52 || $modo == "NOTA_REFRESH") {
// falta terminar tradução

    $hini = pegavar("hini");
    $hfim = pegavar("hfim");
    $credito = pegavar("credito");
    $nvendedor = pegavar("vendedor");
    $lnota = pegavar("nota") == "true";

    $aret["emissao"] = date('d/m/Y H:i:s');
    $aret["antv"] = array();

    //0123-56-89
    $aux = pegavar("dini");
    $datai = substr($aux, 8, 2) . "-" . substr($aux, 5, 2) . '-' . substr($aux, 0, 4);
    $sdatai = $aux;

    $aux = pegavar("dfim");
    $dataf = substr($aux, 8, 2) . "-" . substr($aux, 5, 2) . '-' . substr($aux, 0, 4);
    $sdataf = $aux;

    if ($lnota) {
        $csql = "select n.recno as nota,n.datasai as data,n.horasai as hora,n.moeda
,elt(n.moeda,m.deci1,m.deci2,m.deci3,m.deci4) as deci
,elt(n.moeda,m.simb1,m.simb2,m.simb3,m.simb4) as simb
,n.quansai as itens
,n.valosai as valor
,n.sitsai as paga
,n.retisai as retirada
,n.cliesai as cliente
,c.nomcli as ccliente
,n.lojasai as loja
,n.placasai as placa
,n.sepsai
,n.autzsep

from SAIDAS_SAI n
inner join CAMBIO_NOM m on m.recno=1
inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai AND c.codcli!=0

where n.is_deleted='N' 
and n.datasai>='" . $sdatai . "'
and n.datasai<='" . $sdataf . "'
and n.vendsai=$nvendedor
    order by data desc,hora desc
                ";
        $otab = mysqli_query($db, $csql);

        $ctabela = '<table class="table" style="font-size: .85em;">
                                <tr>
                                <th class="text-center" colspan="1">Lj</th>';
        if ($lveiculo) {
            $ctabela .= '<th class="text-center" colspan="1">Placa</th>';
        }
        $ctabela .= '<th class="text-center" colspan="1">Nota</th>
                                <th class="text-center" colspan="1">Emissão</th>
                                <th class="text-center" colspan="1">Pag</th>
                                <th class="text-center" colspan="1">Ret</th>
                                <th class="text-center" colspan="1">It.</th>
                                <th class="text-center" colspan="1">Vl.</th>
                                <th class="text-center" colspan="2">Cliente</th>
                                </tr>';
        while ($olin = mysqli_fetch_array($otab)) {
            $aret["antv"][] = $olin["nota"];
            $ccor = "success";
            if ($olin["paga"] == "N") {
                $ccor = "warning";
            } elseif ($olin["paga"] == "S" && $olin["retirada"] == "N") {
                $ccor = "info";
            }
//                <td class="text-right"><strong><a onclick="VeNotaV(' . $olin["nota"] . ')" >' . poedigito($olin["nota"]) . '</a></strong><span class="fa fa-print text-primary" onclick="ImpNota('.$olin["nota"].')"></span></td>
            $ctabela .= '<tr class="' . "bg-$ccor text-$ccor" . '">
                <td class="text-right">' . $olin["loja"] . '</td>';
            if ($lveiculo) {
                $aaux = explode("/", $olin["placa"]);
                $ctabela .= '<td class="text-center" colspan="1">' . $aaux[0] . '</td>';
            }
            $ctabela .= '<td class = "text-right"><strong><a onclick = "VeNotaV(' . $olin["nota"] . ')" >' . poedigito($olin["nota"]) . '</a></strong> <span class = "glyphicon glyphicon-print text-primary" onclick = "ImprimeNotas(' . $olin["nota"] . ')"></span> ';
            if ($olin["sitsai"] !== "S") {
                if ($olin["sepsai"] == "S") {
                    $ctabela .= ' <i class="fas fa-dolly-flatbed text-success" title="Em Separação"></i>';
                }
                if ($olin["sepsai"] !== "S" && VeAutSenhas($noperador, "SAIDAS_SEP")) {
                    $ctabela .= ' <i class="fas fa-dolly text-warning" title="Colocar em separação"  onclick="VeNotaSep(' . $olin["nota"] . ',true)"></i>';
                }
                if ($olin["sepsai"] == "S" && VeAutSenhas($noperador, "SAIDAS_CSEP")) {
                    $ctabela .= ' <i class="fas fa-dolly text-danger" title="Retirar de separação" style="transform:scaleX(-1);" onclick="VeNotaSep(' . $olin["nota"] . ',false)"></i>';
                }
            }
//            $ctabela.=' <i class="fas fa-dolly-flatbed text-success"></i> <i class="fas fa-dolly text-warning"></i> <i class="fas fa-dolly text-danger"></i></td>';
            $ctabela .= '    <td class = "text-center">' . sql2data($olin["data"]) . ' ' . substr($olin["hora"], 0, 5) . '</td>
                <td class = "text-center">' . $olin["paga"] . '</td>
                <td class = "text-center">' . $olin["retirada"] . '</td>
                <td class = "text-right">' . my_number_format($olin["itens"], 0) . '</td>
                <td class = "text-right">' . $olin["simb"] . " " . my_number_format($olin["valor"], $olin["deci"] == "S" ? 2 : 0) . '</td>
                <td class = "text-right">' . $olin["cliente"] . '</td>
                <td class = "text-left">' . LimpaChar($olin["ccliente"]) . '</td>
                </tr>
                <tr style = "display: none;" id = "ntv_' . $olin["nota"] . '"><td colspan = "9" id = "ntvc_' . $olin["nota"] . '"></td></tr>
                ';
        }
        $ctabela .= "</table>";
        /* <tr><th class="text-left">Itens:</th><td class="text-right">' . my_number_format($nitens, 0) . '</td></tr>
          <tr><th class="text-left">Produtos:</th><td class="text-right">' . my_number_format($nprodutos, 0) . '</td></tr>
          <tr><th class="text-left">Clientes:</th><td class="text-right">' . my_number_format($nclientes, 0) . '</td></tr>
          <tr><th class="text-left">Notas:</th><td class="text-right">' . my_number_format($nnotas, 0) . '</td></tr>
          <tr><th class="text-left">Valor:</th><td class="text-right">' . my_number_format($nvalor, 2) . '</td></tr>
          </table>
         */
    } else {
        mysqli_query($db, "create table if not exists tablet" . $lweb . "_cre (vendedor int(10) not null default 0,data date default '0000-00-00',credito int(10) not null default 1,primary key(vendedor) )");
        $otcre = mysqli_query($db, "select * from tablet" . $lweb . "_cre where vendedor=$nvendedor");
        $otlin = mysqli_fetch_array($otcre);

        if (mysqli_num_rows($otcre) == 0 || $otlin["data"] !== date('Y-m-d')) {
            mysqli_query($db, "replace tablet" . $lweb . "_cre set vendedor=$nvendedor,data=current_date(),credito=$credito");
        } else {
            $credito = $otlin["credito"];
        }
        $aret["credito"] = $credito;
        if ($credito < 1) {
            $aret["erro"] = '20';
            $aret["cerro"] = _tr("Você não tem mais créditos para relatórios hoje.");
            echo json_encode($aret);
            return;
        }
        $aux = explode(":", date("H:i:s"));
        $atual = $aux[2] + $aux[1] * 60 + $aux[0] * 60 * 60;
        $aux = explode(":", $hini);
        $hini = $aux[2] + $aux[1] * 60 + $aux[0] * 60 * 60;
        $aux = explode(":", $hfim);
        $hfim = $aux[2] + $aux[1] * 60 + $aux[0] * 60 * 60;

        if ($atual < $hini || $atual > $hfim) {
            $aret["erro"] = '20';
            $aret["cerro"] = _tr("Horário não permitido para relatório.\nEmita entre") . ": " . pegavar("hini") . " a " . PegaVar("hfim");
            echo json_encode($aret);
            return;
        }
        $credito = $credito - 1;
        mysqli_query($db, "replace tablet" . $lweb . "_cre set vendedor=$nvendedor,data=current_date(),credito=$credito");
        $aret["credito"] = $credito;

        mysqli_query($db, "set @datai:='$sdatai'");
        mysqli_query($db, "set @dataf:='$sdataf'");
        //mysqli_query($db,"set @datai:='2012-02-01'") ;
        //mysqli_query($db,"set @dataf:='2012-02-12'") ;
        mysqli_query($db, "set @vendedor:=$nvendedor");
        //mysqli_query($db,"set @vendedor:=35");

        mysqli_query($db, "drop temporary table if exists nota");
        mysqli_query($db, "drop temporary table if exists produto");

        mysqli_query($db, "create temporary table nota
select s.RECNO as recno,s.QUANSAI as quant,s.CLIESAI as cliente,s.VALOSAI as valor,s.SITSAI as sitsai
from SAIDAS_SAI s
where is_deleted='N'
and vendsai=@vendedor
and datasai>=@datai and datasai<=@dataf");

        mysqli_query($db, "create temporary table produto
select d.NFSAI as nota,n.cliente,d.PRSAI as codigo,p.NOMELONG as nome,d.QUSAI as quant,d.CUSAI as valor,n.SITSAI as sitsai
from PROSAI_SAI d
inner join nota n on n.recno=d.NFSAI
inner join PRODUTO_PRO p on p.IS_DELETED='N' and p.CODPRO=d.PRSAI
where d.IS_DELETED='N'");

        //my_number_format(mysqli_fetch_row(mysqli_query($db, "select count(*) as quant from nota"))[0],0);
        $nitens = mysqli_fetch_row(mysqli_query($db, "select sum(quant) as quant from nota where sitsai='S'"))[0];
        $nprodutos = mysqli_num_rows(mysqli_query($db, "select codigo from produto where sitsai='S' group by codigo"));
        $nclientes = mysqli_num_rows(mysqli_query($db, "select cliente from nota where sitsai='S' group by cliente"));
        $nnotas = mysqli_fetch_row(mysqli_query($db, "select count(*) as quant from nota where sitsai='S' "))[0];
        $nvalor = mysqli_fetch_row(mysqli_query($db, "select sum(valor) as quant from nota where sitsai='S' "))[0];

        $pnitens = mysqli_fetch_row(mysqli_query($db, "select sum(quant) as quant from nota where sitsai!='S'"))[0];
        $pnprodutos = mysqli_num_rows(mysqli_query($db, "select codigo from produto where sitsai!='S' group by codigo"));
        $pnclientes = mysqli_num_rows(mysqli_query($db, "select cliente from nota where sitsai!='S' group by cliente"));
        $pnnotas = mysqli_fetch_row(mysqli_query($db, "select count(*) as quant from nota where sitsai!='S' "))[0];
        $pnvalor = mysqli_fetch_row(mysqli_query($db, "select sum(valor) as quant from nota where sitsai!='S' "))[0];

        $ctabela = ' <table class = "table" style = "background: #e6f3ff;font-size: .85em;">
                <tr><th class = "text-left" colspan = "2">Vendas do dia ' . $datai . ' a ' . $dataf . ' :</td></tr>
                <tr><th class = "text-left">Itens:</th><td class = "text-right">' . my_number_format($nitens, 0) . '</td></tr>
                <tr><th class = "text-left">Produtos:</th><td class = "text-right">' . my_number_format($nprodutos, 0) . '</td></tr>
                <tr><th class = "text-left">Clientes:</th><td class = "text-right">' . my_number_format($nclientes, 0) . '</td></tr>
                <tr><th class = "text-left">Notas:</th><td class = "text-right">' . my_number_format($nnotas, 0) . '</td></tr>
                <tr><th class = "text-left">Valor:</th><td class = "text-right">' . my_number_format($nvalor, 2) . '</td></tr>
                </table>

                <table class = "table" style = "background: #fff3ff;font-size: .85em;">
                <tr><th class = "text-left" colspan = "2">Vendas Pendentes do dia ' . $datai . ' a ' . $dataf . ' :</td></tr>
                <tr><th class = "text-left">Itens:</th><td class = "text-right">' . my_number_format($pnitens, 0) . '</td></tr>
                <tr><th class = "text-left">Produtos:</th><td class = "text-right">' . my_number_format($pnprodutos, 0) . '</td></tr>
                <tr><th class = "text-left">Clientes:</th><td class = "text-right">' . my_number_format($pnclientes, 0) . '</td></tr>
                <tr><th class = "text-left">Notas:</th><td class = "text-right">' . my_number_format($pnnotas, 0) . '</td></tr>
                <tr><th class = "text-left">Valor:</th><td class = "text-right">' . my_number_format($pnvalor, 2) . '</td></tr>
                </table>

                <table class = "table" style = "background: #e6ffe6;font-size: .85em;">
                <tr><th class = "text-left" colspan = "2">Media por Cliente</th></tr>
                <tr><th class = "text-left">Itens:</th><td class = "text-right">' . my_number_format($nitens / $nclientes, 2) . '</td></tr>
                <tr><th class = "text-left">Produtos:</th><td class = "text-right">' . my_number_format(mysqli_fetch_row(mysqli_query($db, "select sum(codigo) as total from (select count(*) as codigo from produto where sitsai='S' group by cliente) n"))[0] / $nclientes, 2) . '</td></tr>
                <tr><th class = "text-left">Notas:</th><td class = "text-right">' . my_number_format($nnotas / $nclientes, 2) . '</td></tr>
                <tr><th class = "text-left">Valor:</th><td class = "text-right">' . my_number_format($nvalor / $nclientes, 2) . '</td></tr>
                </table>
                <table class = "table" style = "background:  #ffffe6;font-size: .85em;">
                <tr><th class = "text-left" colspan = "2">Media por Nota</th></tr>
                <tr><th class = "text-left">Itens:</th><td class = "text-right">' . my_number_format($nitens / $nnotas, 2) . '</td></tr>
                <tr><th class = "text-left">Produtos:</th><td class = "text-right">' . my_number_format(mysqli_fetch_row(mysqli_query($db, "select sum(codigo) as total from (select count(*) as codigo from produto where sitsai='S' group by nota) n"))[0] / $nnotas, 2) . '</td></tr>
                <tr><th class = "text-left">Valor:</th><td class = "text-right">' . my_number_format($nvalor / $nnotas, 2) . '</td></tr>
                </table>
                <table class = "table" style = "background: #fff2e6;font-size: .85em;">
                <tr><th class = "text-left">Menor Venda:</th><td class = "text-right">' . my_number_format(mysqli_fetch_row(mysqli_query($db, "select min(valor) as total from nota where sitsai='S' "))[0], 2) . '</td></tr>
                <tr><th class = "text-left">Maior Venda:</th><td class = "text-right">' . my_number_format(mysqli_fetch_row(mysqli_query($db, "select max(valor) as total from nota where sitsai='S' "))[0], 2) . '</td></tr>
                </table>
                <table class = "table" style = "background: #e6ffff;font-size: .85em;">
                <tr><th class = "text-center" colspan = "2">Produto</th><th class = "text-center">Quant</th><th class = "text-center">Media</th><th class = "text-center">Min.</th><th class = "text-center">Max.</th> </tr>';
        $otab = mysqli_query($db, "select codigo,nome,sum(quant) as quant,sum(valor*quant) as valor,min(valor) as min,max(valor) as max from produto where sitsai='S' group by codigo order by quant desc");
        while ($olin = mysqli_fetch_array($otab)) {
            $ctabela .= '<tr><td class = "text-right">' . poedigito($olin["codigo"]) .
                    '</td><td class = "text-left">' . $olin["nome"] .
                    '</td><td class = "text-right">' . my_number_format($olin["quant"], 0) .
                    '</td><td class = "text-right">' . my_number_format($olin["valor"] / $olin["quant"], 2) .
                    '</td><td class = "text-right">' . my_number_format($olin["min"], 2) .
                    '</td><td class = "text-right">' . my_number_format($olin["max"], 2) .
                    '</td></tr>';
        }
        $ctabela .= '</table>';
    }
    $aret["tabela"] = $ctabela;

    echo json_encode($aret);
    return;
}

if ($modo == 54) {
    $hini = pegavar("hini");
    $hfim = pegavar("hfim");
    $ncliente = pegavar("cliente");
    $nvendedor = pegavar("vendedor");

    $aret["emissao"] = date('d/m/Y H:i:s');

    //0123-56-89
    $aux = pegavar("dini");
    $datai = substr($aux, 8, 2) . "-" . substr($aux, 5, 2) . '-' . substr($aux, 0, 4);
    $sdatai = $aux;

    $aux = pegavar("dfim");
    $dataf = substr($aux, 8, 2) . "-" . substr($aux, 5, 2) . '-' . substr($aux, 0, 4);
    $sdataf = $aux;

    $csql = "SELECT 
s.recno as nota
,d.moedup as moeda
,IF(d.moedup=4,b.deci4,if(d.moedup=3,b.deci3,if(d.moedup=2,b.deci2,b.deci1))) as deci
,IF(d.moedup=4,b.simb4,if(d.moedup=3,b.simb3,if(d.moedup=2,b.simb2,b.simb1))) as simb
,d.valodup as valor
,d.valodup
,s.vendsai as vendedor
,v.nomven as  cvendedor
,d.recedup as recebe
,d.emisdup as emissao
,d.numedup as doc
,d.vencdup as vence
,datediff(current_date(),d.vencdup) as atraso
,c.jurmes as juro

from DUPLICAT_CLI d 
inner join CONFIG c on c.recno=1
LEFT JOIN CAMBIO_NOM b on  b.RECNO=1
left join SAIDAS_SAI s on s.notasai=left(d.numedup,7)
left join VENDEDOR_VEN v on v.codven=s.vendsai and v.is_deleted='N' 

where 
d.is_deleted='N' 
and d.lotedup=0 
and d.descdup=0 

and d.cliedup='$ncliente' ";

    $latz = PegaVar("atz") == "true";
    $lok = PegaVar("ok") == "true";
    $lven = PegaVar("ven") == "true";

    /*
      and (0";
      if (PegaVar("atz") == "true") {
      $csql .= " or d.recedup<='1000-01-01' and d.vencdup<current_date()";
      }
      if (PegaVar("ok") == "true") {
      $csql .= " or d.recedup>'1000-01-01'";
      }
      if (PegaVar("ven") == "true") {
      $csql .= " or d.vencdup>current_date()";
      }
      $csql .= ")
     * 
     */
    $csql .= " order by if(recebe<='1000-01-01',0,1),vence ";

    /*
      #and d.vencdup>='$sdatai'
      #and d.vencdup<='$sdataf'

      $aret["tabela"] = $csql;

      echo json_encode($aret);
      return;
     */

    $otab = mysqli_query($db, $csql);

    $ctabela = '<table class = "table" style = "background: #e6f3ff;font-size: .85em;">
                <tr><th class = "text-left" >' . _tr('Nota') . '</th>
                <th class = "text-left" >' . _tr('Doc') . '</th>
                <th class = "text-left">' . _tr('Emissão') . '</th>
                <th class = "text-left">' . _tr('Vence') . '</th>
                <th class = "text-left">' . _tr('Valor') . '</th>
                <th class = "text-left">' . _tr('Juros') . '</th>
                <th class = "text-left">' . _tr('Recebe') . '</th>
                <th class = "text-left">' . _tr('Vendedor') . '</th>
                </tr>';
    $aatz = array(0, 0, 0, 0);
    $aven = array(0, 0, 0, 0);
    $aok = array(0, 0, 0, 0);
    $amoe = array('N', 'N', 'N', 'N');
    $anom = array('', '', '', '');

    while ($olin = mysqli_fetch_array($otab)) {
        $amoe[$olin["moeda"] - 1] = $olin["deci"];
        $anom[$olin["moeda"] - 1] = $olin["simb"];
        if ($olin["recebe"] <= '1000-01-01' && $olin["vence"] >= date('Y-m-d')) {
            $cclass = " bg-warning text-warning";
            $aven[$olin["moeda"] - 1] += $olin["valodup"];
        } else if ($olin["recebe"] <= '1000-01-01') {
            $cclass = " bg-danger text-danger";
            $aatz[$olin["moeda"] - 1] += $olin["valodup"];
        } else {
            $cclass = " bg-success text-success";
            $aok[$olin["moeda"] - 1] += $olin["valodup"];
        }

        if (( $latz && $olin["recebe"] <= '1000-01-01' && $olin["vence"] < date('Y-m-d') ) ||
                ( $lok && $olin["recebe"] > '1000-01-01') ||
                ( $lven && $olin["vence"] > date("Y-m-d") )) {

            $caux = "";
            if ($olin["atraso"] > 0) {
                $caux = "alert alert-danger";
            }
            $ctabela .= '<tr class = "' . $caux . '"><td class = "text-right' . $cclass . '">' . $olin["nota"] . '-' . digito($olin["nota"]) .
                    '</td><td class = "text-left' . $cclass . '">' . $olin["doc"] .
                    '</td><td class = "text-center' . $cclass . '">' . sql2data($olin["emissao"]) .
                    '</td><td class = "text-center' . $cclass . '">' . sql2data($olin["vence"]) . ' ' . ($olin["recebe"] <= '1000-01-01' ? $olin["atraso"] : "") .
                    '</td><td class = "text-right' . $cclass . '" >' . $olin["simb"] . " " . my_number_format($olin["valor"], $olin["deci"] == 'S' ? 2 : "0") . '</td>';
            if ($olin["atraso"] > 0 && $olin["recebe"] <= '1000-01-01') {
                $njuro = $olin["valor"] * ((($olin["juro"] / 100) / 30) * $olin["atraso"]);
                $ctabela .= '<td class = "text-right' . $cclass . '" >' . $olin["simb"] . " " . my_number_format($njuro, $olin["deci"] == 'S' ? 2 : "0") . '</td>';
            } else {
                $ctabela .= '<td class = "text-right' . $cclass . '" ></td>';
            }
            $ctabela .= '<td class = "text-center' . $cclass . '">' . ($olin["recebe"] <= '1000-01-01' ? '' : sql2data($olin["recebe"]) ) .
                    '</td><td class = "text-left' . $cclass . '">' . $olin["vendedor"] . '-' . $olin["cvendedor"] .
                    '</td></tr>';
        }
    }
    $ctabela .= '</table>';

    $aret["tabela"] = '<table class = "table" style = "background: #e6f3ff;font-size: .85em;">';

    for ($i = 0; $i < 4; $i++) {
        if ($aatz[$i] == 0 && $aven[$i] == 0 && $aok[$i] == 0) {
            continue;
        }
        $aret["tabela"] .= '<tr><th>' . $anom[$i] . '</th>
                <th class = "text-right" >Saldo:</th><td class = "text-right" >' . my_number_format($aatz[$i] + $aven[$i], $amoe[$i] == "S" ? 2 : 0) . '</td>
                <th class = "text-right" >Atrasado:</th><td class = "text-right" >' . my_number_format($aatz[$i], $amoe[$i] == "S" ? 2 : 0) . '</td></tr>
                <tr><th></th><th class = "text-right" >A vencer:</th><td class = "text-right" >' . my_number_format($aven[$i], $amoe[$i] == "S" ? 2 : 0) . '</td>
                <th class = "text-right" >Recebido:</th><td class = "text-right" >' . my_number_format($aok[$i], $amoe[$i] == "S" ? 2 : 0) . '</td></tr>
                ';
    }

    $aret["tabela"] .= $ctabela;

    echo json_encode($aret);
    return;
}
if ($modo == 80) {
    if (true) {
        $aret["erro"] = "40";
        $aret["cerro"] = _tr("Sem Seguro");
        echo json_encode($aret);
        return;
    }
    $codigo = pegavar("codigo");
    $olin = mysqli_fetch_array(mysqli_query($db, "SELECT 
 s.per_segu1 as s1,s.per_segu2 as s2
,g.per_segu1 as g1,g.per_segu2 as g2
,p1.codpro as cod1,trim(if(trim(p1.nomelong)='',p1.nompro,p1.nomelong)) as nom1
,p2.codpro as cod2,trim(if(trim(p2.nomelong)='',p2.nompro,p2.nomelong)) as nom2
,p.kitpro

from PRODUTO_PRO p
inner join GRUPO_GRU  g on g.is_deleted='N' and g.codgru=p.grupro 
inner join SGRUPO_SGR s on s.is_deleted='N' and s.codsgru=p.sgrupro 
inner join CONFIG c on c.recno=1
left join PRODUTO_PRO p1 on p1.is_deleted='N' and p1.codpro=c.codseg_pr
left join PRODUTO_PRO p2 on p2.is_deleted='N' and p2.codpro=c.codseg_p2
where p.is_deleted='N'
and p.codpro=$codigo"));
    $nseg1 = $olin["s1"] + 0;
    if (!$nseg1) {
        $nseg1 = $olin["g1"] + 0;
    }
    $nseg2 = $olin["s2"] + 0;
    if (!$nseg2) {
        $nseg2 = $olin["g2"] + 0;
    }
    if ($olin["kitpro"] == "S" || (!$nseg1 && !$nseg2)) {
        $aret["erro"] = "40";
        $aret["cerro"] = _tr("Sem Seguro");
        echo json_encode($aret);
        return;
    }
    $aret["seg1"] = $nseg1;
    $aret["cod1"] = $olin["cod1"];
    $aret["nom1"] = limpachar($olin["nom1"]);
    $aret["seg2"] = $nseg2;
    $aret["cod2"] = $olin["cod2"];
    $aret["nom2"] = LimpaChar($olin["nom2"]);

    echo json_encode($aret);
    return;
}


if ($modo == 74 || $modo == "VE_AUT_NIVEL") {
    $noperador = VeSession("usuario"); //$_SESSION["usuario"];
    $nsenha = pegavar("senha");
    $ngrupo = mysqli_fetch_row(mysqli_query($db, "select cifra(grupo) as grupo from OPERADOR_OPE where codigo=$noperador and is_deleted='N' "))[0];
//    $ngrupo = mysqli_fetch_row(mysqli_query($db, "select cifra(grupo) as grupo from OPERADOR_OPE where bloq_vdas!='S' and codigo=$noperador and is_deleted='N' "))[0];
    $cautoriza = mysqli_fetch_row(mysqli_query($db, "select sitopg from OPEGRUPO_OPE where is_deleted='N' and codopg='$ngrupo' and opeopg='$nsenha'"))[0];
    //$aret["erro"]=99;
    //$aret["cerro"]=$ngrupo."-".$cautoriza;
    $aret["aut"] = $cautoriza;

    $aret["arre_pre"] = mysqli_fetch_row(mysqli_query($db, "select IF(NUM_NFCFG=6 AND PERAUM_TJ!=0,'S','N') AS ARRE_PRE FROM CONFIG WHERE RECNO=1"))[0];
    echo json_encode($aret);
    return;
}
if ($modo == 73) {
    $nregistro = pegavar("registro");
    mysqli_query($db, "update AUTORIZA_AUT SET AUTORIZADO='Abortado pelo requerente',is_deleted='Y' WHERE RECNO=$nregistro");
    echo json_encode($aret);
    return;
}
if ($modo == 72) {
    $nregistro = pegavar("registro");
    $otab = mysqli_query($db, "select * from AUTORIZA_AUT WHERE RECNO='$nregistro'");
    if (mysqli_num_rows($otab) == 0) {
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Registro não encontrado");
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);
    if ($olin["IS_DELETED"] == 'Y') {
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Registro deletado");
        echo json_encode($aret);
        return;
    }
    if ($olin["DATA_AUT"] == '1000-01-01') {
        $aret["erro"] = "50";
        $aret["cerro"] = _tr("Esperando Autorização");
        echo json_encode($aret);
        return;
    }
    $cAux = $olin["AUTORIZADO"];
    $cAux = cifra($cAux);

    $lRet = false;
    if (!( str_replace("-", "", $olin["DATA_AUT"]) == substr($cAux, 0, 8) ) ||
            !( $olin["HORA_AUT"] == SubStr($cAux, 9, 8) )) {
        mysqli_query($db, "update AUTORIZA_AUT SET AUTORIZADO='ADULTERADO' WHERE RECNO=$nregistro");
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Registro Adulterado");
        echo json_encode($aret);
        return;
    }

    $lRet = SubStr($cAux, 8, 1) == "1";

    if (!$lRet) {
        $aret["cerro"] = _tr("Autorização Negada") . "\n\n" . $olin["MOTIVO_AUT"];
        $aret["erro"] = "40";
    } else {
        $aret["erro"] = "10";
        $aret["cerro"] = _tr("Autorização Concedida") . "\n\n" . $olin["MOTIVO_AUT"];

        // informa log
        $nmodoautoriza = pegavar("nmodoautoriza");
        $ncusto = pegavar("ncusto");
        $nminino = pegavar("nminimo");
        $nvalor = pegavar("nvalor");
        $nvenda = pegavar("nvenda");
        $ncodigo = pegavar("ncodigo");

        if (($nmodoautoriza == 88 || $nmodoautoriza == 58 || $nmodoautoriza == 72) && $olin["REGLOG"] > 0) {
            // $otab = mysqli_query($db, "select * from AUTORIZA_AUT where recno=$nregistro");
            //$olin = mysqli_fetch_array($otab);
            if ($lCfRdd) {
                $omed = new Mediator4("LOGPRE.LOG", W_CRIAR, '', '', $db);
            } else {
                $omed = new Mediator3("LOGPRE.LOG", W_CRIAR, '', '', $db);
            }
            $olincab = mysqli_fetch_array(mysqli_query($db, "select * from tablet" . $lweb . "_cab where vendedor=$nvendedor and serie=$nserie"));

            $ddata = date("Y-m-d");
            $hdata = date("H:i:s");
            //SAIDAS_UNI 205
            $omed->aadd("LOGCLI", $olincab["cliente"]);
            $omed->aadd("LOGCUS", $ncusto);
            $omed->aadd("LOGDATA", 'current_date()', true);
            $omed->aadd("LOGLOJA", $olincab["loja"]);
            $omed->aadd("LOGMIN", $nminino);
            $omed->aadd("LOGMOE", $olincab["moeda"]);
            $omed->aadd("LOGPRO", $ncodigo);
            $omed->aadd("LOGREG", $olin["REGLOG"]);
            $omed->aadd("LOGVEN", $nvalor);
            $omed->aadd("LOGVND", $nvendedor);
            $omed->aadd("HORA", "current_time()", TRUE);
            $omed->aadd("OPERADOR", $olincab["operador"]);
            $omed->aadd("ESTATUS", 'P'); //verificar
            $omed->aadd("LOGTIPO", ($nmodoautoriza == 88 ? "ABAIXO DO MINIMO" : ($nmodoautoriza == 72 ? "IGUAL AO CUSTO" : "ABAIXO DO CUSTO")));
            $omed->aadd("LOGATA", 0);
            $omed->aadd("LOGPROMO", 0);
            $omed->grava();
            mysqli_query($db, "update LOG_LOG SET documento='PRO" . poedigito($ncodigo) . "' where recno=" . $olin["REGLOG"]);
        }
    }
    echo json_encode($aret);
    return;
}

if ($modo == 71) {
    $ncodigo = pegavar("ncodigo");
    $nquantant = pegavar("nquantant");
    $nquantmax = pegavar("nquantmax");
    $nquant = pegavar("nquant");
    $nvalor = pegavar("nvalor");
    $nminimo = pegavar("nminimo");
    $ncusto = pegavar("ncusto");

    $natacado = mysqli_fetch_row(mysqli_query($db, "select preatac from PRODUTO_PRO WHERE IS_DELETED='N' AND CODPRO=$ncodigo"))[0];
    $nvenda = PegaVar("nvenda");
    $nsolicita = PegaVar("nsolicita");
    $nusuario = VeSession("usuario"); //$_SESSION["usuario"];
    $cobs = PegaVar("cobs");
    $nserie = pegavar('serie') + 0;

    $cstr = "select 
 o.codigo as operador ,o.nome   as coperador
,if(isnull(c.codcli),0,c.codcli) as cliente  ,if(isnull(c.codcli),'',c.nomcli) as ccliente,c.paiscli
,v.codven as vendedor ,v.nomven as cvendedor
,l.codemp as loja     ,l.nomemp as cloja
,p.codpro as produto  ,trim(if(trim(p.nomelong)='',p.nompro,p.nomelong)) as cproduto
,p.estoque,p.cusmed as custo,p.ultcus as ucusto";
    if (!$nlojapre) {
        $cstr .= " ,p.$cpreven as preven,p.$cpremin as premin,p.$cprecot as preatac";
    } else {
        $cstr .= " ,if(isnull(lc.proloc) or lc.$cpreven=0,p.$cpreven,lc.$cpreven) as preven
            ,if(isnull(lc.proloc) or lc.$cpremin=0,p.$cpremin,lc.$cpremin) as premin
            ,if(isnull(lc.proloc) or lc.$cprecot=0,p.$cprecot,lc.$cprecot) as preatac ";
    }
    $cstr .= " ,b.simb1 as simb
,t.orcamento

from tablet" . $lweb . "_cab t 
inner join OPERADOR_OPE o on o.is_deleted='N' and o.codigo=$nusuario
left  join CLIENTE_CLI  c on c.is_deleted='N' and c.codcli=if(t.cliente=0,99999999,t.cliente)
inner join VENDEDOR_VEN v on v.is_deleted='N' and v.codven=t.vendedor
inner join EMPRESA_EMP  l on l.is_deleted='N' and l.codemp=t.loja
inner join PRODUTO_PRO  p on p.is_deleted='N' and p.codpro=$ncodigo ";
//inner join OPERADOR_OPE o on o.bloq_vdas!='S' and o.is_deleted='N' and o.codigo=$nusuario
    if ($nlojapre) {
        $cstr .= " left join LOCAL_LOC lc on lc.is_deleted='N' and lc.locloc=$nlojapre and lc.proloc=p.codpro ";
    }
    $cstr .= " inner join CAMBIO_NOM   b on b.recno=1

where t.vendedor=$vendedor and t.serie='$nserie'";
    $olin = mysqli_fetch_array(mysqli_query($db, $cstr));

    $ctexto = "";
    if ($nquantmax) {
        $latac = $nvalor < $olin["preatac"];
        $ccomp = '** TABLET - VENDA DE QUANT. ACIMA DO PERMITIDO ** ' . ($lorc ? " *PRESUPUESTO*" : "") . chr(13) . chr(10);
        $ccomp .= 'Cliente : ' . $olin["cliente"] . "-" . limpachar($olin["ccliente"]) . "   (" . ($olin["paiscli"] == 1 ? "PGY" : "GLOBAL") . ")" . chr(13) . chr(10);
        $ccomp .= 'Prazo : 0 dias' . chr(13) . chr(10);
        $ccomp .= 'Vendedor : ' . $olin["vendedor"] . "-" . limpachar($olin["cvendedor"]) . chr(13) . chr(10);
        $ccomp .= 'Loja : ' . $olin["loja"] . "-" . $olin["cloja"] . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Produto : <#7>' . poedigito($olin["produto"]) . "-" . LimpaChar($olin["cproduto"]) . "<#1>" . chr(13) . chr(10);
        $ccomp .= "Quant.Vendida : $nquant      [[ Estoque: " . round($olin["estoque"]) . "]]" . chr(13) . chr(10);
        $ccomp .= "Quant.Maxima  : $nquantmax " . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Preço Vendido : ' . $olin["simb"] . str_pad(number_format($nvalor, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
    } else if ($nvalor > $nvenda) {
        $latac = $nvalor < $olin["preatac"];
        $ccomp = '** TABLET - VENDA ACIMA DO PREÇO NORMAL **' . ($lorc ? " *PRESUPUESTO*" : "") . chr(13) . chr(10);
        $ccomp .= 'Cliente  : ' . $olin["cliente"] . "-" . limpachar($olin["ccliente"]) . "   (" . ($olin["paiscli"] == 1 ? "PGY" : "GLOBAL") . ")" . chr(13) . chr(10);
        $ccomp .= 'Prazo    : 0 dias' . chr(13) . chr(10);
        $ccomp .= 'Vendedor : ' . $olin["vendedor"] . "-" . limpachar($olin["cvendedor"]) . chr(13) . chr(10);
        $ccomp .= 'Loja     : ' . $olin["loja"] . "-" . $olin["cloja"] . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Produto       : <#7>' . poedigito($olin["produto"]) . "-" . LimpaChar($olin["cproduto"]) . "<#1>" . chr(13) . chr(10);
        $ccomp .= "Quant.Vendida : $nquant      [[ Estoque: " . round($olin["estoque"]) . "]]" . chr(13) . chr(10);
        $ccomp .= 'Custo Médio   : ' . $olin["simb"] . str_pad(number_format($olin["custo"], 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= 'Ultimo Custo  : ' . $olin["simb"] . str_pad(number_format($olin["ucusto"], 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Preço Normal  : ' . $olin["simb"] . str_pad(number_format($nvenda, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= 'Preço Mínimo  : ' . $olin["simb"] . str_pad(number_format($nminimo, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= 'Preço Atacado : ' . $olin["simb"] . str_pad(number_format($natacado, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Preço Vendido : ' . $olin["simb"] . str_pad(number_format($nvalor, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
    } else {
        $latac = $nvalor < $olin["preatac"];
        $ccomp = '** TABLET - VENDA ABAIXO DO ' . ($ncusto > 0 ? "CUSTO" : ($latac ? "ATACADO" : "MÍNIMO")) . ' **' . ($lorc ? " *PRESUPUESTO*" : "") . chr(13) . chr(10);
        $ccomp .= 'Cliente  : ' . $olin["cliente"] . "-" . limpachar($olin["ccliente"]) . chr(13) . "   (" . ($olin["paiscli"] == 1 ? "PGY" : "GLOBAL") . ")" . chr(10);
        $ccomp .= 'Prazo    : 0 dias' . chr(13) . chr(10);
        $ccomp .= 'Vendedor : ' . $olin["vendedor"] . "-" . limpachar($olin["cvendedor"]) . chr(13) . chr(10);
        $ccomp .= 'Loja     : ' . $olin["loja"] . "-" . $olin["cloja"] . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Produto       : <#7>' . poedigito($olin["produto"]) . "-" . LimpaChar($olin["cproduto"]) . "<#1>" . chr(13) . chr(10);
        $ccomp .= "Quant.Vendida : $nquant      [[ Estoque: " . round($olin["estoque"]) . "]]" . chr(13) . chr(10);
        $ccomp .= 'Custo Médio   : ' . $olin["simb"] . str_pad(number_format($olin["custo"], 2, ".", " "), 15, " ", STR_PAD_LEFT)
                . "  %" . str_pad(number_format(($nvalor / $olin["custo"] * 100) - 100, 2, ".", " "), 7, " ", STR_PAD_LEFT)
                . chr(13) . chr(10);
        $ccomp .= 'Ultimo Custo  : ' . $olin["simb"] . str_pad(number_format($olin["ucusto"], 2, ".", " "), 15, " ", STR_PAD_LEFT)
                . "  %" . str_pad(number_format(( $nvalor / $olin["ucusto"] * 100) - 100, 2, ".", " "), 7, " ", STR_PAD_LEFT)
                . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Preço Normal  : ' . $olin["simb"] . str_pad(number_format($nvenda, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= 'Preço Mínimo  : ' . $olin["simb"] . str_pad(number_format($nminimo, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= 'Preço Atacado : ' . $olin["simb"] . str_pad(number_format($natacado, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);
        $ccomp .= '_____________________________________________________' . chr(13) . chr(10);
        $ccomp .= 'Preço Vendido : ' . $olin["simb"] . str_pad(number_format($nvalor, 2, ".", " "), 15, " ", STR_PAD_LEFT) . chr(13) . chr(10);

        $ctexto = "+-----+-------------------------------------+----------+----------+----------+----------+----------+---------+----------+-----------|" . chr(13) . chr(10);
        $ctexto .= "|Quant| Descricao                           |  Vendido |   Minimo |Custo Med.| Lucro Tot| Lucro Uni|  % Lucro| Valor Ven|    Codigo |" . chr(13) . chr(10);
        $ctexto .= "+-----+-------------------------------------+----------+----------+----------+----------+----------+---------+----------+-----------|" . chr(13) . chr(10);
        $csql1 = "select t.quant,p.nomelong as nome,t.valor,p.premin as minimo,p.cusmed as custo,t.valor*.t.quant-p.cusmed*t.quant as tlucro,t.valor-p.cusmed as ulucro   
                ,t.valor/p.cusmed*100-100 as lucro,t.valor*t.quant as tvenda,t.codigo,digito(t.codigo) as digito
                from tablet1_pro t
                inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=t.codigo
                where t.vendedor=$vendedor and t.serie=$nserie
                order by t.codigo";
        $otpro = mysqli_query($db, $csql1);
        $ntlucro = 0;
        $ntvenda = 0;
        while ($olpro = mysqli_fetch_array($otpro)) {
            $ctexto .= "|" . str_pad($olpro["quant"], 5, " ", STR_PAD_LEFT)
                    . "| " . substr(str_pad($olpro["nome"], 35, " ", STR_PAD_RIGHT), 0, 35)
                    . " |" . str_pad(number_format($olpro["valor"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                    . " |" . str_pad(number_format($olpro["minimo"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                    . " |" . str_pad(number_format($olpro["custo"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                    . " |" . str_pad(number_format($olpro["tlucro"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                    . " |" . str_pad(number_format($olpro["ulucro"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                    . " |" . substr(str_pad(number_format($olpro["lucro"], 2, ".", " "), 8, " ", STR_PAD_LEFT), -8) . "%"
                    . "|" . str_pad(number_format($olpro["tvenda"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                    . " |" . str_pad($olpro["codigo"] . "-" . $olpro["digito"], 11, " ", STR_PAD_LEFT)
                    . "|" . chr(13) . chr(10);
            ;
            $ntcusto += $olpro["custo"] * $olpro["quant"];
            $ntlucro += $olpro["tlucro"];
            $ntvenda += $olpro["tvenda"];
        }
        $ctexto .= "+-----+-----------------------------------------------------------+----------+----------+----------+---------+----------+-----------|" . chr(13) . chr(10);
        $ctexto .= "|                                      Total sem Autorizacao  =>  |"
                . str_pad(number_format($ntcusto, 2, ".", " "), 9, " ", STR_PAD_LEFT) . " |"
                . str_pad(number_format($ntlucro, 2, ".", " "), 9, " ", STR_PAD_LEFT) . " |          |"
                . substr(str_pad(number_format(($ntvenda / $ntcusto * 100) - 100, 2, ".", " "), 8, " ", STR_PAD_LEFT), -8) . "%"
                . "|" . str_pad(number_format($ntvenda, 2, ".", " "), 9, " ", STR_PAD_LEFT) . " |           |" . chr(13) . chr(10);
        ;
        $ctexto .= "+-----+-----------------------------------------------------------+----------+----------+----------+---------+----------+-----------|" . chr(13) . chr(10);
        $ctexto .= "|" . str_pad($nquant, 5, " ", STR_PAD_LEFT)
                . "| " . substr(str_pad(LimpaChar($olin["cproduto"]), 35, " ", STR_PAD_RIGHT), 0, 35)
                . " |" . str_pad(number_format($nvenda, 2, ".", " "), 9, " ", STR_PAD_LEFT)
                . " |" . str_pad(number_format($nminimo, 2, ".", " "), 9, " ", STR_PAD_LEFT)
                . " |" . str_pad(number_format($olin["custo"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                . " |" . str_pad(number_format(($nvenda - $olin["custo"]) * $nquant, 2, ".", " "), 9, " ", STR_PAD_LEFT)
                . " |" . str_pad(number_format($nvenda - $olin["custo"], 2, ".", " "), 9, " ", STR_PAD_LEFT)
                . " |" . substr(str_pad(number_format($nvenda / $olin["custo"] * 100 - 100, 2, ".", " "), 8, " ", STR_PAD_LEFT), -8) . "%"
                . "|" . str_pad(number_format($nvenda * $nquant, 2, ".", " "), 9, " ", STR_PAD_LEFT)
                . " |" . str_pad($olin["produto"] . "-" . digito($olin["produto"]), 11, " ", STR_PAD_LEFT)
                . "|" . chr(13) . chr(10);
        $ctexto .= "+-----+-----------------------------------------------------------+----------+----------+----------+---------+----------+-----------|" . chr(13) . chr(10);
        $ntcusto += $olin["custo"] * $nquant;
        $ntlucro += $nvenda * $nquant - $olin["custo"] * $nquant;
        $ntvenda += $nvenda * $nquant;
        $ctexto .= "|                                      Total com Autorizacao  =>  |"
                . str_pad(number_format($ntcusto, 2, ".", " "), 9, " ", STR_PAD_LEFT) . " |"
                . str_pad(number_format($ntlucro, 2, ".", " "), 9, " ", STR_PAD_LEFT) . " |          |"
                . substr(str_pad(number_format(($ntvenda / $ntcusto * 100) - 100, 2, ".", " "), 8, " ", STR_PAD_LEFT), -8) . "%"
                . "|" . str_pad(number_format($ntvenda, 2, ".", " "), 9, " ", STR_PAD_LEFT) . " |           |" . chr(13) . chr(10);
        ;
        $ctexto .= "+-----+-----------------------------------------------------------+----------+----------+----------+---------+----------+-----------|" . chr(13) . chr(10);
    }
    if ($cobs) {
        $ccomp .= chr(13) . chr(10) . trim($cobs) . chr(13) . chr(10);
    }

    if ($ccommit_web) {
        $nrecno = mysqli_fetch_row(mysqli_query($db, "select recno from AUTORIZA_AUT WHERE TERM_SOL=" . (1000 + $nvendedor)))[0];
        if ($lCfRdd) {
            if ($nrecno) {
                $omed = new Mediator4("AUTORIZA.AUT", W_ALTERAR, '', $nrecno, $db, '', true);
            } else {
                $omed = new Mediator4("AUTORIZA.AUT", W_CRIAR, '', '', $db);
            }
        } else {
            if ($nrecno) {
                $omed = new Mediator3("AUTORIZA.AUT", W_ALTERAR, '', $nrecno, $db, '', true);
            } else {
                $omed = new Mediator3("AUTORIZA.AUT", W_CRIAR, '', '', $db);
            }
        }
    } else {
        $omed = new Mediator1();
        $omed->init($db, "AUTORIZA.AUT");
    }

    $ddata = date("Y-m-d");
    $hdata = date("H:i:s");
//CONFIG IGNOCUST IGNORA CUSTO 
//SAIDAS_MIN 88
//SAIDAS_ATA 228
//SAIDAS_CUS VENDA ABAIXO DO CUSTO
//SAIDAS_CUI VENDA IGUAL CUSTO
    //preço
    $nnivel = ($latac ? 228 : 88);
    //quant. maxima
    if ($nquantmax) {
        //$nnivel = 413;
        $nnivel = VeSenhaAutorizaNumero("SAIDAS_MAQ");
    }



    //cancelar autorizacoes anteriores
    //mysqli_query($db, "update AUTORIZA_AUT SET AUTORIZADO='Abortado pelo requerente',is_deleted='Y' WHERE is_deleted='N' and OPER_SOL=$nusuario and term_sol=" . assql(1000 + $nvendedor));

    $omed->aadd("DATA_SOL", $ddata);
    $omed->aadd("HORA_SOL", $hdata);
    $omed->aadd("COMPLEMENT", iconv("utf8", "cp850", $ccomp));
    $omed->aadd("cor", "w/r,gr+/bg,,,gr+/r,W+/B,W+/BG");
    $omed->aadd("MOTIVO_SOL", iconv("utf8", "cp850", $nquantmax ? "Quantidade máxima" : "Liberação de Preço"));
    $omed->aadd("nivel", cifra($hdata . str_pad($nnivel, 4, " ", STR_PAD_LEFT)));
    $nsolicita = pegavar("nsolicita");
    $omed->aadd("OPER_PED", str_pad(!$nsolicita ? 1 : $nsolicita, 3, "0", STR_PAD_LEFT) . "-");
    $omed->aadd("OPER_SOL", $nusuario);
    $omed->aadd("CHAVE", gerasenha(20));
    $omed->aadd("TEXTO", iconv("utf8", "cp850", $ctexto));
    $omed->aadd("PRO_AUTZ", $olin["produto"]);
    $omed->aadd("CLI_AUTZ", $olin["cliente"]);
    $omed->aadd("TERM_SOL", 1000 + $nvendedor);

    if (!$omed->grava()) {
        $aret["erro"] = "99";
        $aret["cerro"] = "Erro Gravando autorização.\n" . $omed->cerro;
        echo json_encode($aret);
        return;
    }
    $aret["registro"] = $omed->nrecno;
    echo json_encode($aret);
    return;
}
if ($modo == 101) { //ler autorizadores
    if (VeSession("modo") == 0) {
        if (!$lweb) {
            $otab = mysqli_query($db, "select * from TABLET_CFG where IS_DELETED='N' AND  vendedor=$vendedor ");
        } else {
            $otab = mysqli_query($db, "select * from CONFIGVD_WEB where IS_DELETED='N' AND vendedor=$vendedor ");
        }
    } else {
        $otab = mysqli_query($db, "select AMBIENTE from tablet" . $lweb . "_cax where codigo=" . VeSession("usuario"));
    }
    $olin = mysqli_fetch_array($otab);
    $aautoriza = array();
    if (mysqli_num_rows($otab) == 0 || $olin["AMBIENTE"] + 0 == 0) {
        $aret["autoriza"] = $aautoriza;
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Ambiente de autorização não configurado para o operador") . " $vendedor";
        echo json_encode($aret);
        return;
    }
    $nambiente = trim($olin["AMBIENTE"]) + 0;
    $cstr = "select codigo,nome from OPERADOR_OPE WHERE IS_DELETED='N' AND find_in_set($nambiente,replace(ambiente,'-',',')) ";
    $otabope = mysqli_query($db, $cstr);
//    $otabope = mysqli_query($db, "select codigo,nome from OPERADOR_OPE WHERE bloq_vdas!='S' and IS_DELETED='N' AND find_in_set($nambiente,replace(ambiente,'-',',')) ");
    if (mysqli_num_rows($otabope) == 0) {
        $aret["autoriza"] = $aautoriza;
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Sem operadores no Ambiente de autorização configurado para o operador") . " -$nambiente- ";
        echo json_encode($aret);
        return;
    }

    while ($olinope = mysqli_fetch_row($otabope)) {
        $aautoriza[] = array($olinope[0], iconv("cp850", "utf8", $olinope[1]));
    }

    $aret["autoriza"] = $aautoriza;
    echo json_encode($aret);
    return;
}




























if (PegaVar("finalizar") == "true" || $modo == "FINALIZAR_NOTA") {
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar('serie') + 0;

    if (!$vendedor) {
        $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
    }
    $anotavoucher = array();
    $cdata = "\nInicio: " . date("H:i:s");
    $ocfgcec = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG WHERE RECNO=1"));
    mysqli_query($db, "update tablet" . $lweb . "_cab n,(select sum(quant) as itens,sum(quant*valor) as total from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor) d set n.itens=d.itens,n.total=d.total where n.vendedor=$vendedor;");

    $nmoedafim = pegavar("moedafim") + 0;
    if ($nmoedafim) {
        mysqli_query($db, "update tablet" . $lweb . "_cab set moeda=$nmoedafim where serie='$nserie' and vendedor=$vendedor ");
    }

    $otabcab = mysqli_query($db, "select * from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor ");
    $otabpro = mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor ");

    if (mysqli_num_rows($otabcab) == 0 || mysqli_num_rows($otabpro) == 0) {
        $aret["erro"] = "98";
        $aret["cerro"] = _tr("Vendas está vazia");
        echo json_encode($aret);
        return;
    }

    //numero de itens
    //$olcfg = mysqli_fetch_array(mysqli_query($db, "select profact,profat1,BLQVDCLI from CONFIG WHERE RECNO=1"));
    $nMaxItens = $olcfg["PROFACT"];
    $olincab = mysqli_fetch_array($otabcab);

    if ($olincab["loja"] == 0 || $olincab["vendedor"] == 0 || $olincab["cliente"] == 0) {
        $aret["erro"] = "98";
        $aret["cerro"] = _tr("Vendas está com dados corrompidos. Reinicialize a nota de venda");
        echo json_encode($aret);
        return;
    }

    // COLETAS OS VALORES DE CAMBIO ATUAIS
    $amoedas = pegavar("moeda");

    $olinm = mysqli_fetch_array(mysqli_query($db, "select simb1,simb2,simb3,simb4
        ,upper(nome1),upper(nome2),upper(nome3),upper(nome4)
        ,if(deci1='S',2,0),if(deci2='S',2,0),if(deci3='S',2,0),if(deci4='S',2,0)
        from CAMBIO_NOM"));
    $olincam = mysqli_fetch_row(mysqli_query($db, "select moeda1,moeda2,moeda3,moeda4 from CAMBIO_CAM where is_deleted='N' and datcam<=current_date() order by datcam desc,recno desc limit 1 "));
    //var_dump($olincam);
    $amoedas = array(
        array($olinm[0], $olinm[4], $olinm[8], $olincam[0] / $olincam[0], $olincam[0], $olincam[0])
        , array($olinm[1], $olinm[5], $olinm[9], $olincam[1] / $olincam[0], $olincam[1], $olincam[0])
        , array($olinm[2], $olinm[6], $olinm[10], $olincam[2] / $olincam[0], $olincam[2], $olincam[0])
        , array($olinm[3], $olinm[7], $olinm[11], $olincam[3] / $olincam[0], $olincam[3], $olincam[0])
    );

    $olincli = mysqli_fetch_array(mysqli_query($db, "select CODCLI,NOMCLI,PAISCLI,TRIM(REGICLI) as REGICLI,VENCTO_REG,CURRENT_DATE() AS HOJE,VNDCLI,PAISCLI FROM CLIENTE_CLI where is_deleted='N' and codcli=" . $olincab["cliente"]));
    if (!$olincli["CODCLI"] || $olincli["CODCLI"] == 0) {
        $aret["erro"] = "98";
        $aret["cerro"] = _tr("Este cliente") . ": " . $olincab["cliente"] . "-" . limpachar($olincli["NOMCLI"]) . "\n " . _tr("Está com problemas no ARQUIVO");
        echo json_encode($aret);
        return;
    }



    $cstr = "create temporary table tmp_fin select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor";
    mysqli_query($db, $cstr);
    $cstr = "alter table tmp_fin add pacote int(10) not null default 0";
    mysqli_query($db, $cstr);
    $cstr = "alter table tmp_fin add ordem int(10) not null primary key auto_increment";
    mysqli_query($db, $cstr);

    $npacote = mysqli_fetch_array(mysqli_query($db, "select pacoemp from EMPRESA_EMP where is_deleted='N' and codemp=" . $olincab["loja"]))[0];
    $apacotes = array();
    //ajustar o seguro para o pacote do produto
    $apro_pacote = array();
    $otpacote = mysqli_query($db, "select 
        t.codigo
        ,p.pacote
        ,t.seg_pro
        ,t.seg_cod
        ,t.ordem
        from tmp_fin t 
        inner join PRODUTO_PRO p on p.codpro=t.codigo and p.is_deleted='N'
        inner join CONFIG c on c.recno=1
        order by pacote desc");

    $acomissaop = array();
    $npac = 0;
    $ncod_seg = VeConfigCec("CODSEG_PG");

    $aseguro = array();
    $i = 0;
    while ($olpacote = mysqli_fetch_array($otpacote)) {
        $acomissaop[] = $olpacote["codigo"];
        $cstr = "update tmp_fin set pacote=" . ($npacote ? $npacote : $olpacote["pacote"]) . " where ordem=" . $olpacote["ordem"];
        mysqli_query($db, $cstr);
    }
    $otmp = mysqli_query($db, "select * from tmp_fin where seg_pro>0");
    while ($oltmp = mysqli_fetch_array($otmp)) {
        $cstr = "update tmp_fin set pacote=" . (mysqli_fetch_row(mysqli_query($db, "select pacote from tmp_fin where codigo=" . $oltmp["seg_pro"]))[0]) . " where ordem=" . $oltmp["ordem"];
        mysqli_query($db, $cstr);
    }
    //seguro pitzi
    $otmp = mysqli_query($db, "select * from tmp_fin where seg_pito>0");
    while ($oltmp = mysqli_fetch_array($otmp)) {
        $cstr = "update tmp_fin set pacote=" . (mysqli_fetch_row(mysqli_query($db, "select pacote from tmp_fin where codigo=" . $oltmp["seg_pito"]))[0]) . " where ordem=" . $oltmp["ordem"];
        mysqli_query($db, $cstr);
    }
    $otmp = mysqli_query($db, "select * from tmp_fin");
    while ($oltmp = mysqli_fetch_array($otmp)) {
        if (!$lorc && $olincli["PAISCLI"] == 1 && $oltmp["codpromo"] && $olcfg["PERAUM_TJ"]>0) {
            if ($npacote) {
                $apacotes["PA" . $npacote][] = $oltmp["ordem"];
                $npac = $npacote;
            } elseif ($oltmp["pacote"] == 0 && $npac > 0) {
                $apacotes["PA" . $npac][] = $oltmp["ordem"];
            } else {
                $apacotes["PA" . $oltmp["pacote"]][] = $oltmp["ordem"];
                $npac = $oltmp["pacote"];
            }
        } else {
            if ($lorc) {
                $apacotes["A0"][] = $oltmp["ordem"];
            } elseif ($npacote) {
                $apacotes["A" . $npacote][] = $oltmp["ordem"];
                $npac = $npacote;
            } elseif ($oltmp["pacote"] == 0 && $npac > 0) {
                $apacotes["A" . $npac][] = $oltmp["ordem"];
            } else {
                $apacotes["A" . $oltmp["pacote"]][] = $oltmp["ordem"];
                $npac = $oltmp["pacote"];
            }
        }
    }

    $acomissao = CalcPromoQua($acomissaop, $olincab["loja"]);

    $anotasret = array();
    $aentrega = array();
    $cArqSai = $lorc ? "SAIDA.ORC" : "SAIDAS.SAI";
    $cArqPro = $lorc ? "PROSAI.ORC" : "PROSAI.SAI";
    $cArqGra = $lorc ? "GRADESAI.ORC" : "GRADESAI.SAI";

    $cArqSaiS = $lorc ? "SAIDA_ORC" : "SAIDAS_SAI";
    $cArqProS = $lorc ? "PROSAI_ORC" : "PROSAI_SAI";
    $cArqGraS = $lorc ? "GRADESAI_ORC" : "GRADESAI_SAI";

    $aRecnoDel = array();
    $aNotasGeradas = array();

    $cSql = "select if(f.PERAUM_TJ=0 or c.PAISCLI!=1 or c.regicli!='' or p.natureza=1,0,f.PERAUM_TJ) AS indice from CLIENTE_CLI c 
        inner join tablet" . $lweb . "_cab t on t.vendedor=$nvendedor and t.serie=$nserie and t.cliente=c.codcli
        inner join CLIENTE_PGY p on p.codigo=c.codcli and p.is_deleted='N'
        inner join CONFIG f on f.recno=1
        where c.is_deleted='N' AND c.codcli!=0
            ";

    $nindex = mysqli_fetch_row(mysqli_query($db, $cSql))[0];
    $nindex = $nindex + 0.00;
    foreach ($apacotes as $key => $aprodutos) {
        GravaLogTablet("VENDAS_FIN_INI");
        $clog = "";
        $lcompromo = false;
        if (substr($key, 0, 1) == "P") {
            $lcompromo = true;
            $key = substr($key, 1);
        }
        $aentrega[] = $key;
        if ($lCfRdd) {
            $omedn = new Mediator4($cArqSai, W_CRIAR_DEL);
        } else {
            $omedn = new Mediator3($cArqSai, W_CRIAR_DEL);
        }
        $omedn->aadd("VENDSAI", $vendedor);
        if (!$omedn->grava()) {
            $aret["erro"] = $omedn->erro;
            $aret["cerro"] = _tr("Erro gravando em") . " $cArqSai.\n" . $omedn->cerro;
            GravaLogTablet("VENDAS_FIN_FIN", $aret["cerro"]);
//deletar nota            
            echo json_encode($aret);
            return;
        }
        if ($lCfRdd){
             $omedn->dblock(true);
        }
        $nrdias = (($olincab["pagament"] == 3 ? $olincab["prazo"] : 0) + 0) . "";
        $cstr = "update $cArqSaiS SET 
         NOTASAI=" . $omedn->nrecno . "
        ,DATASAI=current_date()
        ,DATAREC=current_date()
        ,HORASAI=current_time()
        ,CLIESAI=" . $olincab["cliente"] . " 
        ,LOJASAI=" . $olincab["loja"] . " 
        ,LOJACOR='" . ($olincab["lojacor"] && $olcfg["LOJCORR"] == "S" ? $olincab["lojacor"] : $olincab["loja"]) . "'
        ,TIPOSAI='" . ($olincab["pagament"] == 3 ? "P" : "V") . "'
        ,COCRSAI='" . ($olincab["pagament"] == 3 ? "2" : "1") . "'
        ,CXUNSAI='C'
        ,MOEDA=" . $olincab["moeda"] . "
        ,CAMBSAI=" . ($amoedas[$olincab["moeda"] - 1][4]) . "
        ,BASESAI=" . $amoedas[0][5] . "
        ,VVISTA=0
        ,NRDIAS='$nrdias'
        ,VENCSAI=date_add(current_date(),INTERVAL '$nrdias' DAY)
        ,VENCSAI=current_date()
        ,OBSERV='" . PegaVar("obs") . "' 
        ,RETISAI='N'
        ,OPESAI='" . VeSession("usuario") . "'
        ,FRETSAI='N' 
        ,SITSAI='N'
        ,VENDFAT='$nvendedor'
        ,DATAREC=current_date()
        ,OPEREC=0
        ,ORIGEM_VDA='APK'
        ,TERMSAI='" . ($nvendedor + 2000) . "'
        ,AUM_TJ='" . ($lcompromo ? '' : $nindex) . "'
        ,CARGSAI='" . (pegavar("carga") + 0) . "' 
        where recno=" . $omedn->nrecno;
        //,OBSAI='" . pegavar("obs") . "'
        mysqli_query($db, $cstr);
        $anotavoucher[] = $omedn->nrecno;
        if ($lCfRdd) {
            $omedn1 = new Mediator4($cArqSai, W_ALTERAR, '', $omedn->nrecno, $db);
        } else {
            $omedn1 = new Mediator3($cArqSai, W_ALTERAR, '', $omedn->nrecno, $db);
        }
//$omedn1->init($db, $cArqSai, $omedn->nrecno);
//blqvdcli para cliente exclusivo do vendedor
// vendfat para cliente ue faturou
        if ($olcfg["BLQVDCLI"] == "S") {
            $omedn1->aadd("VENDSAI", $olincli["VNDCLI"] + 0 !== 0 ? $olincli["VNDCLI"] : $vendedor);
        } else {
            $omedn1->aadd("VENDSAI", $vendedor);
        }
        if ($olincab["loc_ini"] || $olincab["loc_fin"]) {
            $omedn1->aadd("obsai", "LocIni:" . $olincab["loc_ini"] . "\r\nLocFin:" . $olincab["loc_fin"]);

            mysqli_query($db, "insert tablet" . $lweb . "_location set nota=".$omedn->nrecno." ,pos='".$olincab["loc_fin"]."',vendedor='$vendedor',data=date2unix(now()),log='1'");
        }
        if (!$omedn1->grava()) {
            $aret["erro"] = $omedn1->erro;
            $aret["cerro"] = "Erro gravando em $cArqSai.\n" . $omedn1->cerro;
            GravaLogTablet("VENDAS_FIN_FIN", $aret["cerro"]);
//deletar nota            
            echo json_encode($aret);
            return;
        }
//deleta os registros para posterior reativacao
        $aRecnoDel[] = array($cArqSaiS, $omedn->nrecno);
        $aNotasGeradas[] = $omedn->nrecno;
        mysqli_query($db, "update $cArqSaiS set is_deleted='Y' where recno=" . $omedn->nrecno);

        $cdata .= "\n$cArqSai: " . date("H:i:s");
        $nnotarecno = $omedn->nrecno;
        $aprorecno = array();
        $i = 0;
        $afpg = array();
        $ndesctotal = 0;
        $clog .= "Nota: $nnotarecno \n";

        $cstr = "select * from tmp_fin where (0 ";
        foreach ($aprodutos as $value) {
            $cstr .= " or ordem=$value";
        }
        $cstr .= ")";
//        }
        $otabpro = mysqli_query($db, $cstr);
        $nitens_tot = 0;
        $nvalor_tot = 0;
        $ncom_gui = 0;

        $arecnoprosai = array();
        $avendasgrade = array();
        $aGarantia = array();
        while ($olinpro = mysqli_fetch_array($otabpro)) {
            $i++;
            $avendasgrade[] = $olinpro["codigo"];
            $opro = mysqli_fetch_array(mysqli_query($db, "select * FROM PRODUTO_PRO where is_deleted='N' and codpro=" . $olinpro["codigo"]));
            if ($lCfRdd) {
                $omedp = new Mediator4($cArqPro, W_CRIAR_DEL, '', '', $db);
            } else {
                $omedp = new Mediator3($cArqPro, W_CRIAR_DEL, '', '', $db);
            }
            $ndesco = 0;
            $cpromopsa = 'N';
            if ($olinpro["codpromo"] > 0) {
                if ($olinpro["desco"] == 0) {
                    $cpromopsa = 'S';
                } else {
                    $omedp->aadd("agru_promo", $olinpro["nomepromo"]);
                    $omedp->aadd("pre_tabela", $olinpro["tabela"]);
                    $omedp->aadd("perqua", $olinpro["desco"] / $olinpro["tabela"] * 100);
                    $ndesco = $olinpro["desco"];
                    //$ndesctotal += $ndesco * $olinpro["quant"];
                }
            } elseif ($olinpro["desco"] > 0) {
                $omedp->aadd("agru_promo", $olinpro["nomepromo"]);
                $omedp->aadd("pre_tabela", $olinpro["tabela"]);
                $omedp->aadd("perqua", $olinpro["desco"] / $olinpro["tabela"] * 100);
                $ndesco = $olinpro["desco"];
            }

            $olinpro["valor"] = $olinpro["valor"] - $ndesco;

            $ndesctotal += $ndesco * $olinpro["quant"];
            $omedp->aadd("promopsa", $cpromopsa);
            $omedp->aadd("NFSAI", $nnotarecno);
            if (substr($key, 0, 1) == 'S') {
                $omedp->aadd("PRSAI2", $aseguro[$key]);
            }
            //$omedp->aadd("DATASPRO", "current_date()", true);     //       data2sql($ddata);
            $cdata = date("Y-m-d");
            $omedp->aadd("DATASPRO", $cdata);     //       data2sql($ddata);
            $omedp->aadd("PRSAI", $olinpro["codigo"]);
            $omedp->aadd("QUSAI", $olinpro["quant"]);

            /*             * **************************************************ATENCAO ********************************** */
            if (mysqli_fetch_row(mysqli_query($db, "select qualoc from LOCAL_LOC where is_deleted='N'
                and proloc=" . $olinpro["codigo"] . " and locloc=" . $olincab["loja"]))[0] < 0) {
                $omedp->aadd("MONTAPSA", "S");
            } else {
                $omedp->aadd("MONTAPSA", "N");
            }



            //comissao
            if ($olcfg["GUIA_PGRU"] == "S") {
                if (($opro["PER_GUIA"] + 0) * 100 > 0) {
                    $ncom_gui += ($olinpro["quant"] * ($olinpro["valor"] * $amoedas[$olincab["moeda"] - 1][3]) * $opro["PER_GUIA"]) / 100;
                } else {
                    $ncomgru = (mysqli_fetch_row(mysqli_query($db, "select PER_GUIA from GRUPO_GRU where is_deleted='N' and codgru=" . $opro["GRUPRO"]))[0]) + 0;
                    $ncom_gui += ($olinpro["quant"] * ($olinpro["valor"] * $amoedas[$olincab["moeda"] - 1][3]) * $ncomgru) / 100;
                }
            }


            $nitens_tot += $olinpro["quant"];
//            $nvalor_tot += $olinpro["valor"] * $amoedas[$olincab["moeda"] - 1][3] * $olinpro["quant"];
            $nvalor_tot += $olinpro["valor"] * $olinpro["quant"];

            $clog .= "Prod: " . $olinpro["codigo"] . "-" . digito($olinpro["codigo"]) . " Quant: " . $olinpro["quant"] . " Pre: " . $olinpro["valor"] * $amoedas[$olincab["moeda"] - 1][3] . "\n";

            $omedp->aadd("CUMOE", $olinpro["valor"] * $amoedas[$olincab["moeda"] - 1][3]);
            $omedp->aadd("QTVSAI", $olinpro["quant"]);
            $omedp->aadd("REGSAI", $i);
            $omedp->aadd("CXUNSA", "C");
            $omedp->aadd("NOMEPSA", limpachar(trim($opro["NOMELONG"]) ? $opro["NOMELONG"] : $opro["NOMPRO"]));
//cliente tem de ser paraguaio e distribuidor ->  paiscli=1 e regicli!='' 
// bloquear a venda se distribuidor com registro vencido. vencto_reg        
            if ($olincli["PAISCLI"] == 1 && $olincli["REGICLI"] != '') {
                $aiva = CalcIva($olinpro["codigo"], $olinpro["valor"] * $amoedas[$olincab["moeda"] - 1][3]);
                $omedp->aadd("EXENTPRO", $aiva[0]);
                $omedp->aadd("GRAVAPRO", $aiva[1]);
            }

            $omedp->aadd("CUSATU", $ocfgcec["LUCESPE"] == "N" ? ($opro["CUSMED"] < 0 ? $opro["ULTCUS"] : $opro["CUSMED"]) : $opro["ULTCUS"]);
            $omedp->aadd("PREMIN", $opro["PREMIN"]);
            $omedp->aadd("CUSAI", $olinpro["valor"]);
            if ($olincab["seguro"]) {
                $omedp->aadd("SEGURO", "S");
            }
            $omedp->aadd("KITSAI", $opro["KITPRO"]);

            if ($olinpro["iva"] > 1) {
                $omedp->aadd("SEMIVA", $olinpro["valor"] / $olinpro["iva"]);
                $omedp->aadd("IVA", ($olinpro["iva"] - 1) * 100);
            }

            if (!$omedp->grava()) {
                mysqli_query($db, "update $cArqSaiS set is_deleted='Y'  where recno=$nnotarecno ");
                foreach ($aprorecno as $value) {
                    mysqli_query($db, "update $cArqProS set is_deleted='Y'  where recno=$value ");
                }
                $aret["erro"] = "96";
                $aret["cerro"] = "Erro gravando em $cArqSai =>" . $opro["CODPRO"];
                GravaLogTablet("VENDAS_FIN_FIN", $aret["cerro"] . "\n" . $clog, $nnotarecno);
                echo json_encode($aret);
                return;
            }

            //deleta os registros para posterior reativacao
            $aRecnoDel[] = array($cArqProS, $omedp->nrecno);
            mysqli_query($db, "update $cArqProS set is_deleted='Y' where recno=" . $omedp->nrecno);
            $arecnoprosai[] = $omedp->nrecno;

            $aprorecno[] = $omedp->nrecno;
            $afpg[] = array($opro["CODPRO"], $olinpro["quant"]);
            //garantia

            if ($olinpro["seg_pito"] && !$lorc) {
                $cgar = "select codigo,tmin,tmax,if(moeda=0,1,moeda) as moeda from GARANTIA_GAR where is_deleted='N' and prodcec=" . $olinpro["codigo"];
                $otgar = mysqli_query($db, $cgar);
                if (mysqli_num_rows($otgar) > 0) {
                    $olgar = mysqli_fetch_array($otgar);
                    if ($lCfRdd) {
                        $omedg = new Mediator4("PRODUTO.GAR", W_CRIAR, "", "", $db);
                    } else {
                        $omedg = new Mediator3("PRODUTO.GAR", W_CRIAR, "", "", $db);
                    }
                    $omedg->aadd("nota", $nnotarecno);
                    $omedg->aadd("cliente", $olincab["cliente"]);
                    $omedg->aadd("moeda", $olgar["moeda"]);
                    $omedg->aadd("produto", $olinpro["seg_pito"]);
                    $nvalorpro = mysqli_fetch_row(mysqli_query($db, "select valor from tmp_fin where codigo=" . $olinpro["seg_pito"]))[0];
                    $nvalorpro *= $amoedas[$olgar["moeda"] - 1][3];
                    $nvalorseg = $olinpro["valor"] * $amoedas[$olgar["moeda"] - 1][3];

                    $omedg->aadd("preco", $nvalorpro);
                    $omedg->aadd("valor", $nvalorseg);

                     $omedg->aadd("vendedor" . $olincab["vendedor"]);
                    $omedg->aadd("garantia", $olgar["codigo"]);
                    $omedg->aadd("Inicio", Date2Unix() + ($olgar[1] * 24 * 60 * 60)); // ( aAux[ 1, 2 ] * 24 * 60 * 60 )
                    $omedg->aadd("Final", Date2Unix() + ( $olgar[2] * 24 * 60 * 60 ));
                    $omedg->grava();
                }
            }

            //KIT
            if ($opro["KITPRO"] == "S") {
                $clog .= "Kit: " . $opro["CODPRO"] . " Quant: " . $olinpro["quant"] . " Pre: " . $olinpro["valor"] * $amoedas[$olincab["moeda"] - 1][3] . "\n";
                $otkit = mysqli_query($db, "select prokit,quakit,venkit,minkit from PROKIT_PRO where is_deleted='N' and codkit=" . $opro["CODPRO"]);
                while ($olkit = mysqli_fetch_array($otkit)) {
                    $i++;
                    $oprok = mysqli_fetch_array(mysqli_query($db, "select * FROM PRODUTO_PRO where is_deleted='N' and codpro=" . $olkit["prokit"]));
                    if ($lCfRdd) {
                        $omedp = new Mediator4($cArqPro, W_CRIAR_DEL, '', '', $db);
                    } else {
                        $omedp = new Mediator3($cArqPro, W_CRIAR_DEL, '', '', $db);
                    }
                    $ndesco = 0;
                    $omedp->aadd("promopsa", "N");
                    $omedp->aadd("NFSAI", $nnotarecno);
//                    $omedp->aadd("DATASPRO", "current_date()", true);
                    $cdata = date("Y-m-d");
                    $omedp->aadd("DATASPRO", $cdata);     //       data2sql($ddata);
                    $omedp->aadd("PRSAI", $olkit["prokit"]);
                    $omedp->aadd("QUSAI", $olinpro["quant"] * $olkit["quakit"]);

                    $nper = $olinpro["valor"] / $opro["PREVEN"];
                    $omedp->aadd("CUMOE", $olkit["venkit"] * $nper * $amoedas[$olincab["moeda"] - 1][3]);
                    $omedp->aadd("QTVSAI", $olinpro["quant"] * $olkit["quakit"]);
                    $omedp->aadd("REGSAI", $i);
                    $omedp->aadd("CXUNSA", "C");
                    $omedp->aadd("NOMEPSA", limpachar(trim($oprok["NOMELONG"]) ? $oprok["NOMELONG"] : $oprok["NOMPRO"]));
                    if ($olincli["PAISCLI"] == 1 && $olincli["REGICLI"] != '') {
                        $aiva = CalcIva($olkit["prokit"], $olkit["venkit"] * $nper * $amoedas[$olincab["moeda"] - 1][3]);
                    }
                    $omedp->aadd("EXENTPRO", $aiva[0]);
                    $omedp->aadd("GRAVAPRO", $aiva[1]);
                    $omedp->aadd("CUSATU", $ocfgcec["LUCESPE"] == "N" ? ($oprok["CUSMED"] < 0 ? $oprok["ULTCUS"] : $oprok["CUSMED"]) : $oprok["ULTCUS"]);
                    $omedp->aadd("PREMIN", $olkit["minkit"]);
                    $omedp->aadd("CUSAI", $olkit["venkit"] * $nper);
                    $omedp->aadd("KITSAI", "K");

                    if (!$omedp->grava()) {
                        mysqli_query($db, "update $cArqSaiS set is_deleted='Y'  where recno=$nnotarecno ");
                        foreach ($aprorecno as $value) {
                            mysqli_query($db, "update $cArqProS set is_deleted='Y'  where recno=$value ");
                        }
                        $aret["erro"] = "96";
                        $aret["cerro"] = "Erro gravando em $cArqSai =>" . $opro["CODPRO"];
                        GravaLogTablet("VENDAS_FIN_FIN", $aret["cerro"] . "\n" . $clog, $nnotarecno);
                        echo json_encode($aret);
                        return;
                    }
                    //deleta os registros para posterior reativacao
                    $aRecnoDel[] = array($cArqProS, $omedp->nrecno);
                    mysqli_query($db, "update $cArqProS set is_deleted='Y' where recno=" . $omedp->nrecno);

                    $aprorecno[] = $omedp->nrecno;
                }
            }
            $cdata .= "\nproduto $i: " . date("H:i:s");
        }

//recalcula e grava totais da nota
//$otot = mysqli_query($db, "select sum(qusai) as itens,sum(cusai*qusai) as valor from $cArqProS where is_deleted='N' and nfsai=$nnotarecno and kitsai!='K'");
        $caux = "select sum(qusai) as itens
            ,sum(cumoe*qusai) as valor
            ,sum(if(iva=0,0,cusai-semiva)) as valiva
            ,sum(cusai*qusai) as valorsai
            from $cArqProS where (0 ";
        foreach ($arecnoprosai as $value) {
            $caux .= " or recno=$value";
        }
        $caux .= ")";
        $otot = mysqli_query($db, $caux);
        if (mysqli_num_rows($otot) > 0) {
            $oltot = mysqli_fetch_row($otot);
            $csql2 = "UPDATE $cArqSaiS SET NOTASAI=$nnotarecno,QUANFIN=" . $oltot[0] . ", QUANSAI=" . $oltot[0]
                    . " ,valosai=" . $oltot[1]
                    . " ,ivasai=" . $oltot[2]
                    . ($cArqSaiS == "SAIDA_ORC" ? "" : ",valcomgui=" . $ncom_gui)
                    . " where recno=$nnotarecno";
            mysqli_query($db, $csql2);
            /*
              if (!$lorc) {
              VeListaGuia($nnotarecno,'','','');
              }
             */
        }
        $i = 0;
//GRADE
        $otgra = mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor");
        while ($otlin = mysqli_fetch_array($otgra)) {
//            if (array_search($otlin["codigo"], $aprodutos) === false) {
            if (array_search($otlin["codigo"], $avendasgrade) === false) {

                continue;
            }
            if ($lCfRdd) {
                $omedg = new Mediator4($cArqGra, W_CRIAR_DEL, '', '', $db);
            } else {
                $omedg = new Mediator3($cArqGra, W_CRIAR_DEL, '', '', $db);
            }
            $omedg->aadd("nfsai", $nnotarecno);
            $omedg->aadd("prsai", $otlin["codigo"]);
            $omedg->aadd("qusai", $otlin["quant"]);
            $omedg->aadd("seqgrade1", $otlin["seq1"]);
            $omedg->aadd("seqgrade2", $otlin["seq2"]);
            $omedg->grava();
            //deleta os registros para posterior reativacao
            $aRecnoDel[] = array($cArqGraS, $omedg->nrecno);
            mysqli_query($db, "update $cArqGraS set is_deleted='Y' where recno=" . $omedg->nrecno);

//        mysqli_query($db, "update ESTLJGRA_PRO SET FPGLOC=FPGLOC-" . $otlin["quant"] . " WHERE IS_DELETED='N' AND LOJGRADE=$nloja AND PROGRADE=" . $otlin["codigo"] . " and seqgrade1=" . $otlin["seq1"] . " and seqgrade2=" . $otlin["seq2"] . "");
//        mysqli_query($db, "update ESTGRADE_PRO set fpgpro=fpgpro-" . $otlin["quant"] . " WHERE IS_DELETED='N'                     AND PROGRADE=" . $otlin["codigo"] . " and seqgrade1=" . $otlin["seq1"] . " and seqgrade2=" . $otlin["seq2"] . "");
        }
        $aret["nota"][] = $nnotarecno + 0;
        GravaLogTablet("VENDAS_FIN_FIN", $clog, $nnotarecno);
    }

    foreach ($apacotes as $key => $value) {
        if (substr($key, 0, 1) == "P") {
            $key = substr($key, 1);
        }
        $aret["pacote"][] = str_replace("A", "", $key);
    }


//reativa os registros deletados
    $clog = "Recuperando registro: \n";
    foreach ($aRecnoDel as $key => $value) {
        $clog .= $value[0] . " Recno: " . $value[1] . "\n";
        mysqli_query($db, "update " . $value[0] . " set is_deleted='N' where recno=" . $value[1]);
    }
    $nordem = mysqli_fetch_row(mysqli_query($db, "select ordem from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor"))[0];
    if (!$olincab["placa"]) {
        $cstr = "update $cArqSaiS  SET PLACASAI=CONCAT('TBL',lpad($nordem,7,'0')) where 0 ";
    } else {
        $caux = $olincab["placa"];

        if ($olincab["prisma"]) {
            $caux .= "/" . $olincab["prisma"];
        }
        $cstr = "update $cArqSaiS  SET PLACASAI='$caux' where 0 ";
    }
    foreach ($aNotasGeradas as $value) {
        $cstr .= " or recno=$value ";
    }
    mysqli_query($db, $cstr);
    GravaLogTablet("VENDAS_FIN_UNDEL", $clog);

// GUIAS
    if (!$lorc) {
        foreach ($aNotasGeradas as $value) {
            VeListaGuia($value);
            AtuaComis($value);
        }
    }


//Veiculo
    if ($olincab["placa"]) {
        $nrecno = (mysqli_fetch_row(mysqli_query($db, "select  recno VEICULO_CAR WHERE IS_DELETED='N' AND PLACA='" . $olincab["placa"] . "'"))[0]) + 0;
        if ($lCfRdd) {
            $omedv = new Mediator4("VEICULO.CAR", ($nrecno == 0 ? W_CRIAR : W_ALTERAR), '', ($nrecno == 0 ? '' : $nrecno), $db);
        } else {
            $omedv = new Mediator3("VEICULO.CAR", ($nrecno == 0 ? W_CRIAR : W_ALTERAR), '', ($nrecno == 0 ? '' : $nrecno), $db);
        }
        $omedv->aadd("prisma", $olincab["prisma"]);
        $omedv->aadd("placa", $olincab["placa"]);
        $omedv->aadd("marca", $olincab["marca"]);
        $omedv->aadd("modelo", $olincab["modelo"]);
        $omedv->aadd("cor", $olincab["cor"]);
        $omedv->aadd("ano", $olincab["ano"]);
        $omedv->aadd("kilomet", $olincab["kilomet"]);
        $omedv->aadd("classe", $olincab["classe"]);
        $omedv->aadd("tipo", $olincab["tipo"]);
        $omedv->grava();

        $nclivei = (mysqli_fetch_row(mysqli_query($db, "select  cliente VEICLI_CAR WHERE IS_DELETED='N' AND PLACA='" . $olincab["placa"] . "' order by recno desc limit 1"))[0]) + 0;

        if ($nclivei !== $olincab["cliente"]) {
            if ($lCfRdd) {
                $omedv = new Mediator4("VEICLI.CAR", W_CRIAR, '', '', $db);
            } else {
                $omedv = new Mediator3("VEICLI.CAR", W_CRIAR, '', '', $db);
            }
            $omedv->aadd("placa", $olincab["placa"]);
            $omedv->aadd("CLIENTE", $olincab["cliente"]);
            $omedv->aadd("data", Date2Unix());
            $omedv->aadd("km", $olincab["kilomet"]);
            $omedv->grava();
        }
    }

//bloqter
    mysqli_query($db, "update BLOQTER_PRO set is_deleted='Y' where is_deleted='N' and termbloq='" . "T" . $nserie . str_pad($vendedor, 4, "0", STR_PAD_LEFT) . "'");

//voucher
    require_once 'voucher_engine.php';
    if (count($anotavoucher) == 1) {
        $value = $anotavoucher[0];
        $nrefper = 0;
        $nrefval = 0;
        $creferro = '';
        $nret = UsaVoucherNota($value, $olincab["voucher"], $nrefper = 0, $nrefval = 0, $creferro = '', false);
    }
    if ($olincab["loc_fin"]){
        mysqli_query($db, "insert tablet" . $lweb . "_location set pos='".$olincab["loc_fin"]."',nota='".$nnotarecno."',vendedor='$vendedor',data=date2unix(now()),log='1'");
    }
    mysqli_query($db, "delete from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor");
//$aret["erro"]=98;
//$aret["cerro"]="delete from tablet".$lweb."_cab where serie='$nserie' and vendedor=$vendedor";
    mysqli_query($db, "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor");
    mysqli_query($db, "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor");
    $cdata .= "\ndelete : " . date("H:i:s");
    $aret["emissao"] = date("d/m/y H:i:s");
    $aret["mensagem"] = $cdata;
    echo json_encode($aret);
    return;
}
if ($modo == 1) {
    if (!$vendedor) {
        $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
    }
    $nmoeda = PegaVar("moeda");
    $npagamento = PegaVar("pagamento"); //== "true" ? 1 : 2;
    $nnacionalidade = PegaVar("nacionalidade") == "true" ? 1 : 2;
    $nloja = pegavar("loja");
    $nlojacor = pegavar("lojacor");
    $ncliente = PegaVar("cliente");
    $nseguro = PegaVar("seguro");
    $lorcamento = (pegavar("orcamento") == "true" ? 1 : 0);
    $nserie = pegavar('serie') + 0;
    $nprazo = pegavar('prazo') + 0;
    $cvoucher = trim(strtoupper(pegavar("voucher")));

    $cstr = "vendedor=$vendedor
            ,data_ini=date2unix(now())
            ,moeda='$nmoeda'
            ,nacional='$nnacionalidade'
            ,pagament='$npagamento'
            ,loja='$nloja'
            ,lojacor='$nlojacor'
            ,cliente='$ncliente'
            ,seguro='$nseguro'    
            ,orcamento=$lorcamento 
            ,serie='$nserie'
            ,prazo='$nprazo'
            ,operador=" . VeSession("usuario") . "
,prisma='" . strtoupper(pegavar("prisma")) . "'
,placa='" . strtoupper(pegavar("placa")) . "'
,marca='" . strtoupper(pegavar("marca")) . "'
,modelo='" . strtoupper(pegavar("modelo")) . "'
,cor='" . strtoupper(pegavar("cor")) . "'
,tipo='" . strtoupper(pegavar("tipo")) . "'
,classe='" . pegavar("classe") . "'
,ano='" . pegavar("ano") . "'
,kilomet='" . pegavar("kilomet") . "'
,voucher='" . $cvoucher . "'
";

    $aret["insert"] = "0";
    $otab = mysqli_query($db, "select * from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor");
    if (mysqli_num_rows($otab) == 0) {
        $aret["insert"] = "1";
        mysqli_query($db, "insert tablet" . $lweb . "_cab set $cstr");
    } else {
        mysqli_query($db, "update tablet" . $lweb . "_cab set $cstr where serie='$nserie' and vendedor=$vendedor");
    }


    echo json_encode($aret);
    return;
}
if ($modo == 2 || $modo == "GRAVA_ITEM") { //incluir item
    $lpro = pegavar("orcamento") == "true";
    if (!$vendedor) {
        $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
    }
    $nquant = pegavar("nquant");
    $nvalor = str_replace(",", ".", pegavar("nvalor"));
    $ncodigo = pegavar("ncodigo");
    $nautoriza = pegavar("nautoriza");
    $nloja = pegavar("loja");
    $nquantant = PegaVar("nquantant") + 0;
    $lseguro = pegavar("seguro");
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar('serie') + 0;
    $niva = pegavar("iva");
//ve3r se ainda tem saldo se mairo que 
    $lkit = (mysqli_fetch_row(mysqli_query($db, "select kitpro from  PRODUTO_PRO WHERE IS_DELETED='N' AND CODPRO=$ncodigo"))[0]) == "S";
    $ncodigoven = $ncodigo;

    if (!$lkit) {
        $cstr = "select
            sum(if(isnull(l.locloc) or l.locloc!=$nloja,0,l.qualoc))+$nquantant as saldo
            ,sum(if(isnull(l.locloc),0,l.qualoc))+$nquantant as saldot
            ,p.kitpro,$nquant as quant,p.nompro,p.codpro,$nquantant as quantant,p.grupro,gp.vende_neg
            from PRODUTO_PRO p
            inner join GRUPO_GRU gp on gp.is_deleted='N' and gp.codgru=p.grupro
            inner join EMPRESA_EMP c on c.is_deleted='N' and c.codemp=$nloja
            left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
            and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',','))) or l.locloc=$nloja)
            where p.is_deleted='N' and p.codpro=$ncodigo";
    } else {
        $cstr = "select
             sum(if(gp.vende_neg='S',$nquant, if(isnull(l.locloc) or l.locloc!=$nloja,0,l.qualoc)))+($nquantant*k.quakit) as saldo
            ,sum(if(gp.vende_ant='S',$nquant, if(isnull(l.locloc),0,l.qualoc)))                    +($nquantant*k.quakit) as saldot
            ,p.kitpro,($nquant*k.quakit) as quant,p.nompro,p.codpro,$nquantant as quantant,p.grupro,gp.vende_neg

            FROM PROKIT_PRO k
            inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=k.prokit
            inner join GRUPO_GRU gp on gp.is_deleted='N' and gp.codgru=p.grupro
            inner join EMPRESA_EMP c on c.is_deleted='N' and c.codemp=$nloja
            left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
            and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',','))) or l.locloc=$nloja)
            where k.is_deleted='N' and k.codkit=$ncodigo group by k.prokit";
    }
    $otabpro = mysqli_query($db, $cstr);
    $afez = array();

    if (!$lorc) {
        while ($olinpro = mysqli_fetch_array($otabpro)) {
            //if ($olinpro["saldo"] <= 0 && $olinpro["saldot"] <= 0 && $lseguro !== "true" && $olcfg["GRUSES"] !== $olinpro["grupro"] && $olinpro["vende_neg"] != "S" ) {
            if ($olinpro["saldo"] <= 0 && $olinpro["saldot"] <= 0 && $lseguro !== "true" && $olcfg["GRUSES"] !== $olinpro["grupro"] && $olinpro["vende_neg"] != "S" ) {
                $aret["erro"] = "96";
                $aret["cerro"] = poedigito($olinpro["codpro"]) . "-" . $olinpro["nompro"] . "\n Produto sem saldo no momento "; //. $olinpro["saldo"]." ". $olinpro["saldot"]." $nquantant"  ;
                echo json_encode($aret);
                return;
            }
            //if (VeConfigCec("SEMEGER") != 'S' && $olinpro["vende_neg"] != "S" ) {
            if (VeConfigCec("SEMEGER") == 'S' || $olinpro["vende_neg"] == "S" ) {
            }else{
                if ($olinpro["quant"] > $olinpro["saldot"] && $lseguro !== "true" && $olcfg["GRUSES"] !== $olinpro["grupro"]) {
                    $aret["erro"] = "96";
                    $aret["cerro"] = poedigito($olinpro["codpro"]) . "-" . $olinpro["nompro"] . "\n Quantidade ultrapassa o saldo GERAL";
                    echo json_encode($aret);
                    return;
                }
            }
            if (mysqli_num_rows(mysqli_query($db, "select * from LOCAL_LOC WHERE IS_DELETED='N' AND LOCLOC=$nloja and proloc=$ncodigo")) == 0) {
                if ($lCfRdd) {
                    $omed = new Mediator4("LOCAL.LOC", W_CRIAR, '', '', $db);
                } else {
                    $omed = new Mediator3("LOCAL.LOC", W_CRIAR, '', '', $db);
                }
                $omed->aadd("locloc", $nloja);
                $omed->aadd("proloc", $ncodigo);
                if (!$omed->grava()) {
                    $aret["erro"] = "97";
                    $aret["cerro"] = "Erros adicionando registro LOCAL.LOC";
                    echo json_encode($aret);
                    return;
                }
            }
            $afez[] = array($olinpro["codpro"], $olinpro["quant"], $olinpro["quantant"]);
        }
    }


    if ($nquantant == 0) {
//        mysqli_query($db, "insert tablet".$lweb."".($lorc?"_orc":"")."_pro set vendedor=$vendedor,codigo=$ncodigo,quant=$nquant-$nquantant,valor=$nvalor,autoriza='$nautoriza'");
//verifica se já está lançado
        if (mysqli_num_rows(mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where vendedor=$vendedor and codigo=$ncodigo and serie=$nserie"))) {
            $aret["erro"] = "97";
            $aret["cerro"] = "Erros adicionando item duplicado";
            echo json_encode($aret);
            return;
        }


        mysqli_query($db, "insert tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set serie='$nserie',vendedor=$vendedor,codigo=$ncodigo,quant=$nquant,valor=$nvalor,iva=$niva,autoriza='$nautoriza',kit='$lkit'");
    } else {
//        mysqli_query($db, "update tablet".$lweb."".($lorc?"_orc":"")."_pro set quant=$nquant-$nquantant,valor=$nvalor,autoriza='$nautoriza' where vendedor=$vendedor and codigo=$ncodigo");
        mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set quant=$nquant,valor=$nvalor,iva=$niva,autoriza='$nautoriza',kit='$lkit' where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo");
    }

//verifica promoção
    if (!$lkit) {
        $otab = mysqli_query($db, "select p.preco5,gp.codgpm from PRODUTO_PRO p , GRUPROMO_GPM gp
                where p.is_deleted='N' and p.codpro=$ncodigo
                and gp.is_deleted='N' and p.codpromo=gp.codgpm and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set($nloja,replace(gp.excljgpm,'-',','))
                ");
        if (mysqli_num_rows($otab) > 0) {
            $olin = mysqli_fetch_array($otab);
            mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set codpromo=" . $olin["codgpm"] . " where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo");
        }

        /*
          $otab = mysqli_query($db, "select p.preco5,gp.codgpm from PRODUTO_PRO p , GRUPROMO_GPM gp
          where p.is_deleted='N' and p.codpro=$ncodigo
          and gp.is_deleted='N' and p.codpromo=gp.codgpm and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set($nloja,replace(gp.excljgpm,'-',','))
          ");
          if (mysqli_num_rows($otab) > 0) {
          $olin = mysqli_fetch_array($otab);
          mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set codpromo=" . $olin["codgpm"] . " where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo");
          }
          $cstr = "select gp.codgpm,gq.perqua1,gq.perqua2,gq.perqua3,gq.perqua4,gq.perqua5,gq.perqua6,gq.perqua7,gq.perqua8,gq.perqua9,gq.perqua10,gq.perqua11,gq.perqua12,gq.perqm10 as perqua13
          ,concat(if(gq.marca>0  ,'/MARCA','')
          ,if(gq.grupo>0    ,'/GRUPO','')
          ,if(gq.sgrupo>0   ,'/SUBGRUPO' ,'')
          ,if(gq.produto>0  ,'/PRODUTO' ,'')
          ,if(gq.gruesp>0  ,'/GRUESP' ,'')
          ) as nome ";
          if (!$nlojapre) {
          $cstr .= " ,if(gp.tipogpm=1,p.$cpreven,if(gp.tipogpm=2,p.preco3,if(gp.tipogpm=3,p.$cpremin,p.preatac))) as tabela
          from PRODUTO_PRO p , GRUPROMO_GPM gp ";
          } else {
          $cstr .= " ,if(gp.tipogpm=1,if(isnull(lc.proloc) or lc.$cpreven=0,p.$cpreven,lc.$cpreven)
          ,if(gp.tipogpm=2,if(isnull(lc.preco3) or lc.preco3=0,p.preco3,lc.preco3)
          ,if(gp.tipogpm=3,if(isnull(lc.proloc) or lc.$cpremin=0,p.$cpremin,lc.$cpremin)
          ,if(isnull(lc.proloc) or lc.preatac=0,p.preatac,lc.preatac)))) as tabela
          from PRODUTO_PRO p
          left join LOCAL_LOC lc on lc.is_deleted='N' and lc.locloc=$nlojapre and lc.proloc=p.codpro
          , GRUPROMO_GPM gp
          ";
          }
          $cstr .= " inner join PROMOQUA_PRO gq on gq.is_deleted='N' and gq.grugpm=gp.codgpm
          where p.is_deleted='N' and p.codpro=$ncodigo
          and gp.is_deleted='N' and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set($nloja,replace(gp.excljgpm,'-',','))
          and (     if(gq.grupo>0  ,gq.grupo  =p.grupro ,1)
          and if(gq.marca>0  ,gq.marca  =p.marcpro,1)
          and if(gq.produto>0,gq.produto=p.codpro ,1)
          and if(gq.sgrupo>0 ,gq.sgrupo =p.sgrupro,1)
          and if(gq.gruesp>0 ,gq.gruesp =p.gruesp,1)
          )
          and p.kitpro!='S'
          ";
          $otab = mysqli_query($db, $cstr);
          if (mysqli_num_rows($otab) > 0) {
          $olin = mysqli_fetch_array($otab);
          $nqua = $nquant > 12 ? 12 : $nquant;
          //$ndesco = $olin["tabela"] * ($olin["perqua$nqua"] / 100) + 0;
          $ndesco = $nvalor * ($olin["perqua$nqua"] / 100) + 0;
          if ($ndesco > 0) {
          //mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set codpromo=" . $olin["codgpm"] . ",valor=" . $olin["tabela"] . ",tabela=" . $olin["tabela"] . ",desco='$ndesco',nomepromo='" . $olin["nome"] . "' where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo");
          mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set codpromo=" . $olin["codgpm"] . ",valor=" . $nvalor . ",tabela=" . $olin["tabela"] . ",desco='$ndesco',nomepromo='" . $olin["nome"] . "' where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo");
          }
          }
         */
    }
    if (!$lorc) {
        $olcab = mysqli_fetch_array(mysqli_query($db, "select * from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor"));
        foreach ($afez as $value) {
            $ncodigo = $value[0];
            $nquant = $value[1];
            $nquantant = $value[2];

            mysqli_query($db, "update LOCAL_LOC SET QUALOC=QUALOC-$nquant+$nquantant,FPGLOC=FPGLOC+$nquant-$nquantant WHERE IS_DELETED='N' AND LOCLOC=$nloja AND PROLOC=$ncodigo");
            mysqli_query($db, "update PRODUTO_PRO set estoque=estoque-$nquant+$nquantant,fpgpro=fpgpro+$nquant-$nquantant WHERE IS_DELETED='N' AND CODPRO=$ncodigo");
            //ADICIONAR BLOQTER
            mysqli_query($db, "update BLOQTER_PRO set is_deleted='Y' where probloq=$ncodigo and termbloq='" . "T" . $nserie . str_pad($vendedor, 4, "0", STR_PAD_LEFT) . "'");
            if ($lCfRdd) {
                $omed = new Mediator4("BLOQTER.PRO", W_CRIAR, '', '', $db);
            } else {
                $omed = new Mediator3("BLOQTER.PRO", W_CRIAR, '', '', $db);
            }
            $omed->aadd("CLIBLOQ", $olcab["cliente"]);
            $omed->aadd("DATABLOQ", date("Y-m-d"));
            $omed->aadd("HORABLOQ", date("H:i:s"));
            $omed->aadd("LOJABLOQ", $olcab["loja"]);
            $omed->aadd("MOEBLOQ", 1);
            $omed->aadd("PREBLOQ", $nvalor);
            $omed->aadd("PROBLOQ", $ncodigo);
            $omed->aadd("QUABLOQ", $nquant);
            $omed->aadd("TERMBLOQ", "T" . $nserie . str_pad($vendedor, 4, "0", STR_PAD_LEFT));
            $omed->aadd("TIPOBLOQ", "V");
            $omed->aadd("USUBLOQ", $olcab["operador"]);
            $omed->aadd("VENDBLOQ", $vendedor);
            if (!$omed->grava()) {
                $aret["erro"] = "97";
                $aret["cerro"] = _tr("Erros adicionando registro") . " BLOQTER " . $omed->cerro;
                echo json_encode($aret);
                return;
            }
        }
    }
//echo mysqli_error($db);
    /*
      $aret["erro"]="98";
      $aret["cerro"]="$nvalor";
     */

    echo json_encode($aret);
    return;
}
if ($modo == 3) { //deleta item
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar('serie') + 0;
    if (!$vendedor) {
        $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
    }

    $nquant = pegavar("nquant");
    $ncodigo = pegavar("ncodigo");
    $nloja = pegavar("loja");

    $acodigo = array($ncodigo);
    if (pegavar("seguro") == "true") {
        $otab = mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor");
        $acodigo = array();
        while ($olin = mysqli_fetch_array($otab)) {
            $acodigo[] = $olin["codigo"];
        }
    }
//ve3r se ainda tem saldo se mairo que 0

    foreach ($acodigo as $value) {
//bloqter
        mysqli_query($db, "update BLOQTER_PRO set is_deleted='Y' where probloq=$ncodigo and termbloq='" . "T" . $nserie . str_pad($vendedor, 4, "0", STR_PAD_LEFT) . "'");

        $lkit = mysqli_fetch_row(mysqli_query($db, "select kit from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor and codigo=$value"))[0];
        if (!$lkit) {
            $cstr = "select codpro,$nquant as quant from PRODUTO_PRO WHERE IS_DELETED='N' AND CODPRO=$value";
        } else {
            $cstr = "select p.codpro,$nquant*k.quakit as quant from PROKIT_PRO k inner join PRODUTO_PRO p ON p.IS_DELETED='N' AND p.CODPRO=k.PROKIT WHERE k.IS_DELETED='N' AND k.CODKIT=$value";
        }
        $otabpro = mysqli_query($db, $cstr);
        if (!$lorc) {
            while ($olinpro = mysqli_fetch_array($otabpro)) {
                mysqli_query($db, "update LOCAL_LOC SET QUALOC=QUALOC+" . $olinpro["quant"] . ",FPGLOC=FPGLOC-" . $olinpro["quant"] . " WHERE IS_DELETED='N' AND LOCLOC=$nloja AND PROLOC=" . $olinpro["codpro"]);
                mysqli_query($db, "update PRODUTO_PRO set estoque=estoque+" . $olinpro["quant"] . ",fpgpro=fpgpro-" . $olinpro["quant"] . " WHERE IS_DELETED='N' AND CODPRO=" . $olinpro["codpro"]);
            }
        }

        $ncod_seg = mysqli_fetch_row(mysqli_query($db, "select seg_cod from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro  where serie='$nserie' and vendedor=$vendedor and codigo=$value"))[0];
        if ($ncod_seg) {
            mysqli_query($db, "delete from  tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor and codigo=$ncod_seg and seg_pro=$value");
        }
        mysqli_query($db, "delete from  tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor and codigo=$value");
    }
    echo mysqli_error($db);
    echo json_encode($aret);
    return;
}
if ($modo == 63) { //deleta grade
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar('serie') + 0;

    if (!$vendedor) {
        $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
    }
    $nquant = pegavar("quant") + 0;
    $nquantant = pegavar("quantant") + 0;
    $ncodigo = pegavar("ncodigo");

    $nseq1 = pegavar("seq1") + 0;
    $nseq2 = pegavar("seq2") + 0;
    $nloja = pegavar("loja");

    $otab = mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo and seq1=$nseq1 and seq2=$nseq2 ");
    $olin = mysqli_fetch_array($otab);

    $nquant = $olin["quant"];
    mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro SET QUANT=QUANT-$nquant WHERE serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo ");
    if (!$lorc) {
        mysqli_query($db, "update LOCAL_LOC SET QUALOC=QUALOC+$nquant,FPGLOC=FPGLOC-$nquant WHERE IS_DELETED='N' AND LOCLOC=$nloja AND PROLOC=$ncodigo");
        mysqli_query($db, "update PRODUTO_PRO set estoque=estoque+$nquant,fpgpro=fpgpro-$nquant WHERE IS_DELETED='N' AND CODPRO=$ncodigo");

        mysqli_query($db, "update ESTLJGRA_PRO SET ESTOQUE=ESTOQUE+$nquant-$nquantant,FPGLOC=FPGLOC-$nquant+$nquantant WHERE IS_DELETED='N' AND LOJGRADE=$nloja AND PROGRADE=$ncodigo and seqgrade1=$nseq1 and seqgrade2=$nseq2");
        mysqli_query($db, "update ESTGRADE_PRO set estoque=estoque+$nquant-$nquantant,fpgpro=fpgpro-$nquant+$nquantant WHERE IS_DELETED='N' AND PROGRADE=$ncodigo and seqgrade1=$nseq1 and seqgrade2=$nseq2");
    }
    mysqli_query($db, "delete from  tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo and seq1=$nseq1 and seq2=$nseq2 ");

    mysqli_query($db, "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro WHERE serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo and quant=0");

    echo mysqli_error($db);
    echo json_encode($aret);
    return;
}
if ($modo == 62) {
    if (!$vendedor) {
        $vendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
    }
    $nquant = pegavar("nquant");
    $nvalor = str_replace(",", ".", pegavar("nvalor"));
    $ncodigo = pegavar("ncodigo");
    $nautoriza = pegavar("nautoriza");
    $nloja = pegavar("loja");
    $nquantant = PegaVar("nquantant") + 0;
    $nseq1 = PegaVar("seq1") + 0;
    $nseq2 = PegaVar("seq2") + 0;
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar('serie') + 0;
    $cstr = "select
            sum(if(isnull(l.locloc) or l.locloc!=$nloja,0,l.qualoc))+$nquantant as saldo
            ,sum(if(isnull(l.locloc),0,l.qualoc))+$nquantant as saldot,p.grupro

            from PRODUTO_PRO p
            inner join EMPRESA_EMP c on c.is_deleted='N' and c.codemp=$nloja
            left join LOCAL_LOC l on l.is_deleted='N' and l.proloc=p.codpro 
            and (if(c.stokemp='',1,find_in_set(l.locloc, replace(c.stokemp,'-',','))) or l.locloc=$nloja)
            where p.is_deleted='N' and p.codpro=$ncodigo
                group by p.codpro
            ";
    $olinpro = mysqli_fetch_array(mysqli_query($db, $cstr));

    if ($olinpro["saldo"] <= 0 && $olinpro["saldot"] <= 0 && $olcfg["GRUSES"] !== $olinpro["grupro"]) {
        $aret["erro"] = "96";
        $aret["cerro"] = _tr("Produto sem saldo no momento"); //. $olinpro["saldo"]." ". $olinpro["saldot"]." $nquantant"  ;
        echo json_encode($aret);
        return;
    }

    if ($nquant > $olinpro["saldot"] && $olcfg["GRUSES"] !== $olinpro["grupro"]) {
        $aret["erro"] = "96";
        $aret["cerro"] = _tr("Quantidade ultrapassa o saldo GERAL");
        echo json_encode($aret);
        return;
    }

    if (!$lorc) {
        if (mysqli_num_rows(mysqli_query($db, "select * from LOCAL_LOC WHERE IS_DELETED='N' AND LOCLOC=$nloja and proloc=$ncodigo")) == 0) {
            if ($lCfRdd) {
                $omed = new Mediator4("LOCAL.LOC", W_CRIAR, '', '', $db);
            } else {
                $omed = new Mediator3("LOCAL.LOC", W_CRIAR, '', '', $db);
            }
            $omed->aadd("locloc", $nloja);
            $omed->aadd("proloc", $ncodigo);
            if (!$omed->grava()) {
                $aret["erro"] = "97";
                $aret["cerro"] = "Erros adicionando registro LOCAL.LOC";
                echo json_encode($aret);
                return;
            }
        }

        mysqli_query($db, "update LOCAL_LOC SET QUALOC=QUALOC-$nquant+$nquantant,FPGLOC=FPGLOC+$nquant-$nquantant WHERE IS_DELETED='N' AND LOCLOC=$nloja AND PROLOC=$ncodigo");
        mysqli_query($db, "update PRODUTO_PRO set estoque=estoque-$nquant+$nquantant,fpgpro=fpgpro+$nquant-$nquantant WHERE IS_DELETED='N' AND CODPRO=$ncodigo");
    }
    if (mysqli_num_rows(mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo")) == 0) {
        mysqli_query($db, "insert tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set serie='$nserie',vendedor=$vendedor,codigo=$ncodigo,quant=$nquant-$nquantant,valor=$nvalor,autoriza='$nautoriza'");
    } else {
        mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set quant=quant+$nquant-$nquantant,autoriza='$nautoriza' where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo");
    }

//grade
    if (!$lorc) {
        $otab = mysqli_query($db, "select p.preco5,gp.codgpm from PRODUTO_PRO p , GRUPROMO_GPM gp
                where p.is_deleted='N' and p.codpro=$ncodigo
                and gp.is_deleted='N' and p.codpromo=gp.codgpm and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set($nloja,replace(gp.excljgpm,'-',','))
                ");
        if (mysqli_num_rows($otab) > 0) {
            $olin = mysqli_fetch_array($otab);
            mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set codpromo=" . $olin["codgpm"] . " where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo");
        }
        $cstr = "select gp.codgpm,gq.perqua1,gq.perqua2,gq.perqua3,gq.perqua4,gq.perqua5,gq.perqua6,gq.perqua7,gq.perqua8,gq.perqua9,gq.perqua10,gq.perqua11,gq.perqua12,gq.perqm10 as perqua13
                ,concat(if(gq.marca>0  ,'/MARCA','') 
                ,if(gq.grupo>0    ,'/GRUPO','') 
                ,if(gq.sgrupo>0   ,'/SUBGRUPO' ,'') 
                ,if(gq.produto>0  ,'/PRODUTO' ,'') 
                ,if(gq.gruesp>0  ,'/GRUESP' ,'') 
            ) as nome ";

        if (mysqli_num_rows(mysqli_query($db, "select * from ESTLJGRA_PRO WHERE IS_DELETED='N' AND LOJGRADE=$nloja and PROGRADE=$ncodigo AND SEQGRADE1=$nseq1 and SEQGRADE2=$nseq2")) == 0) {
            if ($lCfRdd) {
                $omed = new Mediator4("ESTLJGRA.PRO", W_CRIAR, '', '', $db);
            } else {
                $omed = new Mediator3("ESTLJGRA.PRO", W_CRIAR, '', '', $db);
            }
            $omed->aadd("LOJGRADE", $nloja);
            $omed->aadd("PROGRADE", $ncodigo);
            $omed->aadd("SEQGRADE1", $nseq1);
            $omed->aadd("SEQGRADE2", $nseq2);
            if (!$omed->grava()) {
                $aret["erro"] = "97";
                $aret["cerro"] = "Erros adicionando registro GRADE.LOC";
                echo json_encode($aret);
                return;
            }
        }


        mysqli_query($db, "update ESTLJGRA_PRO SET ESTOQUE=ESTOQUE-$nquant+$nquantant,FPGLOC=FPGLOC+$nquant-$nquantant WHERE IS_DELETED='N' AND LOJGRADE=$nloja AND PROGRADE=$ncodigo and seqgrade1=$nseq1 and seqgrade2=$nseq2");
        mysqli_query($db, "update ESTGRADE_PRO set estoque=estoque-$nquant+$nquantant,fpgpro=fpgpro+$nquant-$nquantant WHERE IS_DELETED='N' AND PROGRADE=$ncodigo and seqgrade1=$nseq1 and seqgrade2=$nseq2");
    }
    $otabgra = mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo and seq1='$nseq1' and seq2='$nseq2' ");
    if (mysqli_num_rows($otabgra) == 0) {
        $cstr = "insert tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra set serie='$nserie',vendedor=$vendedor,codigo=$ncodigo,quant=$nquant-$nquantant,seq1='$nseq1',seq2='$nseq2'";
        mysqli_query($db, $cstr);
    } else {
        mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra set quant=quant+$nquant-$nquantant where serie='$nserie' and vendedor=$vendedor and codigo=$ncodigo and seq1='$nseq1' and seq2='$nseq2'");
    }



//    echo mysqli_error($db);
    echo json_encode($aret);
    return;
}



$aret["erro"] = "98";
$aret["cerro"] = _tr("Erros de parâmetros");
echo json_encode($aret);
return;

function CalcIva($nProduto, $nValor) {
//a pedido do Abdel
    return array(0, 0, 0);
    $nGravada = 0;
    $nExenta = 0;
    $nIva = 0;
    $nAux = 0;
    $nDif = 0;
    global $db;
    global $lCfRdd;
    $otab = mysqli_query($db, "select IVA,DECRETO FROM PRODUTO_PRO WHERE IS_DELETED='N' AND CODPRO=$nProduto");
    $olin = mysqli_fetch_array($otab);

    if (!$olin["IVA"] || $olin["DECRETO"] != 'S') {
        return array(0, 0, 0);
    }
    $nIvaPer = $olin["IVA"];
    $nExenta = round(($nValor * 85 / 100) / 1.015, 4);

    $nAux = ($nValor * 15 / 100) / 1.015;
    $nAux = round($nAux + ($nAux * $nIvaPer / 100), 4);

    if ($nExenta + $nAux <> $nValor) {
        $nDif = $nValor - ($nExenta + $nAux);
        if ($nDif > 0) {
            $nAux = $nAux + $nDif;
        }
        if ($nDif < 0) {
            $nAux = $nAux - $nDif;
        }
    }

    $nGravada = $nAux;
    return array($nExenta, $nGravada, $nGravada - ($nGravada / (1 + ($nIvaPer / 100))));
}

function CalcPromoQua($acodigos, $nloja) {
// aCodigos:={{1234,1},{2231,10},{4534534,5}}
    global $db;
    global $lCfRdd;
    global $lweb;
    $aRet = array();
    $aPromo = array();
    define("G_P1", 1 - 1);
    define("G_P2", 2 - 1);
    define("G_P3", 3 - 1);
    define("G_P4", 4 - 1);
    define("G_P5", 5 - 1);
    define("G_P6", 6 - 1);
    define("G_P7", 7 - 1);
    define("G_P8", 8 - 1);
    define("G_P9", 9 - 1);
    define("G_P10", 10 - 1);
    define("G_P11", 11 - 1);
    define("G_P12", 12 - 1);
    define("G_P13", 13 - 1);
    define("G_COD", 14 - 1);
    define("G_NOM", 15 - 1);
    define("G_TIP", 16 - 1);
    define("G_PRO", 17 - 1);
    define("G_GRU", 18 - 1);
    define("G_MAR", 19 - 1);
    define("G_SGR", 20 - 1);
    define("G_ESP", 21 - 1);
    define("G_QUA", 22 - 1);
    define("G_PDT", 23 - 1);
    /*
      define("R_PRO", 1 - 1);
      define("R_QUA", 2 - 1);
      define("R_COD", 3 - 1);
      define("R_NOM", 4 - 1);
      define("R_QUAP", 5 - 1);
      define("R_DESC", 6 - 1);
      define("R_PROMO", 7 - 1);
     */
    $aRet = array();
    foreach ($acodigos as $value) {
        $aRet[] = array($value[0], $value[1], 0, "", 0.00, 0.00, false);
    }


    $cSql = "select gq.perqua1,gq.perqua2,gq.perqua3,gq.perqua4,gq.perqua5,gq.perqua6,gq.perqua7,gq.perqua8,gq.perqua9,gq.perqua10,gq.perqua11,gq.perqua12,gq.perqm10
    ,gp.codgpm
    ,concat(if(gq.marca>0  ,'/MARCA',''),if(gq.grupo>0    ,'/GRUPO',''),if(gq.sgrupo>0   ,'/SUBGRUPO' ,''),if(gq.produto>0  ,'/PRODUTO' ,''),if(gq.gruesp>0  ,'/GRUESP' ,'')) as nome 
    ,gp.tipogpm 
            ,gq.produto
            ,gq.grupo
            ,gq.marca
            ,gq.sgrupo
            ,gq.gruesp
             FROM GRUPROMO_GPM gp 
             inner join PROMOQUA_PRO gq on gq.is_deleted='N' and gq.grugpm=gp.codgpm 
             and gp.is_deleted='N' and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set($nloja,replace(gp.excljgpm,'-',',')) 
                 order by gp.inigpm
            ";

    $otable = mysqli_query($db, $cSql);
    $aPromo = array();
    while ($olinha = mysqli_fetch_row($otable)) {
        $aPromo[] = $olinha;
//                array($olinha[0], $olinha[1], $olinha[2], $olinha[3], $olinha[4], $olinha[5], $olinha[6], $olinha[7], $olinha[8], $olinha[9]
//            , $olinha[10], $olinha[11], $olinha[12], $olinha[13]+0, $olinha[14], $olinha[15], $olinha[16], $olinha[17], $olinha[18], $olinha[19]
//            , $olinha[20], $olinha[21], $olinha[22]);
    }
//  var_dump($aPromo);
//  echo " <br><br>";
//produto
    for ($i = 0; $i < count($aRet); $i++) {
        if ($aRet[$i][R_PROMO]) {
            continue;
        }
//$opro = mysqli_fetch_array(mysqli_query($db, "select GRUPRO,MARCPRO,SGRUPRO,GRUESP from PRODUTO_PRO where is_deleted='N' and codpro=" . $aRet[$i][R_PRO]));
        for ($k = 0; $k < count($aPromo); $k++) {
            if ($aPromo[$k][G_PRO] == $aRet[$i][R_PRO]) {
                $aPromo[$k][G_QUA] += $aRet[$i][R_QUA];
                $aPromo[$k][G_PDT][] = $i;
                $aRet[$i][R_PROMO] = true;
            }
        }
    }
//grupo,marca,subgrupo,grupoespecial
    for ($i = 0; $i < count($aRet); $i++) {
        if ($aRet[$i][R_PROMO]) {
            continue;
        }
        $opro = mysqli_fetch_array(mysqli_query($db, "select GRUPRO,MARCPRO,SGRUPRO,GRUESP from PRODUTO_PRO where is_deleted='N' and codpro=" . $aRet[$i][R_PRO]));
        for ($k = 0; $k < count($aPromo); $k++) {
            if ($aPromo[$k][G_PRO] != 0) {
                continue;
            }
            if (($aPromo[$k][G_GRU] == 0 || $aPromo[$k][G_GRU] == $opro["GRUPRO"]) &&
                    ($aPromo[$k][G_MAR] == 0 || $aPromo[$k][G_MAR] == $opro["MARCPRO"]) &&
                    ($aPromo[$k][G_SGR] == 0 || $aPromo[$k][G_SGR] == $opro["SGRUPRO"]) &&
                    ($aPromo[$k][G_ESP] == 0 || $aPromo[$k][G_ESP] == $opro["GRUESP"])) {
                $aPromo[$k][G_QUA] += $aRet[$i][R_QUA];
                $aPromo[$k][G_PDT][] = $i;
                $aRet[$i][R_PROMO] = true;
            }
        }
    }
    for ($i = 0; $i < count($aPromo); $i++) {
        if ($aPromo[$i][G_QUA] == 0) {
            continue;
        }
        for ($k = 0; $k < count($aPromo[$i][G_PDT]); $k++) {
            $nPos = $aPromo[$i][G_PDT][$k];
            $opro = mysqli_fetch_array(mysqli_query($db, "select PREVEN,PREMIN,PRECO3,PREATAC,NOMPRO AS NOME from PRODUTO_PRO where is_deleted='N' and codpro=" . $aRet[$nPos][R_PRO]));
            $aRet[$nPos][R_COD] = $aPromo[$i][G_COD];
            $aRet[$nPos][R_NOM] = $aPromo[$i][G_NOM];

            if ($aPromo[$i][G_TIP] == "1") {
                $aRet[$nPos][R_QUAP] = $opro["PREVEN"] + 0;
            } elseif ($aPromo[$i][G_TIP] == "2") {
                $aRet[$nPos][R_QUAP] = $opro["PRECO3"] + 0;
            } elseif ($aPromo[$i][G_TIP] == "3") {
                $aRet[$nPos][R_QUAP] = $opro["PREMIN"] + 0;
            } else {
                $aRet[$nPos][R_QUAP] = $opro["PREATAC"] + 0;
            }
            $nAux = ($aPromo[$i][G_QUA] > 12 ? 13 : $aPromo[$i][G_QUA]) - 1;
            $aRet[$nPos][R_DESC] = $aPromo[$i][$nAux] + 0;
        }
    }


    return $aRet;
}

/*
  function VeListaGuiaCli($nCliente,&$cRefGuia,&$nRefGuia,&$nRefLista) {
  global $db;
  $nRefGuia=0;
  $cRefGuia='';
  $nRefLista=0;

  if (!$nCliente) {
  return 0;
  }
  $olcli = mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI WHERE IS_DELETED='N' AND CODCLI=$nCliente"));
  if (!$olcli) {
  return 0;
  }

  $crg = $olcli["RUCCLI"];
  $crg = LimpaRg($crg);

  $nDiasAnteriores = mysqli_fetch_row(mysqli_query($db,"select guia_d_ant from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];
  $nDiasPosteriores = mysqli_fetch_row(mysqli_query($db,"select guia_d_pos from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];

  $nDiasAnteriores += 0;
  $nDiasPosteriores += 0;
  $dData = mysqli_fetch_row(mysqli_query($db,"select current_date()"))[0];

  $cRefErro = "";
  $nRefGuia = 0;
  $nRefLista = 0;

  $nCliente = $olnot["CLIESAI"];


  $cRg = strtoupper(LimpaRg($olcli["RUCCLI"]));

  if (!$cRg) {
  $cRefErro = "Cliente sem RUC/RG";
  return 0;
  }

  $dIni = date2unix($dData, "00:00:00", TRUE) - ($nDiasAnteriores * 24 * 60 * 60);
  $dFim = date2unix($dData, "23:59:59", TRUE) + ($nDiasPosteriores * 24 * 60 * 60);

  $cSql = "Select d.rg,d.nome,d.codigo AS lista,l.guia,d.recno as reg,d.presente
  from LISTADET_GUI d
  inner join LISTA_GUI l ON l.is_deleted='N' and l.codigo=d.codigo
  where d.is_deleted='N' and d.rg='$cRg'
  and l.data>=$dIni and l.data<=$dFim
  order by d.data";

  $otab = mysqli_query($db, $cSql);
  if (mysqli_num_rows($otab) == 0) {
  $cRefErro = "Nada presente na lista";
  return 0;
  }
  $olis = mysqli_fetch_array($otab);


  $nRefGuia = $olis["guia"];
  $nRefLista = $olis["lista"];

  $cRefGuia= mysqli_fetch_row(mysqli_query($db, "select nomfor from FORNEC_FOR where is_deleted='N' and  codfor=$nRefGuia"))[0];


  return $nRefGuia;

  }
 */

function VeListaGuia($nNota, &$cRefErro = '', &$nRefGuia = 0, &$nRefLista = 0) {
    global $db;
    global $lCfRdd;
    global $ccommit_web;
    global $lweb;
    $nDiasAnteriores = mysqli_fetch_row(mysqli_query($db, "select guia_d_ant from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];
    $nDiasPosteriores = mysqli_fetch_row(mysqli_query($db, "select guia_d_pos from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];

    $nDiasAnteriores += 0;
    $nDiasPosteriores += 0;
    $dData = mysqli_fetch_row(mysqli_query($db, "select current_date()"))[0];

    if (!$nNota) {
        $cRefErro = _tr("Nota não passada");
        return -1;
    }

    $cRefErro = "";
    $nRefGuia = 0;
    $nRefLista = 0;

    $olnot = mysqli_fetch_array(mysqli_query($db, "select * from SAIDAS_SAI WHERE RECNO=$nNota"));
    if (!$olnot || $olnot["IS_DELETED"] == 'Y') {
        $cRefErro = _tr("Nota Deletada");
        return -1;
    }
    $nCliente = $olnot["CLIESAI"];

    $olcli = mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI WHERE IS_DELETED='N' AND CODCLI=$nCliente"));

    $cRg = strtoupper(LimpaRg($olcli["RUCCLI"]));

    if (!$cRg) {
        $cRefErro = _tr("Cliente sem RUC/RG");
        return -1;
    }

    $dIni = date2unix($dData, "00:00:00", TRUE) - ($nDiasAnteriores * 24 * 60 * 60);
    $dFim = date2unix($dData, "23:59:59", TRUE) + ($nDiasPosteriores * 24 * 60 * 60);

    $cSql = "Select d.rg,d.nome,d.codigo AS lista,l.guia,d.recno as reg,d.presente 
     from LISTADET_GUI d 
     inner join LISTA_GUI l ON l.is_deleted='N' and l.codigo=d.codigo 
     where d.is_deleted='N' and d.rg='$cRg' 
     and l.data>=$dIni and l.data<=$dFim
     order by d.data";

    $otab = mysqli_query($db, $cSql);
    if (mysqli_num_rows($otab) == 0) {
        $cRefErro = _tr("Nada presente na lista");
        return -1;
    }
    $olis = mysqli_fetch_array($otab);

    $nRefGuia = $olis["guia"];
    $nRefLista = $olis["lista"];

    if ($olis["presente"] !== 'Y') {
        /*
          (cDet)->(DBGoTo((cSql)->reg),RegLock())
          (cLis)->(DBSeek((cDet)->codigo))
          (cDet)->codcli:=ncliente
          IF Empty((cDet)->presente)
          AbreArq("entrada.ent",cEnt,FALSE,FALSE,"idx")
          AbreArq("duplicat.for",cDup,FALSE,FALSE,"idx")
          (cEnt)->(ApLock())
          (cEnt)->notaent        :=(cDet)->(RecNo())+7000000
          (cEnt)->fornent        :=(cLis)->guia
          (cEnt)->valpent        :=selval("select guiapremio from CONFIG_PFC WHERE RECNO=1","N")
          (cEnt)->ATUAENT        :="N" ///???
          (cEnt)->baseent        :=1
          (cEnt)->cambent        :=1
          (cEnt)->cxunent        :="C" ///???
          (cEnt)->emisent        :=meddate()
          (cEnt)->entrent        :=meddate()
          (cEnt)->lojaent        :=1 ///???
          (cEnt)->moeent         :=1
          (cEnt)->nrdup          :=1
          (cEnt)->obsent         :="Premio Lista Guia "+mytrim((cLis)->guia)+" - RG Cliente : "+(cDet)->rg
          (cEnt)->sitent         :="S" ///???
          (cEnt)->valdesm        :=(cEnt)->valpent
          (cEnt)->vencto         :=meddate()+1
          (cEnt)->viprent        :="P" ///???
          (cent)->despesa        :="S"

          (cDup)->(ApLock())
          (cDup)->numedupf       :=Str((cent)->notaent,7,0)+" 1"
          (cDup)->valodupf       :=(cent)->valpent
          (cDup)->vencdupf       :=(cent)->vencto
          (cDup)->forndupf       :=(cEnt)->fornent
          (cDup)->obsedupf       :=(cent)->obsent
          (cDup)->moedupf        :=(cent)->moeent
          (cDup)->cambdupf       :=(cEnt)->cambent
          (cDup)->basedupf       :=(cEnt)->baseent
          (cDup)->despdupf       :="S" ///???
          (cDup)->desmdupf       :="S" ///???
          (cDup)->AUTZPAG        :=1

          (cDup)->(DBCommit(),DBCloseArea())
          (cEnt)->(DBCommit(),DBCloseArea())
          (cDet)->presente:=true
          (cDet)->DATA:=date2unix()
          (cDet)->premio_reg:=(cdup)->(RecNo())
          (cDet)->premio_mod:=1
          ENDIF
         */
    }


    $cStr = "select convert(sum((s.cumoe*s.qusai*g.per_guia/100)),decimal(13,2)) as comissao 
                ,convert(sum((s.cumoe*s.qusai*g.per_guia/100))/n.valosai*100,decimal(13,2)) as pcom 
                from PROSAI_SAI s 
                inner join SAIDAS_SAI     n on n.is_deleted='N' and n.recno =s.nfsai 
                inner join PRODUTO_PRO     p on p.is_deleted='N' and p.codpro=s.prsai 
                inner join GRUPO_GRU     g on g.is_deleted='N' and g.codgru=p.grupro 
                where s.is_deleted='N' and s.nfsai=$nNota ";
    $otcom = mysqli_query($db, $cStr);
    if (mysqli_num_rows($otcom) == 0) {
        $cRefErro = _tr("Sem comissão a lançar");
        return -1;
    }

    $olcom = mysqli_fetch_array($otcom);
    if ($olcom["comissao"] == 0 && $olcom["pcom"] == 0) {
        $cRefErro = _tr("Sem comissão a lançar");
        return -1;
    }

    mysqli_query($db, "update SAIDAS_SAI set guiasai=$nRefGuia ,valcomgui=" . $olcom["comissao"] . ",comgui=" . $olcom["pcom"] . " where recno=$nNota");

    /*

      aComissao:=CalcComissaoGuiaNota(nnota,(cLis)->guia)
      IF !empty(aComissao) .AND. selval("select nota from NOTA_GUI where is_deleted='N' and nota="+AsSql(nNota)+" and codigo="+AsSql((cDet)->codigo),"N")==0
      (cNot)->(DBGoTo((cNot)->(RecNo())))
      (cDet)->venda   +=(cNot)->valosai
      (cDet)->comissao+=(cNot)->valcomgui
      (cNtg)->(ApLock())
      (cNtg)->codigo  :=(cDet)->codigo
      (cNtg)->lista   :=(cDet)->(RecNo())
      (cNtg)->nota    :=nNota
      (cNtg)->comissao:=(cNot)->valcomgui

      ENDIF

      (cDet)->(DBCommit())
      (cNtg)->(DBCommit())

      (cSql)->(DBCloseArea())

      oArq:close()
     */
    return $nRefGuia;
}

function PEDE_AUT_TUDO($nvendedor, $apro, &$wvalven, &$wvalmin, &$cerro = '') {
    global $db;
    global $lCfRdd;
    global $nvendedor;
    global $nserie;
    global $cprecoa;
    global $cprecob;
    global $cprecoc;
    global $cprecot;
    global $ccommit_web;
    global $lweb;

    $cArq = "AUF_" . (1000 + $nvendedor);
    /*
      $olcfg=mysqli_fetch_array(mysqli_query($db,"select * from CONFIG"));
      $nindex=1+($olcfg["PERAUM_TJ"]/100);
      if ($nindex>1){
      $nindex="*".$nindex;
      }else{
      $nindex="";
      }
     */
    $cSql = "select if(f.PERAUM_TJ=0 or c.PAISCLI!=1 or c.regicli!='',0,f.PERAUM_TJ) AS indice from CLIENTE_CLI c 
        inner join tablet" . $lweb . "_cab t on t.vendedor=$nvendedor and t.serie=$nserie and t.cliente=c.codcli
        inner join CONFIG f on f.recno=1
        where c.is_deleted='N' AND c.codcli!=0
            ";

    $nindex = mysqli_fetch_row(mysqli_query($db, $cSql))[0];

    if ($nindex > 0) {
        $nindex = "*" . (1 + ($nindex / 100));
    } else {
        $nindex = "";
    }


    mysqli_query($db, "drop table if exists $cArq");
    mysqli_query($db, "DELETE FROM CLP_TABLES WHERE TAB_CLP_NAME='$cArq'");
    mysqli_query($db, "DELETE FROM CLP_TAB_COLS WHERE TAB_CLP_NAME='$cArq'");
    mysqli_query($db, "INSERT INTO `CLP_TABLES` VALUES ('$cArq','N','1','$cArq',NULL,NULL,'1')");
/*
+--------------+------------+---------+----------+----------+--------------+-------------+-------------+-------------+--------------+-------------+--------------+-------------+-------------+---------+---------+----------+----------+------------+--------------+-------------+
| TAB_CLP_NAME | COL_NAME   | COL_ORD | TAB_NAME | COL_TYPE | COL_CLP_TYPE | COL_CLP_LEN | COL_CLP_DEC | COL_UNICODE | BAG_CLP_NAME | BAG_CLP_ORD | IND_CLP_NAME | IND_CLP_EXP | IND_CLP_FOR | IND_EXP | IND_FOR | IND_TYPE | IND_NAME | IND_IN_USE | IND_EXP_TYPE | IND_EXP_LEN |
+--------------+------------+---------+----------+----------+--------------+-------------+-------------+-------------+--------------+-------------+--------------+-------------+-------------+---------+---------+----------+----------+------------+--------------+-------------+
| AUF_78       | ATATPO     |       1 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | AUTZ_PRECO |       2 | AUF_78   |        0 |            2 |           4 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | AUTZ_QUANT |       3 | AUF_78   |        0 |            2 |           4 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | CLIETPO    |       4 | AUF_78   |        0 |            2 |           7 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | CODTPO     |       5 | AUF_78   |        0 |            2 |           9 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | CUSTPO     |       6 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | HORAAUTP   |       7 | AUF_78   |        0 |            1 |           8 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | IS_DELETED |   10001 | AUF_78   |        2 |            4 |        NULL |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | IVATPO     |       8 | AUF_78   |        0 |            1 |           1 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | KITTPO     |       9 | AUF_78   |        0 |            1 |           1 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | LOJATPO    |      10 | AUF_78   |        0 |            2 |           5 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | MCUSTPO    |      11 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | MINTPO     |      12 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | MOETPO     |      13 | AUF_78   |        0 |            2 |           4 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | NOMTPO     |      14 | AUF_78   |        0 |            1 |          70 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | PRE_LIBANT |      15 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | PRE_LIBER  |      16 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | PRE_SUGER  |      17 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | PROMTPO    |      18 | AUF_78   |        0 |            1 |           1 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | QUATPO     |      19 | AUF_78   |        0 |         2048 |          15 |           3 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | RECNO      |   10000 | AUF_78   |        1 |            2 |          10 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | UCUSTPO    |      20 | AUF_78   |        0 |         2048 |          15 |           4 |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
| AUF_78       | VENDETPO   |      21 | AUF_78   |        0 |            2 |           4 |        NULL |        NULL | NULL         |        NULL | NULL         | NULL        | NULL        | NULL    | NULL    |     NULL | NULL     | NULL       | NULL         |        NULL |
+--------------+------------+---------+----------+----------+--------------+-------------+-------------+-------------+--------------+-------------+--------------+-------------+-------------+---------+---------+----------+----------+------------+--------------+-------------+
*/
    mysqli_query($db, "INSERT INTO `CLP_TAB_COLS` VALUES 
        ('$cArq','ATATPO'       ,'1','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','AUTZ_PRECO'   ,'2','$cArq','0','2','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','AUTZ_QUANT'   ,'3','$cArq','0','2','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','CLIETPO'      ,'4','$cArq','0','2','7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','CODTPO'       ,'5','$cArq','0','2','9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','CUSTPO'       ,'6','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','HORAAUTP'     ,'7','$cArq','0','1','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','IS_DELETED'   ,'10001','$cArq','2','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','IVATPO'       ,'8','$cArq','0','1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','KITTPO'       ,'9','$cArq','0','1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','LOJATPO'      ,'10','$cArq','0','2','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','MCUSTPO'      ,'11','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','MINTPO'       ,'12','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','MOETPO'       ,'13','$cArq','0','2','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','NOMTPO'       ,'14','$cArq','0','1','70',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','PRE_LIBANT'   ,'15','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','PRE_LIBER'    ,'16','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','PRE_SUGER'    ,'17','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','PROMOTPO'     ,'18','$cArq','0','1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','QUATPO'       ,'19','$cArq','0','2048','15','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','RECNO'        ,'10000','$cArq','1','2','10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','UCUSTPO'      ,'20','$cArq','0','2048','15','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
        ('$cArq','VENDETPO'     ,'21','$cArq','0','2','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)");
    mysqli_query($db, "CREATE TABLE `$cArq` (`RECNO` int(10) NOT NULL auto_increment,
`IS_DELETED` char(1) NOT NULL DEFAULT 'N',
`ATATPO` decimal(15,4) DEFAULT '0.0000',
`AUTZ_PRECO` decimal(4,0) DEFAULT '0',
`AUTZ_QUANT` decimal(4,0) DEFAULT '0',
`CLIETPO` decimal(7,0) DEFAULT '0',
`CODTPO` decimal(9,0) DEFAULT '0',
`CUSTPO` decimal(15,4) DEFAULT '0.0000',
`HORAAUTP` VARCHAR(8) DEFAULT ' ',
`IVATPO` varchar(1) DEFAULT ' ',
`KITTPO` varchar(1) DEFAULT ' ',
`LOJATPO` decimal(5) DEFAULT '0',
`MCUSTPO` decimal(15,4) DEFAULT '0.0000',
`MINTPO` decimal(15,4) DEFAULT '0.0000',
`MOETPO` decimal(4,0) DEFAULT '0',
`NOMTPO` varchar(70) DEFAULT ' ',
`PRE_LIBANT` decimal(15,4) DEFAULT '0.0000',
`PRE_LIBER` decimal(15,4) DEFAULT '0.0000',
`PRE_SUGER` decimal(15,4) DEFAULT '0.0000',
`PROMOTPO` VARCHAR(1) DEFAULT ' ',
`QUATPO` decimal(15,3) DEFAULT '0.000',
`UCUSTPO` decimal(15,4) DEFAULT '0.0000',
`VENDETPO` decimal(4,0) DEFAULT '0',
PRIMARY KEY (`RECNO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1");

    $cstr = "select 
 tp.codigo
,p.nomelong as nome
,p.$cprecoc$nindex as premin
,p.preatac$nindex as preatac
,p.ultcus$nindex as ultcus
,p.cusmed$nindex as cusmed
,p.iva

,c.paiscli
,cf.ivamas
,c.regicli
,p.decreto
,c.exen_cli

,cf.nome_3dec
,cf.arrpre
,cf.iva_distr
,cf.connot
,cf.ad_ivadis
,cf.ata_cus

,tp.quant
,tp.valor
,tp.kit
,tp.autz_preco
,tp.autz_quant

,t.moeda
,t.cliente
,e.custo_ata as pre_loj
,e.codemp

from tablet" . $lweb . "_cab t
inner join EMPRESA_EMP e on e.is_deleted='N' and e.codemp=t.loja
inner join tablet" . $lweb . "_pro tp on tp.vendedor=t.vendedor and t.serie=$nserie
inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=tp.codigo
inner join CONFIG cf on cf.recno=1
inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=t.cliente AND c.codcli!=0

where t.vendedor=$nvendedor and t.serie=$nserie";

    $otab = mysqli_query($db, $cstr);
    $nrecno = 0;
    $wvalven = 0;
    $wvalmin = 0;

    while ($olin = mysqli_fetch_object($otab)) {
        $nrecno++;
        $wpremin = $olin->premin;
        $wataca = $olin->preatac;

        $w_iva = "N";
        $iva1_5 = $olin->ad_ivadis == "S" ? 1.015 : 1;

//    IF ((M->ESTATUS=="S" .AND. M->FAT<>"F") .OR. (M->ESTATUS=="N" .AND. M->CONNOT=="S")) .AND. CLI->PAISCLI==1 .AND. M->IVAMAS=="S" .AND. Empty(CLI->REGICLI) .AND. PRO->DECRETO=="S" .AND. CLI->EXEN_CLI<>"S"
        if ($olin->connot == "S" && $olin->paiscli == 1 && $olin->ivamas == "S" && trim($olin->regicli) == '' && $olin->decreto == "S" && $olin->exen_cli !== "S") {
            $wpremin = round($wpremin * (1 + ($olin->iva / 100)), 2);
            $wataca = round($wataca * (1 + ($olin->iva / 100)), 2);
            $w_iva = "S";
        }

// PARA CLIENTES DISTRIBUIRODES QUE ESTAO NO NOVO CALCULO DO 1.5%
//    IF M->IVA_DISTR=="S" .AND. !Empty(CLI->REGICLI) .AND. PRO->DECRETO=="S" .AND. CLI->PAISCLI==1 .AND. PRO->IVA<>0 .AND. CLI->EXEN_CLI<>"S"
        if ($olin->iva_distr == "S" && trim($olin->regicli) && $olin->decreto && $olin->paiscli == 1 && $olin->iva !== 0 && $olin->exen_cli !== "S") {
            $wpremin = round($wpremin * $iva1_5, 2);
            $wataca = round($wataca * $iva1_5, 2);
            $w_iva = "S";
        }

        $acampos = array();
        $acampos[] = array("CODTPO", $olin->codigo, false);
        $acampos[] = array("NOMTPO", "'" . $olin->nome . "'", true);
        $acampos[] = array("IVATPO", "'" . $w_iva . "'", false);
        $acampos[] = array("QUATPO", $olin->quant, false);
        $acampos[] = array("CUSTPO", $olin->valor, false);
        $acampos[] = array("MINTPO", $wpremin, false);
        $acampos[] = array("LOJATPO", $olin->codemp, false);

        if ($olin->ata_cus == "S" && $olin->pre_loj !== 0 && $olin->preatac !== 0) {  // SE O TERMINAL ESTIVER COMO PARA TER PRECO DE ATACADO
            $acampos[] = array("UCUSTPO", $olin->preatac, false);
            $acampos[] = array("MCUSTPO", $olin->preatac, false);
            $acampos[] = array("ATATPO", 0, false);
        } else {
            $acampos[] = array("UCUSTPO", $olin->ultcus, false);
            $acampos[] = array("MCUSTPO", $olin->cusmed, false);
            $acampos[] = array("ATATPO", $wataca, false);
        }

//_FIELD->T_AU->UCUSTPO:=(PRO->ULTCUS/tipcam[1]*tipcam[tmp1->moedtemp]) COMENTEI EM 14-09-2018 PASSEI PRAS LINHAS ACIMA
//_FIELD->T_AU->MCUSTPO:=(PRO->CUSMED/tipcam[1]*tipcam[tmp1->moedtemp]) COMENTEI EM 14-09-2018
        $nsol = 0;
        foreach ($apro as $value1) {
            if ($value1[0] == $olin->codigo) {
                $nsol = $value1[1];
                break;
            }
        }
        $acampos[] = array("PRE_SUGER", $nsol, false);
//preço autorizado anteriormente
        if ($olin->autz_preco !== 0) {
            $acampos[] = array("PRE_LIBER", $olin->valor);
        }

        $acampos[] = array("PRE_LIBANT", $olin->valor);

        $acampos[] = array("KITTPO", $olin->kit ? "'S'" : "'N'");
        $acampos[] = array("AUTZ_PRECO", $olin->autz_preco);
        $acampos[] = array("AUTZ_QUANT", $olin->autz_quant);
        $acampos[] = array("MOETPO", $olin->moeda);
        $acampos[] = array("CLIETPO", $olin->cliente);
        $acampos[] = array("VENDETPO", $nvendedor);

        $cstr = "insert $cArq set recno=$nrecno";
        foreach ($acampos as $value) {
            $cstr .= "," . $value[0] . "=" . $value[1];
        }
        mysqli_query($db, $cstr);
        $wvalven += ($olin->quant * $olin->valor);
        $wvalmin += ($olin->quant * $wpremin);
    }

    if ($lCfRdd) {
        //$omed = new Mediator4($cArq, W_CRIAR);
    } else {
        $omed = new Mediator3($cArq, W_REFRESH);
        return $omed->grava();
    }
}

function AtuaComis($nnota) {
    global $db;
    global $lCfRdd;
    global $lweb;
    $WVEN = 0;
    $olsai = mysqli_fetch_array(mysqli_query($db, "select * from SAIDAS_SAI WHERE IS_DELETED='N' AND RECNO=$nnota"));
    $otpro = mysqli_query($db, "select * from PROSAI_SAI WHERE IS_DELETED='N' AND NFSAI=$nnota");
    $ocfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG WHERE RECNO=1 "));
    $omoe = mysqli_fetch_array(mysqli_query($db, "select * from CAMBIO_NOM WHERE RECNO=1"));

    while ($olpro = mysqli_fetch_array($otpro)) {
        $opro = mysqli_fetch_array(mysqli_query($db, "select * from PRODUTO_PRO WHERE IS_DELETED='N' AND CODPRO=" . $olpro["PRSAI"]));
        if ($olsai["DESC_PRO"] !== "S") {
            $WVEN = ( $olsai["CXUNSAI"] == 'U' ? $olpro["CUSAI"] * $opro["QUACAX"] : $olpro["CUSAI"] ) * ( $olsai["DESCO"] == 0 && $olsai["DESCTOT"] == 0 && $olsai["DESCREC"] == 0 ? 1 : 1 -
                    ( ( $ocfg["DESPROD"] == 'S' ? $olsai["DESCREC"] : ( $olsai["DESCTOT"] == 0 ? $olsai["DESCO"] : $olsai["DESCTOT"] ) ) / 100 ) );
        } else {
            $WVEN = ($olsai["CXUNSAI"] == 'U' ? $olpro["CUSAI"] * $opro["QUACAX"] : $olpro["CUSAI"] ) * (1 - ($olpro["PERDESC"] / 100));
        }

        if ($omoe["DECI" . $olsai["MOEDA"]] == "N") {
            $WVEN = Round($WVEN, 3) + 0.005;
        }
        $acampospro = array();
        if ($WVEN >= $opro["PREVEN"]) {
            $acampospro["COMSAI"] = $opro["ACIVEN"];
            $acampospro["CLASPRE"] = 6;
        }

        if ($WVEN >= $opro["PRECO3"] && $WVEN < $opro["PREVEN"]) {
            $acampospro["COMSAI"] = $opro["ABAVEN"];
            $acampospro["CLASPRE"] = 5;
        }

        if ($WVEN >= $opro["PREMIN"] && $WVEN < $opro["PRECO3"]) {
            $acampospro["COMSAI"] = $opro["ABA3"];
            $acampospro["CLASPRE"] = 4;
        }

        if ($WVEN >= $opro["PREATAC"] && $WVEN < $opro["PREMIN"]) {
            $acampospro["COMSAI"] = $opro["ABAMIN"];
            $acampospro["CLASPRE"] = 3;
        }

        if ($ocfg["IGNOCUST"] == "N" && $WVEN >= ( $opro["CUSMED"] == 0 ? $opro["ULTCUS"] : $opro["CUSMED"] ) && $WVEN < $opro["PREATAC"]) {
            $acampospro["COMSAI"] = $opro["ABAATA"];
            $acampospro["CLASPRE"] = 2;
        }

        if ($ocfg["IGNOCUST"] == "N" && $WVEN < ( $opro["CUSMED"] == 0 ? $opro["ULTCUS"] : $opro["CUSMED"] )) {
            $acampospro["COMSAI"] = $opro["ABACUS"];
            $acampospro["CLASPRE"] = 1;
        }

// normal sem a opcao do ignocus  -- ate aqui


        if ($ocfg["IGNOCUST"] == "S" && $WVEN < $opro["PREATAC"]) {
            $acampospro["COMSAI"] = $opro["ABAATA"];
            $acampospro["CLASPRE"] = 2;
        }
        $cstr = "update PROSAI_SAI SET IS_DELETED=IS_DELETED";
        foreach ($acampospro as $key => $value) {
            $cstr .= ",$key='$value'";
        }
        $cstr .= " where recno=" . $olpro["RECNO"];
        mysqli_query($db, $cstr);
    }
    return;
}

function ImprimeSeparacaoBema($nnota, $nimp = 0, $cnomeimp = '', &$creferro) { //apenas CecWeb
    global $db;
    global $lCfRdd;
    global $vendedor;
    global $lweb;

    $aimp = [];
    $olcfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIGVD_WEB WHERE VENDEDOR=$vendedor"));
    $cterminal = $olcfg["TERMINAL"];
    $aaux = explode("-", trim($olcfg["PACO_IMP"]));
    foreach ($aaux as $value) {
        $aaux1 = explode(",", $value);
        $aimp[$aaux1[0]] = [$aaux1[1], strtoupper(trim($aaux1[2]))];
    }
    $creferro = "";

    $csql = "select c.codcli as cliente,c.nomcli as ccliente,c.endcli as endereco,c.cidcli as cidade,c.ruccli as identidade,if(c.paiscli!=1,'',c.regicli) as regicli
    ,n.datasai as data,n.horasai as hora,n.termsai as terminal,n.nomger as nomegeral,n.endger as enderecogeral,n.clist1,n.rucger as rucgeral,if(n.tiposai='P' and n.vencsai>'1000-01-01',n.vencsai,'') as vencimento,n.tiposai,n.operec,n.observ
    ,v.codven as vendedor,v.nomven as cvendedor
    ,l.codemp as empresa,l.nomemp as cempresa,if(l.pacoemp,l.pacoemp,p.pacote) as pacote,l.entrega
    ,p.codpro as produto,p.nomelong as cproduto
    ,s.qusai as quant
    from SAIDAS_SAI n
    inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai
    inner join VENDEDOR_VEN v on v.is_deleted='N' and v.codven=n.vendsai
    inner join EMPRESA_EMP l on l.is_deleted='N' and l.codemp=n.lojasai
    inner join PROSAI_SAI s on s.is_deleted='N' and s.nfsai=n.notasai
    inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai
    where n.notasai=$nnota
    ";
    $olnot = mysqli_fetch_array(mysqli_query($db, $csql . " limit 1"));

    if (!$cnomeimp && $aimp[$olnot["pacote"]]) {
        $cnomeimp = $aimp[$olnot["pacote"]][1];
    }
    if (!$nimp && $aimp[$olnot["pacote"]]) {
        $nimp = $aimp[$olnot["pacote"]][0];
    }
    $lepson = !(strpos(strtoupper($cnomeimp), "EPSON") === false);
    if ($lepson) {
        define("P_INIT", Chr(27) . "@");
        define("P_NEG", Chr(27) . "E" . "1");
        define("P_DNEG", Chr(27) . "E" . "0");
        define("P_DOUBLE", chr(29) . "!" . chr(48));
        define("P_DDOUBLE", chr(29) . "!" . chr(0));
        define("P_EXP", chr(29) . "!" . chr(16));
        define("P_DEXP", chr(29) . "!" . chr(0));
        define("P_CR", chr(13) . chr(10));
        define("P_CORTE_TOT", Chr(27) . "i");
        define("P_CORTE_PAR", Chr(27) . "m");
    } else {
        define("P_INIT", Chr(29) . Chr(249) . Chr(53) . Chr(0) . Chr(27) . "@");
        define("P_NEG", Chr(27) . "E");
        define("P_DNEG", Chr(27) . "F");
        define("P_DOUBLE", Chr(27) . Chr(100) . Chr(1));
        define("P_DDOUBLE", Chr(27) . Chr(100) . Chr(0));
        define("P_EXP", chr(14));
        define("P_DEXP", chr(20));
        define("P_CR", chr(13) . chr(10));
        define("P_CORTE_TOT", Chr(27) . "i");
        define("P_CORTE_PAR", Chr(27) . "m");
    }

    $cimp = P_INIT;
    $cimp .= P_NEG . P_DOUBLE . "*SEPARACAO*" . P_DDOUBLE . P_CR;
    $cimp .= str_repeat("-", 48) . P_CR;

    $cimp .= P_NEG . padc($olnot["cempresa"], 48) . P_CR;

    if ($olnot["entrega"]) {
        $cimp .= P_NEG . PadC(trim($olnot["entrega"]), 24) . P_DNEG . P_CR;
    }

    $cimp .= P_CR . str_repeat("=", 48) . P_CR;
    $cimp .= sql2data($olnot["data"]) . " " . $olnot["hora"] . " Pedido: " . P_EXP . P_NEG . $nnota . "-" . digito($nnota) . P_DNEG . P_DEXP . P_CR;
    $cimp .= padr("Cli:" . P_NEG . $olnot["cliente"] . "-" . $olnot["ccliente"], 48) . P_DNEG . P_CR;
    if ($olnot["clist1"]) {
        $olcli = mysqli_fetch_row(mysqli_query($db, "select codcli,nomcli from CLIENTE_CLI where is_deleted='N' and codcli=" . $olnot["cliente"]));
        $cimp .= padr("Cli Ref:" . P_NEG . $olcli[0] . "-" . $olcli[1], 48) . P_DNEG . P_CR;
    }
    $cimp .= padr("Ven:" . P_NEG . $olnot["vendedor"] . "-" . $olnot["cvendedor"], 29) . "  Term: " . $cterminal . P_DNEG . P_CR;

    $cimp .= padr("End:" . P_NEG . ($olnot["nomegeral"] ? $olnot["enderecogeral"] : $olnot["endereco"]), 48) . P_DNEG . P_CR;
    $cimp .= padr("Cid:" . P_NEG . $olnot["cidade"], 48) . P_DNEG . P_CR;
    $cimp .= padr("Ruc/Rg:" . P_NEG . ($olnot["rucgeral"] ? $olnot["rucgeral"] : $olnot["identidade"]), 48) . P_DNEG . P_CR;

    if (trim($olnot["regicli"])) {
        $cimp .= padr("Reg.Distribuidor:" . P_NEG . $olnot["regicli"], 48) . P_DNEG . P_CR;
    }
    if ($olnot["vencimento"]) {
        $cimp .= padr("Vencimento.:" . P_NEG . sql2data($olnot["vencimento"]), 48) . P_DNEG . P_CR;
    }

    $cimp .= padr("Cond. Pgto.:" . P_NEG . ($olnot["tiposai"] == "P" ? "Prazo" : ($olnot["tiposai"] == "V" ? "Vista" : "Ajuste")) . "   Oper:" . $olnot["operec"], 48) . P_DNEG . P_CR;

    if (trim($olnot["observ"])) {
        $cimp = "Obs:" . P_NEG . substr($olnot["observ"], 0, 44) . P_DNEG . P_CR;
        for ($i = 4; $i < strlen($olnot["observ"]); $i += 44) {
            $cimp = "    " . P_NEG . substr($olnot["observ"], $i, 44) . P_DNEG . P_CR;
        }
    }

    $cimp .= str_repeat("=", 48) . P_CR;
    $cimp .= P_NEG . " Quant  Cod Pro / Nome do Produto " . P_DNEG . P_CR;

    $nitens = 0;

    $otpro = mysqli_query($db, $csql);
    while ($olpro = mysqli_fetch_array($otpro)) {
        $cimp .= padl(floor($olpro["quant"]), 6) . " " . padl($olpro["produto"] . "-" . digito($olpro["produto"]), 10) . P_CR .
                substr($olpro["cproduto"], 0, 48) . P_CR;
        $nitens += $olpro["quant"];
    }
    $cimp .= str_repeat("-", 48) . P_CR;
    $cimp .= "Total Geral: " . P_DOUBLE . P_NEG . "*" . $nitens . "*" . P_DNEG . P_DDOUBLE . P_CR;
    $cimp .= str_repeat("-", 48) . P_CR;
    $cimp .= P_NEG . Padr("** NAO USAR ESTE DOCUMENTO PARA ENTREGAR **", 48) . P_CR;
    $cimp .= padr("** SOMENTE <<SEPARACAO>>  **", 48) . P_CR;
    $cimp .= P_CR . P_CR . P_CR . P_CR . P_CR . P_CORTE_TOT;

    if ($lCfRdd) {
        $omedn = new Mediator4("LISTA.IMP", W_CRIAR_DEL, '', '', $db);
    } else {
        $omedn = new Mediator3("LISTA.IMP", W_CRIAR_DEL, '', '', $db);
    }
    $omedn->aadd("DATA", Date2Unix());
    $omedn->aadd("TEXTO", $cimp);
    $omedn->aadd("IMPRESSORA", $nimp);
    $omedn->aadd("COPIAS", 1);
    $omedn->aadd("TERMINAL", $cterminal);
    $omedn->aadd("RAW", TRUE);
    if (!$omedn->grava()) {
        $creferro = "Erro gravando nota a imprimir";
        return;
    }
    mysqli_query($db, "update LISTA_IMP SET is_deleted='N' where recno=" . $omedn->nrecno);
    return;
}
