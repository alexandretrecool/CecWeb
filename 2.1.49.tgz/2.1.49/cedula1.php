<?php


error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

$ncod = $_POST["cod"];
if (!$ncod)
    $ncod = $_GET["cod"];

$npro = $_POST["pro"];
if (!$npro)
    $npro = $_GET["pro"];

if (!$ncod && !$npro)
    return;
$nimg = $_POST["img"];
if (!$nimg)
    $nimg = $_GET["img"];
if (!$nimg)
    $nimg = 1;

require("inc/config.php");

if (!$db){
    $db = conecta();
}
if (!$db) {
    return;
}
if ($ncod) {
    $cstr = "select m.memo as imagem 
from CEDULA_CLI c
inner join CEDULA_CLI_MEMO m on m.recno=c.recno
where is_deleted='N' and codigo=$ncod 
and ordem=$nimg
order by parte
";
} else {
    $cstr = "select m.memo as imagem 
from PRODUTOS_IMG c
inner join PRODUTOS_IMG_MEMO m on m.recno=c.recno
where is_deleted='N' and codigo=$npro
and ordem=$nimg
order by parte
";
}
$otable = mysqli_query($db, $cstr);

if (mysqli_num_rows($otable) == 0) {
    $oimg = imagecreatefromjpeg("noimage.jpg");
    header("Content-Type: image/jpeg");
    imagejpeg($oimg);
    imagedestroy($oimg);
    mysqli_close();

    return;
} else {
    $caux = "";
    while ($olinha = mysqli_fetch_array($otable)) {
        $caux .= $olinha["imagem"];
    }

    $aaux = array();
    $aaux[] = "\\";
    $aaux[] = chr(0);
    $aaux[] = chr(13);
    $aaux[] = chr(10);
    $aaux[] = '"';
    $aaux[] = "'";
    $aaux[] = "`";
    $aaux[] = chr(9);
    $aaux[] = chr(141);
    $aaux[] = chr(8);
    $aaux[] = chr(26);
    $aaux[] = "%";
    $aaux[] = "_";

    for ($i = 0; $i < count($aaux); $i++) {
        $caux = str_replace("/chr" . ($i + 1) . "/", $aaux[$i], $caux);
    }
    $oimg = imagecreatefromstring($caux);
    header("Content-Type: image/jpeg");
    imagejpeg($oimg);
    imagedestroy($oimg);
    mysqli_close($db);
}
