<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
//session_start();
$lweb = $_SESSION["web"];
session_write_close();
//if (session_status()==PHP_SESSION_NONE ){
//}
function VeSidVendas($nmodo = 0, $sid = '') {
    global $db;
    global $lweb;
    if (!$db) {
        $db = conecta();
    }
    if (!$nmodo && $nmodo != 0) {
        $nmodo = VeSession("modo"); //$_SESSION["modo"];
    }
    $nmodo = $nmodo + 0;
    $carq = $nmodo == 0 ? "vendas" : "caixa";
    $tempolimite = VeSession("tempolimite") * 60; //$_SESSION["tempolimite"] * 60;
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    $_SESSION["ntempolimite"]=$tempolimite;
    session_write_close();
    if (!$tempolimite) {
        $tempolimite = 120 * 60;
    }
    $sid = VeSession("sid"); //$_SESSION["sid"];
    if (!$sid) {
        return "Não existe SID na sessão ";
    }

    $carq = "vendas";
    $otab = mysqli_query($db, "select v.*,date2unix(now()) as agora from " . $carq . "tablet" . $lweb . "_sid v where v.sid='$sid'");
    if (mysqli_num_rows($otab) == 0) {
        $carq = "caixa";
        $otab = mysqli_query($db, "select v.*,date2unix(now()) as agora from " . $carq . "tablet" . $lweb . "_sid v where v.sid='$sid'");
        if (mysqli_num_rows($otab) == 0) {
            return 'Não existe SID na tabela';
        }
    }
    /*
      /*
      $otab = mysqli_query($db, "select v.*,date2unix(now()) as agora from ".$carq."tablet".$lweb."_sid v where v.sid='$sid'");
      if (mysqli_num_rows($otab) == 0) {
      return 'Não existe SID na tabela';
      }
     */
    $olin = mysqli_fetch_array($otab);
    if ($olin["data_sai"] > 0) {
        return 'Sessão já finalizada';
    }
    if ($olin["data_atu"] + $tempolimite < $olin["agora"]) {
        mysqli_query($db, "update " . $carq . "tablet" . $lweb . "_sid data_sai=date2unix(now()) where sid='$sid'");
        return 'Sessão expirada';
    }
    mysqli_query($db, "update " . $carq . "tablet" . $lweb . "_sid set data_atu=date2unix(now()) where sid='$sid'");
    if (!$lweb) {
        $otabven = mysqli_query($db, "select * from TABLET_CFG where is_deleted='N' and vendedor=" . VeSession("vendedor"));
    } else {
        $otabven = mysqli_query($db, "select * from CONFIGVD_WEB where is_deleted='N' and vendedor=" . VeSession("vendedor"));
    }
    if (mysqli_num_rows($otabven) != 0) {
        $olinven = mysqli_fetch_array($otabven);
        if ($olinven["BLOQUEADO"] == 'Y') {
            //VENDEDOR BLOQUEADO
            return 'Vendedor bloqueado';
        }
        if ($olinven["IPS"]) {
            $aips = explode(",", $olinven["IPS"]);
            $ipaddress = '';
            if (getenv('HTTP_CLIENT_IP'))
                $ipaddress = getenv('HTTP_CLIENT_IP');
            else if (getenv('HTTP_X_FORWARDED_FOR'))
                $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
            else if (getenv('HTTP_X_FORWARDED'))
                $ipaddress = getenv('HTTP_X_FORWARDED');
            else if (getenv('HTTP_FORWARDED_FOR'))
                $ipaddress = getenv('HTTP_FORWARDED_FOR');
            else if (getenv('HTTP_FORWARDED'))
                $ipaddress = getenv('HTTP_FORWARDED');
            else if (getenv('REMOTE_ADDR'))
                $ipaddress = getenv('REMOTE_ADDR');
            else
                $ipaddress = 'UNKNOWN';

            $lok = false;
            foreach ($aips as $value) {
                if ($value == substr($ipaddress, 0, strlen($value)) || $value == "0.0.0.0/0") {
                    $lok = true;
                    break;
                }
            }
            if (!$lok) {
                //ip nao autorizado
                return 'IP não autorizado => ' . $ipaddress;
            }
        }

        if (!$lweb) {
            $ndia = date("w") + 1;
            if (trim($olinven["D$ndia"]) == '') {
                //dia não autorizado
                return "Não autorizado trabalhar este dia ";
            }
            $adata = explode(" ", $olinven["D$ndia"]);
            if (date('H:i:s') < $adata[0] || date("H:i:s") > $adata[1]) {
                //Hora não autorizada
                return "Horário não autorizado ";
            }
            mysqli_query($db, "update TABLET_VEN set iplog='$ipaddress' where vendedor=" . VeSession("vendedor"));
        } else {
            $ndia = date("w") + 1;
            if (trim($olinven["ACCESS_$ndia"]) == '') {
                //dia não autorizado
                return "Não autorizado trabalhar este dia ";
            }
            $adata = array(substr($olinven["ACCESS_$ndia"],0,8),substr($olinven["ACCESS_$ndia"],9,8));
            if (date('H:i:s') < $adata[0] || date("H:i:s") > $adata[1]) {
                //Hora não autorizada
                return "Horário não autorizado ";
            }
            mysqli_query($db, "update TABLET_VEN set iplog='$ipaddress' where vendedor=" . VeSession("vendedor"));
            
        }
    }
    return "";
}

function FechaSidVendas($nmodo) {
    global $db;
    global $lweb;

    if (!$db) {
        $db = conecta();
    }
    if ($nmodo) {
        $nmodo = 0;
    }
    $nmodo = $nmodo + 0;
    $carq = $nmodo == 0 ? "vendas" : "caixa";
    $sid = pegavar("sid"); //VeSession("sid");//$_SESSION["sid"];
    if ($sid) {
        $olin = mysqli_fetch_array(mysqli_query($db, "select * from " . $carq . "tablet" . $lweb . "_sid where sid='$sid'"));
        GravaLogTablet("LOG_OUT", '', '', $olin["usuario"]);
        mysqli_query($db, "update " . $carq . "tablet" . $lweb . "_sid set data_sai=date2unix(now()) where sid='$sid'");
    }
    VeSession("sid", "null"); //$_SESSION['sid'] = '';
    VeSession("vendedor", 0); //$_SESSION["vendedor"] = 0;

    return;
}
