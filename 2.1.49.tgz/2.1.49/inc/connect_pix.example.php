<?php

$cSite = "https://apisandbox.agillitas.com.br/efx/v1/external/";

$nId = '';
$cEmail = "cellshoploja@piloto.com";
$cPass = "Welcome123456*";

$nBancoPix='token';


$aUsersAut=array(1,306);
$cWebHook="";
$nEspera=5*60;
$aoperadores_rel=array(1,2,3);
$ntimeout_rel=10;
$aIpsPermitidos=array('192.168.12.');
