<?php

/*
  W_CRIAR/W_CRIAR_DEL Cria um registro e adiciona campos / Cria deletado
  $omed=new Mediator4("TESTE.DBF",W_CRIAR);
  $omed->add("codigo",1);
  $omed->add("nome","Dunha");

  if ($omed->grava()){
  var_dump(omed->nrecno);
  }

  W_DELETAR/W_RECALL Deleta/Recupera um registro
  $nregistro=10;
  $omed=new Mediator4("TESTE.DBF",W_DELETAR,'',$nregistro);

  if ($omed->grava()){
  echo "ok";
  }

  W_ELIMINAR Apaga arquivo
  $omed=new Mediator4("TESTE.DBF",W_ELIMINAR);

  if ($omed->grava()){
  echo "Arquivo apagado";
  }

  W_CRIAR_ARQUIVO  Cria arquivo
  $aestru=array();
  $aestru[]=array("codigo","n",10,0);
  $aestru[]=array("nome","c",30,0);

  $omed=new Mediator4("TESTE.DBF",W_CRIAR_ARQUIVO,$aestru);

  if ($omed->grava()){
  echo "ok";
  }

  W_REFRESH  Refresh no arquivo e traz o ultimo recno
  $omed=new Mediator4("TESTE.DBF",W_REFRESH);

  if ($omed->grava()){
  echo $omed->nrecno;
  }

  W_COMMIT  Comita os dados (para os indices IE$x)
  $omed=new Mediator4("TESTE.DBF",W_COMMIT);

  if ($omed->grava()){
  echo "ok";
  }



  W_BLOQUEAR Tenta Bloquea um registro. ** Desbloqueia após a execução
  $nregistro=10;
  $omed=new Mediator4("TESTE.DBF",W_BLOQUEAR,'',$nregistro);

  if ($omed->grava()){
  echo "Conseguiu bloquear";
  }else{
  echo "Não Conseguiu bloquear";
  }



  W_STRUCT
  $omed=new Mediator4("TESTE.DBF",W_STRUCT);
  $omed->grava();
  var_dump(omed->estrutura);
 */

define("W_CRIAR", 1);
define("W_ALTERAR", 2);
define("W_CRIAR_DEL", 3);
define("W_ALTERAR_DEL", 4);
define("W_DELETAR", 5);
define("W_RECALL", 6);
define("W_BLOQUEAR", 7);
define("W_ELIMINAR", 8);
define("W_CRIAR_ARQUIVO", 9);
define("W_REFRESH", 10);
define("W_COMMIT", 11);
define("W_STRUCT", 12);
define("W_DESBLOQUEAR", 13);

define("W_MAX", 13);
require_once 'rddfuncoes.php';
$GLOBALS['s_aConn'] = array(1=>$db);

class Mediator4 {

    private $tabela;
    private $tabela_memo = '';
    private $arquivo;
    private $campos = array();
    private $commit = 'http://localhost/cgi-bin/medweb.cgi';
    private $aret = array();
    private $aestru = array();
    private $id;
    private $chave = 0;
    private $aEstruTab;
    private $db;
    private $nwa;
    public $modo = 0;
    public $llock = false;
    public $lFlock = false;
    public $recnopos = 0;
    public $ntempo = 0;
    public $campocodigo = '';
    public $codigogerado = 0;
    public $erro = 0;
    public $cerro = "";
    public $omedret;
    public $recno;
    public $nrecno;
    public $estrutura = array();
    public $lLimpaAltera = false;

    public function __destruct() {
        $this->dblock(true);
    }
    public function __construct($cArquivo = '', $nmodo = 0, $acampos = '', $nRecnoposcWhere = 0, $odb = '', $cCampoCodigo = '', $lLimpaAltera = false) {
        global $ccommit_web;
        global $db;

        $this->lLimpaAltera=$lLimpaAltera;
        if ($ccommit_web) {
            $this->commit = $ccommit_web;
        }
        if ($cCampoCodigo) {
            $this->campocodigo = strtoupper(trim($cCampoCodigo));
        }

        if (!$this->commit) {
            $this->cerro = "Sem COMMIT CONFIGURADO";
            $this->erro = 11;
            return false;
        }
        if (!$cArquivo) {
            $this->cerro = "Sem arquivo informado";
            $this->erro = 12;
            return false;
        }
        if ($odb) {
            $this->db = $odb;
            $GLOBALS['s_aConn'] = array(1=>$odb);
        } else {
            $this->db = $db;
            $GLOBALS['s_aConn'] = array(1=>$db);
        }
        if (!$this->db) {
            $this->cerro = "Nao conectado ao MySql";
            $this->erro = 13;
            return false;
        }
        if ($nmodo < 1 || $nmodo > W_MAX) {
            $this->cerro = "Modo invalido";
            $this->erro = 14;
            return false;
        }
        $this->modo = $nmodo;

        $cArquivo = trim(strtoupper($cArquivo));
        if (substr($cArquivo, -4) == ".DBF") {
            $cArquivo = substr($cArquivo, 0, -4);
        } else if (substr($cArquivo, -1) == ".") {
            $cArquivo = substr($cArquivo, 0, -1);
        }
        if (strlen($cArquivo) > 12) {
            $cArquivo = substr($cArquivo, 0, 12);
        }



        $this->arquivo = $cArquivo;
        $this->tabela = str_replace(".", "_", $this->arquivo);

        if ($nRecnoposcWhere) {
            if (is_numeric($nRecnoposcWhere)) {
                $this->recnopos = $nRecnoposcWhere;
            } else {
                $naux = mysqli_fetch_row(mysqli_query($odb, "select recno from " . $this->tabela . " where " . $nRecnoposcWhere))[0];
                if (mysqli_errno($odb)) {
                    $this->cerro = "Erro na clausula WHERE => " . mysqli_error($odb);
                    $this->erro = 15;
                    return false;
                }
                $this->recnopos = $naux;
            }
        }
        if (!$this->recnopos && ($this->modo == W_DELETAR || $this->modo == W_RECALL || $this->modo == W_BLOQUEAR || $this->modo == W_DESBLOQUEAR )) {
            $this->cerro = "Falta registro para este modo";
            $this->erro = 15;
            return false;
        }


        if ($acampos) {
            foreach ($acampos as $value) {
                $caux = trim(strtoupper($value[0]));
                $this->campos[$caux] = array($value[1], $value[2], 0);
                if (count($value) > 3) {
                    $this->campos[$caux][2] = $value[3];
                }
            }
        }
        $this->nwa = random_int(1000, 2000);
    }

    public function dblock($lUnlock = false) {

        if ($this->llock && !$lUnlock) {
            return true;
        }
        if (!$lUnlock) {
            if (!mysqlLock(1, CF_LOCK_RECNO, $this->arquivo, $this->recnopos, $this->nwa, $cRefErro)) {
                $this->erro = 901;
                $this->cerro = "Erro bloqueando registro. Arquivo => " . $this->arquivo . "-" . $this->recnopos . "\n" . $cRefErro;
                return false;
            }
            $this->llock = true;
            return true;
        } else {
            if (!mysqlRelease(1, CF_LOCK_RECNO, $this->arquivo, $this->recnopos, $this->nwa)) {
                $this->erro = 901;
                $this->cerro = "Erro bloqueando registro. Arquivo => " . $this->arquivo . "-" . $this->recnopos ;
                return false;
            }
            $this->llock = false;
            return true;
        }
    }

    public function limpar() {
        if (!$this->dblock()) {
            return false;
        }
        $cstr = "`IS_DELETED`='N'";
        $lmemo = false;
        foreach ($this->aestru as $value) {
            $cstr .= ",`" . $value[0] . "`=";
            switch ($value[1]) {
                case "M":
                    $cstr .= "0";
                    $lmemo = true;
                    break;
                case "N":
                    $cstr .= "0";
                    break;

                case "L":
                    $cstr .= "'N'";
                    break;
                case "D":
                    $cstr .= "'1001-01-01'";
                    break;
                case "C":
                    $cstr .= "''";
                    break;
            }
        }
        $cstr .= "Update `" . $this->tabela . "` set " . $cstr . " where recno=" . $this->recnopos;
        mysqli_query($this->db, $cstr);
        if ($lmemo) {
            $cstr .= "delete from `" . $this->tabela . "_MEMO` where recno=" . $this->recnopos;
            mysqli_query($this->db, $cstr);
        }
        return true;
    }

    public function grava() {
        if ($this->erro) {
            return false;
        }
        $aaux = explode(" ", microtime());
        $this->ntempo = $aaux[1] + $aaux[0];

        $cchave = date("U") . rand(1, 99999);
        $this->chave = $cchave;
        if ($this->modo == W_ELIMINAR) {
            if (!cf_file(1, $this->arquivo, $cerro)) {
                $this->erro = 400;
                $this->cerro = "Arquivo não existe RDD => " . $this->arquivo . "\n" . $cerro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            if (!mysqlLock(1, CF_LOCK_FILE, $this->arquivo, "X", $this->nwa)) {
                $this->erro = 401;
                $this->cerro = "Arquivo não pode ser aberto exclusivo=> " . $this->arquivo;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            mysqlRelease(1, CF_LOCK_FILE, $this->arquivo, "X", $this->nwa) ;
            if (!cf_dropFile(1, $this->arquivo, $cRefErro, true)) {
                $this->erro = 201;
                $this->cerro = "Erro deletando arquivo => " . $this->arquivo . "\n" . $cRefErro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;

            return true;
        }
        if ($this->modo == W_CRIAR_ARQUIVO) {
            if (cf_file(1, $this->arquivo, $cerro)) {
                $this->erro = 200;
                $this->cerro = "Arquivo já existe RDD => " . $this->arquivo . "\n" . $cerro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            $aEstru = array();
            foreach ($this->campos as $key => $value) {
                $aaux = array($key, strtoupper($value[0]), 10, 0);
                if ($value[1]) {
                    $aaux[2] = $value[1];
                }
                if ($value[2]) {
                    $aaux[3] = $value[2];
                }
                $aEstru[] = $aaux;
            }
            if (!cf_createTable(1, $this->arquivo, $aEstru, $cRefErro)) {
                $this->erro = 201;
                $this->cerro = "Erro criado arquivo => " . $this->arquivo . "\n" . $cRefErro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;

            return true;
        }
        if ($this->modo == W_REFRESH) {
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
        }
         $this->aestru = cf_dbStruct(1, $this->arquivo, $cRefErro);
        if ($cRefErro) {
            $this->erro = 303;
            $this->cerro = "Erro lendo estrutura " . $this->arquivo . "\n" . $cRefErro;
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return false;
        }
        if ($this->modo == W_DELETAR) {
            if (!$this->dblock()) {
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            mysqli_query($this->db, "update " . $this->tabela . " set is_deleted='Y' ");
            $this->dblock(true);
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return true;
        }
        if ($this->modo == W_RECALL) {
            if (!$this->dblock()) {
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            mysqli_query($this->db, "update " . $this->tabela . " set is_deleted='N' ");
            $this->dblock(true);
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return true;
        }
        if ($this->modo == W_BLOQUEAR) {
            if (!$this->dblock()) {
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return true;
        }
        if ($this->modo == W_DESBLOQUEAR) {
            if (!$this->dblock(true)) {
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return true;
        }
        if ($this->modo == W_STRUCT) {
            $this->erro = 0;
            $this->cerro = "";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return true;
        }

        if ($this->lLimpaAltera && ($this->modo == W_ALTERAR || $this->modo == W_ALTERAR_DEL || $this->modo == W_LIMPAR)) {
            if (!$this->dblock()) {
                $this->erro = 801;
                $this->cerro = "Erro bloquando registro arquivo => " . $this->arquivo ."-".$this->recnopos. "\n" . $cRefErro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
            $lret = $this->limpar();
            $this->dblock(true);
            if ($this->modo == W_LIMPAR) {
                return $lret;
            }
        }
        if ($this->modo == W_ALTERAR || $this->modo == W_ALTERAR_DEL) {
            if (!$this->dblock()) {
                $this->erro = 801;
                $this->cerro = "Erro bloquando registro arquivo => " . $this->arquivo ."-".$this->recnopos. "\n" . $cRefErro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }
        }

        if ($this->modo == W_CRIAR_DEL || $this->modo == W_CRIAR || $this->modo == W_ALTERAR || $this->modo == W_ALTERAR_DEL) {
          $amemo = array();
            $cstr = "";
            foreach ($this->campos as $key => $value) {
                $npos = array_search($key, array_column($this->aestru, 0));
                if ($npos === false) {
                    continue;
                }
                if ($this->aestru[$npos][1] == "M") {
                    $cstr .= ",`" . $key . "`=0";// . strlen($value[1]);
                    $amemo[$key] = assql($value[1]);
                } else {

                    $cstr .= ",`" . $key . "`=" . ($value[0] == "Q" ? $value[1] : assql($value[1]));
                }
            }
          if ($this->modo == W_ALTERAR || $this->modo == W_ALTERAR_DEL) {
                $cstr = "update `" . $this->tabela . "` set `IS_DELETED`=" . ($this->modo == W_ALTERAR_DEL ? "'Y'" : "IS_DELETED") . $cstr . " where recno=" . $this->recnopos;
                mysqli_query($this->db, $cstr);
                $this->recno = $this->recnopos;
                $this->nrecno = $this->recnopos;
            } else {
                $cstr = "insert `" . $this->tabela . "` set `IS_DELETED`=" . ($this->modo == W_CRIAR_DEL ? "'Y'" : "'N'") . $cstr;
                mysqli_query($this->db, $cstr);
                $this->id = mysqli_fetch_row(mysqli_query($this->db, "select last_insert_id()"))[0];
                $this->recno = $this->id;
                $this->nrecno = $this->id;
                $this->recnopos = $this->id;
            }
            if ($amemo) {
                foreach ($amemo as $key => $value) {
                    $cstr = "replace `" . $this->tabela . "_MEMO` (recno,col_name,memo) values (" . $this->recno . ",'" . $key . "'," . $value . ")";
                    mysqli_query($this->db, $cstr);
                    $cstr = "UPDATE `" . $this->tabela . "` p, `" . $this->tabela . "_MEMO` m set p.`".$key."`=length(m.`memo`) where m.`recno`=".$this->recno." and m.`col_name`=".assql($key). " and p.`recno`=".$this->recno;
                    mysqli_query($this->db, $cstr);
                }
            }

            if ($this->campocodigo && ( $this->modo == W_CRIAR || $this->modo == W_CRIAR_DEL)) {
                $cstr = "(select max(`" . $this->campocodigo . "`)+1 from `" . $this->tabela . "`)";
                $cstr = "(@ncodigo:=" . $cstr . ")";
                $cstr = "update `" . $this->tabela . "` set `" . $this->campocodigo . "`=" . $cstr . " where recno=" . $this->recno;
                mysqli_query($this->db, $cstr);
                $this->codigogerado = mysqli_fetch_row(mysqli_query($this->db, "select @ncodigo"))[0];
            }
            //ajusta indice composto
            $cstr = "select COL_NAME,IND_KEY FROM CLP_TAB_IDX WHERE TAB_CLP_NAME=" . assql($this->arquivo);
            $otab = mysqli_query($this->db, $cstr);
            while ($olin = mysqli_fetch_row($otab)) {
                $cstr = "update `" . $this->tabela . "` set `" . $olin[0] . "`=" . $olin[1] . " where recno=" . $this->recno;
                mysqli_query($this->db, $cstr);
            }
            if (!$this->llock) {
                $this->dblock();
            }
            if ($this->modo== W_CRIAR_DEL || $this->modo== W_ALTERAR_DEL){
                $cstr = "update `" . $this->tabela . "` set `IS_DELETED`='Y' where recno=" . $this->recno;
                mysqli_query($this->db, $cstr);
            }
            return true;
        }
    }

    public function add($cCampo, $cTipo = 'C', $uValor = '', $uDec = 0) {
        $cCampo = trim(strtoupper($cCampo));
        $this->campos[$cCampo] = array($cTipo, $uValor, $uDec);
    }

    public function aadd($cCampo, $uValor = '', $lsql = false) {

        if (!$this->aEstruTab) {
            /*
              8-data
              1-char
              65-memo
              `       2048-2-integer
              4-logico
             */
            $otab = mysqli_query($this->db, "SELECT COL_NAME,COL_CLP_TYPE FROM CLP_TAB_COLS WHERE TAB_NAME='" . $this->tabela . "' AND COL_NAME!='RECNO' AND COL_NAME!='IS_DELETED' AND COL_NAME NOT LIKE 'IE$%'");

            $this->aEstruTab = array();
            while ($olin = mysqli_fetch_row($otab)) {
                $ctipo = "C";
                if ($olin[1] == 8) {
                    $ctipo = "D";
                } elseif ($olin[1] == 65) {
                    $ctipo = "M";
                } elseif ($olin[1] == 2048 || $olin[1] == 2) {
                    $ctipo = "N";
                } elseif ($olin[1] == 4) {
                    $ctipo = "L";
                } else {
                    $ctipo = "C";
                }
                $this->aEstruTab[$olin[0]] = $ctipo;
            }
        }
        $cCampo = trim(strtoupper($cCampo));
        if ($lsql) {
            $this->campos[$cCampo] = array("Q", $uValor, 0);
        } else {
            $this->campos[$cCampo] = array($this->aEstruTab[$cCampo], $uValor, 0);
        }
    }

    public function grava_web() {
        $crequest = $this->commit . "?chave=" . $this->chave;
        //echo $crequest."<br><br>";
        $cret = file_get_contents($crequest);
        //echo "Ret:".$cret."<br><br>";
        $this->omedret = json_decode($cret);
        if (!$this->omedret) {
            $this->erro = 100;
            $this->cerro = "erro acessando medweb";
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return false;
        }
        if ($this->omedret->erro > 0) {
            $this->erro = $this->omedret->erro;
            $this->cerro = $this->omedret->cerro;
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return false;
        }
        if ($this->omedret->estrutura) {
            $this->estrutura = $this->omedret->estrutura;
        }
        $this->recno = $this->omedret->reg;
        $this->nrecno = $this->omedret->reg;
        $aaux = explode(" ", microtime());
        $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
        return true;
    }

    public function CriaFunction() {

        $afuncoes = array();
        $afuncoes["ctod"] = "create function ctod(cstr varchar(256))
returns varchar(100)
begin
	declare dia char(2);
	declare mes char(2);
	declare ano varchar(4);

	set dia=substring_index(cstr,'/',1);
	set mes=substring_index(cstr,'/',-2);
	set mes=substring_index(mes,'/',1);
	set ano=substring_index(cstr,'/',-1);

	set dia=lpad(dia,2,'0');
	set mes=lpad(mes,2,'0');
	if length(ano) = 2 then
    	    set ano=concat('20',ano);
	end if;
	set ano=lpad(ano,4,'0');

 	return concat(ano,'-',mes,'-',dia);
end
";
        $afuncoes["dtoc"] = "create function dtoc(cstr varchar(256))
returns varchar(100)

begin
 	return concat(substr(cstr,9,2),'/',substr(cstr,6,2),'/',substr(cstr,3,2));
end
";
        $afuncoes["alltrim"] = "create function alltrim(cstr varchar(256))
returns varchar(100)

begin
 	return trim(cstr);
end
";
        $afuncoes["len"] = "create function len(cstr varchar(256))
returns varchar(100)

begin
 	return length(cstr);
end
";
        $afuncoes["str"] = "create function str(numero DECIMAL(25,10),tam INT)
returns varchar(100)
begin
        declare deci int(1) default 0;
	declare cret varchar(100) default '';
	declare cdec varchar(20) default '';
	if (deci>0) THEN
		set cret=lpad(floor(numero),tam-1-deci,' ');
		set cdec=concat((numero%1),'0000000000');
		set cdec=substr(cdec,3,deci);
		return concat(cret,'.',cdec);	
	end if;
 	return lpad(round(numero,0),tam,' ');
end

";
        $afuncoes["strzero"] = "create function strzero(numero DECIMAL(25,10),tam INT,deci INT)
returns varchar(100)
begin
	declare cret varchar(100) default '';
	declare cdec varchar(20) default '';
	if (deci>0) THEN
		set cret=lpad(floor(numero),tam-1-deci,'0');
		set cdec=concat((numero%1),'0000000000');
		set cdec=substr(cdec,3,deci);
		return concat(cret,'.',cdec);	
	end if;
 	return lpad(round(numero,0),tam,'0');
end
";
        $afuncoes["dtos"] = "create function dtos(ddata CHAR(10))
returns varchar(30)

begin
return if(ddata='1000-01-01','        ',replace(ddata,'-',''));
return 'lpad(\''+if(ddata='1000-01-01','        ',replace(ddata,'-',''))+'\',8,\'\')';
end
";
        $afuncoes["val"] = "create function val(cstr VARCHAR(20))
returns DECIMAL(12,2)

begin
    return cstr+0;
end
";
        $afuncoes["descend"] = "create function descend(cstr VARCHAR(20))
returns varchar(20)

begin
declare i int default 0;
declare cret varchar(20) default '';

while (i<length(cstr)) DO
    set cret = concat(cret,char(256-ascii(substr(cstr,i+1,1))));
    set i = i+1;
end while;
return cret;
end
";

        $otab = mysqli_query($this->db, "show function status where db=database()");
        $afuncoes = array();
        while ($olin = mysqli_fetch_row($otab)) {
            $afuncoes[] = $olin[1];
        }

        foreach ($afuncoes as $key => $value) {
            if (array_search($key, $afuncoes) === false) {
                mysqli_query($this->db, $value);
            }
        }
    }

    public function __get($nome) {
        $nome = strtoupper($nome);
        return $this->campos[$nome][1];
    }

    public function __set($nome, $uvalue) {
        $nome = strtoupper($nome);
        if (is_array($uvalue) && count($uvalue) > 1) {
            $this->aadd($nome, $uvalue[0], $uvalue[1]);
        } else {
            $this->aadd($nome, $uvalue);
        }
        return $this->campos[$nome][1];
    }
}
