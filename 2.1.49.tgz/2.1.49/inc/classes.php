<?php
error_reporting(E_ALL);
ini_set('display_errors',0);
ini_set('display_startup_erros',0);
class celula
{
    var $cbuffer= "";

    var $str	= "";
    var $pos	= "";
    var $neg	= "";
    var $tamfon = "";
    var $colspn = "";
    var $rowspn = "";
    var $cor	= "";
    var $corfun = "";
    var $align  = "";
    var $lgr	= "";
    var $lLinAberta = false ;
    var $lCelAberta = false ;
    var $ntableaberta = 0 ;    
    var $link	= "";
    function celula() {
	$this->limpa();
    }

    function limpa(){
        $this->str	= "";
	$this->pos	= "";
        $this->neg	= "";
        $this->tamfon 	= "";
	$this->colspn 	= "";
        $this->rowspn 	= "";
	$this->cor	= "";
	$this->corfun	= "";
	$this->align	= "";
        $this->lgr	= "";
        $this->link	= "";
    }

    
    function linhadiv($nspan){
	$this->abrelinha(true);
	$this->pos="h2";
	if($nspan)
	    $this->colspn=$nspan;
	$this->abrecel(".");
	$this->fechalinha();
    }
    function abretable($nborder=0,$npad='',$nspace='',$cwidth=''){
	$this->cbuffer.=htmltableon($nborder,$npad,$nspace,$cwidth);
	$this->ntableaberta=$this->ntableaberta+1;
    }
    function fechatable(){
	$this->cbuffer.=htmltableoff();
	$this->ntableaberta=$this->ntableaberta-1;
    }
    function abrelin($llimpa=false){
	$this->abrelinha($llimpa);
    }

    function abrelinha($llimpa=false){
	if ($llimpa) $this->limpa();
	$this->fechalin();
	$this->lLinAberta=true;
	$this->cbuffer .= "\r<tr>";
    }
    

    function abrecel($cstr=''){
	$this->abrecelula($cstr);
    }
    
    function abrecelula($cstr=''){
	$this->fechacel();
	if (!$this->lLinAberta) $this->abrelinha();
	
	$this->lCelAberta=true;
	$this->cbuffer.="\r  <td class=\"";
	$calign="";
	if (strtoupper($this->pos)=="D" ){ 
	    $this->cbuffer.="right";
	    $calign="right";
	  }elseif (strtoupper($this->pos)=="E") {
	    $this->cbuffer.="default";
	    $calign="left";
	  }elseif (strtoupper($this->pos)=="C" ){
	    $this->cbuffer.="cent";
	    $calign="center";
	  }elseif (strtoupper($this->pos)=="H" ){
	    $this->cbuffer.="header";
	    $calign="center";
	  }elseif (strtoupper($this->pos)=="H1" || strtoupper($this->pos)=="H2"){
	    $this->cbuffer.="headers";
	    $calign="center";
	  }elseif ($this->pos!='') {
	    $this->cbuffer.=$this->pos;
	  }else {
	    $this->cbuffer.="default";
	    $calign="left";
	}
	$this->cbuffer.="\" ";
	if ($this->align){
	    $this->align=strtoupper(substr($this->align,0,1));
	    if ($this->align=="E" || $this->align=="L"){
		$calign="left";
	    }elseif ($this->align=="R" || $this->align=="D"){
		$calign="right";
	    }else {
		$calign="center";
	    }
	}
	$caux="<p align=\"$calign\" ";

	if ($this->colspn>1) $this->cbuffer.=" colspan=\"".$this->colspn."\" ";
	if ($this->rowspn>1) $this->cbuffer.=" rowspan=\"".$this->rowspn."\" ";
	if ($this->lgr) $this->cbuffer.=" width=\"".$this->lgr."\" ";
	$this->cbuffer.=">";


/*
	$this->cbuffer.=$caux."\">";

	if ($this->corfun){
	$this->cbuffer.="<p style=\"background-color: ".$this->corfun.";\">";
	}
	if ($this->tamfon || $this->cor){
	    $this->cbuffer.="<font ";
	    if ($this->tamfon) $this->cbuffer.=" size=\"".$this->tamfon."\" ";
	    if ($this->cor)    $this->cbuffer.=" color=\"".$this->cor."\" ";
	    $this->cbuffer.=">";
	}
	if ($this->link){
	    $this->cbuffer.="<a href='".$this->link."'>";
	}

	if (strtoupper($this->pos)=="H2" )
	    $this->cbuffer.="<p style=\"font-size: 2pt  \"><font color=\"#cfcfcf\">";
	
	if ($this->neg) $this->cbuffer.="<b>";
	if ($cstr) $this->cbuffer.=$cstr;
*/

	if ($this->corfun){
	    $caux.=" style=\"background-color: ".$this->corfun.";\"";
	}
	if (strtoupper($this->pos)=="H2" ){
	    $this->tamfon=2;
	    $this->cor="#cfcfcf";
	}

	$this->cbuffer.=$caux.">";
	if ($this->tamfon || $this->cor){
	    $this->cbuffer.="<font ";
	    if ($this->tamfon) $this->cbuffer.=" size=\"".$this->tamfon."\" ";
	    if ($this->cor)    $this->cbuffer.=" color=\"".$this->cor."\" ";
	    $this->cbuffer.=">";
	}
//	$this->cbuffer.=$caux.">";
	if ($this->link){
	    $this->cbuffer.="<a href='".$this->link."'>";
	}

	if ($this->neg) $this->cbuffer.="<b>";
	if ($cstr) $this->cbuffer.=$cstr;
    }

    
    function imp($cstr){
	$this->imprime($cstr);
    }
    function impcel($cstr){
	$this->imprime($cstr);
    }
    function imprime($cstr){
	if (!$this->lCelAberta) $this->abrecel() ;
	$this->cbuffer.=$cstr;
    }
    
    function fechacel(){
	$this->fechacelula();
    }
    function fechacelula(){
	if ($this->lCelAberta) $this->cbuffer.="\r  </td>";
	$this->lCelAberta=false;
    }
    function fechalin(){
	$this->fechalinha();
    }
    function fechalinha($cstr=''){
	$this->fechacel();
	if ($this->lLinAberta) $this->cbuffer.="\r</tr>$cstr";
	$this->lLinAberta=false;
    }

    function mostra($llimpa=false,$lretornacar=false){
	$cret="";
	$this->fechalin();
    	while ($this->ntableaberta){
	    $this->cbuffer.=htmltableoff();
	    $this->ntableaberta=$this->ntableaberta-1;
	}
	if ($lretornacar){
	    $cret=$this->cbuffer;
	}else{
    	    echo $this->cbuffer;
	}
	$this->cbuffer="";
	if ($llimpa) $this->limpa();
	return $cret;
    }
}

?>
