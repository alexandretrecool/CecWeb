<?php
require_once 'login.php';
if (PegaVar("usuario") && !pegavar("senha")) {
    VeOperadorSenha(pegavar("usuario"), '', 0, $cnome, $nnumsen);
    $aret = array();
    $aret["numero"] = $nnumsen;
    $aret["nome"] = $cnome;
    echo json_encode($aret);
    return;
}
if (PegaVar("usuario") && pegavar("senha")) {
    $aret = array();
    $aret["erro"] = 0;
    if (!VeOperadorSenha(pegavar("usuario"), PegaVar("senha"), pegavar("numero"), $cnome, $nnumsen, $noperador)) {
        $aret["erro"] = 1;
        $aret["cerro"] = "Login inválido . " . PegaVar("usuario") . " - " . PegaVar("senha") . " - " . PegaVar("numero");
        echo json_encode($aret);
        return;
    }
    $oope = new Operador('', $noperador, PegaVar("modulo"), 15 * 60, PegaVar("terminal"));
    if (!$oope->lok) {
        $aret["erro"] = 2;
        $aret["cerro"] = "Login inválido";
        echo json_encode($aret);
        return;
    }
    $aret["codigo"] = $noperador;
    $aret["nome"] = $cnome;
    $aret["sid"] = $oope->csid;
    echo json_encode($aret);
    return;
}
?>
<html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Controle de Entregas">
        <meta name="author" content="Kemmer Roberto">
        <title>Controle de Transferência</title>
        <link rel="shortcut icon" href="favicon.ico">
        <link rel="icon" href="favicon.ico">
        <link rel="stylesheet" href="../assets/components/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/components/bootstrap/css/font-awesome.min.css">

    </head>

    <body>
        <style >
            #trf-modal-dialog,
            #trf-modal-content {
                /* 80% of window height */
                height: 80%;
            }

            #trf-corpo {
                /* 100% = dialog height, 120px = header + footer */
                max-height: calc(100% - 140px);
                overflow-y: scroll;
            }   

            .well-sm {
                border: 1px solid #ddd;border-radius: 10px;
            }
            .tabletran {
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
                font-size: .9em;
            }

            .tabletran td, .tabletran th {
                border-top: 1px solid #ddd;
                border-bottom: 1px solid #ddd;
                padding: 0px;
            }

            .tabletran tr:nth-child(even){background-color: #f2f2f2;}

            .tabletran tr:hover {background-color: #ddd;}
            .tabletran th {
                padding-top: 5px;
                padding-bottom: 5px;
                text-align: left;
                background-color: #4CAF50;
                color: white;
            }
            .tempomax th{
                background-color: #cc3300;
                color: yellow;
            }
        </style>
        <div class="modal fade" id="operador" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog" role="document" >
                <div class="modal-content">
                    <div class="modal-header bg-warning">
                        <h5 class="modal-title text-warning" id="linha1"><strong>Senha para acesso:</strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="input-group">
                            <span class="input-group-addon">Usuário: <i class="fa fa-user fa-lg" aria-hidden="true"></i></span> 
                            <input type="text" class="form-control" id="cusuario" style="text-transform: uppercase;">
                            <span class="input-group-addon"></span> 
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon">Senha: <i class="fa fa-lock fa-lg" aria-hidden="true"></i></span> 

                            
                            <input type="password" class="form-control" id="csenha">
                            <span id="nnumero" class="input-group-addon"></span> 
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" id="btok">Ok</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="../assets/components/jquery/jquery.min.js"></script>
        <script src="../assets/components/jquery-mask/jquery.mask.min.js"></script>
        <script src="../assets/components/bootstrap/js/bootstrap.min.js"></script>
        <script src="../assets/components/bootbox/mybootbox.js"></script>
        <script src="../js/consoft.js"></script>
        <script>

            $("#operador").modal('show');
            $("#cusuario").focus();
            $("#btok").on("click", function () {
                if (!$("#cusuario").val()) {
                    bootbox.alert({
                        message: "Informe um usuário",
                        colorType: "warning",
                        sound: "warning",
                        timeOut: 10000,
                        callback: function () {
                            $("#cusuario").focus()
                        }
                    });
                    return false;
                }
                if (!$("#csenha").val()) {
                    bootbox.alert({
                        message: "Informe a senha",
                        colorType: "warning",
                        sound: "warning",
                        timeOut: 10000,
                        callback: function () {
                            $("#csenha").focus()
                        }
                    });
                    return false;
                }
                $.ajax({
                    method: "POST",
                    url: "login1.php",
                    cache: false,
                    data: {usuario: $("#cusuario").val(),
                        senha: $("#csenha").val(),
                        numero: $("#nnumero").html(),
                        terminal: '<?php echo pegavar("terminal") ?>',
                        modulo: '<?php echo pegavar("modulo") ?>'
                    }
                }).done(function (e) {
                    var aret = JSON.parse(e);
                    if (aret.erro != 0) {
                        bootbox.alert({
                            message: "Login inválido",
                            colorType: "danger",
                            sound: "danger",
                            timeOut: 10000,
                            callback: function () {
                                $("#cusuario").focus();
                                $("#cusuario").val("");
                                $("#csenha").val("");
                                $("#nnumero").html("");
                                return false;
                            }
                        });
                        return false;

                    }
                    window.location.href = '<?php echo pegavar("location") . "&sid=" ?>' + aret["sid"];
                    return false;
                }).fail(function (e, d) {

                });
                return false;
            });
            $("#cusuario").on("blur", function () {
                if (!this.value) {
                    $("#nnumero").html("");
                } else {
                    $.ajax({
                        method: "POST",
                        url: "login1.php",
                        cache: false,
                        data: {usuario: $("#cusuario").val()}
                    }).done(function (e) {
                        var aret = JSON.parse(e);
                        var naux=parseInt(Math.random()*1000);
                        $("#nnumero").html(naux%parseInt(aret.numero));
                        if (aret.nome) {
                            $("#cusuario").val(aret.nome);
                        }
                        return false;
                    }).fail(function (e, d) {
                        $("#nnumero").val("");
                    });

                }
            });
<?php
if (pegavar("timeout") == "true") {
    ?>
                bootbox.alert({
                    message: "Login Expirado",
                    colorType: "danger",
                    sound: "danger",
                    timeOut: 10000,
                    callback: function () {
                        $("#cusuario").focus();
                        $("#cusuario").val("");
                        $("#csenha").val("");
                        $("#nnumero").html("");
                        return false;
                    }
                });

    <?php
}
?>
        </script>
    </body>

</html>



