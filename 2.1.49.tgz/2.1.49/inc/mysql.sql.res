<?php
error_reporting(E_ALL);
ini_set('display_errors',0);ini_set('display_startup_erros',0);

$server ="192.168.12.121";
$port = "3306";
$user = "root";
$password = "KoNeCt@3313" ;
$database = "abdel";
//$lCfRdd=true;
/*
 $server ="10.11.11.100";
$port = "3306";
$user = "root";
$password = "KoNeCt@3313" ;
$database = "cec";

 */
//$ccommit="http://192.168.12.100/cgi-bin/mediator";
//$ccommit_new="http://192.168.12.103/cgi-bin.new/mediator";
$ccommit_new="http://localhost/MediatorPhp/hscript.php";
$ccommit_web="http://192.168.12.110/cgi-bin/medweb.cgi";
$cNomeCli="Consoft Informática S.A.";
$titulo="CecVendas";
$nLarguraImpressao="48%";
$lLadoALado=true;
$lCliente=true;
$lImprimeDireto=true;

if (file_exists("inc/connect.php")) {
    require 'connect.php';
}
/*NAO ESQUECER DE INSTLAR O PHP5-OPENSSL
 * e php5-gd
 * 
 */ 

/*
 $mail_server="smtp.gmail.com";
 
$mail_ssl="ssl";
$mail_user="webcellbr@gmail.com";
$mail_password="rsk24432595";
$mail_port="465";
$mail_zone="America/Sao_Paulo";
$mail_from="webcellbr@gmail.com";
$mail_name="Sistema WebCell";
$mail_cabecalho="<img src=\"http://www.zambi.com.br/webcell/consoft.jpg\"><BR><h2><b>WebCell - Sistema de vendas On-Line</b><BR>";
$mail_rodape="<p><font color=black size=1>
Essa mensagem é destinada exclusivamente ao seu destinatário e pode conter informações confidenciais,<br> 
protegidas por sigilo profissional ou cuja divulgação seja proibida por lei. <br>
O uso não autorizado de tais informações é proibido e está sujeito às penalidades cabíveis. <br>
<hr>
Este mensaje se dirige exclusivamente a su destinatario y puede contener información que es confidencial <br>
y protegido por un secreto profesional o cuya divulgación esté prohibida por la ley. <br>
El uso no autorizado de esa información está prohibida y sujeta a las sanciones aplicables. <BR>
<hr>
This message is intended exclusively for its addressee and may contain information that is confidential <br>
and protected by a professional privilege or whose disclosure is prohibited by law. <br>
Unauthorized use of such information is prohibited and subject to applicable penalties.</p>";
*/
?>