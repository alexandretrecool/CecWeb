<?php

//require("config.php");

$language = array();
$language["usuario"] = array("Usuário", "Usuario", "User");
$language["senha"] = array("Senha", "Clave", "Password");
$language["versao"] = array("Versão", "Versión", "Version");
$language["usuario ou senha invalidos"] = array("Usuário ou senha inválidos", "Usuario o clave no valida", "Invalid username or password");
$language["usuario nao permitido"] = array("Usuário não permitido", "Usuario no permitido", "Unallowed user");
$language["configuracion de acessos"] = array("Configuração de acessos", "Configuración de acessos", "Access setup");
$language["ventas producto"] = array("Vendas de produto", "Ventas de producto", "Product sales");
$language["ventas cliente"] = array("Vendas por cliente", "Ventas por cliente", "Sales by customer");
$language["posicion de stock"] = array("Posição de estoque", "Posición de stock", "Stock position");
$language["ventas grupo mensual"] = array("Vendas mensais por grupo", "Ventas mensuales por grupo", "Monthly sales by group");
$language["ventas plazo medio"] = array("Vendas por prazo médio", "Ventas por plazo medio", "Sales by average term");
//$language[""] = array("","","");
$language["ubique la opcion"] = array("Selecione a opção", "Ubique la opción", "Select the option");
$language["salir"] = array("Sair", "Salir", "Exit");
$language["acceso"] = array("Acesso", "Acceso", "Access");
$language["relatorio"] = array("Relatório", "Listado", "Report");
$language["listado de ventas con plazo"] = array("Relatorio de vendas por prazo médio", "Listado de ventas por plazo medio", "Sales report by average term");
$language["listado de ventas por cliente"] = array("Relatório de vendas por cliente", "Listado de ventas por cliente", "Sales report by customer");
$language["tienda"] = array("Loja", "Tienda", "Store");
$language["cliente"] = array("Cliente", "Cliente", "Customer");
$language["producto"] = array("Produto", "Producto", "Product");
$language["fechas"] = array("Datas", "Fechas", "Dates");
$language["fecha"] = array("Data", "Fecha", "Date");
$language["vendedor"] = array("Vendedor", "Vendedor", "Vendor");
$language["nota"] = array("Nota", "Nota", "Invoice");
$language["valor"] = array("Valor", "Valor", "Value");
$language["agrupar"] = array("Agrupar", "Agrupar", "Group");
$language["hasta"] = array("Até", "Hasta", "To");
$language["ordem"] = array("Ordem", "Orden", "Order");
$language["volver"] = array("Voltar", "Volver", "Back");
$language["limpar"] = array("Limpar", "Limpiar", "Clear");
$language["enviar"] = array("Enviar", "Enviar", "Send");
$language["codigo no es valido"] = array("Codigo inválido", "Codigo no es valido", "Invalid code");
$language["codigo no existe"] = array("Codigo não existe", "Codigo no existe", "Code does not exist");
$language["fechas no validas"] = array("Datas inválidas", "Fechas no validas", "Invalid dates");
$language["emision"] = array("Emissão", "Emisión", "Emission");
$language["periodo"] = array("Período", "Periodo", "Period");
$language["todas"] = array("Todas", "Todas", "All");
$language["todos"] = array("Todos", "Todos", "All");
$language["itens"] = array("Itens", "Itens", "Items");
$language["contado"] = array("Vista", "Contado", "Cash");
$language["plazo"] = array("Prazo", "Plazo", "Credit");
$language["pagado"] = array("Pago", "Pagado", "Paid");
$language["plazo medio"] = array("Prazo médio", "Plazo medio", "Average term");
$language["total"] = array("Total", "Total", "Total");
$language["total general"] = array("Total geral", "Total general", "Grand total");
$language["total parcial"] = array("Total parcial", "Total parcial", "Partial total");
$language["configuracion de accesos"] = array("Configuração de acessos", "Configuración de accesos", "Access setup");
$language["descripccion"] = array("Descrição", "Descripción", "Description");
$language["nivel exigido"] = array("Nivel exigido", "Nivel exigido", "Required level");
$language["operadores bloqueados"] = array("Operadores bloqueados", "Operadores bloqueados", "Blocked users");
$language["ninguno"] = array("Nenhum", "Ninguno", "None");
$language["seleccion"] = array("Seleção", "Seleción", "Select");
$language["acesso invalido"] = array("Acesso inválido", "Acceso no valido", "Invalid access");
$language["acceso no valido"] = array("Acesso inválido", "Acceso no valido", "Invalid access");
$language["listado de ventas de productos"] = array("Relatorio de vendas de Produtos", "Listado de ventas de productos", "Product sales report");
$language["informe un producto"] = array("Informe um produto", "Informe un producto", "Inform a product");
$language["mes"] = array("Mês", "Mes", "Month");
$language["cantidad"] = array("Quantidade", "Cantidad", "Amount");
$language["media"] = array("Média", "Media", "Average");
$language["nombre"] = array("Nome", "Nombre", "Name");
$language["cresciente"] = array("Crescente", "Cresciente", "Growing");
$language["decresciente"] = array("Decrescente", "Decresciente", "Decreasing");
$language["el numero maximo de periodos es"] = array("O número máximo de períodos é:", "El numero maximo de periodos es:", "The maximum number of periods is:");
$language["listado de stock"] = array("Relatorio de estoque", "Listado de stock", "Stock report");
$language["grupo"] = array("Grupo", "Grupo", "Group");
$language["proveedor"] = array("Fornecedor", "Proveedor", "Supplier");
$language["marca"] = array("Marca", "Marca", "Brand");
$language["precio unitario"] = array("Preço unitário", "Precio unitario", "Unit price");
$language["costo"] = array("Custo", "Costo", "Cost");
$language["minimo"] = array("Minimo", "Minimo", "Minimum");
$language["venta"] = array("Venda", "Venta", "Sale");
$language["margen"] = array("Margem", "Margen", "Margin");
$language["precio total"] = array("Preço total", "Precio total", "Total price");
$language["porcientual"] = array("Percentual", "Porcientual", "Percentage");
$language["parcial"] = array("Parcial", "Parcial", "Partial");
$language["operador"] = array("Operador", "Operador", "Operator");
$language["saldo"] = array("Saldo", "Saldo", "Stock");
$language["valor total"] = array("Valor Total", "Valor Total", "Grand total");
$language["general"] = array("Geral", "General", "Main");
$language["Uno o mas opciones deben ser elegidas"] = array("Uma ou mais opções devem ser escolhidas", "Uno o mas opciones deben ser elegidas", "One or more options must be chosen");
$language["emitir listado"] = array("Emitir relatorio", "Emitir el listado", "Issue report");
$language["aguarde, procesando"] = array("Aguarde, processando...", "Aguarde, procesando...", "Wait, processing...");
$language["listar clientes"] = array("Listar clientes", "Listar clientes", "List customers");
$language["consulta de clientes"] = array("Consulta de clientes", "Consulta de clientes", "Customers inquiry");
$language["consulta de productos"] = array("Consulta de produtos", "Consulta de productos", "Products inquiry");
$language["buscar"] = array("Procurar", "Buscar", "Search");
$language["inicio"] = array("Início", "Inicio", "Start");
$language["medioo"] = array("Meio", "Medio", "Middle");
$language["fantasia"] = array("Fantasia", "Fantasia", "Trading name");
$language["cliente no achado"] = array("Cliente não encontrado", "Cliente no achado", "Customer not found");
$language["producto no achado"] = array("Produto não encontrado", "Producto no achado", "Product not found");
$language["error del sistema"] = array("Erro do sistema", "Error del sistema", "System error");
$language["mensaje del sistema"] = array("Mensagem do sistema", "Mensaje del sistema", "System message");
$language["Esta nao e uma conexao segura.<br><br><b>Incie com https://...."] = array("Esta não e uma conexao segura.<br><br><b>Inicie com 'https://' ao invés de 'http://'.", "Esta no es una conexión segura.<br><br><b>Empeze con 'https://' en vez de 'http://'.", "This is not a safe connection.<br><br><br>Start with 'https://' instead of 'http://'.");
$language["error accendendo al servidor sql"] = array("Erro acessando o servidor SQL:", "Error accendendo al servidor SQL:", "Error accessing SQL server:");
$language["la version instalada es inferior a la actual.<br>instalada: "] = array("A versão instalada é inferior a atual.<br>Instalada: ", "La version instalada es inferior a la actual.<br>Instalada: ", "The installed version is inferior to the latest.");
$language["<br>utilizada :"] = array("<br>Utilizada: ", "<br>Utilizada: ", "<br>Used: ");
$language["identificador no valido"] = array("Identificador de operação inválido", "Identificador de operaccción no valido", "Invalid operation identifier");
$language["tiempo expirado"] = array("Tempo de utilização expirado.<BR>Entre novamente no sistema.", "Tiempo de utilización expirado.<br>Ingrese nuevamente nel sistema.", "Connection timeout.<br>Login the system again.");
$language["sistema accesado en otro local o"] = array("Sistema acessado em outro local ou", "Sistema accesado en otro local o", "System logged-in other computer or");
$language["relatorios"] = array("Relatórios", "Listados", "Reports");
$language["ultimos accesos"] = array("Últimos acessos", "Ultimos accesos", "Last hits");
$language["ventas y ganancia"] = array("Vendas e lucros", "Ventas y ganancias", "Sales and profit");
$language["deudas de clientes"] = array("Dívidas de clientes", "Deudas de clientes", "Debts of customers");
$language["stock deposito"] = array("Estoque disponível no depósito", "Stock disponible en el depósito", "Stock available into depot");
$language["stock tiendas"] = array("Estoque disponível na loja", "Stock disponible en la tienda", "Stock available into store");
$language["relatorios impressos no gerente"] = array("Relatórios impressos no Gerente®", "Listados impresos en Gerente®", "Reports printed in Gerente®");
$language["codigo"] = array("Código", "Codigo", "Code");
$language["relatorios web"] = array("Relatórios Web", "Relatorios Web", "Web reports");

$language["autorizacao negada"] = array("Autorização Negada", "Autorización Denegada", "Authorization Denied");

$ncount=0;

$ncount++;$language["Par_$ncount"]=array("Erro acessando servidor","Error al acceder al servidor","Error accessing the server");
$ncount++;$language["Par_$ncount"]=array("Cliente não localizado","Cliente no encontrado","Cusotmer not found");
$ncount++;$language["Par_$ncount"]=array("Este cliente","Este Cliente","This customer");
$ncount++;$language["Par_$ncount"]=array("É distribuidor e seu registro está vencido. \nVenceu em","Es distribuidor y su registro ha caducado. \nCaducó en","He is a distributor and his registration is expired. \nWon on");
$ncount++;$language["Par_$ncount"]=array("Erros de parâmetros","Errores de parámetros","Parameter errors");
$ncount++;$language["Par_$ncount"]=array("Cliente sem RUC/RG","Cliente sin RUC/RG","No RUC/RG for Customer");
$ncount++;$language["Par_$ncount"]=array("Nada presente na lista","No hay nada en la lista","Nothing on the list");
$ncount++;$language["Par_$ncount"]=array("Operador não localizado","Operador no achado","Operator not found");
$ncount++;$language["Par_$ncount"]=array("Senha inválida","Clave no es válida","Invalid Password");
$ncount++;$language["Par_$ncount"]=array("Vendedor não cadastrado para o usuário","Vendedor no registrado para usuario","Seller not registered for user");
$ncount++;$language["Par_$ncount"]=array("Sem loja cadastrada para o usuário","Ninguna tienda registrada para el usuario","No store registered for the user");
$ncount++;$language["Par_$ncount"]=array("Nota já finalizada no CEC\n sob nº","Nota ya completada en CEC \n bajo el nº","Note already completed at CEC \n under nº");
$ncount++;$language["Par_$ncount"]=array("Nome de cliente já existe me outro código","El nombre del cliente ya existe con otro código","Customer name already exists with another code");
$ncount++;$language["Par_$ncount"]=array("E-mail de cliente já existe em outro código","E-Mail del cliente ya existe con otro código","Customer E-mail already exists with another code");
$ncount++;$language["Par_$ncount"]=array("RG de cliente já existe em outro código","RUC/RG del cliente ya existe con otro código","Customer RG already exists with another code");
$ncount++;$language["Par_$ncount"]=array("Erro no sql.","Error en SQL","Erro on the sql");
$ncount++;$language["Par_$ncount"]=array("Erro adicionando no arquivo","Error al agregar al archivo","Error adding to file");
$ncount++;$language["Par_$ncount"]=array("Nota zerada","Nota vacía","Empty note");
$ncount++;$language["Par_$ncount"]=array("Nada a zerar","Nada que resetear","Nothing to reset");
$ncount++;$language["Par_$ncount"]=array("Loja","Tienda","Store");
$ncount++;$language["Par_$ncount"]=array("Saldo","Saldo","Stock");
$ncount++;$language["Par_$ncount"]=array("Pend","Pend","Pend");
$ncount++;$language["Par_$ncount"]=array("Total","","");
$ncount++;$language["Par_$ncount"]=array("Etiqueta não localizada","Etiqueta no achada","Label not found");
$ncount++;$language["Par_$ncount"]=array("Produto já lançado nesta Venda","Producto ya lanzado en esta Venta","Product already launched in this Sale");
$ncount++;$language["Par_$ncount"]=array("Código inválido na grade","Codigo de grade no válido","Invalid grid code");
$ncount++;$language["Par_$ncount"]=array("GRADE Inválida ou sem saldo","Grade no valida o sin saldo","Invalid Grid or no stock");
$ncount++;$language["Par_$ncount"]=array("Digito verificador inválido","Dígito de control no válido","Invalid check digit");
$ncount++;$language["Par_$ncount"]=array("Nota não passada","Nota no pasada","Note not informed");
$ncount++;$language["Par_$ncount"]=array("Nota Deletada","Nota Borrada","Deleted note");
$ncount++;$language["Par_$ncount"]=array("Nada presente na lista","Nada en la Lista","Nothing on the list");
$ncount++;$language["Par_$ncount"]=array("Nota inválida","Nota no es válida","Invalid Note");
$ncount++;$language["Par_$ncount"]=array("Nota está deletada","Nota está borrada","Note is deleted");
$ncount++;$language["Par_$ncount"]=array("Nota não existe","Nota no existe","Note does not exist");
$ncount++;$language["Par_$ncount"]=array("NUMERO NO PAINEL","NUMERO EN EL PANEL","NUMBER IN THE PANEL");
$ncount++;$language["Par_$ncount"]=array("Pedido","Pedido","Order");
$ncount++;$language["Par_$ncount"]=array("Erro acessando SQL","Error accendendo al SQL","SQL Accessing Error");
$ncount++;$language["Par_$ncount"]=array("Erro Gravando dados","Error al guardar datos","Data Write error ");
$ncount++;$language["Par_$ncount"]=array("Registro não encontrado","Registro no achado","Register not found");
$ncount++;$language["Par_$ncount"]=array("Registro deletado","Registro borrado","Register Deleted");
$ncount++;$language["Par_$ncount"]=array("Esperando Autorização","Aguardando Autorización","Authorization Waiting");
$ncount++;$language["Par_$ncount"]=array("Registro Adulterado","Registro Corrompido","Corrupt Register");
$ncount++;$language["Par_$ncount"]=array("Erro Gravando autorização","Error al guardar autorización","Write error saving authorization");
$ncount++;$language["Par_$ncount"]=array("Orçamento","Presupuesto","Budget");
$ncount++;$language["Par_$ncount"]=array("Nota","Nota","Note");
$ncount++;$language["Par_$ncount"]=array("não existe","no existe","not found");
$ncount++;$language["Par_$ncount"]=array("está deletada","está borrada","is deleted");
$ncount++;$language["Par_$ncount"]=array("já está paga","Ya está pagada","already paid");
$ncount++;$language["Par_$ncount"]=array("não é deste vendedor","no es de este vendedor","not from this seller");
$ncount++;$language["Par_$ncount"]=array("Erros Bloqueando NOTA","Errores Bloquando Nota","Locking errors on the Note");
$ncount++;$language["Par_$ncount"]=array("não é da loja que você tem acesso","no es desde la tienda a la que tienes acceso","it is not from the store that you have access");
$ncount++;$language["Par_$ncount"]=array("Orçamento não existe","Presupuesto no existe","Budget not found");
$ncount++;$language["Par_$ncount"]=array("Orçamento está deletado","Presupuesto está borrado","Deleted Budget");
$ncount++;$language["Par_$ncount"]=array("Orçamento não é da loja que você tem acesso","","");
$ncount++;$language["Par_$ncount"]=array("Erros adicionando registro","Presupuesto no es desde la tienda a la que tienes acceso","Budget is not from the store that you have access");
$ncount++;$language["Par_$ncount"]=array("Orçam","Presu","Budget");
$ncount++;$language["Par_$ncount"]=array("Valor","Valor","Value");
$ncount++;$language["Par_$ncount"]=array("Emissão","Emisión","Emission");
$ncount++;$language["Par_$ncount"]=array("Cliente","Cliente","Customer");
$ncount++;$language["Par_$ncount"]=array("Itens","Itenes","Items");
$ncount++;$language["Par_$ncount"]=array("Você não tem mais créditos para relatórios hoje.","Hoy ya no tiene créditos de informes.","You no longer have reporting credits today.");
$ncount++;$language["Par_$ncount"]=array("Horário não permitido para relatório.\nEmita entre","Tiempo no permitido para informe. \nEmitir entre","Time not allowed for reporting. \nSend between");
$ncount++;$language["Par_$ncount"]=array("Doc","Doc","Doc");
$ncount++;$language["Par_$ncount"]=array("Nota","Nota","Note");
$ncount++;$language["Par_$ncount"]=array("Vence","Expira","Expire");
$ncount++;$language["Par_$ncount"]=array("Juros","Interess","Interest");
$ncount++;$language["Par_$ncount"]=array("Recebe","Recibe","Receive");
$ncount++;$language["Par_$ncount"]=array("Vendedor","Vendedor","Seller");
$ncount++;$language["Par_$ncount"]=array("Sem Seguro","Sin seguro","No insurance");
$ncount++;$language["Par_$ncount"]=array("Ambiente de autorização não configurado para o vendedor","Entorno de autorización no configurado para el vendedor","Authorization environment not set up for the seller");
$ncount++;$language["Par_$ncount"]=array("Sem operadores no Ambiente de autorização configurado para o vendedor","No hay operadores en el entorno de autorización configurado para el vendedor","No operators in the Authorization Environment configured for the seller");
$ncount++;$language["Par_$ncount"]=array("Vendas está vazia","Ventas está en cero","Empty Sale");
$ncount++;$language["Par_$ncount"]=array("Este cliente","Este Cliente","This Customer");
$ncount++;$language["Par_$ncount"]=array("Está com problemas no ARQUIVO","Tiene problemas con el ARCHIVO","Having problems with the FILE");
$ncount++;$language["Par_$ncount"]=array("Erro gravando em","Error guardando en","Error saving in");
$ncount++;$language["Par_$ncount"]=array("Produto sem saldo no momento","Producto sin saldo en el momento","no stock for the product");
$ncount++;$language["Par_$ncount"]=array("Quantidade ultrapassa o saldo GERAL","La cantidad excede el saldo GENERAL","Quantity exceeds the GENERAL stock");
$ncount++;$language["Par_$ncount"]=array("Erros de parametros","Errores de parametros","Parameter errors");
$ncount++;$language["Par_$ncount"]=array("Nota não passada","Nota no informada","Note no passed");
$ncount++;$language["Par_$ncount"]=array("Nota Deletada","Nota borrada","Deleted Note");
$ncount++;$language["Par_$ncount"]=array("Nada presente na lista","No hay nada en la lista","Nothing on the list");
$ncount++;$language["Par_$ncount"]=array("Sem comissão a lançar","Sin comisión a lanzar","No comission to launch");
$ncount++;$language["Par_$ncount"]=array("Autorização Concedida","Autorización Concedida","Authorization granted");

/*
$language["$ncount"]=array("Erro acessando servidor
$language["$ncount"]=array("Cliente não localizado
$language["$ncount"]=array("Este cliente
$language["$ncount"]=array("É distribuidor e seu registro está vencido. \nVenceu em
$language["$ncount"]=array("Erros de parâmetros
$language["$ncount"]=array("Cliente sem RUC/RG
$language["$ncount"]=array("Nada presente na lista        
$language["$ncount"]=array("Operador não localizado
$language["$ncount"]=array("Senha inválida
$language["$ncount"]=array("Vendedor não cadastrado para o usuário
$language["$ncount"]=array("Sem loja cadastrada para o usuário
$language["$ncount"]=array("Nota já finalizada no CEC\n sob nº
$language["$ncount"]=array("Nome de cliente já existe me outro código
$language["$ncount"]=array("E-mail de cliente já existe em outro código
$language["$ncount"]=array("RG de cliente já existe em outro código
$language["$ncount"]=array("Erro no sql.
$language["$ncount"]=array("Erro adicionando no arquivo
$language["$ncount"]=array("Nota zerada
$language["$ncount"]=array("Nada a zerar
$language["$ncount"]=array("Erros de parâmetros
$language["$ncount"]=array("Loja
$language["$ncount"]=array("Saldo
$language["$ncount"]=array("Pend
$language["$ncount"]=array("Total
$language["$ncount"]=array("Etiqueta não localizada
$language["$ncount"]=array("Produto já lançado nesta Venda
$language["$ncount"]=array("Código inválido na grade
$language["$ncount"]=array("GRADE Inválida ou sem saldo
$language["$ncount"]=array("Digito verificador inválido
$language["$ncount"]=array("Nota não passada
$language["$ncount"]=array("Nota Deletada
$language["$ncount"]=array("Cliente sem RUC/RG
$language["$ncount"]=array("Nada presente na lista
$language["$ncount"]=array("Nota inválida
$language["$ncount"]=array("Nota está deletada
$language["$ncount"]=array("Nota não existe
$language["$ncount"]=array("NUMERO NO PAINEL
$language["$ncount"]=array("Pedido
$language["$ncount"]=array("Erro acessando SQL
$language["$ncount"]=array("Erro Gravando dados
$language["$ncount"]=array("Registro não encontrado
$language["$ncount"]=array("Registro deletado
$language["$ncount"]=array("Esperando Autorização
$language["$ncount"]=array("Registro Adulterado
$language["$ncount"]=array("Erro Gravando autorização
$language["$ncount"]=array("Orçamento
$language["$ncount"]=array("Nota
$language["$ncount"]=array("não existe
$language["$ncount"]=array("está deletada
$language["$ncount"]=array("já está paga
$language["$ncount"]=array("não é deste vendedor
$language["$ncount"]=array("Erros Bloqueando NOTA
$language["$ncount"]=array("não é da loja que você tem acesso
$language["$ncount"]=array("Orçamento não existe
$language["$ncount"]=array("Orçamento está deletado
$language["$ncount"]=array("Orçamento não é da loja que você tem acesso
$language["$ncount"]=array("Erros adicionando registro
$language["$ncount"]=array("Orçam
$language["$ncount"]=array("Valor
$language["$ncount"]=array("Emissão
$language["$ncount"]=array("Cliente
$language["$ncount"]=array("Itens
$language["$ncount"]=array("Você não tem mais créditos para relatórios hoje.
$language["$ncount"]=array("Horário não permitido para relatório.\nEmita entre
$language["$ncount"]=array("Doc
$language["$ncount"]=array("Nota
$language["$ncount"]=array("Vence
$language["$ncount"]=array("Juros
$language["$ncount"]=array("Recebe
$language["$ncount"]=array("Vendedor
$language["$ncount"]=array("Sem Seguro
$language["$ncount"]=array("Ambiente de autorização não configurado para o vendedor
$language["$ncount"]=array("Sem operadores no Ambiente de autorização configurado para o vendedor
$language["$ncount"]=array("Vendas está vazia
$language["$ncount"]=array("Este cliente
$language["$ncount"]=array("Está com problemas no ARQUIVO
$language["$ncount"]=array("Erro gravando em
$language["$ncount"]=array("Produto sem saldo no momento
$language["$ncount"]=array("Quantidade ultrapassa o saldo GERAL
$language["$ncount"]=array("Erros de parâmetros
$language["$ncount"]=array("Nota não passada
$language["$ncount"]=array("Nota Deletada
$language["$ncount"]=array("Nada presente na lista
$language["$ncount"]=array("Sem comissão a lançar
*/        


        










        
        
        



























        
        
        
        




        



        




        








function _tr($cstr){
    global $language;
    $nidioma=VeSession("idioma");//$_SESSION["idioma"];
    if (!$nidioma){
        $nidioma=1;
    }
    if ($nidioma==1){
        return $cstr;
    }
    foreach ($language as $value) {
        if (trim(strtoupper($value[0]))==trim(strtoupper($cstr))){
            if ($value[$nidioma-1]!==''){
                $cstr=$value[$nidioma-1];
            }
            break;
        }
    }
    return $cstr;
}
function idm($str) {
    $caux="";
    global $idioma;
    global $language;
    
    $caux=$str;
    $cstr = strtolower($str);
    $npos = iif($idioma == "ES", 1, iif($idioma == "US", 2, 0));


    if (!array_key_exists($cstr, $language))
            return $caux;
    
    $cret = $language[$cstr][$npos];

    if (!$cret)
        $cret = $caux;

    return $cret;
}
?>
