<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);
$ctimezone = "America/Sao_Paulo";
$lerro = false;
if ($lerro) {
    error_reporting(E_ALL);

    ini_set('display_errors', '1');      // Mostra na tela
    ini_set('display_startup_errors', '1');

    ini_set('log_errors', '1');          // Grava no log
    ini_set('error_log', '/var/log/httpd/ecommerce.log'); // ou outro arquivo
}
set_time_limit(10 * 60);


date_default_timezone_set($ctimezone);

$lweb = $_SESSION["web"];
$cChave = "MIIDRzCCArCgAwIBAgICVYkwDQYJKoZIhvcNAQEFBQAwgb8xCzAJBgNVBAYTAi0t
MRIwEAYDVQQIDAlTb21lU3RhdGUxETAPBgNVBAcMCFNvbWVDaXR5MRkwFwYDVQQK
DBBTb21lT3JnYW5pemF0aW9uMR8wHQYDVQQLDBZTb21lT3JnYW5pemF0aW9uYWxV
bml0MSAwHgYDVQQDDBdzZXJ2ZXIxMC5jb25zb2Z0LmNvbS5weTErMCkGCSqGSIb3
DQEJARYccm9vdEBzZXJ2ZXIxMC5jb25zb2Z0LmNvbS5weTAeFw0xNDEwMDMwODMw
NTRaFw0xNTEwMDMwODMwNTRaMIG/MQswCQYDVQQGEwItLTESMBAGA1UECAwJU29t
ZVN0YXRlMREwDwYDVQQHDAhTb21lQ2l0eTEZMBcGA1UECgwQU29tZU9yZ2FuaXph
dGlvbjEfMB0GA1UECwwWU29tZU9yZ2FuaXphdGlvbmFsVW5pdDEgMB4GA1UEAwwX
c2VydmVyMTAuY29uc29mdC5jb20ucHkxKzApBgkqhkiG9w0BCQEWHHJvb3RAc2Vy
dmVyMTAuY29uc29mdC5jb20ucHkwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGB
ALhnCHk3loDXqe5NvM+tgMd+v/cXKDWzYHfSd2LHQXcbSa/I+rxhpVKaM+K2bgkl
+9j/2CaPTBus1mX+jZvi6l2HGIRC3CE/TobwzRmmhvU5zQ+0jd5BYvpz+x8Pbuea
NZCw+/2bUFFbc9Vb8gpIt6nCvfXzb0uqn6ZFb7iadHw5AgMBAAGjUDBOMB0GA1Ud
DgQWBBRW+z1SUPl8E60dkWa8kKWABpI6mzAfBgNVHSMEGDAWgBRW+z1SUPl8E60d
kWa8kKWABpI6mzAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAJD4hfVN
OozCi/OTM8f7ze/YWq7QUECSkCkhfWNtFq3rxzHrx3fwmu3HSfmf4RSVd5CuY3Zr
jVfrG63rVZDRU6lZuBURxoVysgB1obEHjZjJuFAYhv+6deCMjuUa+H+3fwt8t1LB
/r9yRP+6lOB8UHwvR2Gpx9Cauf5IhaNJAVA7
";

global $db;
global $sid;
define("SP", "&nbsp;");
define("CR", "<br>");
define("AZUL", "#000080");
define("CIAN", "#7FFFD4");
define("VERM", "#FF0000");
define("BRAN", "#FFFFFF");
define("PRET", "#000000");
define("VERD", "#00FF00");
define("MAGE", "#FF00FF");
define("MARR", "#800000");
define("CINZ", "#808080");
define("AMAR", "#FFFF00");
define("OLIV", "#808000");
define("AZUF", "#0000FF");
define("LILA", "#800080");
require_once "mysql.php";
require_once "classes.php";
require_once "classes_1.php";
require_once "language.php";
require_once "Mobile_Detect.php";
require_once "mediator.php";

$aConfigCec = array();


$crosto = "./consoft.css";
$versao = "0.13";
$clanguage = "BR";
$cempresa = "Abba";
$data_min = "01/01/2000";
$data_max = "31/12/2019";
$ausuario = array(0, "", 0);
$SitePrincipal = "http://www.cellshop.com.py";

$dir_relatorios_pdf = "/home/sist/sistema/gerente/impress/web";
$refresh_pdf_segundos = 10;
$limite_ler_pdf = 10;
$pdf_em_nova_janela = 1;
$local_tamanho = 5;

define("cfg_max", 14);
define("cfg_tlimite", 1);
define("cfg_tlimpa", 2);
define("cfg_idioma", 3);
define("cfg_mserver", 4);
define("cfg_mssl", 5);
define("cfg_muser", 6);
define("cfg_mpassword", 7);
define("cfg_mport", 8);
define("cfg_mzone", 9);
define("cfg_mfrom", 10);
define("cfg_mname", 11);
define("cfg_mcabecalho", 12);
define("cfg_mrodape", 13);
define("cfg_tpendente", 14);

$db = '';

$atiposnomes = array("RC" => "Recepcionado",
    "AN" => "Em Análise",
    "CT" => "Análise de Custos",
    "AP" => "Em Aprovação",
    "AV" => "Aprovado",
    "EX" => "Em Execução",
    "PC" => "Aguardando Peças",
    "ET" => "Executado",
    "CK" => "Em Checagem",
    "EN" => "Entregue",
    "OT" => "Outros",
    "RJ" => "Rejeitado",
    "ST" => "Substituição"
);

        $aSenhaAutoriza = array(
              "PRODUTO_ENT" => 1
            , "GRUPO_ENT" => 2
            , "CLIENTE_ENT" => 3
            , "EMPRESA_ENT" => 4
            , "VENDEDO_ENT" => 5
            , "CAMBIOS_ENT" => 6
            , "TIPOCLI_ENT" => 7
            , "ZONACLI_ENT" => 8
            , "PRECCLI_ENT" => 9
            , "BANCOS_ENT" => 10
            , "CONTAS_ENT" => 11
            , "HISTOR_ENT" => 12
            , "FORNEC_ENT" => 13
            , "ENTRAD_ENT" => 14
            , "SAIDAS_ENT" => 15
            , "TRANSF_ENT" => 16
            , "REFISC_ENT" => 17
            , "REFINA_ENT" => 18
            , "REGANA_ENT" => 19
            , "REVEND_ENT" => 20
            , "RECLIP_ENT" => 21
            , "RECOMP_ENT" => 22
            , "RETRAN_ENT" => 23
            , "RESUGS_ENT" => 24
            , "RECONF_ENT" => 25
            , "RETIPP_ENT" => 26
            , "CANCEL_SAI" => 27
            , "ORGANI_EST" => 28
            , "DESMCL_ENT" => 29
            , "RECBCL_ENT" => 30
            , "REPACL_ENT" => 31
            , "RESICL_ENT" => 32
            , "DESMFO_ENT" => 33
            , "RECBFO_ENT" => 34
            , "REPAFO_ENT" => 35
            , "RESIFO_ENT" => 36
            , "MOVIME_ENT" => 37
            , "RESMOV_ENT" => 38
            , "CANREC_CLI" => 39
            , "CANPAG_FOR" => 40
            , "CANCAX_CAX" => 41
            , "IMPRES_CFG" => 42
            , "LIMCAD_CLI" => 43
            , "RECBXS_CLI" => 44
            , "RECBXS_FOR" => 45
            , "ORGANI_IND" => 46
            , "ALTCAX_CAX" => 47
            , "INCCAX_CAX" => 48
            , "RELCAX_CAX" => 49
            , "ORGCAX_CAX" => 50
            , "EMPRES_MEN" => 51
            , "CLIENT_CUS" => 52
            , "VENDAS_PRE" => 53
            , "RELCMS_CMS" => 54
            , "DESMBC_CLI" => 55
            , "SAIDAS_REF" => 56
            , "ENTRDA_ALT" => 57
            , "SAIDAS_CUS" => 58
            , "REMAQD_SAI" => 59
            , "REMAVL_SAI" => 60
            , "REPACL_VEN" => 61
            , "RENFSR_VEN" => 62
            , "REFECH_ENT" => 63
            , "REESTV_ENT" => 64
            , "REESTT_ENT" => 65
            , "PRODUT_CUS" => 66
            , "DISTRI_ENT" => 67
            , "REESTC_ENT" => 68
            , "REESTP_ENT" => 69
            , "RERAZA_ENT" => 70
            , "REERSU_ENT" => 71
            , "SAIDAS_CUI" => 72
            , "CONRESU_CLI" => 73
            , "REESTH_ENT" => 74
            , "DESCTO_CLI" => 75
            , "RESUFO_ENT" => 76
            , "CONTEN_ENT" => 77
            , "CONTEIN_ENT" => 78
            , "CONTEN_ALT" => 79
            , "CONCIF_ENT" => 80
            , "BAXDIA_REC" => 81
            , "ENCERRA_ENT" => 82
            , "ALTNFAN_ENT" => 83
            , "ALTERAD_ENT" => 84
            , "SGRUPO_ENT" => 85
            , "TECNICO_ENT" => 86
            , "PECAS_ENT" => 87
            , "SAIDAS_MIN" => 88
            , "PRODUTO_ALT" => 89
            , "NAOCAXA_SAI" => 90
            , "OSTEC_ENT" => 91
            , "OSTEC_CAF" => 92
            , "OSTEC_DEL" => 93
            , "OSTEC_FEC" => 94
            , "OSTEC_ALT" => 95
            , "OSTEC_INC" => 96
            , "INCPR_CON" => 97
            , "ALTPR_CON" => 98
            , "RETIRA_ENT" => 99
            , "PEDIDO_ENT" => 100
            , "LIMITE_CRE" => 101
            , "RECEBE_NOT" => 102
            , "SAIDAS_CAN" => 103
            , "DEVOLU_ENT" => 104
            , "SAIDAS_ALT" => 105
            , "SAIDAS_ALR" => 106
            , "ENTRADA_LUC" => 107
            , "REESCO_ENT" => 108
            , "SAIDAS_CDT" => 109
            , "ENTRADA_DEV" => 110
            , "AJUSTE_ENT" => 111
            , "AJUSTE_SAI" => 112
            , "PASERO_BLO" => 113
            , "ENTPRO_EXC" => 114
            , "ENTPRO_ALT" => 115
            , "AUMPRO_AUM" => 116
            , "SAIDAS_PDT" => 117
            , "DATANT_CEC" => 118
            , "SAIDAS_EAL" => 119
            , "SAIDAS_IAL" => 120
            , "SAIDAS_AAL" => 121
            , "ORCAME_ENT" => 122
            , "ORCAME_ALT" => 123
            , "ORCAME_EXC" => 124
            , "ORCAME_REF" => 125
            , "DESMCL_ALT" => 126
            , "DESMCL_ALP" => 127
            , "DESMCL_EXP" => 128
            , "DESMFO_ALT" => 129
            , "DESMFO_ALP" => 130
            , "DESMFO_EXP" => 131
            , "SAIDAS_PRJ" => 132
            , "ENCERRA_PER" => 133
            , "PRECCLI_ALT" => 134
            , "CLIENTE_ALT" => 135
            , "CLIENTE_INC" => 136
            , "ENTRAD_SUP" => 137
            , "SAIDAS_DES" => 138
            , "CREDITO_ENT" => 139
            , "CREDITO_ALT" => 140
            , "CREPRO_ALT" => 141
            , "CREPRO_EXC" => 142
            , "TIPCLI_ALT" => 143
            , "RELLOG_LOG" => 144
            , "INCPR_MOD" => 145
            , "ALTPR_MOD" => 146
            , "CLIENTE_AAA" => 147
            , "CLIENTE_III" => 148
            , "RECBVL_CLI" => 149
            , "DESMCL_INC" => 150
            , "RECARG_ENT" => 151
            , "RECRED_ENT" => 152
            , "ENTCNF_ENT" => 153
            , "CREVIS_ENT" => 154
            , "PRECFUT_ENT" => 155
            , "PRODUTO_LI1" => 156
            , "PRODUTO_LI2" => 157
            , "RECIGN_ENT" => 158
            , "TIPOCLI_ALT" => 159
            , "PRODUTO_COM" => 160
            , "CARGAS_INC" => 161
            , "CARGAS_ALT" => 162
            , "REFALT_ENT" => 163
            , "ENTRDA_ALE" => 164
            , "TRANSF_ALT" => 165
            , "TRANSF_REF" => 166
            , "TRANSF_DEL" => 167
            , "DESMFO_INC" => 168
            , "ALTCAXD_CAX" => 169
            , "INCCAXD_CAX" => 170
            , "EXCCAXD_CAX" => 171
            , "CREDITO_DEL" => 172
            , "PROD_REST" => 173
            , "RECARG_IMP" => 174
            , "CLIENTE_BLO" => 175
            , "CARGAS_TRO" => 176
            , "IMPRES_LER" => 177
            , "MARCAS_ENT" => 178
            , "OSTEC_COM" => 179
            , "OSTEC_CCM" => 180
            , "OSTEC_REL" => 181
            , "CREVIS_CAN" => 182
            , "SAIDAS_DSV" => 183
            , "CREDITO_INC" => 184
            , "ALTPR_QCX" => 185
            , "CREDITO_VEN" => 186
            , "CAIXA_ABERT" => 187
            , "CAIXA_OPERA" => 188
            , "SAIDAS_CRC" => 189
            , "SAIDAS_CRA" => 190
            , "ENTRADA_CPD" => 191
            , "ENTRADA_CPA" => 192
            , "CLIENTE_DBQ" => 193
            , "RETIRA_REF" => 194
            , "PERSON_ENT" => 195
            , "FATURA_REF" => 196
            , "ENTREG_OPE" => 197
            , "SAIDAS_VEG" => 198
            , "SAIDAS_VEL" => 199
            , "ENTRADA_DIF" => 200
            , "CANRED_CLI" => 201
            , "CREPRO_INC" => 202
            , "KIT_ALT" => 203
            , "CREPRO_NSE" => 204
            , "SAIDAS_UNI" => 205
            , "CAIXA_LOG" => 206
            , "PRAZO_SAI" => 207
            , "PARAM_ALT" => 208
            , "PARAM_RET" => 209
            , "STATU_ALT" => 210
            , "CAIXA_CONS" => 211
            , "SAIDAS_DIA" => 212
            , "SAIDAS_DCT" => 213
            , "CAMION_INC" => 214
            , "CAMION_ALT" => 215
            , "CAMION_LIB" => 216
            , "ULTVEN_PRO" => 217
            , "CAIXAS_FEC" => 218
            , "GPOOPE_INC" => 219
            , "GPOOPE_ALT" => 220
            , "GPOOPE_MOD" => 221
            , "ALTGPO_MOD" => 222
            , "ENTRADA_ALQ" => 223
            , "CREDITO_DIA" => 224
            , "CONTAS_INC" => 225
            , "CONTAS_ALT" => 226
            , "CLIENTE_DIV" => 227
            , "SAIDAS_ATA" => 228
            , "COBRAD_ZER" => 229
            , "COBRAD_NUM" => 230
            , "SAIDAS_ATZ" => 231
            , "CONTAS_ALS" => 232
            , "SAIDAS_APV" => 233
            , "FORNEC_III" => 234
            , "FORNEC_AAA" => 235
            , "SAIDAS_FRT" => 236
            , "PRODUT_CPA" => 237
            , "ORCAME_PRC" => 238
            , "REGANA_ST1" => 239
            , "RECLIP_ST1" => 240
            , "RETIPP_ST1" => 241
            , "SAIDAS_DSP" => 242
            , "WORDPD_REL" => 243
            , "ENTRS1_ENT" => 244
            , "PRODS1_CUS" => 245
            , "ENTRS1_ALT" => 246
            , "ENTPS1_EXC" => 247
            , "ENTRAS1_ALQ" => 248
            , "ENTRAS1_DIF" => 249
            , "SAIDAS_LUN" => 250
            , "SAIST1_LUN" => 251
            , "GUIAS_INC" => 252
            , "GUIAS_ALT" => 253
            , "REMOVG_ENT" => 254
            , "REVEND_CUS" => 255
            , "INCPR1_MOD" => 256
            , "ALTPR1_MOD" => 257
            , "INCPR1_CON" => 258
            , "ALTPR1_CON" => 259
            , "CREDEV_CAX" => 260
            , "GIFTCR_INC" => 261
            , "GIFTCR_ALT" => 262
            , "GIFTCR_EXC" => 263
            , "SAIDAS_DI1" => 264
            , "PRAZO_SAI1" => 265
            , "SERIAL_DEL" => 266
            , "SERIAL_ALT" => 267
            , "SERIAL_ENT" => 268
            , "RESUMO_DAT" => 269
            , "CAIXA_NEGAT" => 270
            , "TABPRZ_INC" => 271
            , "TABPRZ_ALT" => 272
            , "TABPRZ_EXC" => 273
            , "OSTEC_FAT" => 274
            , "OSTEC_REM" => 275
            , "OSTEC_CON" => 276
            , "OSTEC_ORC" => 277
            , "RECOMP1_ENT" => 278
            , "PRODQUA_CON" => 279
            , "SAIDAS_FAT" => 280
            , "CR1DIT_ENT" => 281
            , "CR1DIT_ALT" => 282
            , "CR1PRO_ALT" => 283
            , "CR1PRO_EXC" => 284
            , "CR1DEV_CAX" => 285
            , "CR1DIT_DIA" => 286
            , "CR1DIT_VEN" => 287
            , "CRE1TO_DEL" => 288
            , "CR1PRO_INC" => 289
            , "CRE1TO_INC" => 290
            , "CAIXA_DESC" => 291
            , "MOVIME_FIL" => 292
            , "GRUPO_ALT" => 293
            , "OSTEC_CFC" => 294
            , "OSTEC_SCO" => 295
            , "OSTEC_APC" => 296
            , "OSTEC_TDF" => 297
            , "RECGN_ENT" => 298
            , "RECGN_INC" => 299
            , "RECGN_IMP" => 300
            , "SAIDAS_MIQ" => 301
            , "PARAMS_ALT" => 302
            , "PARAMS_RET" => 303
            , "CHEQRC_ALT" => 304
            , "CHEQPG_ALT" => 305
            , "CAMBSF_ENT" => 306
            , "SAI1_MIN" => 307
            , "SAI1_ALT" => 308
            , "SAI1_VEG" => 309
            , "SAI1_VEL" => 310
            , "PREFOR_ENT" => 311
            , "PREFOR_INC" => 312
            , "PREFOR_ALT" => 313
            , "PREFOR_EXC" => 314
            , "PREFOR_CNF" => 315
            , "PREFOR_REL" => 316
            , "OSTEC_KAB" => 317
            , "OSTEC_AAA" => 318
            , "PRODZER_ENT" => 319
            , "PREFOR_CFP" => 320
            , "MONITO_CON" => 321
            , "SAIDAS_ALD" => 322
            , "SAIDAS1_ALD" => 323
            , "SAIDAS1_CUS" => 324
            , "SAIDAS1_CUI" => 325
            , "DTADIF_STA" => 326
            , "ALTVEN_SUP" => 327
            , "CAIXA_PZTJT" => 328
            , "CAIXA_PZCAR" => 329
            , "EXCEL_REL" => 330
            , "RELAT_TOT" => 331
            , "FORNECE_DIV" => 332
            , "SAIDAS_DAP" => 333
            , "BLOQPRO_ALT" => 334
            , "AJUST1_ENT" => 335
            , "AJUST1_SAI" => 336
            , "CAIXA_CHMNR" => 337
            , "FUNCIO_ENT" => 338
            , "FUNCIO_ALT" => 339
            , "CANVAL_CAX" => 340
            , "SAIDA1_CDT" => 341
            , "CANCE1_SAI" => 342
            , "SAIDA1_CAN" => 343
            , "ALTNFAN1_ENT" => 344
            , "SAIDA1_ALR" => 345
            , "ENTRD1_ALE" => 346
            , "ENTCN1_ENT" => 347
            , "CONSMIN_VDA" => 348
            , "ESTATUS_2" => 349
            , "OSTEC_INP" => 350
            , "FINAN_AJU" => 351
            , "SERIAL_SXE" => 352
            , "PRODUTO_ATX" => 353
            , "ENTPS1_ALT" => 354
            , "CLIENTE_ALV" => 355
            , "CLIENTE_PRZ" => 356
            , "LIMIT1_CRE" => 357
            , "TRANSF_INC" => 358
            , "CLIENTE_OPE" => 359
            , "VENDAS_CONS" => 360
            , "PRODSTK_LIS" => 361
            , "PRODMIN_LIS" => 362
            , "SAIDAAL_ALT" => 363
            , "CHEQPG_REF" => 364
            , "PRECLI_ENT" => 365
            , "PRECLI_INC" => 366
            , "PRECLI_ALT" => 367
            , "PRECLI_EXC" => 368
            , "PRECLI_CNF" => 369
            , "PRECLI_REL" => 370
            , "PRECLI_CFP" => 371
            , "CAMBIOS_INC" => 372
            , "CAMBIOS_ALT" => 373
            , "SAIDAS_ALTN" => 374
            , "OSTEC_IMP" => 375
            , "CHEQCL_ENT" => 376
            , "CHEQCL_TRO" => 377
            , "CLIENTE_ALN" => 378
            , "CLIENTE_REG" => 379
            , "CONFIGU_SEN" => 380
            , "CUSGRUP_CON" => 381
            , "REFIN1_ENT" => 382
            , "MARCAS_COR" => 383
            , "ENTRDA_EXC" => 384
            , "ENTRS1_EXC" => 385
            , "PRODUTO_LOC" => 386
            , "REGRASC_ENT" => 387
            , "REGRASC_INC" => 388
            , "REGRASC_ALT" => 389
            , "REGRASC_EXC" => 390
            , "REGRASB_ENT" => 391
            , "REGRASB_INC" => 392
            , "REGRASB_ALT" => 393
            , "REGRASB_EXC" => 394
            , "PREFOR_CAN" => 395
            , "MINIMO_GRU" => 396
            , "GERAVD_EXC" => 397
            , "OSTEC_DLP" => 398
            , "OSTEC_ECQ" => 399
            , "OSTEC_ELT" => 400
            , "OSTEC_EDG" => 401
            , "OSTEC_ERT" => 402
            , "OSTEC_EOB" => 403
            , "BACKUP_CEC" => 404
            , "SAIDAS_COP" => 405
            , "MENSAGE_INC" => 406
            , "ESTOQE_GRU" => 407
            , "OSTEC_ABN" => 408
            , "OSTEC_FBN" => 409
            , "SAIDAS_CDS" => 410
            , "PROD_MARG" => 411
            , "CRED_CONF" => 412
            , "SAIDAS_MAQ" => 413
            , "CAIXA_ALTIP" => 414
            , "HISTOR_ALT" => 415
            , "CAIXA_HISDB" => 416
            , "SAIDAS_SEP" => 417
            , "SAIDAS_CSEP" => 418
            , "AUTPAG_FOR" => 419
            , "EMPREST_CLI" => 420
            , "SAIDAS_PRV" => 421
            , "PRODUTO_AGR" => 422
            , "CLIENTE_REL" => 423
            , "FORNECE_REL" => 424
            , "SAIVALO_VDA" => 425
            , "SAIDAS_LUP" => 426
            , "CLIENTE_DOC" => 427
            , "PRODUTO_FRD" => 428
            , "SAIDAS_FRD" => 429
            , "SAIDAS_STG" => 430
            , "RELATO_ANT" => 431
            , "PROFLO_CUS" => 432
            , "REGANV_ENT" => 433
            , "ULTCOM_PRO" => 434
            , "NOTADEB_INC" => 435
            , "NOTADEB_ALT" => 436
            , "NOTADEB_ENT" => 437
            , "NOTADEB_EXC" => 438
            , "NOTADB1_INC" => 439
            , "NOTADB1_ALT" => 440
            , "NOTADB1_ENT" => 441
            , "NOTADB1_EXC" => 442
            , "ENTCNFE_ENT" => 443
            , "ENTCNE1_ENT" => 444
            , "ORGANI_DAT" => 445
            , "ORGANI1_DAT" => 446
            , "OSTEC_RCD" => 447
            , "SAIDAS_PREV" => 448
            , "OSTEC_TRO" => 449
            , "SAIDAS_PRM" => 450
            , "CREDITO_SNT" => 451
            , "SAIDAS_PRMA" => 452
            , "NOTADEB_FIN" => 453
            , "SAIDAS_PSEG" => 454
            , "PROMOC_INCL" => 455
            , "PROMOC_ALTE" => 456
            , "PROMOC_ATIV" => 457
            , "PROMOC_DTIV" => 458
            , "CONTAS_SAL" => 459
            , "VDAPDT_PRO" => 460
            , "RELFOB_ENT" => 461
            , "SAIDAS_QSEG" => 462
            , "PRODUTO_AWB" => 463
            , "CONS_CTRF9" => 464
            , "CONS_CTRF11" => 465
            , "CONS_CTRF12" => 466
            , "SAIDAS_LFAE" => 467
            , "CAMBIO_MUDA" => 468
            , "CAIXA_TRACT" => 469
            , "FLUXFIN_INC" => 470
            , "FLUXFIN_ALT" => 471
            , "FLUXFIN_EXC" => 472
            , "FLUXFIN_REL" => 473
            , "FLUXFIN_ENT" => 474
            , "FLUXFIN_CBN" => 475
            , "FLUXFIN_CCB" => 476
            , "FLUXFIN_ALV" => 477
            , "FLUXFIN_CRE" => 478
            , "SAIDAS_CSG" => 479
            , "GRUPO_GUIA" => 480
            , "SAIDAS_TMP" => 481
            , "CLIENTE_FON" => 482
            , "CLIENTE_ABC" => 483
            , "REGANM_ENT" => 484
            , "CREDEV_REC" => 485
            , "PROTPR_DEV" => 486
            , "ATACADO_GRU" => 487
            , "CUSTO_GRU" => 488
            , "LUCOPE_ENT" => 489
            , "PENDTE_VDA" => 490
            , "CAMBVEN_IGU" => 491
            , "CAMBVEN_DIF" => 492
            , "CAMBIOS_STK" => 493
            , "CAMBIOS_REC" => 494
            , "NOTADEB_CNF" => 495
            , "REFSTOK_GER" => 496
            , "LIBRVEN_ST2" => 497
            , "LIBRVEN_ST1" => 498
            , "LIBRCPA_ST2" => 499
            , "LIBRCPA_ST1" => 500
            , "LIBRCRE_ST2" => 501
            , "LIBRCRE_ST1" => 502
            , "USOCRED_CLI" => 503
            , "STATCRE_CLI" => 504
            , "SAIDAS_VVD" => 505
            , "FAC_FAT_ENT" => 506
            , "FAC_FAT_INC" => 507
            , "FAC_FAT_XML" => 508
            , "FAC_FAT_IMP" => 509
            , "FAC_FAT_ENV" => 510
            , "FAC_FAT_LOT" => 511
            , "FAC_FAT_LOG" => 512
            , "FAC_FAT_DEL" => 513
            , "FAC_TIM_ENT" => 514
            , "FAC_TIM_INC" => 515
            , "FAC_TIM_ALT" => 516
            , "FAC_TIM_SER" => 517
            , "FAC_TIM_CONT" => 518
            , "FAC_CLI_ENT" => 519
            , "FAC_CLI_INC" => 520
            , "FAC_CLI_ALT" => 521
            , "FAC_PRO_ENT" => 522
            , "FAC_PRO_AJU" => 523
            , "FAC_PRO_INC" => 524
            , "FAC_PRO_ALT" => 525
            , "FAC_CAM_ENT" => 526
            , "FAC_CAM_INC" => 527
            , "FAC_TRA_LOC_ENT" => 528
            , "FAC_TRA_LOC_INC" => 529
            , "FAC_TRA_LOC_ALT" => 530
            , "FAC_TRA_VEI_ENT" => 531
            , "FAC_TRA_VEI_INC" => 532
            , "FAC_TRA_VEI_ALT" => 533
            , "FAC_TRA_MOT_ENT" => 534
            , "FAC_TRA_MOT_INC" => 535
            , "FAC_TRA_MOT_ALT" => 536
            , "FAC_LOT_ENT" => 537
            , "FAC_LOT_ENV" => 538
            , "FAC_LOT_REC" => 539
            , "IMP_AUTO_ENT" => 540
            , "IMP_AUTO_INC" => 541
            , "IMP_AUTO_ALT" => 542
            , "IMP_AUTO_DEL" => 543
            , "IMP_AUTO_GER" => 544
            , "CRED_PROSRV1" => 545
            , "CRED_PROSRV2" => 546
            , "CAIXA_LIBHI" => 547
            , "PEDIDO_LIB" => 548
            , "PEDIDO_ALT" => 549
            , "FAC_FOR_ENT" => 550
            , "FAC_FOR_INC" => 551
            , "FAC_FOR_ALT" => 552
            , "FAC_CONF_TER" => 553
            , "INCPR_VCT" => 554
            , "ALTPR_VCT" => 555
            , "EXCPR_VCT" => 556
            , "RELPR_VCT" => 557
            , "TRANSF_CNF" => 558
            , "FRETEIRO_VER" => 559
            , "FRETEIRO_INC" => 560
            , "FRETEIRO_ALT" => 561
            , "FRETEIRO_CHV" => 562
            , "FRETEIRO_RET" => 563
            , "FRETEIRO_IMP" => 564
            , "AJUSTES_MODU" => 565
            , "AJUSTES_CONF" => 566
            , "AJUSTES_INC" => 567
            , "AJUSTES_ALT" => 568
            , "AJUSTES_EXC" => 569
            , "LIMICOM_MOD" => 570
            , "LIMICOM_INC" => 571
            , "LIMICOM_ALT" => 572
            , "LIMICOM_EXC" => 573
            , "LIMICOM_LIB" => 574);
function VeSenhaAutorizaNumero($cTag){
    global $aSenhaAutoriza;
    return $aSenhaAutoriza[strtoupper(trim($cTag))];
}
function NewImg2Array($cimg, $nbloco = 50000) {
    $aaux1 = array();
    $aaux1[] = "\\";
    $aaux1[] = chr(0);
    $aaux1[] = chr(13);
    $aaux1[] = chr(10);
    $aaux1[] = '"';
    $aaux1[] = "'";
    $aaux1[] = "`";
    $aaux1[] = chr(9);
    $aaux1[] = chr(141);
    $aaux1[] = chr(8);
    $aaux1[] = chr(26);
    $aaux1[] = "%";
    $aaux1[] = "_";

    $aaux = array();

    $i = 0;
    while (true) {
        $caux = substr($cimg, $i, $nbloco);
        if (strlen($caux) == 0) {
            break;
        }
        for ($k = 0; $k < count($aaux1); $k++) {
            $caux = str_replace($aaux1[$k], "/chr" . ($k + 1) . "/", $caux);
        }

        $aaux[] = $caux;
        $i += $nbloco;
    }

    return $aaux;
}

function NewArray2img($cimg, $l64 = false, $lsemcab64 = false, $nwidth = 0, $nheight = 0) {
    if (gettype($cimg) == "array") {
        $caux = "";
        foreach ($cimg as $value) {
            $caux .= $value;
        }
        $cimg = $caux;
    }

    $aaux = array();
    $aaux[] = "\\";
    $aaux[] = chr(0);
    $aaux[] = chr(13);
    $aaux[] = chr(10);
    $aaux[] = '"';
    $aaux[] = "'";
    $aaux[] = "`";
    $aaux[] = chr(9);
    $aaux[] = chr(141);
    $aaux[] = chr(8);
    $aaux[] = chr(26);
    $aaux[] = "%";
    $aaux[] = "_";

    for ($i = 0; $i < count($aaux); $i++) {
        $cimg = str_replace("/chr" . ($i + 1) . "/", $aaux[$i], $cimg);
    }
    if ($nwidth > 0 && $nheight > 0) {
        $oimg = imagecreatefromstring($cimg);
        $width = imagesx($oimg);
        $height = imagesy($oimg);
        $nindexw = $width / $nwidth;
        $nindexh = $height / $nheight;
        $nindex = $nindexw > $nindexh ? $nindexw : $nindexh;
        if ($nindex > 1) {
            $newwidth = $width / $nindex;
            $newheight = $height / $nindex;
            $dst = imagecreatetruecolor($newwidth, $newheight);
            imagecopyresampled($dst, $oimg, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
            imagedestroy($oimg);

            ob_start();
            imagejpeg($dst);
            $cimg = ob_get_contents(); // read from buffer
            ob_end_clean(); // delete buffer
            imagedestroy($dst);
        }
        imagedestroy($oimg);
    }
    if ($l64) {
        $cimg = base64_encode($cimg);
        if (!$lsemcab) {
            $cimg = "data:image/jpeg;base64, " . $cimg;
        }
    }

    return $cimg;
}

function VeOperador($nOperador = 0, $cOperador = '') {
    global $db;
    global $lweb;
    if ($nOperador) {
        $oope = mysqli_fetch_array(mysqli_query($db, "select * from OPERADOR_OPE WHERE IS_DELETED='N' AND CODIGO=$nOperador"));
    } else {
        $oope = mysqli_fetch_array(mysqli_query($db, "select * from OPERADOR_OPE WHERE IS_DELETED='N' AND NOME='" . strtoupper(trim($cOperador)) . "'"));
    }
    $aret = array();
    $aret["CODIGO"] = $oope["CODIGO"];
    $aret["NOME"] = $oope["NOME"];
    $aret["NIVEL"] = cifra($oope["DEGRAU"]);
    $aret["SENHA"] = cifra($oope["SENHA"]);
    $aret["GRUPO"] = cifra($oope["GRUPO"]) + 0;
    $aret["NUM_SEN"] = cifra($oope["NUM_SEN"]) + 0;
    return $aret;
}

function VeConfSen($nSen) {
    global $db;
    global $lweb;
    $csen = '';
    $aret = array("TAG" => "", "DESC" => "", "NIVEL" => 0, "LOG" => "N", "CLASS" => "      ");

    $asen = mysqli_fetch_array(mysqli_query($db, "select * from CONFSEN_SEN WHERE RECNO=" . $nSen));

    foreach ($asen as $key => $value) {
        if (substr($key, 0, 3) == 'IE$' && strlen($value) > 68) {
            $csen = $value;
            break;
        }
    }
    $caux = substr($csen, 0, 68);
    $aaux = explode("-", $caux);
    $aret["TAG"] = trim($aaux[0]);
    $aret["DESC"] = trim($aaux[1]);
    $aret["NIVEL"] = substr($csen, 68, 1) + 0;
    $aret["LOG"] = substr($csen, 69, 1);
    $aret["CLASS"] = substr($csen, 70, 6);

    return $aret;
}

function VeSession($cnome, $uval = '', $csidref = '') {
    global $db;
    global $lweb;
    if (!$db) {
        $db = conecta();
    }
    $cstr = "create table if not exists tablet" . $lweb . "_ctl_sid (
        sid varchar(150) not null default ''
        ,nome varchar(100) not null default ''
        ,valor varchar(200) not null default ''
        ,data datetime
        ,index sid (sid,nome)
        ,index data (data)
        )";
    mysqli_query($db, $cstr);
    if ($cnome == "sid" && $uval) {
        mysqli_query($db, "insert tablet" . $lweb . "_ctl_sid (sid,nome,valor) values('$uval','sid','$uval')");
        return $uval;
    } else if ($cnome == "sid" && !$uval) {
        return pegavar("sid");
    }
    if ($csidref) {
        $sid = $csidref;
    } else {
        $sid = pegavar("sid");
    }
    if (!$uval) {
        return mysqli_fetch_row(mysqli_query($db, "select valor from tablet" . $lweb . "_ctl_sid where sid='$sid' and nome='$cnome' "))[0];
    } else {
        if ($uval == "null") {
            $uval = '';
        }
        if (mysqli_num_rows(mysqli_query($db, "select valor from tablet" . $lweb . "_ctl_sid where sid='$sid' and nome='$cnome'")) == 00) {
            mysqli_query($db, "insert tablet" . $lweb . "_ctl_sid (valor,sid,nome) values ('$uval','$sid','$cnome')");
        } else {
            mysqli_query($db, "update tablet" . $lweb . "_ctl_sid set valor='$uval' where sid='$sid' and nome='$cnome'");
        }
        return uval;
    }
    return '';
}

function MedDbf2Array($cstr, $db1 = '') {
    global $db;
    if (!$db1) {
        $db1 = $db;
    }
    $otab = mysqli_query($db1, $cstr);
    $aret = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $aret[] = $olin;
    }
    return $aret;
}

function medfile($cfile, $db1 = '', &$nrows = 0) {
    global $db;
    if (!$db1) {
        $db1 = $db;
    }
    if (empty($cfile)) {
        return false;
    }
    if (!(strpos($cfile, ".") === false)) {
        $cfile = str_replace(".", "_", $cfile);
    }
    if (mysqli_num_rows(mysqli_query($db1, "show tables like '$cfile'")) == 0) {
        return false;
    }
    $nrows = mysqli_fetch_row(mysqli_query($db1, "selectr count(*) as quant from $cfile"))[0] + 0;
    return true;
}

function is_ssl() {
    if (isset($_SERVER['HTTPS'])) {
        if ('on' == strtolower($_SERVER['HTTPS']))
            return true;
        if ('1' == $_SERVER['HTTPS'])
            return true;
    } elseif (isset($_SERVER['SERVER_PORT']) && ( '443' == $_SERVER['SERVER_PORT'] )) {
        return true;
    }
    return false;
}

function velocalvendas() {
    $aipspermitidos = array("192.168.12.", "192.168.3.", "10.10.50.", "200.195.155.178", "192.168.9.");

    $lok = false;
    foreach ($aipspermitidos as $value) {
        if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($value)) == $value) {
            $lok = true;
            break;
        }
    }
    if (!$lok) {
        die($_SERVER['REMOTE_ADDR'] . " Acesso nao autorizado deste local");
        return false;
    }

    return true;
}

//return;
function GravaLogTablet($ctipo, $cmensagem = '', $cdocumento = '', $noperador = 0, $nvendedor = 0, $nrecno = 0) {
    global $db;
    global $lweb;
    if (!$db) {
        return 0;
    }
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_log (ordem int(10) not null primary key auto_increment
        ,operador int(10) not null default 0
        ,vendedor int(10) not null default 0
        ,tipo varchar(20) not null default ''
        ,data datetime not null default '0000-00-00 00:00:00'
        ,mensagem text not null default ''
        ,ip varchar(100) not null default ''
        ,documento varchar(100) not null default ''
        ,index documento(documento)
        ,index data (data)
        )
        ");
    if (!$nvendedor) {
        $nvendedor = VeSession("vendedor"); //$_SESSION["vendedor"];
    }
    if (!$noperador) {
        $noperador = VeSession("usuario"); //$_SESSION["usuario"];
    }
    if (!$nrecno) {
        $cstr = "insert tablet" . $lweb . "_log (data,operador,vendedor,tipo,mensagem,documento,ip) "
                . "values(now(),'$noperador','$nvendedor','$ctipo','$cmensagem','$cdocumento','" . $_SERVER['REMOTE_ADDR'] . "')";
        mysqli_query($db, $cstr);
        return mysqli_fetch_row(mysqli_query($db, "select last_insert_id()"))[0];
    } else {
        $cstr = "update tablet" . $lweb . "_log set mensagem=concat(mensagem,'\n','$cmensagem') where ordem=$nrecno ";
        mysqli_query($db, $cstr);
    }
    return;
}

function velocal() {
    $aipspermitidos = array("192.168.12.", "192.168.3.", "10.10.50.", "200.195.155.178");

    $lok = false;
    foreach ($aipspermitidos as $value) {
        if (substr($_SERVER['REMOTE_ADDR'], 0, strlen($value)) == $value) {
            $lok = true;
            break;
        }
    }
    if (!$lok) {
        die($_SERVER['REMOTE_ADDR'] . " Acesso nao autorizado deste local");
        return false;
    }

    return true;
}

function mysqli_myquery($cstr) {
    global $db;
    $otableret = mysqli_query($db, $cstr);
    if (mysqli_error($db) != '') {
        echo "<br><b>******************* ERRO NA REQUISICAO SQL   *******************<BR>";
        echo $cstr . "<br>";
        echo mysqli_error($db);
        echo "<br><b>****************************************************************<BR>";
    }
    return $otableret;
}

function mysql_myquery($cstr) {
    return mysqli_myquery($cstr);
}

function ve_ssl() {
    global $cSemSsl;

    require("mysql.php");

    $lSemSsl = 1;

    $aip = array();
    $cip = strtok($cSemSsl, " ");
    while ($cip) {
        $aip[] = $cip;
        $cip = strtok(" ");
    }

    $cip = getenv("REMOTE_ADDR");
    for ($i = 0; $i < count($aip); $i++) {
        if (!strncmp($aip[$i], $cip, strlen($aip[$i]))) {
            $lSemSsl = 1;
            break;
        }
    }
    if ($lSemSsl)
        return 1;

    if (getenv("SSL_SESSION_ID") == "") {
        men("Esta não é uma conexão segura.<br><br><b>Incie com https://....", ($paginainicial ? "window.location.assign('$paginainicial')" : ""), '', '', 'Ir para a página');
//        erro(idm("Esta nao e uma conexao segura.<br><br><b>Incie com https://...."));
        return 0;
    }
    return 1;
}

function cifra($a = '', $b = '') {
    $var = "";

    if (empty($b)) {
        $b = 3;
    }

    for ($i = 1; $i <= strlen($a); $i++) {
        $var = $var . chr(255 + $i - (($b * $i) + ord(substr($a, $i - 1, 1))));
    }

    return $var;
}

function data2sql($ddata, $lSemAspas = false) {
    $ddata = str_replace("-", "", $ddata);
    $ddata = str_replace("/", "", $ddata);
    $ddata = str_replace(".", "", $ddata);
    $ddata = str_replace(" ", "", $ddata);
    $aux = ($lSemAspas ? "" : "'") . substr($ddata, 4, 4) . "-" . substr($ddata, 2, 2) . "-" . substr($ddata, 0, 2) . ($lSemAspas ? "" : "'");
    return $aux;
}

function hora2sql($chora, $lSemAspas = false) {
    $aaux = explode(":", $chora);
    while (count($aaux) < 3) {
        $aaux[] = "00";
    }
    for ($i = 0; $i < 3; $i++) {
        while (strlen($aaux[$i]) < 2) {
            $aaux[$i] = "0" . $aaux[$i];
        }
    }
    $aux = ($lSemAspas ? "" : "'") . $aaux[0] . ":" . $aaux[1] . ":" . $aaux[2] . ($lSemAspas ? "" : "'");
    return $aux;
}

function sql2time($ddata) {
    if ($ddata == '1000-01-01')
        return '';
    $aux = substr($ddata, 11, 2) . ":" . substr($ddata, 14, 2) . ":" . substr($ddata, 17, 2);
    return $aux;
}

function sql2data($ddata) {
    if ($ddata == '1000-01-01' || $ddata == '0000-00-00')
        return ' ';
    $aux = substr($ddata, 8, 2) . "/" . substr($ddata, 5, 2) . "/" . substr($ddata, 2, 2);
    return $aux;
}

function c2sql($str) {
    return carac2sql($str);
}

function carac2sql($str) {
    $aux = "'" . $str . "'";
    return $aux;
}

function nHtml2Sql($cstr) {
    $cstr = strtok($cstr, ",");
    $cstr = str_replace(".", "", $cstr);
    return $cstr;
}

function erro($cmen = '', $ctitulo = '') {

    require("mysql.php");

    if (!$ctitulo)
        $ctitulo = idm("Error del Sistema");
    echo HtmlCabOn($ctitulo, "", "inicio", "./index.php");
    echo HtmlTableOn(0, 0, 1);

    if ($cImagem)
        abrelinha(HtmlImage($cImagem, 0), "H", "", "", 2);
    abrelinha(idm("ERROR DEL SISTEMA"), "H", "", "", 2);
    abrelinha(SP, "C", "", "", 2);
    abrelinha($cmen, "C", true, "", 2);
    abrelinha(SP, "C", true, "", 2);
    abrelinha();
    abrecel("", "C", "", "", 2);
    echo criabotao("submit");
    echo HtmlTableOff();
    echo HtmlCabOff();

    return 0;
}

function men($cmen, $clink, $lfecha, $ctitulo, $cbotao) {

    require("mysql.php");

    if (empty($ctitulo))
        $ctitulo = idm("Mensaje Del Sistema");
    echo HtmlCabOn($ctitulo);
    echo HtmlTableOn(0, 0, 1);
    if ($cImagem)
        abrelinha(HtmlImage($cImagem, 0), "H", "", "", 2);
    abrelinha(idm("MENSAJE DEL SISTEMA"), "H", "", "", 2);
    abrelinha(SP, "C", "", "", 2);
    abrelinha($cmen, "C", true, "", 2);
    abrelinha(SP, "C", "", "", 2);

    if ($lfecha) {
        $cclick = "javascript:window.close()";
    } elseif (empty($clink)) {
        $cclick = "javascript:history.go(-1)";
    } else {
        $cclick = $clink;
    }

    if (!$cbotao)
        $cbotao = "Ok";
    echo abrelinha(criabotao("ok", $cbotao, $cclick), "C", "", "", 2);

    echo HtmlTableOff();
    echo HtmlCabOff();

    return 0;
}

function conecta($server = '', $port = '', $user = '', $password = '', $database = '') {
    global $db;
    if (!ve_ssl())
        return 0;
    if (!$server) {
        require "mysql.php";
    }
    $db = mysqli_connect($server, $user, $password, $database, $port);
    if (!$db) {
        erro(idm("Error accendendo al servidor MySQL") . " <br>" . mysqli_error($db));
        return 0;
    }
    mysqli_set_charset($db, "latin1");
    return $db;
}

function gera_sid($user) {
    global $versao;
    global $idioma;
    global $db;
    global $lweb;

    $caux = "10q2wertyu3iopasd4fghj5klzx6cvbnm7poiu9ytre0wqmn1bvc2xzlkj3hgf4dsa51235fg86773";
    $caux1 = getdate();
    $caux1 = rand(999999, 99999999999999);
    $caux1 = $caux1 . rand(999999, 99999999999999);
    $caux1 = $caux1 . rand(999999, 99999999999999);
    $caux1 = $caux1 . rand(999999, 99999999999999);
    $caux1 = $caux1 . rand(999999, 99999999999999);
    $caux1 = $caux1 . rand(999999, 99999999999999);
    $sid = "";
    for ($i = 1; $i < strlen($caux1); $i++) {
        $sid = $sid . substr($caux, substr($caux1, $i, 1) + $i, 1);
    }


    $sid = $idioma . $sid;
    $olinha = mysql_linha("OPERADOR_OPE", "codigo,nome,degrau", "codigo=$user and is_deleted='N'");
//    $olinha = mysql_linha("OPERADOR_OPE", "codigo,nome,degrau", "bloq_vdas!='S' and codigo=$user and is_deleted='N'");

    $caux = "insert php_wc_session set codigo=" . $user . ",nome='" . limpachar($olinha[1]) . "',nivel=" . cifra($olinha[2]) . ",data_in=now(),sid='" . $sid . "',ip='" . getenv("REMOTE_ADDR") . "'";
    mysqli_query($db, "update php_wc_session set data_out=now() where codigo=" . $user . " and data_out= '0000-00-00' ");
    mysqli_query($db, $caux);
//controle de versao
    mysqli_query($db, "create table if not exists php_wc_config (
	    versao int(10) not null default 0,
	    data datetime not null default '0000-00-00 00:00:00'
	     )");
    $otable = mysqli_query($db, "select versao from php_wc_config order by data desc limit 1");
    $linha = mysqli_fetch_row($otable);

    if ($linha && ceil($linha[0]) == ceil($versao * 100)) {
        ve_sid($sid);
        return $sid;
    }
    if (!$linha || ceil($linha[0]) < ceil($versao * 100)) {
        mysqli_query($db, "insert php_config set data=now(),versao=" . ceil($versao * 100));
        ve_sid($sid);
        return $sid;
    }
    erro(idm("La version instalada es inferior a la actual.<br>Instalada: ") . number_format($linha[0] / 100, 2) . idm("<br>Utilizada: ") . number_format($versao, 2));
    return;
//return false;
}

function ve_sid(&$sid) {
    global $codven;
    global $nomven;
    global $lojven;
    global $ausuario;
    global $idioma;
    global $db;
    global $lweb;
    if (!velocal()) {
        return;
    }
    $idioma = substr($sid, 0, 2);
    if (!$db) {
        $db = conecta();
        if (!$db)
            return;
    }

    if (empty($sid)) {
//        $sid = $_GET['sid'];
//        if (empty($sid))
//            $sid = $_POST['sid'];
        $sid = PegaVar("sid");
    }
    $idioma = substr($sid, 0, 2);

    $tempo = 12000;

    if (empty($sid)) {
        erro(idm("Identificador no valido"));
        return 0;
    }

    $caux = "select * from php_wc_session where sid='" . $sid . "'";
    $otable = mysqli_query($db, $caux);

    if (mysqli_num_rows($otable) == 0) {
        erro(idm("Identificador no valido"));
        return 0;
    }

    $olinha = mysqli_fetch_row($otable);

    if (!($olinha[4] == '0000-00-00 00:00:00')) {
        fecha_sid($sid);
        erro(idm("Sistema accesado en otro local o") . "<br>" . idm("Identificador no valido"));
        return 0;
    }

    $otable = mysqli_query($db, "select now()-data_in from php_wc_session where sid='" . $sid . "'");
    $olinha = mysqli_fetch_row($otable);
    if ($olinha[0] > $tempo) {
        fecha_sid($sid);
        erro(idm("Tiempo expirado"));
        return 0;
    }

    mysqli_query($db, "update php_wc_session set data_in=now() where sid='" . $sid . "'");
    $otable = mysqli_query($db, "select codigo,nome,nivel from php_wc_session where sid='" . $sid . "'");
    $olinha = mysqli_fetch_row($otable);
    $ausuario = array($olinha[0], $olinha[1], $olinha[2]);
    return array($olinha[0], $olinha[1], $olinha[2]);
}

function fecha_sid($sid) {
    global $db;
    global $lweb;
    mysqli_query($db, "update php_wc_session set data_out=now() where sid='" . $sid . "'");
    return 0;
}

function multi_post_item($input_item_name) {
    $array_output = array();
    $in_handle = fopen("php://input", "r");
    $raw_input_items = split("&", urldecode(fread($in_handle, 100000)));
    foreach ($raw_input_items as $input_item) {
        // split this item into name/value pair
        $item = split("=", $input_item);
        // form item name
        $item_name = $item[0];
        // form item value
        $item_value = $item[1];
        if ($item_name == $input_item_name) {
            $array_output[] = $item_value;
        }
    }

    if ($array_output) {
        return $array_output;
    } else {
        return multi_get_item($input_item_name);
    }
}

function ve_nivel($ausu, $nniv) {
    global $db;
    global $lweb;
    $otable = mysqli_query($db, "select * from php_menu where codigo=" . $nniv);
    $olinha = mysqli_fetch_row($otable);
    if ($ausu[2] < $olinha[3])
        return 0;
    return 1;
}

function men_java($cmen) {

    $cjava = "function fecha(eu){
    alert('" . $cmen . "');
    eu.close();
    return true;
  }";

    echo HtmlCabOn(idm("Mensaje Del Sistema"), $cjava, "", "", "fecha(this)");
    echo HtmlCabOff();
    return;
}

function FirstUpper($cstr, $primeiro = '') {
    $cret = "";
    $caux = strtok($cstr, " ");
    while ($caux) {
        $cret = $cret . " " . strtoupper(substr($caux, 0, 1)) . strtolower(substr($caux, 1));
        $caux = strtok(" ");
    }
    $cstr = ltrim(rtrim($cret));

    $cret = "";
    $caux = strtok($cstr, ".");
    while ($caux) {
        $cret = $cret . "." . strtoupper(substr($caux, 0, 1)) . substr($caux, 1);
        $caux = strtok(".");
    }
    $cstr = substr($cret, 1);

    $cret = "";
    $caux = strtok($cstr, "-");
    while ($caux) {
        $cret = $cret . "." . strtoupper(substr($caux, 0, 1)) . substr($caux, 1);
        $caux = strtok(".");
    }

    return substr($cret, 1);
}

function digito($ncod) {
    $ncod = str_pad($ncod, 12, "0", STR_PAD_LEFT);
    $apar = 0;
    $aimp = 0;
    for ($i = 0; $i < 12; $i++) {
        if ($i % 2 == 0) {
            $aimp = $aimp + substr($ncod, $i, 1);
        } else {
            $apar = $apar + substr($ncod, $i, 1);
        }
    }
    $nret = (3 * $apar) + $aimp;
    $nret = $nret % 10;
    $nret = 10 - $nret;
    if ($nret > 9)
        $nret = 0;

    return $nret;
}

function poedigito($ncod) {
    return $ncod * 10 + digito($ncod);
}

function tiradigito($ncod) {
    return floor($ncod / 10);
}

function vedigito($ncod) {
    $nint = substr($ncod, 0, -1);
    //$nint = floor($ncod / 10);
    //$ndig = $ncod % 10;
    $ndig = substr($ncod, -1, 1);
    //return $ndig."-".$nint."-".digito($nint);
    return ($ndig == digito($nint));
}

function html2num($cnum) {
    return str_replace(",", ".", str_replace(".", "", $cnum));
}

function fechacel() {
    echo "</td>";
}

// mostra,posicao(E,D,C,H),negrito,fonte,span colunas,span linhas)
function abrelinha($cstr = '', $cpos = '', $lneg = false, $ntamfonte = '', $ncolspan = '', $nrowspan = '', $ccor = '', $clarg = '') {
    echo "<tr>";
    if ($cstr || $cpos || $ncolspan || $ncolspan)
        impcel($cstr, $cpos, $lneg, $ntamfonte, $ncolspan, $nrowspan, false, $ccor, $clarg);
}

function fechalinha() {
    echo "</tr>";
}

function abrecel($cstr = '', $cpos = '', $lneg = '', $ntamfonte = '', $ncolspan = '', $nrowspan = '', $ccor = '', $clarg = '') {
    impcel($cstr, $cpos, $lneg, $ntamfonte, $ncolspan, $nrowspan, true, $ccor, $clarg);
}

function impcel($cstr = '', $cpos = '', $lneg = '', $ntamfonte = '', $ncolspan = '', $nrowspan = '', $lsemfechar = '', $ccor = '', $clarg = '') {
    $lcent = 0;
    echo "<td class=\"";
    if ($cpos == "D" || $cpos == "d") {
        echo "right";
        $lcent = 2;
    } elseif ($cpos == "C" || $cpos == "c") {
        echo "cent";
        $lcent = 1;
    } elseif ($cpos == "H" || $cpos == "h") {
        echo "header";
        $lcent = 1;
    } elseif ($cpos == "H1" || $cpos == "h1") {
        echo "headers";
        $lcent = 1;
    } else {
        echo "default";
    }
    echo "\" ";
    if ($ncolspan > 1)
        echo " colspan=\"" . $ncolspan . "\" ";
    if ($nrowspan > 1)
        echo " rowspan=\"" . $nrowspan . "\" ";
    if (!empty($clarg))
        echo " width=\"" . $clarg . "\"";

    echo ">";
    if ($lcent == 2) {
        echo "<p align=right>";
    } elseif ($lcent == 1) {
        echo "<p align=center>";
    }
    if ($ntamfonte || $ccor) {
        echo "<font ";
        if ($ntamfonte)
            echo "size=\"" . $ntamfonte . "\" ";
        if ($ccor)
            echo "color=\"" . $ccor . "\" ";
        echo ">";
    }
    if ($lneg)
        echo "<b>";
    if ($cstr)
        echo $cstr;
    if (!$lsemfechar)
        echo "</td>";
}

function my_number_format($p1 = 0, $p2 = 0, $p3 = ",", $p4 = ".") {
    if ($p1 == 0)
        return "&nbsp;";
    if (!$p3) {
        $p3 = ",";
        $p4 = ".";
    }
    if (!$p4) {
        $p3 = ",";
        $p4 = ".";
    }
    if (!$p2)
        $p2 = 0;
    return number_format($p1, $p2, $p3, $p4);
}

/*
  none 			-> nenhuma formatacao
  integer numeric  	-> numerico inteiro
  float 			-> decimal com 2
  date 			-> data dd/mm/aaaa
  time 			-> hora hh:mm
  month_year 		-> mes e ano mm/aaaa
  cep 			-> cep 99999-999
  percent 		-> percentual 6 int e 2 dec
  cpf 			-> apenas 11 numeros sem checagem
  cnpj			-> apenas 14 numeros sem checagem
  text 			-> somente letras
  uppercase 		-> qq letras e numeros para maiusculo
  textnumber		-> letras e numeros
  full_name		-> letras e espacos
  text_entry		-> qq texto
  password 		-> nenhuma formatacao com senha
  email 		-> email
 */

function CriaCampo($cnome, $ctipo, $ntam = '', $default = '', $ctexto = '', $nlinha = 1, $csaifoco = '', $ldisabled = false, $nfontepadrao) {
    if ($default && $ctipo == "money") {
        $default = str_replace(".", ",", $default);
    }
    if ($ctipo == "livre") {
        if (empty($nlinha))
            $nlinha = 1;
        if (empty($ntam))
            $ntam = 10;
        $cstr = "<textarea ";
        if ($nfontepadrao) {
            $cstr .= " style=\"font-size:" . $nfontepadrao . "pt; \"";
        }
        $cstr .= " name=\"$cnome\" id=\"$cnome\" cols=\"$ntam\" rows=\"$nlinha\" " . ($ldisabled ? " disabled " : "") . " >" . $default . "</textarea>";

        if (!empty($ctexto))
            $cstr = $ctexto . $cstr;
        return $cstr;
    }
    $cstr = "<input ";
    if ($nfontepadrao) {
        $cstr .= " style=\"font-size:" . $nfontepadrao . "pt; \"";
    }
    $cstr .= " type=\"text\" name=\"[[0]]\" id=\"[[0]]\"  size=\"[[4]]\" maxlength=\"[[1]]\" value=\"[[2]]\"  onkeypress=\"return(validaConteudo(event,this,'[[3]]'))\" onFocus=\"removeCaracs(this,'[[3]]')\" onblur=\"formatCamp(this,'[[3]]')";
    if ($csaifoco)
        $cstr .= ";$csaifoco";
    $cstr .= "\" onkeyup=\"saltaCampo(event,this,'[[3]]',[[1]] )\" " . ($ldisabled ? " disabled " : "") . " > ";
    $areplace = array();

    $areplace[0] = $cnome;
    if (!$ntam)
        $ntam = 10;
    $areplace[1] = $ntam;
    $areplace[2] = $default;
    $areplace[3] = $ctipo;

    if ($areplace[3] == 'date') {
        if (!$areplace[2])
            $areplace[2] = date('d/m/Y');
        $areplace[1] = 10;
    } elseif ($areplace[3] == 'time') {
        if (!$areplace[2])
            $areplace[2] = date('H:i');
        $areplace[1] = 5;
    } elseif ($areplace[3] == 'month_year') {
        if (!$areplace[2])
            $areplace[2] = date('m/Y');
        $areplace[1] = 7;
    } elseif ($areplace[3] == 'cep') {
        if (!$areplace[2])
            $areplace[2] = "";
        $areplace[1] = 9;
    } elseif ($areplace[3] == 'password') {
        $areplace[3] = "none";
        $cstr = str_replace("\"text\"", "\"password\"", $cstr);
        if (!$areplace[2])
            $areplace[2] = "";
    } elseif ($areplace[3] == 'percent') {
        if (!$areplace[2])
            $areplace[2] = "0";
        $areplace[1] = 9;
    } elseif ($areplace[3] == 'numeric' || $areplace[3] == 'integer' || $areplace[3] == 'float' || $areplace[3] == 'money') {
        if (!$areplace[2])
            $areplace[2] = "0";
    } elseif ($areplace[3] == 'text' || $areplace[3] == 'textnumber' || $areplace[3] == 'uppercase' ||
            $areplace[3] == 'full_name' || $areplace[3] == 'none') {
        if (!$areplace[2])
            $areplace[2] = "";
    } else {
        $areplace[3] = "text_entry";
        if (!$areplace[2])
            $areplace[2] = "";
    }


    $areplace[4] = $areplace[1];

    if ($areplace[3] == 'float' || $areplace[3] == 'money')
        $areplace[4] += 3;

    for ($i = 0; $i < count($areplace); $i++) {
        $cstr = str_replace("[[" . $i . "]]", $areplace[$i], $cstr);
    }
    if ($ctexto)
        $cstr = $ctexto . $cstr;
    return $cstr;
}

function CriaBotoesFinal($lvoltar = false, $llimpar = false, $lenviar = false, $lcongelar = false, $nvoltar = '', $nfontepadrao) {
    if (!$nvoltar)
        $nvoltar = -1;
    $cstr = "";
    if ($lvoltar) {
        if ($lvoltar == 1) {
            $cstr .= criabotao("voltar", idm("Volver"), "javascript:history.go(" . $nvoltar . ")", '', '', $nfontepadrao);
        } else {
            $cstr .= criabotao("voltar", idm("Volver"), "window.location.href='" . $lvoltar . "'", '', '', $nfontepadrao);
        }
    }
    if ($llimpar) {
        $cstr .= criabotao("reset", idm("Limpar"), "", SP . SP, '', $nfontepadrao);
    }
    if ($lenviar) {
        $cstr .= criabotao("submeter", idm("Enviar"), iif($lcongelar, "this.disabled=true;document.forms[0].submit()", ""), SP . SP, '', $nfontepadrao);
    }
    return $cstr;
}

function CriaBotao($cnome, $cescrita = '', $cexec = '', $ctexto = '', $cimagem = '', $nfontsize) {
    if ($cnome == "submit" || $cnome == "submeter") {
        $ctipo = "submit";
    } elseif ($cnome == "reset") {
        $ctipo = "reset";
    } else {
        $ctipo = "button";
    }
    if (!$cescrita)
        $cescrita = "Ok";
    if (!$cimagem) {
        $caux = "<input ";
        if ($nfontsize) {
            $caux .= ' style="font-size: ' . $nfontsize . 'pt;"';
        }
        $caux .= " type=\"" . $ctipo . "\"  name=\"" . $cnome . "\"  id=\"" . $cnome . "\" value=\"" . $cescrita . "\" ";
    } else {
        $caux = "<input ";
        if ($nfontsize) {
            $caux .= ' style="font-size: ' . $nfontsize . 'pt;"';
        }
        $caux .= " type=\"image\" src=\"$cimagem\"  name=\"" . $cnome . "\"  id=\"" . $cnome . "\" value=\"" . $cescrita . "\" ";
    }
    if ($cexec)
        $caux = $caux . " onclick=\"" . $cexec . "\" ";
    if ($ctexto)
        $caux = $ctexto . $caux;

    $caux = $caux . ">";
    return $caux;
}

function CriaCombo($cnome, $ctodos = '', $ctabela = '', $ccampos = '', $cretorno = '', $cwhere = '', $cordem = '', $nlinha = 1, $aselect = '', $cexec = '', $csql = '', $ldisabled = false, $nfontepadrao) {
//echo $csql.CR;
    global $db;
    global $lweb;

    if ($csql) {
        $caux = $csql;
    } else {
        $caux = "select concat_ws('-'," . $ccampos . ") as nome," . $cretorno . " as codigo  from " . $ctabela . " where is_deleted='N' ";
    }
    MyDefault($nlinha, 1);
    if ($cwhere)
        $caux = $caux . " and " . $cwhere;
    if ($cordem)
        $caux = $caux . " order by " . $cordem;

    $otable = mysqli_query($db, $caux);

    $caux = "<select";
    if ($nfontepadrao) {
        $caux .= " style=\"font-size: " . $nfontepadrao . "pt \" ";
    }
    $caux .= " size=\"" . $nlinha . "\" ";
    if ($nlinha > 1)
        $caux .= " multiple ";
    $caux .= " name=\"" . $cnome . "\" ";
    $caux .= " id=\"" . $cnome . "\" ";
    if ($cexec) {
        $caux .= " onchange=\"" . $cexec . "\" ";
    }
    $caux .= ($ldisabled ? " disabled " : "") . " > ";
    if ($ctodos) {
        $caux .= "<option ";
        if (!$aselect)
            $caux .= "selected ";
        $caux .= "value=\"" . strtok($ctodos, ",") . "\">" . strtok(',') . "</option>";
    }

    while ($linha = mysqli_fetch_row($otable)) {
        $caux .= "<option ";
        if ($aselect) {
            for ($i = 0; $i < count($aselect); $i++) {
                if ($linha[1] == $aselect[$i])
                    $caux .= " selected ";
            }
        }
        $caux .= " value=\"" . $linha[1] . "\">" . $linha[0] . "</option>";
    }
    $caux = $caux . "</select>";
    return $caux;
}

function CriaComboBox($cnome, $ctodos, $acampos, $nlinha, $aselect, $cfunselect, $nfontsize) {
    MyDefault($nlinha, 1);

    $caux = "<select ";
    if ($nfontsize) {
        $caux .= ' style="font-size: ' . $nfontsize . 'pt;"';
    }
    $caux .= " size=\"" . $nlinha . "\" ";
    if ($nlinha > 1)
        $caux .= " multiple ";
    if ($cfunselect)
        $caux .= " onchange=\"" . $cfunselect . "\" ";
    $caux .= " name=\"" . $cnome . "\" id=\"" . $cnome . "\" >";

    if ($ctodos) {
        $caux .= "<option ";
        if (!$aselect)
            $caux .= "selected ";
        $caux .= "value=\"" . strtok($ctodos, ",") . "\">" . strtok(',') . "</option>";
    }

    for ($j = 0; $j < count($acampos); $j++) {
        $caux .= "<option ";
        $ccod = strtok($acampos[$j], ",");
        $cnom = strtok(",");
        for ($i = 0; $i < count($aselect); $i++) {
            if ($ccod == $aselect[$i])
                $caux .= " selected ";
        }
        $caux .= " value=\"" . $ccod . "\">" . $cnom . "</option>";
    }
    $caux = $caux . "</select>";
    return $caux;
}

// aop=array("c,Codigo,1" ,...)
function CriaRadio($cnome, $aop, $lcomsp = false, $conclick = '') {
    $caux = "";
    for ($i = 0; $i < count($aop); $i++) {
        if ($lcomsp)
            $caux = $caux . SP;
        $caux = $caux . "<input type=\"radio\" name=\"" . $cnome . "\" value=\"" . strtok($aop[$i], ",") . "\"";
        $cstr = strtok(",");
        if (strtok(","))
            $caux = $caux . " checked";
        if ($conclick)
            $caux .= " onclick=\"" . $conclick . "\" ";

        $caux = $caux . ">" . $cstr;
    }
    return $caux;
}

function CriaCheck($cnome, $lcheck = false, $cstr = '', $conclick = '', $nfontsize) {
    $caux = "<input ";
    if ($nfontsize) {
        $caux .= ' style="width: ' . ($nfontsize + 2) . 'px;height: ' . ($nfontsize + 2) . 'px;"';
    }
    $caux .= " type=\"checkbox\" name=\"" . $cnome . "\" id=\"" . $cnome . "\" ";
    if ($lcheck)
        $caux .= "checked ";
    if ($conclick)
        $caux .= " onclick=\"" . $conclick . "\" ";
    $caux .= "> ";
    if ($cstr)
        $caux .= $cstr;
    return $caux;
}

function ReCriaHidden($cnome) {
    return CriaHidden($cnome, PegaVar($cnome));
}

function AReCriaHidden($anome) {
    $caux = "";
    for ($i = 0; $i < count($anome); $i++) {
        $caux .= CriaHidden($anome[$i], PegaVar($anome[$i]));
    }
    return $caux;
}

function CriaHidden($cnome, $uval) {
    return $caux = "<input type=\"hidden\" name=\"" . $cnome . "\" id=\"" . $cnome . "\" value=\"" . $uval . "\" >";
}

function HtmlCabOn($ctitulo = '', $cjava = '', $cform = '', $cform_action = '', $conload = '', $consubmit = '', $chead = '') {
    global $crosto;

    echo mobilecabecalho();
    $cstr = '';
    $cstr .= "<html><head>
<meta HTTP-EQUIV=\"PRAGMA\" CONTENT=\"NO-CACHE\">     
<meta http-equiv=\"expires\" content = \"-1\" />
<meta http-equiv=\"Content-Language\" content=\"pt-br\">
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
<title>" . $ctitulo . "</title>
  <link href=\"" . $crosto . "\" type=text/css rel=stylesheet>
$chead
 <script type=\"text/javascript\" src=\"consoft.js\"></script> ";
    if ($cjava) {
        if ($cjava == "|") {
            $cstr .= "|";
        } else {
            $cstr .= "<script language=\"JavaScript\">" . $cjava . "</script>";
        }
    }
    $cstr .= "</head>
<body";

    if ($conload)
        $cstr .= " onload=\"" . $conload . "\" ";
    $cstr .= "><div id=\"popsen\"></div>";

    if ($cform) {
        $cstr .= "<form method=\"post\" name=\"" . $cform . "\" ";
        if ($cform_action)
            $cstr .= "  action=\"" . $cform_action . "\" ";
        if ($consubmit)
            $cstr .= " onSubmit=\"" . $consubmit . "\" ";
        $cstr .= ">";
    }
    $cstr .= "
<center>
";
    return $cstr;
}

function HtmlCabOnXX($ctitulo, $cjava, $cform, $cform_action, $conload, $consubmit, $nrefresh) {
    global $crosto;

    $cstr = "<html><head>";
    if ($nrefresh) {
        $cstr .= "<meta http-equiv=\"refresh\" content=\"$nrefresh\" >
     ";
    }
    $cstr .= "<meta http-equiv=\"Content-Language\" content=\"pt-br\">
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
<title>" . $ctitulo . "</title>
  <link href=\"" . $crosto . "\" type=text/css rel=stylesheet>
  <script language=\"JavaScript\" src=\"./consoft.js\" type=\"text/javascript\" ></script>
    <script language=\"JavaScript\">
    <!--
" . $cjava . "
    -->
    </script>
</head>
<body";
    if ($conload)
        $cstr .= " onload=\"" . $conload . "\" ";
    $cstr .= ">";

    if ($cform) {
        $cstr .= "<form method=\"post\" name=\"" . $cform . "\" ";
        if ($cform_action)
            $cstr .= "  action=\"" . $cform_action . "\" ";
        if ($consubmit)
            $cstr .= " onSubmit=\"" . $consubmit . "\"; ";
        $cstr .= ">";
    }
    $cstr .= "
<div align=\"center\"> <center>
";
    return $cstr;
}

function MyDefault(&$uvar, $uret) {
    if (!($uvar))
        $uvar = $uret;
    return $uvar;
}

function HtmlImage($cimagem, $nborder, $nwidth, $nheight) {
    global $cImagemLink;
    MyDefault($nborder, 0);
    $caux = "";
    if ($cImagemLink)
        $caux .= "<a href=\"$cImagemLink\">";
    $caux .= "<img border=\"" . $nborder . "\" src=\"" . $cimagem . "\" ";
    if ($nwidth && $nheight)
        $caux .= " width=\"" . $nwidth . "\" height=\"" . $nheight . "\" ";
    $caux .= ">
  ";
    if ($cImagemLink)
        $caux .= "</a>";
    return $caux;
}

function HtmlTableOff() {
    return "</table>";
}

function HtmlCabOff($cjava = '', $chtml = '') {
    $caux = "</center></div></form></body>";
    if ($chtml)
        $caux .= $chtml;
    if ($cjava)
        $caux .= "<script language=\"JavaScript\" >" . $cjava . "</script>";
    $caux .= "</html>";
    return $caux;
}

function HtmlTableOn($nborder = '', $npad = '', $nspace = '', $cwidth = '') {

    MyDefault($nborder, 0);
    MyDefault($npad, 0);
    MyDefault($nspace, 0);
    MyDefault($cwidth, "100%");
    if ($nborder > 998)
        return "</table>
	";

    return "<table border=\"" . $nborder . "\" cellpadding=\"" . $npad . "\" cellspacing=\"" . $nspace . "\" width=\"" . $cwidth . "\" >
  ";
}

function mysqli_linha($cTableString, $ccampos = '', $cwhere = '', $lSemIsDeleted = false) {
    return mysql_linha($cTableString, $ccampos, $cwhere, $lSemIsDeleted);
}

function mysql_linha($cTableString, $ccampos = '', $cwhere = '', $lSemIsDeleted = false) {
    global $db;
    if ($ccampos) {
        $caux = "select " . $ccampos . " from " . $cTableString . " where 1 ";
        if (!$lSemIsDeleted)
            $caux .= " and is_deleted='N' ";
        if ($cwhere)
            $caux .= " and " . $cwhere;
    } else {
        $caux = $cTableString;
    }
    return mysqli_fetch_array(mysqli_query($db, $caux));
}

function data_dif_sql($dataini, $datafim) {
//echo $datafim."/".$dataini;
    return ceil((mktime(0, 0, 0, substr($datafim, 5, 2), substr($datafim, 8, 2), substr($datafim, 0, 4)) - mktime(0, 0, 0, substr($dataini, 5, 2), substr($dataini, 8, 2), substr($dataini, 0, 4)) ) / 86400);
}

function data_dif($dataini, $datafim) {
    return ceil((mktime(0, 0, 0, substr($datafim, 3, 2), substr($datafim, 0, 2), substr($datafim, 6, 4)) - mktime(0, 0, 0, substr($dataini, 3, 2), substr($dataini, 0, 2), substr($dataini, 6, 4)) ) / 86400);
}

function hoje_sql() {
    return date("Y-m-d", time());
}

function hoje_html() {
    return date("d/m/Y", time());
}

function PegaVar($cvar, $lpost = false, $lget = false) {
    if (!$lpost && !$lget) {
        $lpost = true;
        $lget = true;
    }
    if ($lpost && array_key_exists($cvar, $_POST)) {
        return $_POST[$cvar];
    }
    if ($lget && array_key_exists($cvar, $_GET)) {
        return $_GET[$cvar];
    }
    return "";
}

function tira($cstr, $alista, $crep) {
    if (strlen($crep) == 0) {
        $crep = "";
    }
    for ($i = 0; $i < count($alista); $i++) {
        $cstr = str_replace($alista[$i], "", $cstr);
    }
    return $cstr;
}

function GravaSql($ctabela, $acampos, $lupdate, $cwhere) {
    global $db;
    if ($lupdate) {
        $cstr = "update ";
    } else {
        $cstr = "insert ";
    }
    $cstr .= $ctabela . " set ";
    for ($i = 0; $i < count($acampos); $i++) {
        if ($i > 0)
            $cstr .= ",";
        if ($acampos[$i][2]) {
            $cstr .= $acampos[$i][0] . "=" . $acampos[$i][1];
        } else {
            $cstr .= $acampos[$i][0] . "='";
//	    $cstr.=$acampos[$i][1]."'";
            $cstr .= str_replace("'", "\\'", $acampos[$i][1]) . "'";
        }
    }
    if ($cwhere) {
        $cstr .= " where " . $cwhere;
    }
    mysql_myquery($cstr);
//    men($cstr);
    $nid = mysqli_fetch_row(mysqli_query($db, "select last_insert_id()"));
    return $nid[0];
}

function bom($dat) {
    return mktime(0, 0, 0, date('m', $dat), '01', date('Y', $dat));
}

function eom($dat) {
    return mktime(0, 0, 0, date('m', $dat) + 1, 0, date('Y', $dat));
}

function bom_html() {
    return date('d/m/y', mktime(0, 0, 0, date('m'), '01', date('Y')));
}

function eom_html() {
    return date('d/m/y', mktime(0, 0, 0, date('m') + 1, 0, date('Y')));
}

function str2date($cdata, &$aRetMDY) {
    $cdata = str_replace("-", "", str_replace(" ", "", str_replace("/", "", $cdata)));
    $cdia = substr($cdata, 0, 2);
    $cmes = substr($cdata, 2, 2);
    $cano = substr($cdata, 4, 4);

    if ($cano < 100 && $cano > 20)
        $cano += 1900;
    if ($cano < 100 && $cano <= 20)
        $cano += 2000;
    $aRetMDY = array($cmes, $cdia, $cano);
    $cdia = mktime(0, 0, 0, $cmes, $cdia, $cano);
    return $cdia;
}

function str2data($ddata) {
    $cdia = date('d/m/Y', str2date($ddata));
    return $cdia;
}

function DateAddDays($data, $ndias, $lunix = false) {
    if ($lunix) {
        $data = Unix2Date($data)[1];
    }
    $data = substr($data, 0, 10);
    $d = DateTime::createFromFormat('d/m/Y', $data);
    if ($ndias > 0) {
        $d->modify('+' . $ndias . ' days');
    } else {
        $d->modify($ndias . ' days');
    }
    return $d->format('d/m/Y');
}

function somadata($ddata, $ndias, $ctipo) {
    $adata = array();
    str2date($ddata, $adata);
    if (strtoupper($ctipo) == "Y") {
        $adata[2] += $ndias;
    } elseif (strtoupper($ctipo) == "M") {
        $adata[0] += $ndias;
    } else {
        $adata[1] += $ndias;
    }
    return date("d/m/Y", mktime(0, 0, 0, $adata[0], $adata[1], $adata[2]));
}

function somadate($ddata, $ndias, $ctipo) {
    $adata = array(date("m", $ddata), date("d", $ddata), date("Y", $ddata));

    if (strtoupper($ctipo) == "Y") {
        $adata[2] += $ndias;
    } elseif (strtoupper($ctipo) == "M") {
        $adata[0] += $ndias;
    } else {
        $adata[1] += $ndias;
    }
    return mktime(0, 0, 0, $adata[0], $adata[1], $adata[2]);
}

function flink($clink, $sid, $avar, $ldireto) {
    if (!$clink)
        return "</a>";

    if ($ldireto) {
        $caux = "parent.location='$clink";
    } else {
        $caux = "<a href='$clink";
    }
    $caux .= ( strpos($clink, "?", 1) ? "&" : "?" ) . "sid=$sid";
    for ($i = 0; $i < count($avar); $i++) {
        $caux .= "&" . $avar[$i][0] . "=" . urlencode($avar[$i][1]);
    }
    if ($ldireto) {
        $caux .= "'";
    } else {
        $caux .= "'>";
    }
    return $caux;
}

function EncBrowser($nnum = '', $ldecifra = false) {
    $caux = "~A!B@C#D$E%F^G&H*I(J_K+L-M=N[O]P{Q}R<S>T?U,V.W/X|Y";
    $cret = "";
    if (!$ldecifra) {
        for ($i = 0; $i < strlen($nnum); $i++) {
            $naux = substr($nnum, $i, 1);
            $cret .= substr($caux, $i + $naux, 1);
        }
    } else {
        for ($i = 0; $i < strlen($nnum); $i++) {
            $naux = substr($nnum, $i, 1);
            $npos = strpos($caux, $naux);
            $cret .= ($npos - $i);
        }
    }

    return $cret;
}

function VeAcesso($noperador, $ncodigo) {
    global $db;
    global $lweb;

    if ($noperador == 1) {
        return true;
    }
    $otable = mysqli_query($db, "select * from php_wc_menu3 where codigo=$ncodigo and operador=$noperador ");
    if (mysqli_num_rows($otable) == 0) {
        return false;
    }
    $olinha = mysqli_fetch_array($otable);

    return $olinha["liberado"] > 0;
}

function VeAcesso1($noperador, $ncodigo) {
    global $db;
    global $lweb;
    $otable = mysqli_query($db, "select * from php_wc_menu1 where codigo=$ncodigo");
    $olinha = mysqli_fetch_array($otable);
    $nnivel = $olinha["nivel"];

//    $otable = mysqli_query($db, "select degrau as nivel from OPERADOR_OPE where bloq_vdas!='S' and codigo=$noperador and is_deleted='N'");
    $otable = mysqli_query($db, "select degrau as nivel from OPERADOR_OPE where codigo=$noperador and is_deleted='N'");
    $olinha = mysqli_fetch_array($otable);

    if ($nnivel > cifra($olinha["nivel"])) {
        return 0;
    }

    $otable = mysqli_query($db, "select * from php_wc_menu2 where (operador=$noperador 
    or operador=999999) and
    codigo=$ncodigo");
    return mysqli_num_rows($otable) == 0;
}

function iif($lcondicao, $rtrue, $rfalse) {
    if ($lcondicao) {
        return $rtrue;
    } else {
        return $rfalse;
    }
}

function assql($uvar, $ctipo = '') {
    if (strtoupper($ctipo) == 'D') {
        return "'" . date("Y-m-d", $uvar) . "'";
    } elseif (strtoupper($ctipo) == 'N') {
        return $uvar;
    } elseif (strtoupper($ctipo) == 'L') {
        return iff($uvar, 1, 0);
    } else {
        return "'" . $uvar . "'";
    }
}

function html_ir_para($curl, $lsemsid, $aparametros) {
    global $sid;
    $caux = "<html><body onload=\"location='" . $curl . "?";
    if (!$lsemsid) {
        $caux .= "sid=" . $sid;
    } else {
        $caux .= "no_sid=Y";
    }

    for ($i = 0; $i < count($aparametros); $i++) {
        $caux .= "&" . $aparametros[$i][0] . "=" . rawurlencode($aparametros[$i][1]);
    }

    $caux .= "'\" ></body></html>";
    echo $caux;
}

function multi_get_item($cvar) {
    strtok(getenv("REQUEST_URI"), "?");
    $caux = strtok("?");
    $aaux = split("&", $caux);
    $aret = array();
    for ($i = 0; $i < count($aaux); $i++) {
        $caux = strtok($aaux[$i], "=");
        if ($caux == $cvar) {
            $aret[] = strtok("=");
        }
    }
    return $aret;
}

function Num2Base($nNum, $nBase) {
    $cRet = "";

    while ($nNum > 0) {
        $cRet = SubStr("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ,./;[]\-=<>?:{}|!@#$%^&*()_+", ($nNum % $nBase), 1) . $cRet;
        $nNum = floor($nNum / $nBase);
    }

    return $cRet;
}

function VeConfigRma($ccampo) {
    global $db;

    $otable = mysqli_query($db, "select $ccampo from CONFIG_$cLojaRma ");
    $olinha = mysqli_fetch_row($otable);
    return $olinha[0];
}

function Conv850($cstr) {
    return iconv("cp850", "utf-8", $cstr);
}

function ConvWin($cstr) {
    return iconv("ISO-8859-1", "utf-8", $cstr);
}

function StrFile($cfile, $cstr, $lAppend = false) {
    $farq = fopen($cfile, ($lAppend ? "a" : "w"));
    $nret = fwrite($farq, $cstr);
    fclose($farq);
    return ($nret == strlen($cstr));
}

function FileStr($cfile) {
    $farq = fopen($cfile, "r");
    $conteudo = fread($farq, filesize($cfile));
    fclose($farq);
    return ($conteudo);
}

function veconfig($ccampo = '', $noperador = 0) {
    global $db;
    global $server;
    global $port;
    global $user;
    global $password;
    global $database;
    global $lweb;
    if (!$db)
        conecta($server, $port, $user, $password, $database);
    if (!$ccampo) {
        mysqli_query($db, "create table if not exists php_wc_config_geral (codigo int(10) not null auto_increment primary key,valor text)");
        $otable = mysqli_query($db, "select count(*) as total from php_wc_config_geral");
        $olinha = mysqli_fetch_array($otable);
        for ($i = $olinha["total"]; $i < cfg_max; $i++) {
            mysqli_query($db, "insert php_wc_config_geral set valor=''");
        }
        return true;
    }
    if (!$noperador) {
        $otable = mysqli_query($db, "select valor from php_wc_config_geral where codigo=$ccampo");
        $olinha = mysqli_fetch_row($otable);
        return $olinha[0];
    } else {
        $otable = mysqli_query($db, "select $ccampo from php_wc_config_operador where usuario=$noperador");
        $olinha = mysqli_fetch_row($otable);
        return $olinha[0];
    }
}

function CriaSelect($cnome, $aselect, $nlinha) {
    MyDefault($nlinha, 1);

    $caux = "<select size=\"" . $nlinha . "\" ";
    if ($nlinha > 1)
        $caux .= " multiple ";
    $caux .= " id=\"$cnome\"  name=\"" . $cnome . "\" >";

    for ($i = 0; $i < count($aselect); $i++) {
        $caux .= "<option ";
        $aaux = explode(",", $aselect[$i]);
        if ($aaux[2])
            $caux .= " selected ";
        $caux .= " value=\"" . $aaux[1] . "\">" . $aaux[0] . "</option>";
    }
    $caux = $caux . "</select>";

    return $caux;
}

function VeSaldoProduto($nproduto, $nloja) {
    global $db;

    if (!$nproduto || !$nloja) {
        return 0;
    }
    if (VeConfigCec("MINMAX") == "S") {
        $csql = "select if(isnull(r.prores) or r.quares=0 or r.quares>l.qualoc,l.qualoc,r.quares) as qualoc from LOCAL_LOC l left join RESTOK_PRO r on r.is_deleted='N' and r.lojres=l.locloc and r.prores=l.proloc where l.is_deleted='N' and l.LOCLOC=$nloja and l.PROLOC=$nproduto ";
    } else {
        $csql = "select qualoc from LOCAL_LOC where is_deleted='N' and LOCLOC=$nloja and PROLOC=$nproduto ";
    }
    $otab = mysqli_query($db, $csql);
    $olin = mysqli_fetch_row($otab);

    if (!$olin || !$olin[0]) {
        return 0;
    }
    return $olin[0];
}

/*
 * $aselect = array( array(<codigo>,<nome>,[<marcado>],[<desabilitado>]), ....)
 * $amark = vetor com os itens marcados
 * $adisabled = vetor com os itens desabilitados
 * $nmarcados = 0 - todos    1 - Apenas sem selecionar    2 - Apenas selecionados
 * 
 */

function CriaSelectCheck($cnome, $aselect, $nlargura = 300, $naltura = 100, $ctabela, $ccampos, $cwhere, $amark, $adisabled, $nmarcados = 0) {
    global $db;

    if ($ctabela) {
        $cstr = "select $ccampos from $ctabela ";
        if ($cwhere) {
            $cstr .= " where $cwhere ";
        }
        $otable = mysqli_query($db, $cstr);
        $aselect = array();
        while ($olinha = mysql_fetch_array($otable)) {
            $aselect[] = array($olinha[0], $olinha[1]);
        }
    }

    for ($i = 0; $i < count($aselect); $i++) {
        if (count($aselect[$i]) == 2) {
            $aselect[$i] = array($aselect[$i][0], $aselect[$i][1], false);
        }
        if (count($aselect[$i]) == 3) {
            $aselect[$i] = array($aselect[$i][0], $aselect[$i][1], $aselect[$i][2], false);
        }
        $lmark = false;
        foreach ($amark as $value) {
            if ($value == $aselect[$i][0]) {
                $lmark = true;
            }
        }
        $aselect[$i][2] = $lmark;

        $lmark = false;
        foreach ($adisabled as $value) {
            if ($value == $aselect[$i][0]) {
                $lmark = true;
            }
        }
        $aselect[$i][3] = $lmark;
    }

    if ($amark) {
        $asaida = array();
        if ($nmarcados == 2 || $nmarcados == 0) {
            foreach ($aselect as $avalue) {
                if ($avalue[2]) {
                    $asaida[] = $avalue;
                }
            }
        }
        if ($nmarcados == 1 || $nmarcados == 0) {
            foreach ($aselect as $avalue) {
                if (!$avalue[2]) {
                    $asaida[] = $avalue;
                }
            }
        }
        $aselect = $asaida;
    }


    $caux = "
     <style>
    #$cnome  { height: " . $naltura . "px; overflow: auto; width: " . $nlargura . "px; border: 1px solid #000; }
    #$cnome { list-style-type: none; margin: 0; padding: 0; overflow-x: hidden; }
    #$cnome li { margin: 0; padding: 0; }
    #$cnome label { display: block; color: WindowText; background-color: Window; margin: 0; padding: 0; width: 100%; }
    #$cnome label:hover { background-color: Highlight; color: HighlightText; }
</style>    


<ul id=\"$cnome\">
    ";

    $i = 0;
    foreach ($aselect as $avalue) {
        ++$i;
        $caux .= "<li><label for=\"$cnome" . $i . "\"><input type=\"checkbox\" name=\"$cnome" . $avalue[0] . "\" id=\"$cnome" . $i . "\" " . ($avalue[2] ? " checked  " : "") . ($avalue[3] ? " disabled  " : "") . ">" . $avalue[1] . "-" . $avalue[0] . "</label></li>
        ";
    }

    $caux .= "</ul>
    ";

    return $caux;
}

function img2html($ctexto) {
    $ctexto = str_replace(chr(141), CR, $ctexto);
    $ctexto = str_replace(chr(13) . chr(10), CR, $ctexto);
    $ctexto = str_replace(chr(10), CR, $ctexto);
    $ctexto = utf8_encode($ctexto);

    return $ctexto;
}

function Date2Unix($cData = '', $cHora = '', $lsql = false, $lutc = false) {
    global $ctimezone;
    if (!$cData) {
        $cData = date("d/m/Y");
        $lsql = false;
    }

    if (!$cHora) {
        $cHora = date("H:i:s");
    }

    $ahora = explode(":", $cHora . ":00:00");
    $adata = array(0, 0, 0);
    if ($lsql) {
        $aaux = explode("-", $cData);
        $adata[0] = $aaux[2];
        $adata[1] = $aaux[1];
        $adata[2] = $aaux[0];
    } else {
        $aaux = explode("/", $cData);
        $adata[0] = $aaux[0];
        $adata[1] = $aaux[1];
        $adata[2] = $aaux[2];
    }
    $nhora = mktime($ahora[0], $ahora[1], $ahora[2], $adata[1], $adata[0], $adata[2]);

    if (!$lutc) {
        $dateTimeZoneUTC = new DateTimeZone("UTC");
        $dateTimeZoneLOCAL = new DateTimeZone($ctimezone);

        $dateTimeUTC = new DateTime("now", $dateTimeZoneUTC);
        $dateTimeLOCAL = new DateTime("now", $dateTimeZoneLOCAL);

        $timeOffset = $dateTimeZoneLOCAL->getOffset($dateTimeUTC);
        $nhora += $timeOffset;
    }




    return $nhora;
}

function Unix2Date($nHora, $lsql = false, $lutc = false) {
    global $ctimezone;
    if (!$lutc) {
        $dateTimeZoneUTC = new DateTimeZone("UTC");
        $dateTimeZoneLOCAL = new DateTimeZone($ctimezone);

        $dateTimeUTC = new DateTime("now", $dateTimeZoneUTC);
        $dateTimeLOCAL = new DateTime("now", $dateTimeZoneLOCAL);

        $timeOffset = $dateTimeZoneLOCAL->getOffset($dateTimeUTC);
        $nHora -= $timeOffset;
    }

    $adata = array("", "", "");
    $adata[2] = date("H:i:s", $nHora);

    if ($lsql) {
        $adata[0] = date("Y-m-d H:i:s", $nHora);
        $adata[1] = date("Y-m-d", $nHora);
    } else {
        $adata[0] = date("d/m/Y H:i:s", $nHora);
        $adata[1] = date("d/m/Y", $nHora);
    }
    return $adata;
}

function Sec2Time($nHora) {
    $nsegundos = $nHora % 60;
    $nminutos = floor($nHora / 60) % 60;
    $nhora = floor($nHora / 60 / 60);

    if ($nhora > 99) {
        $cret = $nhora;
    } else {
        $cret = str_pad($nhora, 2, "0", STR_PAD_LEFT);
    }
    $cret .= ":";
    $cret .= str_pad($nminutos, 2, "0", STR_PAD_LEFT);
    $cret .= ":";
    $cret .= str_pad($nsegundos, 2, "0", STR_PAD_LEFT);
    return $cret;
}

function GeraSenha($ntam) {
    //alert(parseInt((Math.random()*10000)%62));
    $caux = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    while (true) {
        $csenha = "";
        for ($i = 0; $i < $ntam; $i++) {
            $csenha .= substr($caux, rand(0, 61), 1);
        }
        preg_match("/[0-9]/", $csenha, $cret);
        if (count($cret) == 0) {
            continue;
            ;
        }
        preg_match("/[A-Z]/", $csenha, $cret);
        if (count($cret) == 0) {
            continue;
            ;
        }
        preg_match("/[a-z]/", $csenha, $cret);
        if (count($cret) == 0) {
            continue;
            ;
        }
        break;
    }
    return $csenha;
}

function randString($size) {
    //String com valor possíveis do resultado, os caracteres pode ser adicionado ou retirados conforme sua necessidade
    $basic = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    $return = "";

    for ($count = 0; $size > $count; $count++) {
        //Gera um caracter aleatorio
        $return .= $basic[rand(0, strlen($basic) - 1)];
    }

    return $return;
}

//Imprime uma String randônica com 20 caracteres

function LimpaRg($crg, $lSemLetras = false) {
    $crg = strtoupper($crg);
    $cret = '';

    for ($ni = 0; $ni < strlen($crg); $ni++) {
        $naux = ord($crg[$ni]);
        if ($lSemLetras) {
            if (($naux >= 48 && $naux <= 57)) {
                $cret .= substr($crg, $ni, 1);
            }
        } else {
            if (($naux >= 65 && $naux <= 90) || ($naux >= 48 && $naux <= 57)) {
                $cret .= substr($crg, $ni, 1);
            }
        }
    }
    return $cret;
}

function Commit($afile) {
    global $ccomimit;
    $caux = "";
    foreach ($afile as $value) {
        $caux .= $value;
    }
    $caux = substr($caux, 1);
    if ($caux) {
        file($ccomimit . " \"refresh=$caux\" ");
    }
}

function LimpaChar($cstr) {
    $cret = "";
    $cstr = strtoupper($cstr);
    $areplace = array();
    $areplace[] = array("ñ", "N");
    $areplace[] = array("Ñ", "N");
    $areplace[] = array("Á", "A");
    $areplace[] = array("Ã", "A");
    $areplace[] = array("Â", "A");
    $areplace[] = array("Ä", "A");
    $areplace[] = array("À", "A");
    $areplace[] = array("á", "A");
    $areplace[] = array("ã", "A");
    $areplace[] = array("â", "A");
    $areplace[] = array("ä", "A");
    $areplace[] = array("à", "A");
    $areplace[] = array("É", "E");
    $areplace[] = array("È", "E");
    $areplace[] = array("Ê", "E");
    $areplace[] = array("Ë", "E");
    $areplace[] = array("é", "E");
    $areplace[] = array("è", "E");
    $areplace[] = array("ê", "E");
    $areplace[] = array("ë", "E");
    $areplace[] = array("Í", "I");
    $areplace[] = array("Ì", "I");
    $areplace[] = array("Î", "I");
    $areplace[] = array("Ï", "I");
    $areplace[] = array("í", "I");
    $areplace[] = array("ì", "I");
    $areplace[] = array("î", "I");
    $areplace[] = array("ï", "I");
    $areplace[] = array("Õ", "O");
    $areplace[] = array("Ó", "O");
    $areplace[] = array("Ò", "O");
    $areplace[] = array("Ô", "O");
    $areplace[] = array("Ö", "O");
    $areplace[] = array("õ", "O");
    $areplace[] = array("ó", "O");
    $areplace[] = array("ò", "O");
    $areplace[] = array("ô", "O");
    $areplace[] = array("ö", "O");
    $areplace[] = array("Ú", "U");
    $areplace[] = array("Ù", "U");
    $areplace[] = array("Û", "U");
    $areplace[] = array("Ü", "U");
    $areplace[] = array("ú", "U");
    $areplace[] = array("ù", "U");
    $areplace[] = array("û", "U");
    $areplace[] = array("ü", "U");
    $areplace[] = array("Ý", "Y");
    $areplace[] = array("ý", "Y");
    $areplace[] = array("Ç", "C");
    $areplace[] = array("ç", "C");
    $areplace[] = array("%", "/");

    foreach ($areplace as $value) {
        $cstr = str_replace($value[0], $value[1], $cstr);
    }
    $cstr = strtoupper($cstr);
    $cret = preg_replace('/[\x00-\x1F\x7F-\xFF]/', '', $cstr);
    return $cret;
}

function VeConfigCec($cVar) {
    global $db;
    global $aConfigCec;
    global $lweb;
    if (count($aConfigCec) == 0) {
        $aaux = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG WHERE RECNO=1"));
        $aaux1 = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG2 WHERE RECNO=1"));
        foreach ($aaux as $key => $value) {
            if (!is_numeric($key)) {
                $aConfigCec[$key] = $aaux[$key];
            }
        }
        foreach ($aaux1 as $key => $value) {
            if (!is_numeric($key)) {
                $aConfigCec[$key] = $aaux1[$key];
            }
        }
    }
    return $aConfigCec[strtoupper($cVar)];
}

/*
  function VeConfigCec($cCampo) {
  global $aConfigCec;
  global $db;
  if (count($aConfigCec) == 0) {
  $olin = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG WHERE RECNO=1"),MYSQLI_ASSOC);
  foreach ($olin as $key => $value) {
  $aConfigCec[$key]=$value;
  }
  }
  $cCampo= strtoupper($cCampo);
  return $aConfigCec[$cCampo];
  }
 */

function padr($cstr, $ntam = 10, $cpad = " ") {
    return str_pad($cstr, $ntam, $cpad, STR_PAD_RIGHT);
}

function padl($cstr, $ntam = 10, $cpad = " ") {
    return str_pad($cstr, $ntam, $cpad, STR_PAD_LEFT);
}

function padc($cstr, $ntam = 10, $cpad = " ") {
    return str_pad($cstr, $ntam, $cpad, STR_PAD_BOTH);
}

function VeDigitoRuc($uRuc, $nBase = 11) {
    $lRet = false;

    if (!$uRuc) {
        return true;
    }

    $cRuc = Trim($uRuc);
    $nDigito = substr($cRuc, -1);
    $cRuc = substr($cRuc, 0, -1);

    if (LimpaRg($cRuc, true) !== $cRuc) {
        return false;
    }

    return CalcDigitoRuc($cRuc, 11) == $nDigito;
}

function CalcDigitoRuc($uRuc, $nBase = 11) {

    $cRuc = trim($uRuc);
    $cCaracter = "";
    $nNumero_a1 = "";

    $k = 2;
    $nTotal = 0;
    $nNumero_aux = 0;
    $nResto = 0;
    $nDigito = 0;

    for ($i = 0; $i < strlen($cRuc); $i++) {
        $cCaracter = SubStr($cRuc, $i, 1);
        $cCaracterAscii = ord($cCaracter);
        if ($cCaracterAscii >= 48 && $cCaracterAscii <= 57) {
            $nNumero_a1 .= $cCaracter;
        } else {
            $nNumero_a1 .= $cCaracterAscii;
        }
    }
    for ($i = strLen($nNumero_a1); $i >= 1; $i--) {
        if ($k > $nBase) {
            $k = 2;
        }
        $nNumero_aux = SubStr($nNumero_a1, $i - 1, 1) + 0;
        $nTotal += $nNumero_aux * $k;
        $k++;
    }

    $nResto = $nTotal % 11;
    if ($nResto > 1) {
        $nDigito = 11 - $nResto;
    } else {
        $nDigito = 0;
    }

    return $nDigito;
}

function ExisteSql($cfile, $db1 = '') {
    global $db;
    if (!$cfile) {
        return false;
    }
    if (!$db1) {
        $db1 = $db;
    }
    if (!$db1) {
        return false;
    }
    $cfile = str_replace(".", "_", $cfile);
    if (substr($cfile, -4) == "_DBF") {
        $cfile = substr($cfile, 0, -4);
    }
    return (mysqli_num_rows(mysqli_query($db1, "show tables like '$cfile'")) > 0);
}

function aicrypt($str, $key = '') {
    if (!$key) {
        $key = hex2bin("3432353235353435524f424552544f534b41554b454d4d45523539353835303438393439415254485552534b41554b454d4d45524341544152494e45434f5554494e484f4b454d4d4552474c41554349414d4152434f4c494e4f4b454d4d455245554445534755535441564f444153494c5641");
    }
    $slen = strlen($str);
    $klen = strlen($key);

    # <-- IMPORTANTE: só retorna cedo se AMBAS forem < 2 (comportamento VO/Harbour)
    if ($slen < 2 && $klen < 2) {
        return $str;
    }

    # leitura "raw" little-endian dos dois primeiros bytes da chave
    $b0 = ord($key[0]);
    $b1 = ord($key[1]);
    $nCode1 = ((($b1 << 8) | $b0) ^ $klen) & 0xFFFF;

    $nCode2 = 0xAAAA;
    $res = "";
    $j = 0;

    for ($i = 0; $i < $slen; $i++) {

        if ($j >= $klen)
            $j = 0;

        $c1 = ord($str[$i]);
        $c2 = ord($key[$j]);
        $c = ($c1 ^ $c2) & 0xFF;

        # bloco 1: atualizar nCode1
        $nCode1 ^= ($nCode1 >> 8);
        $nRotate = $nCode1 & 0xF;

        if ($nRotate !== 0) {
            $nTemp1 = ($nCode1 >> $nRotate) & 0xFFFF;
        } else {
            $nTemp1 = $nCode1 & 0xFFFF;
        }
        $nTemp2 = ($nCode1 << (16 - $nRotate)) & 0xFFFF;
        $nCode1 = ($nTemp1 | $nTemp2) & 0xFFFF;

        $nCode1 ^= $nCode2;
        $nCode1 = ($nCode1 + 0x10) & 0xFFFF;

        $nCounter = ($nCode1 & 0x1E) + 2;

        # bloco 2: atualizar nCode2 — atenção: decremento duplo por iteração (como no VO)
        if ($nCounter > 0) {
            while (true) {
                $nCounter--; // primeiro decremento

                $nRotate = $nCounter & 0xF;

                if ($nRotate !== 0) {
                    $t1 = $nCode2 >> $nRotate;
                } else {
                    $t1 = $nCode2;
                }
                $t2 = ($nCode2 << (16 - $nRotate)) & 0xFFFF;
                $nCode2 = ($t1 | $t2) & 0xFFFF;

                # nCode2 = OR( nCode2 << 8 , XOR( nCode2 >> 8, 0xFF ) )
                $hi = ($nCode2 >> 8) & 0xFF;
                $lo = $nCode2 & 0xFF;
                $hi ^= 0xFF;
                $nCode2 = ((($lo << 8) | $hi) & 0xFFFF);

                # rotate-left-1 with wrap
                $carry = ($nCode2 & 0x8000) ? 1 : 0;
                $nCode2 = ((($nCode2 << 1) & 0xFFFF) | $carry) & 0xFFFF;

                $nCode2 ^= 0xAAAA;

                # nibble manipulation (8-bit)
                $nibble = $nCode2 & 0xFF;
                $tmp = $nibble << 1;
                if ($tmp > 255)
                    $tmp -= 255;
                $nibble = ($tmp | ($nibble >> 7)) & 0xFF;

                $nCode2 = ($nCode2 & 0xFF00) | $nibble;

                $nCounter--; // SEGUNDO decremento (replica exatamente do/while(--x) do código original)

                if (!($nCounter > 0))
                    break;
            }
        }

        $final = ($c ^ ($nCode2 & 0xFF)) & 0xFF;
        $res .= chr($final);

        $j++;
    }

    return $res;
}

# helpers para HEX

function decryptHarbourHex($hex, $key) {
    return aicrypt(hex2bin($hex), $key);
}

function encryptHarbourToHex($plain, $key) {
    return strtoupper(bin2hex(aicrypt($plain, $key)));
}

function gera_ser() {
    global $db;
    global $lweb;

    $caux = mysqli_fetch_row(mysqli_query($db, "select PRECO1 FROM CONFIG_FPT WHERE RECNO=1"))[0];
    $caux = aicrypt($caux);
    $aPos = array(SubStr($caux, 0, 2) + 0, SubStr($caux, 2, 2) + 0, SubStr($caux, 4, 2) + 0, SubStr($caux, 6, 2) + 0, SubStr($caux, 8, 2) + 0, SubStr($caux, 10, 2) + 0);
    $caux = mysqli_fetch_row(mysqli_query($db, "select PRECO" . $aPos[0] . " FROM CONFIG_FPT WHERE RECNO=1"))[0];
    $caux = aicrypt($caux);

    $caux = SubStr($caux, 12);
    $nSer = $caux + 0;

    $cnomeserial = mysqli_fetch_row(mysqli_query($db, "select nome_cli FROM CONFIG WHERE RECNO=1"))[0];
    $cnomeserial = trim($cnomeserial);
    $nAux = 0;
    for ($i = 1; $i <= strlen($cnomeserial); $i++) {
        $nAux += floor(pow(( ord(SubStr($cnomeserial, $i - 1, 1)) * $i), 3) / $i);
    }
    $nSer = floor(( ( $nAux * 1000 ) / ( $nSer / 100 ) ) * 100);
    return $nSer;
}

function VeAutSenhas($noperador, $ncope) {
    global $db;
    global $aSenhaAutoriza;
    if (!$noperador) {
        return false;
    }
    if (!is_numeric($ncope)) {
        $ncope=$aSenhaAutoriza[strtoupper(trim($ncope))];
    }
    if (!$ncope){
        return false;
    }
    $olin=mysqli_fetch_row(mysqli_query($db,"select c.SITOPG FROM OPEGRUPO_OPE c inner join OPERADOR_OPE o on o.is_deleted='N' and o.codigo=$noperador and c.codopg=(cifra(o.grupo)+0) where c.is_deleted='N' and opeopg=$ncope "));
    if (!$olin){
        return false;
    }
    return trim($olin[0])=="X";
}
