<?php

$server = "localhost";
$port = "3306";
$user = "root";
$password = "KoNeCt@3313" ;
$database = "cec";

$cNomeCli="********Consoft S.A.********";
