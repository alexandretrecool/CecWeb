<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_erros', 1);

require_once 'mysql.php';
if (file_exists("connect.php")){
    require_once 'connect.php';
}
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$db = mysqli_connect($server, $user, $password, $database, $port);
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = "Erro acessando servidor<br>\n". mysqli_connect_error();
}
sleep(15);
echo json_encode($aret);
return;