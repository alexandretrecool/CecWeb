<?php
$server = "192.168.12.110";
$port = "3306";
$user = "root";
$password = "KoNeCt@3313" ;
$database = "cec";
