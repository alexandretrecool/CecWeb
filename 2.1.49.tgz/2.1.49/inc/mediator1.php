<?php

error_reporting(0);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);
require_once 'mysql.php';
if ($lCfRdd){
require_once 'mediator4.php';
}else{
require_once 'mediator3.php';
}
/*

  //commit
  $omed = new MedCommit("transfe.tra,protra.tra", true);
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //ADICIONAR REGISTRO
  $omed = new MedCommit("transfe.tra", false, true);
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //DELETAR
  $omed = new MedCommit("transfe.tra", false, false,true,336985);
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //ATUALIZAR REGISTRO
  $omed = new MedCommit("transfe.tra", false, true,false,336985,array("obstra" => "okokokokokok"));
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //INCLUIR REGISTRO
  $omed = new MedCommit("transfe.tra", false, true,false,0,array("obstra" => "&Teste de ação à data 01/01/2018"));
  //var_dump($omed->erro);
  //var_dump($omed->cerro);

  return;
 */

class MedCommit {

    public $nrecno;
    private $ctabela;
    private $acampos = "";
    private $cgrava = "";
    private $commit = 'http://localhost/cgi-bin/mediator.new';
    private $aret = array();
    public $erro = 0;
    public $cerro = "";

    public function __construct($cTabela = '', $lRefresh = false, $lAdiciona = false, $lDeleta = false, $nRecno = 0, $aCampos = array()) {
        global $ccommit_new;
        if ($ccommit_new) {
            $this->commit = $ccommit_new;
        }
        if (!$this->commit) {
            $this->cerro = "Sem COMMIT CONFIGURADO";
            $this->erro = 1;
            return false;
        }
        if (!$cTabela) {
            $this->cerro = "Sem tabela informada";
            $this->erro = 1;
            return false;
        }
        $this->ctabela = $cTabela;
        if ($lRefresh) {
            $this->cgrava = "refresh=" . $this->ctabela;
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (trim($this->aret[0]) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                return;
            }
            if (trim($this->aret[0]) == "OK:") {
                $this->erro = 0;
                for ($i = 1; $i < count($this->aret); $i++) {
                    if (trim($this->aret[$i])) {
                        $this->cerro .= "," . $this->aret[1];
                        $this->nrecno .= "," . explode("-", $this->aret[$i])[0];
                    }
                }
                $this->nrecno = substr($this->nrecno, 1);
                $this->cerro = substr($this->cerro, 1);
                return;
            }
            $this->cerro = $this->aret[0];
            return;
        }
        if ($lDeleta) {
            if (!$nRecno) {
                $this->erro = 99;
                $this->cerro .= "Registro não passao";
            }
            $this->cgrava = "tabela=" . $this->ctabela . "&recno=" . ($nRecno * -1);
            //var_dump($this->cgrava);
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (trim($this->aret[0]) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                return;
            }
            if (trim($this->aret[0]) == "OK:") {
                $this->erro = 0;
                $this->cerro .= $this->aret[1];
                $this->nrecno .= $nRecno;
                return;
            }
            $this->cerro = $this->aret[0];
            return;
        }
        if ($lAdiciona && !$aCampos) {
            $this->cgrava = "tabela=" . $this->ctabela . "&recno=0";
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (trim($this->aret[0]) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                return;
            }
            if (trim($this->aret[0]) == "OK:") {
                $this->erro = 0;
                $this->cerro .= $this->aret[1];
                $this->nrecno .= explode("-", $this->aret[1])[0];
                return;
            }
            $this->cerro = $this->aret[0];
            return;
        }
        if ($aCampos) {
            $this->cgrava = "tabela=" . $this->ctabela . "&recno=" . ($lAdiciona ? "0" : $nRecno);
            foreach ($aCampos as $key => $value) {
                $this->cgrava .= "&CMP$key=" . str_replace("+", "%20", urlencode(iconv("utf8", "cp850", $value)));
            }
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (trim($this->aret[0]) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                return;
            }
            if (trim($this->aret[0]) == "OK:") {
                $this->erro = 0;
                $this->cerro .= $this->aret[1];
                $this->nrecno .= explode("-", $this->aret[1])[0];
                return;
            }
            $this->cerro = $this->aret[0];
            return;
        }
    }

    private function grava() {
        $cstr = $this->commit . "?" . $this->cgrava;
        $this->aret = file($cstr);
        if ($this->aret[0] == "ERR:") {
            $this->erro = 0;
            $this->nerro = $this->aret[1];
            $this->cerro = $this->aret[2];
            return;
        }
        //var_dump($this->aret);
    }

}

class Mediator {

    public $db;
    public $arquivo;
    public $tabela;
    public $where;
    public $cerro = "";
    public $lok = false;
    private $campos = array();
    private $codigo = "";
    public $ncodigo = 0;
    private $agrava = array();
    public $nrecno = 0;
    public $arecno = array();

    public function limpa() {
        $this->agrava = array();
        $this->nrecno = 0;
        $this->arecno = array();
        $this->lok = false;
        $this->ncodigo = 0;
        $this->cerro = "";
    }

    public function CriaFunction() {

        $afuncoes = array();
        $afuncoes["ctod"] = "create function ctod(cstr varchar(256))
returns varchar(100)
begin
	declare dia char(2);
	declare mes char(2);
	declare ano varchar(4);

	set dia=substring_index(cstr,'/',1);
	set mes=substring_index(cstr,'/',-2);
	set mes=substring_index(mes,'/',1);
	set ano=substring_index(cstr,'/',-1);

	set dia=lpad(dia,2,'0');
	set mes=lpad(mes,2,'0');
	if length(ano) = 2 then
    	    set ano=concat('20',ano);
	end if;
	set ano=lpad(ano,4,'0');

 	return concat(ano,'-',mes,'-',dia);
end
";
        $afuncoes["dtoc"] = "create function dtoc(cstr varchar(256))
returns varchar(100)

begin
 	return concat(substr(cstr,9,2),'/',substr(cstr,6,2),'/',substr(cstr,3,2));
end
";
        $afuncoes["alltrim"] = "create function alltrim(cstr varchar(256))
returns varchar(100)

begin
 	return trim(cstr);
end
";
        $afuncoes["len"] = "create function len(cstr varchar(256))
returns varchar(100)

begin
 	return length(cstr);
end
";
        $afuncoes["str"] = "create function str(numero DECIMAL(25,10),tam INT)
returns varchar(100)
begin
        declare deci int(1) default 0;
	declare cret varchar(100) default '';
	declare cdec varchar(20) default '';
	if (deci>0) THEN
		set cret=lpad(floor(numero),tam-1-deci,' ');
		set cdec=concat((numero%1),'0000000000');
		set cdec=substr(cdec,3,deci);
		return concat(cret,'.',cdec);	
	end if;
 	return lpad(round(numero,0),tam,' ');
end

";
        $afuncoes["strzero"] = "create function strzero(numero DECIMAL(25,10),tam INT,deci INT)
returns varchar(100)
begin
	declare cret varchar(100) default '';
	declare cdec varchar(20) default '';
	if (deci>0) THEN
		set cret=lpad(floor(numero),tam-1-deci,'0');
		set cdec=concat((numero%1),'0000000000');
		set cdec=substr(cdec,3,deci);
		return concat(cret,'.',cdec);	
	end if;
 	return lpad(round(numero,0),tam,'0');
end
";
        $afuncoes["dtos"] = "create function dtos(ddata CHAR(10))
returns varchar(30)

begin
return if(ddata='1000-01-01','        ',replace(ddata,'-',''));
return 'lpad(\''+if(ddata='1000-01-01','        ',replace(ddata,'-',''))+'\',8,\'\')';
end
";
        $afuncoes["val"] = "create function val(cstr VARCHAR(20))
returns DECIMAL(12,2)

begin
    return cstr+0;
end
";
        $afuncoes["descend"] = "create function descend(cstr VARCHAR(20))
returns varchar(20)

begin
declare i int default 0;
declare cret varchar(20) default '';

while (i<length(cstr)) DO
    set cret = concat(cret,char(256-ascii(substr(cstr,i+1,1))));
    set i = i+1;
end while;
return cret;
end
";
        foreach ($afuncoes as $key => $value) {
            if (mysqli_num_rows(mysqli_query($this->db, "show function status where db=database() and name='$key'")) == 0) {
                mysqli_query($this->db, $value);
//                ////var_dump($value);
            }
//            ////var_dump(mysqli_error($this->db));
        }
    }

    public function init($db, $cArquivo, $cWhere = '', $cCampoCodigo = '') {
        if (!$db) {
            $this->cerro = "Erro conectando à database";
            return false;
        }
        $this->db = $db;
        $this->where = $cWhere;
        if (!$cArquivo) {
            $this->cerro = "Falta parâmetros";
            return false;
        }
        $this->CriaFunction();
        $this->codigo = strtoupper($cCampoCodigo);
        $this->arquivo = $cArquivo;
        $this->tabela = strtoupper($cArquivo);
        $this->tabela = str_replace(".", "_", $this->tabela);
        if (substr($this->tabela, -4) == "_DBF") {
            $this->tabela = substr($this->tabela, 0, -4);
        }
        $otable = mysqli_query($this->db, "SELECT COL_NAME NAME
,IF(COL_CLP_TYPE=1,'C',
IF(COL_CLP_TYPE=2048,'N',
IF(COL_CLP_TYPE=65,'M',
IF(COL_CLP_TYPE=8,'D',
IF(COL_CLP_TYPE=4,'L',
'' ))))) TIPO
,IF(COL_CLP_TYPE=1,COL_CLP_LEN,
IF(COL_CLP_TYPE=2048,COL_CLP_LEN,
IF(COL_CLP_TYPE=65,10,
IF(COL_CLP_TYPE=8,8,
IF(COL_CLP_TYPE=4,1,
'0' ))))) TAMANHO
,IF(COL_CLP_TYPE=2048,COL_CLP_DEC,'0') DECIMAIS
FROM CLP_TAB_COLS
WHERE TAB_NAME='" . $this->tabela . "'
");
        if (mysqli_num_rows($otable) == 0) {
            $this->cerro = "Tabela " . $this->tabela . " não encontrada";
            return false;
        }
        while ($olinha = mysqli_fetch_array($otable)) {
            $this->campos[$olinha["NAME"]] = array("NAME" => $olinha["NAME"], "TIPO" => $olinha["TIPO"], "TAMANHO" => $olinha["TAMANHO"], "DECIMAIS" => $olinha["DECIMAIS"]);
        }
        return true;
    }

    public function aadd($cCampo, $uValor, $lDireto = false) {
        if (!$lDireto) {
            $this->agrava[strtoupper($cCampo)] = $uValor;
        } else {
            $this->agrava[strtoupper($cCampo)] = "'" . $uValor . "'";
        }
    }

    public function grava() {
        global $ccommit;
        global $ccommit_new;
        if (!$this->where) {
            if ($this->codigo) {
                $this->ncodigo = mysqli_fetch_array(mysqli_query($this->db, "select max($this->codigo) as codigo from " . $this->tabela))[0] + 1;
                if (mysqli_errno($this->db)) {
                    $this->cerro = mysqli_error($this->db);
                    return false;
                }
                $this->agrava[$this->codigo] = $this->ncodigo;
            }

            $cstr = "insert ";
            $cstr .= $this->tabela . " (`RECNO`";

            foreach ($this->agrava as $key => $value) {
                $cstr .= "," . $key;
            }
            $cstr .= ") values (RECNO";

            foreach ($this->agrava as $key => $value) {
                $cstr .= ",";
                if ($this->campos[$key]["TIPO"] == "N") {
                    if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                    } else {
                        $value = "'" . addslashes($value) . "'";
                    }
                    $cstr .= $value;
                } elseif ($this->campos[$key]["TIPO"] == "L") {
                    $cstr .= strtoupper($value) == "N" || strtoupper($value) == "F" || !strtoupper($value) ? "'N'" : "'Y'";
                } elseif ($this->campos[$key]["TIPO"] == "M") {
                    $cstr .= "0";
                } else {
                    if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                    } else {
                        $value = "'" . addslashes($value) . "'";
                    }
                    $cstr .= $value;
                }
            }
            $cstr .= ")";
            $ltradicional = true;
            if ($ccommit_new) {
                $omed = new MedCommit($this->arquivo, false, true);
                if ($omed->nrecno) {
                    $ltradicional = false;
                    $this->arecno[] = $omed->nrecno;
                    $this->nrecno = $omed->nrecno;
                } else {
                    return false;
                }
            }
            if ($ltradicional) {
                $this->nrecno = (mysqli_fetch_row(mysqli_query($this->db, "select max(recno) from $this->tabela"))[0]) + 1;
                if (mysqli_errno($this->db)) {
                    $this->cerro = mysqli_error($this->db);
                    return false;
                }

                $this->arecno[] = $this->nrecno;
            }
            $cstr = str_replace("(RECNO,", "(" . $this->nrecno . ",", $cstr);
            if (!$ltradicional) {
                $cstr = "replace " . substr($cstr, 7);
            }
            mysqli_query($this->db, "LOCK TABLES " . $this->tabela . " WRITE");
            if (mysqli_errno($this->db)) {
                $this->cerro = mysqli_error($this->db);
                return false;
            }

            mysqli_query($this->db, $cstr);
            if (mysqli_errno($this->db)) {
                $this->cerro = mysqli_error($this->db);
                return false;
            }
            if (!$ltradicional) {
                mysqli_query($this->db, "UNLOCK TABLES ");
                $omed = new MedCommit($this->arquivo, true);
            } else {
                mysqli_query($this->db, "UNLOCK TABLES ");
                if (mysqli_errno($this->db)) {
                    $this->cerro = mysqli_error($this->db);
                    return false;
                }
            }

            mysqli_query($this->db, "UNLOCK TABLES ");
            if (mysqli_errno($this->db)) {
                $this->cerro = mysqli_error($this->db);
                return false;
            }
        } else {
            $cstr = "update ";
            $cstr .= $this->tabela . " set RECNO=RECNO";

            foreach ($this->agrava as $key => $value) {
                $cstr .= ",$key=";

                /*
                  if ($this->campos[$key]["TIPO"] == "N") {
                  if (substr($value, -1, 1) == "'") {
                  $value = substr($value, 1);
                  $value = substr($value, 0, -1);
                  } else {
                  $value = "'" . addslashes($value) . "'";
                  }
                  $cstr .= $value;
                  } elseif ($this->campos[$key]["TIPO"] == "L") {
                  $cstr .= strtoupper($value) == "N" || strtoupper($value) == "F" || !strtoupper($value) ? "'N'" : "'Y'";
                  } elseif ($this->campos[$key]["TIPO"] == "M") {
                  $cstr .= "0";
                  } else {
                  if (substr($value, -1, 1) == "'") {
                  $value = substr($value, 1);
                  $value = substr($value, 0, -1);
                  } else {
                  $value = "'" . addslashes($value) . "'";
                  }
                  $cstr .= $value;
                  }

                 */





                if ($this->campos[$key]["TIPO"] == "N") {
//                    $cstr .= $value;
                    if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                    } else {
                        $value = "'" . addslashes($value) . "'";
                    }
                    $cstr .= $value;
                } elseif ($this->campos[$key]["TIPO"] == "L") {
                    $cstr .= strtoupper($value) == "N" || strtoupper($value) == "F" || !strtoupper($value) ? "'N'" : "'Y'";
                } elseif ($this->campos[$key]["TIPO"] == "M") {
                    $cstr .= "0";
                } else {

                    if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                    } else {
                        $value = "'" . addslashes($value) . "'";
                    }
                    $cstr .= $value;
                }
            }
            $cstr .= " where $this->where";
            $otab = mysqli_query($this->db, "select recno from $this->tabela where $this->where");
            if (mysqli_errno($this->db)) {
                $this->cerro = mysqli_error($this->db);
                return false;
            }
            while ($olin = mysqli_fetch_row($otab)) {
                $this->arecno[] = $olin[0];
            }
            /*
              mysqli_query($this->db, "UNLOCK TABLES ");
              $this->cerro = $cstr;
              return false;
             */

            mysqli_query($this->db, $cstr);
            if (mysqli_errno($this->db)) {
                $this->cerro = mysqli_error($this->db);
                return false;
            }
        }

        foreach ($this->arecno as $recno) {

            foreach ($this->agrava as $key => $value) {
                if ($this->campos[$key]["TIPO"] == "M") {
                    $cstr = "REPLACE " . $this->tabela . "_MEMO (recno,col_name,memo) values ($recno,'$key','" . addslashes($value) . "')";
                    mysqli_query($this->db, $cstr);
                    if (mysqli_errno($this->db)) {
                        $this->cerro = mysqli_error($this->db);
                        return false;
                    }

                    $cstr = "update $this->tabela set $key=" . strlen($value) . " where recno=$recno";
                    mysqli_query($this->db, $cstr);
                    if (mysqli_errno($this->db)) {
                        $this->cerro = mysqli_error($this->db);
                        return false;
                    }
                }
            }
        }

        foreach ($this->campos as $key => $value) {
            if (substr($key, 0, 3) == "IE\$") {
                $otable = mysqli_query($this->db, "select col_name as nome,ind_clp_exp as indice from CLP_TAB_COLS where ind_clp_exp!='' and col_name like '$key' and  tab_name='$this->tabela'");
                while ($olinha = mysqli_fetch_array($otable)) {
                    $caux = str_replace('+', ',', $olinha["indice"]);
                    $caux = str_replace('"', "'", $caux);
                    $caux = str_replace('==', "=", $caux);
                    $cstr = "update $this->tabela set " . $olinha["nome"] . "=concat(" . $caux . ") where (0 ";
                    foreach ($this->arecno as $recno) {
                        $cstr .= " or recno=$recno";
                    }
                    $cstr .= ")";
                    mysqli_query($this->db, $cstr);
                    if (mysqli_errno($this->db)) {
                        $this->cerro = mysqli_error($this->db);
                        return false;
                    }
                }
            }
        }
        if ($ccommit_new) {
            $omed = new MedCommit($this->arquivo, true);
        }
        return true;
    }

    public function __get($nome) {
        $nome = strtoupper($nome);
        return $this->agrava[$nome];
    }

    public function __set($nome, $uvalue) {
        $nome = strtoupper($nome);
        $this->aadd($nome, $uvalue);
        return $this->agrava[$nome];
    }

}

class MedCommit1 {

    public $nrecno;
    private $ctabela;
    private $acampos = "";
    private $cgrava = "";
    private $commit = 'http://192.168.12.100/MediatorPhp/hscript.php';
    private $aret = array();
    public $erro = 0;
    public $cerro = "";
    public $ntempo;

    public function __construct($cTabela = '', $lRefresh = false, $lAdiciona = false, $lDeleta = false, $nRecno = 0, $aCampos = array(), $lCriaDeletado = false, $nLock = 0, $lfecha = false) {
        global $ccommit_new;
        $aaux = explode(" ", microtime());
        $this->ntempo = $aaux[1] + $aaux[0];
        if ($ccommit_new) {
            $this->commit = $ccommit_new;
        }
        if (!$this->commit) {
            $this->cerro = "Sem COMMIT CONFIGURADO";
            $this->erro = 1;
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return false;
        }
        if (!$cTabela) {
            $this->cerro = "Sem tabela informada";
            $this->erro = 1;
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return false;
        }
        $this->ctabela = $cTabela;
        //fechar tabela
        if ($lfecha) {
            $this->cgrava = "fecha=" . $this->ctabela;
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (substr($this->aret[0], 0, 4) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            if (substr($this->aret[0], 0, 3) == "OK:") {
                $this->erro = 0;
                for ($i = 1; $i < count($this->aret); $i++) {
                    if (trim($this->aret[$i])) {
                        $this->cerro .= "," . $this->aret[1];
                        $this->nrecno .= "," . explode("-", $this->aret[$i])[0];
                    }
                }
                $this->nrecno = substr($this->nrecno, 1);
                $this->cerro = substr($this->cerro, 1);
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            $this->cerro = $this->aret[0];
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return;
        }
        //refresh na tabela
        if ($lRefresh) {
            $this->cgrava = "refresh=" . $this->ctabela;
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (substr($this->aret[0], 0, 4) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            if (substr($this->aret[0], 0, 3) == "OK:") {
                $this->erro = 0;
                for ($i = 1; $i < count($this->aret); $i++) {
                    if (trim($this->aret[$i])) {
                        $this->cerro .= "," . $this->aret[1];
                        $this->nrecno .= "," . explode("-", $this->aret[$i])[0];
                    }
                }
                $this->nrecno = substr($this->nrecno, 1);
                $this->cerro = substr($this->cerro, 1);
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            $this->cerro = $this->aret[0];
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return;
        }
        //fim refresh tabela
        //deletar registro
        if ($lDeleta) {
            if (!$nRecno) {
                $this->erro = 99;
                $this->cerro .= "Registro não passao";
            }
            $this->cgrava = "tabela=" . $this->ctabela . "&recno=" . ($nRecno * -1);
            //var_dump($this->cgrava);
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (substr($this->aret[0], 0, 4) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            if (substr($this->aret[0], 0, 3) == "OK:") {
                $this->erro = 0;
                $this->cerro .= $this->aret[1];
                $this->nrecno .= $nRecno;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            $this->cerro = $this->aret[0];
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return;
        }
        //fim deletar registro
        //adiciona sem replace
        if ($lAdiciona && !$aCampos) {
            $this->cgrava = "tabela=" . $this->ctabela . "&recno=0";
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (substr($this->aret[0], 0, 4) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            if (substr($this->aret[0], 0, 3) == "OK:") {
                $this->erro = 0;
                $this->cerro .= $this->aret[1];
                $this->nrecno .= explode("-", $this->aret[1])[0];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            $this->cerro = $this->aret[0];
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return;
        }
        //fim adiciona sem replace
        //reposicao de campos
        if ($aCampos) {
            $this->cgrava = "tabela=" . $this->ctabela . "&recno=" . ($lAdiciona ? "0" : $nRecno);
            foreach ($aCampos as $key => $value) {
//                $this->cgrava .= "&CMP$key=" . str_replace("+", "%20", urlencode(iconv("utf8", "cp850", $value)));
                $this->cgrava .= "&CMP$key=" . str_replace("+", "%20", urlencode($value));
            }
            if ($lCriaDeletado) {
                $this->cgrava .= "&criadel=true";
            }
            //var_dump($aCampos);
            //echo $this->cgrava . "<br>";
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (substr($this->aret[0], 0, 4) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            if (substr($this->aret[0], 0, 3) == "OK:") {
                $this->erro = 0;
                $this->cerro .= $this->aret[1];
                $this->nrecno .= explode("-", $this->aret[1])[0];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            $this->cerro = $this->aret[0];
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return;
        }
        //fim reposicao de campos
        //bloquear
        if ($nLock) {
            $this->cgrava = "tabela=" . $this->ctabela . "&recno=" . $nRecno . "&bloq=" . $nLock;
            $cstr = $this->commit . "?" . $this->cgrava;
            $this->aret = file($cstr);
            if (substr($this->aret[0], 0, 4) == "ERR:") {
                $this->erro = $this->aret[1];
                $this->cerro = $this->aret[2];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            if (substr($this->aret[0], 0, 3) == "OK:") {
                $this->erro = 0;
                $this->cerro .= $this->aret[1];
                $this->nrecno .= explode("-", $this->aret[1])[0];
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return;
            }
            $this->cerro = $this->aret[0];
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return;
        }
        $aaux = explode(" ", microtime());
        $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
    }

}

class Mediator1 {

    public $db;
    public $arquivo;
    public $tabela;
    public $where;
    public $cerro = "";
    public $lok = false;
    private $campos = array();
    private $codigo = "";
    public $ncodigo = 0;
    private $agrava = array();
    public $nrecno = 0;
    public $arecno = array();
    public $nrecnog = 0;
    public $cenvia = '';
    public $ntempo;
    public $lCriaDeletado = false;

    public function __construct($db = '', $cArquivo = '', $nrecnograva = 0, $cCampoCodigo = '', $lCriaFuncao = false) {
        if ($db) {
            $this->init($db, $cArquivo, $nrecnograva, $cCampoCodigo, $lCriaFuncao);
        }
    }

    public function limpa() {
        $this->agrava = array();
        $this->nrecno = 0;
        $this->arecno = array();
        $this->lok = false;
        $this->ncodigo = 0;
        $this->cerro = "";
    }

    public function CriaFunction() {

        $afuncoes = array();
        $afuncoes["ctod"] = "create function ctod(cstr varchar(256))
returns varchar(100)
begin
	declare dia char(2);
	declare mes char(2);
	declare ano varchar(4);

	set dia=substring_index(cstr,'/',1);
	set mes=substring_index(cstr,'/',-2);
	set mes=substring_index(mes,'/',1);
	set ano=substring_index(cstr,'/',-1);

	set dia=lpad(dia,2,'0');
	set mes=lpad(mes,2,'0');
	if length(ano) = 2 then
    	    set ano=concat('20',ano);
	end if;
	set ano=lpad(ano,4,'0');

 	return concat(ano,'-',mes,'-',dia);
end
";
        $afuncoes["dtoc"] = "create function dtoc(cstr varchar(256))
returns varchar(100)

begin
 	return concat(substr(cstr,9,2),'/',substr(cstr,6,2),'/',substr(cstr,3,2));
end
";
        $afuncoes["alltrim"] = "create function alltrim(cstr varchar(256))
returns varchar(100)

begin
 	return trim(cstr);
end
";
        $afuncoes["len"] = "create function len(cstr varchar(256))
returns varchar(100)

begin
 	return length(cstr);
end
";
        $afuncoes["str"] = "create function str(numero DECIMAL(25,10),tam INT)
returns varchar(100)
begin
        declare deci int(1) default 0;
	declare cret varchar(100) default '';
	declare cdec varchar(20) default '';
	if (deci>0) THEN
		set cret=lpad(floor(numero),tam-1-deci,' ');
		set cdec=concat((numero%1),'0000000000');
		set cdec=substr(cdec,3,deci);
		return concat(cret,'.',cdec);	
	end if;
 	return lpad(round(numero,0),tam,' ');
end

";
        $afuncoes["strzero"] = "create function strzero(numero DECIMAL(25,10),tam INT,deci INT)
returns varchar(100)
begin
	declare cret varchar(100) default '';
	declare cdec varchar(20) default '';
	if (deci>0) THEN
		set cret=lpad(floor(numero),tam-1-deci,'0');
		set cdec=concat((numero%1),'0000000000');
		set cdec=substr(cdec,3,deci);
		return concat(cret,'.',cdec);	
	end if;
 	return lpad(round(numero,0),tam,'0');
end
";
        $afuncoes["dtos"] = "create function dtos(ddata CHAR(10))
returns varchar(30)

begin
return if(ddata='1000-01-01','        ',replace(ddata,'-',''));
return 'lpad(\''+if(ddata='1000-01-01','        ',replace(ddata,'-',''))+'\',8,\'\')';
end
";
        $afuncoes["val"] = "create function val(cstr VARCHAR(20))
returns DECIMAL(12,2)

begin
    return cstr+0;
end
";
        $afuncoes["descend"] = "create function descend(cstr VARCHAR(20))
returns varchar(20)

begin
declare i int default 0;
declare cret varchar(20) default '';

while (i<length(cstr)) DO
    set cret = concat(cret,char(256-ascii(substr(cstr,i+1,1))));
    set i = i+1;
end while;
return cret;
end
";

        $otab = mysqli_query($this->db, "show function status where db=database()");
        $afuncoes = array();
        while ($olin = mysqli_fetch_row($otab)) {
            $afuncoes[] = $olin[1];
        }

        foreach ($afuncoes as $key => $value) {
            //if (mysqli_num_rows(mysqli_query($this->db, "show function status where db=database() and name='$key'")) == 0) {
            if (array_search($key, $afuncoes) === false) {
                mysqli_query($this->db, $value);
            }
        }
    }

    public function init($db, $cArquivo, $nrecnograva = 0, $cCampoCodigo = '', $lCriaFuncao = false, $lCriaDeletado = false) {
        if (!$db) {
            $this->cerro = "Erro conectando à database";
            return false;
        }
        $this->db = $db;
        if (!$cArquivo) {
            $this->cerro = "Falta parâmetros";
            return false;
        }
        if ($lCriaFuncao) {
            $this->CriaFunction();
        }
        $this->lCriaDeletado = $lCriaDeletado;
        $this->nrecnog = $nrecnograva ? $nrecnograva : 0;
        $this->codigo = strtoupper($cCampoCodigo);
        $this->arquivo = $cArquivo;
        $this->tabela = strtoupper($cArquivo);
        $this->tabela = str_replace(".", "_", $this->tabela);
        if (substr($this->tabela, -4) == "_DBF") {
            $this->tabela = substr($this->tabela, 0, -4);
        }
        $otable = mysqli_query($this->db, "SELECT COL_NAME NAME
,IF(COL_CLP_TYPE=1,'C',
IF(COL_CLP_TYPE=2048,'N',
IF(COL_CLP_TYPE=65,'M',
IF(COL_CLP_TYPE=8,'D',
IF(COL_CLP_TYPE=4,'L',
'' ))))) TIPO
,IF(COL_CLP_TYPE=1,COL_CLP_LEN,
IF(COL_CLP_TYPE=2048,COL_CLP_LEN,
IF(COL_CLP_TYPE=65,10,
IF(COL_CLP_TYPE=8,8,
IF(COL_CLP_TYPE=4,1,
'0' ))))) TAMANHO
,IF(COL_CLP_TYPE=2048,COL_CLP_DEC,'0') DECIMAIS
FROM CLP_TAB_COLS
WHERE TAB_NAME='" . $this->tabela . "'
");

        if (mysqli_num_rows($otable) == 0) {
            $this->cerro = "Tabela " . $this->tabela . " não encontrada";
            return false;
        }
        while ($olinha = mysqli_fetch_array($otable)) {
            $this->campos[$olinha["NAME"]] = array("NAME" => $olinha["NAME"], "TIPO" => $olinha["TIPO"], "TAMANHO" => $olinha["TAMANHO"], "DECIMAIS" => $olinha["DECIMAIS"]);
        }
        return true;
    }

    public function aadd($cCampo, $uValor, $lDireto = false) {
        if (!$lDireto) {
            $this->agrava[strtoupper($cCampo)] = $uValor;
        } else {
            $this->agrava[strtoupper($cCampo)] = "'" . $uValor . "'";
        }
    }

    public function fecha() {
        global $ccommit;
        global $ccommit_new;
        $aaux = explode(" ", microtime());
        $this->ntempo = $aaux[1] + $aaux[0];

        $omed = new MedCommit1($this->arquivo, false, false, false, 0, array(), false, 0, true);
        if ($omed->nrecno) {
            $this->arecno[] = $omed->nrecno;
            $this->nrecno = $omed->nrecno;
        } else {
            $this->cerro = $omed->cerro;
            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return false;
        }

        if ($this->codigo) {
            $this->ncodigo = mysqli_fetch_array(mysqli_query($this->db, "select $this->codigo as codigo from " . $this->tabela . " where recno=$this->nrecno"))[0];
        }

        $aaux = explode(" ", microtime());
        $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
        return true;
    }

    public function grava() {
        global $ccommit;
        global $ccommit_new;
        global $ccommit_web;
        $aaux = explode(" ", microtime());
        $this->ntempo = $aaux[1] + $aaux[0];

        if (!$ccommit_web) {
            if ($this->codigo) {
                $this->agrava[$this->codigo] = "AUTO_INCREMENT";
            }


            $acampos = array();

            foreach ($this->agrava as $key => $value) {

                if ($this->campos[$key]["TIPO"] == "N") {
                    if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                    }
                } elseif ($this->campos[$key]["TIPO"] == "D") {
                    if (substr($value, 4, 1) == "-" && substr($value, 7, 1) == "-") {
                        $value = substr($value, 8, 2) . '/' . substr($value, 5, 2) . '/' . substr($value, 0, 4);
                    } else if ("CURRENT_DATE" == substr(strtoupper($value), 0, 12) || "CURRENT_DATE" == substr(strtoupper($value), 1, 12)) {
                        $value = "00/00/00";
                    }
                } elseif ($this->campos[$key]["TIPO"] == "L") {
                    $acampos[$key] = strtoupper($value) == "N" || strtoupper($value) == "F" || !strtoupper($value) ? "'N'" : "'Y'";
                } else {
                    if ("CURRENT_TIME" == substr(strtoupper($value), 0, 12) || "CURRENT_TIME" == substr(strtoupper($value), 1, 12)) {
                        $value = "00:00:00";
                    } else if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                    } else if ("CURRENT_TIME" == substr(strtoupper($value), 0, 12)) {
                        $value = "00:00:00";
                    }
                }
                $acampos[$key] = $value;
            }

            $omed = new MedCommit1($this->arquivo, false, $this->nrecnog == 0, false, $this->nrecnog, $acampos, $this->lCriaDeletado);
            if ($omed->nrecno) {
                $this->arecno[] = $omed->nrecno;
                $this->nrecno = $omed->nrecno;
            } else {
                $this->cerro = $omed->cerro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }

            if ($this->codigo) {
                $this->ncodigo = mysqli_fetch_array(mysqli_query($this->db, "select $this->codigo as codigo from " . $this->tabela . " where recno=$this->nrecno"))[0];
            }

            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return true;
        } else {
            $omed3=new Mediator3($this->arquivo, $this->lCriaDeletado?W_CRIAR_DEL:W_CRIAR , '' , $this->recnog, $this-db, $this->codigo);


            $acampos = array();

            foreach ($this->agrava as $key => $value) {

                if ($this->campos[$key]["TIPO"] == "N") {
                    if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                    }
                    $omed3->add($key,"N",$value);
                } elseif ($this->campos[$key]["TIPO"] == "D") {
                    if (substr($value, 4, 1) == "-" && substr($value, 7, 1) == "-") {
                        $omed3->add($key,"D",$value);
                    } else if ("CURRENT_DATE" == substr(strtoupper($value), 0, 12) || "CURRENT_DATE" == substr(strtoupper($value), 1, 12)) {
                        $omed3->add($key,"Q","CURRENT_DATE");
                    }
                } elseif ($this->campos[$key]["TIPO"] == "L") {
                    $omed3->add($key,"L",strtoupper($value) == "N" || strtoupper($value) == "F" || !strtoupper($value) ? "'N'" : "'Y'");
                } else {
                    if ("CURRENT_TIME" == substr(strtoupper($value), 0, 12) || "CURRENT_TIME" == substr(strtoupper($value), 1, 12)) {
                        $omed3->add($key,"Q","CURRENT_TIME");
                    } else if (substr($value, -1, 1) == "'") {
                        $value = substr($value, 1);
                        $value = substr($value, 0, -1);
                        $omed3->add($key,$this->campos[$key]["TIPO"],$value);
                    }else{
                        $omed3->add($key,$this->campos[$key]["TIPO"],$value);
                        
                    }
                }
            }

//    public function __construct($cTabela = '', $lRefresh = false, $lAdiciona = false, $lDeleta = false, $nRecno = 0, $aCampos = array()) {
            $omed = new MedCommit1($this->arquivo, false, $this->nrecnog == 0, false, $this->nrecnog, $acampos, $this->lCriaDeletado);
            if ($omed->nrecno) {
                $this->arecno[] = $omed->nrecno;
                $this->nrecno = $omed->nrecno;
            } else {
                $this->cerro = $omed->cerro;
                $aaux = explode(" ", microtime());
                $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
                return false;
            }

            if ($this->codigo) {
                $this->ncodigo = mysqli_fetch_array(mysqli_query($this->db, "select $this->codigo as codigo from " . $this->tabela . " where recno=$this->nrecno"))[0];
            }

            $aaux = explode(" ", microtime());
            $this->ntempo = $aaux[1] + $aaux[0] - $this->ntempo;
            return true;
            
        }
    }

    public function __get($nome) {
        $nome = strtoupper($nome);
        return $this->agrava[$nome];
    }

    public function __set($nome, $uvalue) {
        $nome = strtoupper($nome);
        $this->aadd($nome, $uvalue);
        return $this->agrava[$nome];
    }

}
