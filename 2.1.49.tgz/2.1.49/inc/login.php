<?php


error_reporting(1);
ini_set('display_errors', 1);
ini_set('display_startup_erros', 1);

require_once 'config.php';

/*

  //commit
  $omed = new MedCommit("transfe.tra,protra.tra", true);
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //ADICIONAR REGISTRO
  $omed = new MedCommit("transfe.tra", false, true);
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //DELETAR
  $omed = new MedCommit("transfe.tra", false, false,true,336985);
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //ATUALIZAR REGISTRO
  $omed = new MedCommit("transfe.tra", false, true,false,336985,array("obstra" => "okokokokokok"));
  //var_dump($omed->erro);
  //var_dump($omed->cerro);
  //INCLUIR REGISTRO
  $omed = new MedCommit("transfe.tra", false, true,false,0,array("obstra" => "&Teste de ação à data 01/01/2018"));
  //var_dump($omed->erro);
  //var_dump($omed->cerro);

  return;
 */


function VeOperadorSenha($operador, $csenha = '', $nnum = 0, &$cnome = '', &$nnumsen = 0,&$ncodigo) {
    if (!$operador) {
        return false;
    }
    global $db;
    if (!$db) {
        $db = conecta();
        if (!$db) {
            return false;
        }
    }
    $operador= addslashes(strtoupper(trim($operador)));
    $otab= mysqli_query($db,"select * from OPERADOR_OPE WHERE IS_DELETED='N' AND (CODIGO='$operador' OR NOME='$operador' OR MAIL='$operador') ");
//    $otab= mysqli_query($db,"select * from OPERADOR_OPE WHERE bloq_vdas!='S' and IS_DELETED='N' AND (CODIGO='$operador' OR NOME='$operador' OR MAIL='$operador') ");
    if (mysqli_num_rows($otab)==0){
        return false;
    }
    $olin= mysqli_fetch_array($otab);
    $cnome=LIMPACHAR($olin["NOME"]);
    $nnumsen=$olin["NUM_SEM"];
    $ncodigo=$olin["CODIGO"];

    if ($olin["CODIGO"]==1 && $nnumsen==0){
        $nnumsen=10;
    }
    if (!$csenha){
        return FALSE;
    }
    $ndigitado=0;
    if ($nnumsen){
        $ndigitado= substr($csenha, -2)+0;
        $csenha= substr($csenha, 0, -2);
    }
    $csenha= cifra(str_pad($csenha,10, " " ,STR_PAD_RIGHT ));
    if ($csenha!==$olin["SENHA"]){
        return false;
    }
    if ($nnumsen && $nnumsen!= $nnum+$ndigitado ){
        return false;
    }
    return true;
}

class Operador {

    public $cip;
    public $csid;
    public $nini;
    public $nfim;
    public $natu;
    public $dini;
    public $hini;
    public $dfim;
    public $hfim;
    public $noperador;
    public $coperador;
    public $ctermnal;
    public $cmodulo;
    public $ntimeout;
    public $natual;
    public $cerro = "";
    public $nerro = 0;
    private $db;
    public $lok=false;

    public function __construct($csid, $noperador, $cmodulo = '', $ntimeout = 10 * 60, $cterminal) {
        global $db;
        if (!$noperador && !$csid) {
            $this->nerro = 1;
            $this->cerro = "Operador não informado";
            return false;
        }
        if (!$db) {
            $db = conecta();
            if (!$db) {
                $this->nerro = 99;
                $this->cerro = mysqli_connect_error();
                return false;
            }
        }
        $this->db = $db;
        mysqli_query($db, "create table if not exists entrega_access (
            sid varchar(100) not null default '',
            data_in decimal(10,0) not null default 0,
            data_out decimal(10,0) not null default 0,
            data_atu decimal(10,0) not null default 0,
            timeout  decimal(10,0) not null default 0,
            operador decimal(10,0) not null default 0,
            coperador varchar(100) not null default '',
            terminal varchar(3) not null default 0,
            modulo varchar(30) not null default '',
            ip varchar(15) not null default '',
            primary key (sid),
            key operador_out (operador,modulo,data_out)
            )
            ENGINE=innodb DEFAULT CHARSET=latin1 
        ");
        if (!$csid) {
            $otope = mysqli_query($this->db, "select * from OPERADOR_OPE where codigo=$noperador and is_deleted='N' ");
//            $otope = mysqli_query($this->db, "select * from OPERADOR_OPE where bloq_vdas!='S' and  codigo=$noperador and is_deleted='N' ");
            if (mysqli_num_rows($otope) == 0) {
                $this->nerro = 98;
                $this->cerro = "Operador não localizado".".";
                return false;
            }
            $olope = mysqli_fetch_array($otope);
            $coperador = LimpaChar($olope["NOME"]);

            mysqli_query($this->db, "update entrega_access  set data_out=date2unix(now()) where data_out=0 and operador='$noperador' and modulo='$cmodulo' ");
            $ipaddress = '';
            if (getenv('HTTP_CLIENT_IP'))
                $ipaddress = getenv('HTTP_CLIENT_IP');
            else if (getenv('HTTP_X_FORWARDED_FOR'))
                $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
            else if (getenv('HTTP_X_FORWARDED'))
                $ipaddress = getenv('HTTP_X_FORWARDED');
            else if (getenv('HTTP_FORWARDED_FOR'))
                $ipaddress = getenv('HTTP_FORWARDED_FOR');
            else if (getenv('HTTP_FORWARDED'))
                $ipaddress = getenv('HTTP_FORWARDED');
            else if (getenv('REMOTE_ADDR'))
                $ipaddress = getenv('REMOTE_ADDR');
            else
                $ipaddress = 'UNKNOWN';

            while (true) {
                $csid = GeraSenha(95);
                $otab = mysqli_query($this->db, "select operador from entrega_access  where sid='$csid' ");
                if (mysqli_num_rows($otab) == 0) {
                    mysqli_query($this->db, "insert entrega_access set sid='$csid',data_in=date2unix(now()),data_atu=date2unix(now()),timeout=$ntimeout
                        ,operador=$noperador,coperador='$coperador',terminal='$cterminal',modulo='$cmodulo',ip='$ipaddress' ");
                    break;
                }
            }
        }
        if ($csid) {
            $this->csid = $csid;
            $otab = mysqli_query($db, "select * from entrega_access where sid='$csid'");
            if (mysqli_num_rows($otab) == 0) {
                $this->nerro = 2;
                $this->cerro = "SID não localizado";
                return false;
            }
            $olin = mysqli_fetch_array($otab);
            $this->cip = $olin["ip"];
            $this->nini = $olin["data_in"];
            $this->nfim = $olin["data_out"];
            $this->natu = $olin["data_atu"];
            $this->dini = Unix2Date($olin["data_in"])[0];
            $this->hini = Unix2Date($olin["data_in"])[1];
            $this->dfim = Unix2Date($olin["data_out"])[0];
            $this->hfim = Unix2Date($olin["data_out"])[1];
            $this->noperador = $olin["operador"];
            $this->coperador = $olin["coperador"];
            $this->cterminal = $olin["terminal"];
            $this->cmodulo = $olin["modulo"];
            $this->ntimeout = $olin["timeout"];
            if ($this->nfim) {
                $this->nerro = 3;
                $this->cerro = "SID já encerrado";
                return false;
            }
            mysqli_query($db, "update entrega_access  set data_atu=date2unix(now()) where sid='$csid'");
            $natual=mysqli_fetch_row(mysqli_query($db, "select data_atu from  entrega_access where sid='$csid'"))[0];
            
            if ($this->ntimeout + $this->natu < $natual) {
                $this->fechasid();
                $this->nerro = 4;
                $this->cerro = "Tempo Expirado";
                return false;
            }
            $this->lok=true;
            return true;
        }
    }

    public function fechasid() {
        mysqli_query($this->db, "update entrega_access  set data_out=date2unix(now()) where data_out=0 and sid='" . $this->csid . "'");
        $this->lok=false;
        
        return true;
    }

    public function tempo() {
        mysqli_query($this->db, "update entrega_access  set data_atu=date2unix(now()) where sid='" . $this->csid . "'");
        $natual=mysqli_fetch_row(mysqli_query($this->db, "select data_atu from  entrega_access where sid='" . $this->csid . "'"))[0];
        if ($this->ntimeout + $this->natu < $natual) {
            $this->fechasid();
            $this->nerro = 4;
            $this->cerro = "Tempo Expirado";
            return false;
        }
        $this->natu = natual;
        return true;
    }

}

