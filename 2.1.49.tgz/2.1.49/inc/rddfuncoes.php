<?php

/**
 * Conversão de teste.prg para PHP 5.6.
 * Objetivo: preservar a lógica e as requisições SQL do código xHarbour.
 * Banco: MySQL/MariaDB através de mysqli procedural.
 */
define('SUCCESS', 1);
define('SYSTEM_CEC', 1);
define('SYSTEM_CECWIN', 2);
define('SYSTEM_IMG', 3);
define('SYSTEM_APK', 4);
define('SYSTEM_ECOMAPI', 5);
define('SYSTEM_CEC_PSERVER', 6);
define('SYSTEM_OTHER', 99);
define('CF_RDD_VERSION', '0.1.4');
define('CF_LOCK_FILE', 1);
define('CF_LOCK_TABLE', 1);
define('CF_LOCK_RECNO', 2);
define('CF_LOCK_TERMINAL', 3);
define('CF_LOCK_F_DATA', 1);
define('CF_LOCK_F_TABLE', 2);
define('CF_LOCK_F_MODE', 3);
define('CF_LOCK_F_AREA', 4);
define('CF_LOCK_F_ID', 5);
define('CF_LOCK_R_DATA', 1);
define('CF_LOCK_R_TABLE', 2);
define('CF_LOCK_R_RECNO', 3);
define('CF_LOCK_R_AREA', 4);
define('CF_LOCK_R_ID', 5);
define('CF_LOCK_T_DATA', 1);
define('CF_LOCK_T_TERMINAL', 2);
define('CF_LOCK_T_ID', 3);
define('MYSQL_PING_TIME', 30);
define('MYSQL_PING_TAM', 100000);

$GLOBALS['s_aConn'] = array();
$GLOBALS['cf_error_handler'] = null;
$GLOBALS['cf_area_resolver'] = null;
$GLOBALS['cf_alias_resolver'] = null;

function cf_start() {
    return null;
}

function cf_erro($cErro) {
    return $cErro;
}

function cfEmpty($v) {
    return $v === null || $v === false || $v === 0 || $v === 0.0 || $v === '' || (is_array($v) && count($v) === 0);
}

function cfRaise($message, $context = '') {
    if (is_callable($GLOBALS['cf_error_handler'])) {
        return call_user_func($GLOBALS['cf_error_handler'], $message, $context);
    }
    throw new RuntimeException($message . ($context !== '' ? ' [' . $context . ']' : ''));
}

function cfAreaToTable($area) {
    if (is_callable($GLOBALS['cf_area_resolver']))
        return call_user_func($GLOBALS['cf_area_resolver'], $area);
    if (is_string($area))
        return $area;
    cfRaise('Não foi definido um resolvedor para área RDD', (string) $area);
    return '';
}

function cfAreaAlias($area, $fallback = '') {
    if (is_callable($GLOBALS['cf_alias_resolver']))
        return call_user_func($GLOBALS['cf_alias_resolver'], $area);
    return $fallback;
}

function cf_start_connection_index() {
    $i = 1;
    while (array_key_exists($i, $GLOBALS['s_aConn']) && $GLOBALS['s_aConn'][$i] !== null)
        $i++;
    return $i;
}

function cfConnection($nConn) {

    veConn($nConn, true);
    //return $GLOBALS['s_aConn'][$nConn]['link'];
    return $GLOBALS['s_aConn'][$nConn];
}

function cfDbName($nConn) {
    veConn($nConn, true);
    return mysqli_fetch_row(mysqli_query($GLOBALS['s_aConn'][$nConn], "select database()"))[0];
}

function cfMysqlId($nConn = 1) {
    $link = cfConnection($nConn);
    return mysqli_thread_id($link);
}

function cf_mysqlid($nConn = 1) {
    return cfMysqlId($nConn);
}

function cfFetchAllRows($result) {
    $rows = array();
    if ($result instanceof mysqli_result) {
        while (($row = mysqli_fetch_row($result)) !== null)
            $rows[] = $row;
        mysqli_free_result($result);
    }
    return $rows;
}

function cfSqlColumnDefinition($type, $len, $dec, $charLimit) {
    $type = strtoupper(trim($type));
    $len = (int) $len;
    $dec = (int) $dec;
    if ($type === 'C')
        return $len <= $charLimit ? "varchar(" . $len . ") DEFAULT ' '" : 'mediumtext DEFAULT NULL';
    if ($type === 'N')
        return 'decimal(' . $len . ',' . $dec . ') DEFAULT 0' . ($dec > 0 ? '.' . str_repeat('0', $dec) : '');
    if ($type === 'L')
        return "char(1) DEFAULT 'N'";
    if ($type === 'D')
        return "date DEFAULT '1000-01-01'";
    if ($type === 'M')
        return 'decimal(10,0) DEFAULT 0';
    return '';
}

function cfClpType($type, $len) {
    $type = strtoupper(trim($type));
    if ($type === 'C')
        return 1;
    if ($type === 'N')
        return ((int) $len > 9) ? 2048 : 2;
    if ($type === 'L')
        return 4;
    if ($type === 'D')
        return 8;
    if ($type === 'M')
        return 65;
    return 0;
}

function cfFindRowByFirstColumn($rows, $value) {
    foreach ($rows as $i => $row)
        if (trim((string) $row[0]) === trim((string) $value))
            return $i;
    return -1;
}

function asNumber($uVar) {
    if (cfEmpty($uVar))
        return 0;
    if (is_string($uVar))
        return (float) $uVar;
    if (is_bool($uVar))
        return $uVar ? 1 : 0;
    if ($uVar instanceof DateTimeInterface)
        return (float) $uVar->format('Ymd');
    return $uVar;
}

function asString($uVar) {
    if (is_string($uVar))
        return $uVar;
    if ($uVar instanceof DateTimeInterface)
        return $uVar->format('d/m/Y');
    if (is_bool($uVar))
        return $uVar ? 'V' : 'F';
    if (is_numeric($uVar)) {
        $n = (float) $uVar;
        return (($n - floor($n)) * 100 > 0) ? trim(number_format($n, 2, '.', '')) : trim(sprintf('%.0f', $n));
    }
    return '';
}

function cf_assql($uCampo, $lSemApostrofe = false, $lData2Med = false, $lTrimm = false) {
    if ($uCampo instanceof DateTimeInterface) {
        $cStr = $uCampo->format('Y-m-d');
        if ($lData2Med && $cStr <= '1000-01-01')
            $cStr = '1000-01-01';
        return $lSemApostrofe ? $cStr : "'" . $cStr . "'";
    }
    if (is_bool($uCampo))
        return $lData2Med ? ($uCampo ? "'Y'" : "'N'") : ($uCampo ? '1' : '0');
    if (is_string($uCampo)) {
        $cStr = strtr($uCampo, array('\\' => '\\\\', "\0" => '\\0', "\r" => '\\r', "\n" => '\\n', '"' => '\\"', "'" => "\\'", '`' => '\\`'));
        if ($lTrimm)
            $cStr = trim($cStr);
        return $lSemApostrofe ? $cStr : "'" . $cStr . "'";
    }
    if (is_numeric($uCampo))
        return trim((string) $uCampo);
    return $lSemApostrofe ? ' ' : "' '";
}

function file2Sql($cArq, $lMemo = false) {
    $cArq = strtoupper(trim($cArq));
    if (substr($cArq, -4) === '.DBF')
        $cArq = substr($cArq, 0, -4);
    $cArq = str_replace('.', '_', $cArq);
    if (strlen($cArq) > 12)
        $cArq = substr($cArq, 0, 12);
    return $cArq . (cfEmpty($lMemo) ? '' : '_MEMO');
}

function cf_limpaRg($cRg, $lSemLetra = false, $cCharEsp = '') {
    $cAux = '';
    $cRg = strtoupper((string) $cRg);
    for ($i = 0; $i < strlen($cRg); $i++) {
        $ch = $cRg[$i];
        if (strpos('0123456789', $ch) !== false || strpos($cCharEsp, $ch) !== false || (!$lSemLetra && strpos('ABCDEFGHIJKLMNOPQRSTUVWXYZ', $ch) !== false))
            $cAux .= $ch;
    }
    return $cAux;
}

function nTrim($x, $y = null) {
    $cStr = is_numeric($x) ? (((float) $x == floor((float) $x)) ? sprintf('%.0f', $x) : number_format($x, 2, '.', '')) : (string) $x;
    $cStr = trim($cStr);
    if (!cfEmpty($y))
        $cStr = str_pad($cStr, (int) $y, ' ', STR_PAD_RIGHT);
    return $cStr;
}

function myTrim($x, $y = null) {
    return nTrim($x, $y);
}

function cf_sec2time($nSegundos) {
    $nSegundos = (int) $nSegundos;
    $neg = '';
    if ($nSegundos < 0) {
        $nSegundos *= -1;
        $neg = '-';
    }
    $s = str_pad((string) ($nSegundos % 60), 2, '0', STR_PAD_LEFT);
    $nSegundos = (int) ($nSegundos / 60);
    $s = str_pad((string) ($nSegundos % 60), 2, '0', STR_PAD_LEFT) . ':' . $s;
    $nSegundos = (int) ($nSegundos / 60);
    return $neg . str_pad((string) $nSegundos, 2, '0', STR_PAD_LEFT) . ':' . $s;
}

function cf_sectotime($n) {
    return cf_sec2time($n);
}

function cf_unix2date($nSeconds, &$dRefData = null, &$cRefHora = null, &$cRefHorasTotais = null, $lMostraVazio = false) {
    $nSeconds = (int) $nSeconds;
    $cRefHorasTotais = cf_sectotime($nSeconds);
    if ($nSeconds > 0) {
        $nDias = (int) ($nSeconds / 86400);
        $nSegundos = $nSeconds % 86400;
        $dRefData = DateTime::createFromFormat('!Ymd', '19700101');
        $dRefData->modify('+' . $nDias . ' days');
        $cRefHora = cf_sectotime($nSegundos);
    } elseif ($nSeconds === 0) {
        $dRefData = null;
        $cRefHora = '00:00:00';
    } else {
        $nDias = (int) ($nSeconds / 86400);
        $nSegundos = 86400 + ($nSeconds % 86400);
        $dRefData = DateTime::createFromFormat('!Ymd', '19700101');
        $dRefData->modify('-' . abs($nDias) . ' days');
        $cRefHora = cf_sectotime($nSegundos);
    }
    $display = (!$lMostraVazio && cfEmpty($nSeconds)) ? str_repeat(' ', 19) : (($dRefData ? $dRefData->format('d/m/Y') : '') . ' ' . $cRefHora);
    //return array($dRefData, $cRefHora, $cRefHorasTotais, $display);
    return array($dRefData->format("d/m/y"), $cRefHora, $cRefHorasTotais, $display);
}

function asDate($uDados) {
    if ($uDados instanceof DateTimeInterface)
        return clone $uDados;
    if (is_numeric($uDados)) {
        if ($uDados > 999999999) {
            $r = cf_unix2date($uDados, $d, $h, $t);
            return $r[0];
        }
        return DateTime::createFromFormat('!Ymd', str_pad((string) (int) $uDados, 8, '0', STR_PAD_LEFT)) ?: null;
    }
    if (is_string($uDados)) {
        if (strlen($uDados) > 10)
            $uDados = substr($uDados, 0, 10);
        if (strpos($uDados, '-') !== false)
            $uDados = str_replace('-', '/', $uDados);
        if (strpos($uDados, '/') === false && strlen($uDados) === 8)
            return DateTime::createFromFormat('!Ymd', $uDados) ?: null;
        $p = explode('/', $uDados);
        if (isset($p[0]) && (int) $p[0] > 1900)
            return DateTime::createFromFormat('!Ymd', str_replace('/', '', $uDados)) ?: null;
        return DateTime::createFromFormat('!d/m/Y', $uDados) ?: null;
    }
    return null;
}

function time2Sec($tHora) {
    return (int) myToken($tHora, ':', 1) * 3600 + (int) myToken($tHora, ':', 2) * 60 + (int) myToken($tHora, ':', 3);
}

function myToken($cStr, $cSep, $nPos) {
    $a = explode($cSep, (string) $cStr);
    return ($nPos > count($a) || $nPos < 1) ? '' : $a[$nPos - 1];
}

function myNumToken($cStr, $cSep) {
    return count(explode($cSep, (string) $cStr));
}

function cf_token2array($cStr, $cSep, $lSemVazio = false, $lVoltaNumero = false) {
    if ($lSemVazio || $lVoltaNumero)
        $cStr = trim($cStr);
    $r = array();
    foreach (explode($cSep, $cStr) as $v) {
        if (cfEmpty($v) && $lSemVazio)
            continue;
        $r[] = $lVoltaNumero ? (float) $v : $v;
    } return $r;
}

function cf_array2token($aArray, $cSep = '-', $lSemVazio = false, $lNaoRepete = false) {
    $cRet = '';
    $aAux = array();
    foreach ($aArray as $v) {
        if (cfEmpty($v) && $lSemVazio)
            continue;
        if ($lNaoRepete && in_array($v, $aAux, true))
            continue;
        $aAux[] = $v;
        $cRet .= $cSep . asString($v);
    }
    return substr($cRet, strlen($cSep));
}

function cf_lastToken($cStr, $cSep, $lSemVazio = false) {
    $a = explode($cSep, $cStr);
    if (empty($a))
        return '';
    if (!$lSemVazio || end($a) !== '')
        return end($a);
    for ($i = count($a) - 1; $i >= 0; $i--)
        if (!cfEmpty($a[$i]))
            return $a[$i];
    return '';
}

function cf_token2arrayNum(&$cRefStr, &$aRefRet, $aSep = null, $lRepete = false, $lSemOrdem = false, $cSepPadrao = '-') {
    $nTam = strlen($cRefStr);
    $aRefRet = array();
    if (cfEmpty($cRefStr))
        return true;
    if (cfEmpty($aSep))
        $aSep = array('-', ',', ';', '.');
    $cAux = str_replace($aSep, $cSepPadrao, $cRefStr);
    $aRet = array();
    foreach (explode($cSepPadrao, $cAux) as $v) {
        $n = (float) $v;
        if (!cfEmpty($n))
            $aRet[] = $n;
    }
    if (empty($aRet)) {
        $cRefStr = str_repeat(' ', $nTam);
        return true;
    }
    if (!$lRepete) {
        foreach ($aRet as $i => $v)
            for ($j = $i + 1; $j < count($aRet); $j++)
                if ($aRet[$j] == $v)
                    return cf_erro('O Valor => ' . nTrim($v) . ';Esta repetido');
    }
    if (!$lSemOrdem)
        sort($aRet, SORT_NUMERIC);
    $aRefRet = $aRet;
    $cRefStr = str_pad(implode('-', array_map('nTrim', $aRet)), $nTam, ' ', STR_PAD_RIGHT);
    return true;
}

function cf_dbmysqlconnection($cConnString, &$cRefErro, &$oRefConn = null) {
    $cRefErro = '';
    $p = array_pad(explode(';', $cConnString), 6, '');
    $link = @mysqli_connect($p[0], $p[2], $p[3], '', (int) $p[4]);
    if (!$link) {
        $cRefErro = mysqli_connect_error();
        return 0;
    }
    if (!@mysqli_select_db($link, $p[1])) {
        $cRefErro = 'Erro acessando database: ' . $p[1];
        mysqli_close($link);
        return 0;
    }
    $nConn = cf_start_connection_index();
    $GLOBALS['s_aConn'][$nConn] = array('link' => $link, 'database' => $p[1], 'host' => $p[0], 'user' => $p[2], 'port' => (int) $p[4]);
    $oRefConn = $GLOBALS['s_aConn'][$nConn];
    return $nConn;
}

function cf_dbmysqlclearconnection($nConn = 1) {
    veConn($nConn, true);
    mysqli_close($GLOBALS['s_aConn'][$nConn]);
    $GLOBALS['s_aConn'][$nConn] = null;
    return SUCCESS;
}

function cf_plugin($nConn) {
    $a = array();
    cf_mysqlExecToArray("SELECT PLUGIN_NAME, PLUGIN_STATUS FROM information_schema.plugins WHERE plugin_name = 'METADATA_LOCK_INFO'", $nConn, $a);
    return count($a) > 0 && trim($a[0][1]) === 'ACTIVE';
}

function cf_mysqlVersion($nConn = 1) {
    return cf_mysqlSelVal2('select version()', 'C', $nConn, 1);
}

function mysql_query_rdd($nSocket, $cStr) {
    if (is_numeric($nSocket)) {
        $nConn = $nSocket;
        veConn($nConn, false, $nSocket);
    }
    $result = mysqli_query($nSocket, $cStr);
    if ($result === false)
        cfRaise('( ' . $cStr . ' )' . "\r\n" . mysqli_error($nSocket), 'CFRDD/3002');
    return $result;
}

function cf_mysqlExecToArray($cSql, $nConn = 1, &$aRefRet = array(), &$cRefErro = '') {

    $aRefRet = array();
    $cRefErro = '';
    veConn($nConn, TRUE, $link);
    //$link = cfConnection($nConn);
    $result = @mysqli_query($link, $cSql);
    if ($result === false) {
        $cRefErro = mysqli_error($link);
        return false;
    }
    if ($result instanceof mysqli_result) {
        while (($row = mysqli_fetch_row($result)) !== null)
            $aRefRet[] = $row;
        mysqli_free_result($result);
    }
   return true;
}

function cf_mysqlExec($cSql, $nConn = 1, &$cRefErro = '') {
    $cRefErro = '';
    veConn($nConn, true, $link);
    //$link = cfConnection($nConn);
    $result = @mysqli_query($link, $cSql);
    if ($result === false) {
        $cRefErro = mysqli_error($link);
        return false;
    }
    if ($result instanceof mysqli_result)
        mysqli_free_result($result);
    return true;
}

function cf_mysqlSelVal($cStr, $cTipoRet = 'C', $nConn = 1, $nField = 1) {
    return cf_mysqlSelVal2($cStr, $cTipoRet, $nConn, $nField);
}

function cf_mysqlSelVal2($cStr, $cTipoRet = 'C', $nConn = 1, $nField = 1) {
    $a = array();
    $e = '';
    cf_mysqlExecToArray($cStr, $nConn, $a, $e);
    if (!cf_mysqlExecToArray($cStr, $nConn, $a, $e) || empty($a))
        return $cTipoRet === 'N' ? 0 : ($cTipoRet === 'D' ? null : ($cTipoRet === 'L' ? false : ''));
    $idx = max(0, (int) $nField - 1);
    $cAux = isset($a[0][$idx]) ? $a[0][$idx] : null;
    $cTipoRet = strtoupper($cTipoRet);
    if ($cTipoRet === 'N')
        return asNumber($cAux);
    if ($cTipoRet === 'C')
        return asString($cAux);
    if ($cTipoRet === 'D')
        return asDate($cAux);
    if ($cTipoRet === 'L') {
        if (is_string($cAux))
            return strpos('SYTV', strtoupper($cAux)) !== false;
        if (is_numeric($cAux))
            return $cAux > 0;
        return (bool) $cAux;
    }
    return $cAux;
}

function cf_hasIndex($nConn, $cTable, $cIndex = '', &$aRefKeys = array(), &$cRefErro = '') {
    $aRefKeys = array();
    $cRefErro = '';
    $cTable = cf_table2Sql($cTable)[1];
    $cIndex = strtoupper(trim($cIndex));
    $cStr = "SELECT TABLE_NAME,INDEX_NAME,IF(LOCATE('_',INDEX_NAME)=0,INDEX_NAME,RIGHT(INDEX_NAME,LOCATE('_',REVERSE(INDEX_NAME))-1)) INDEX_NAME1," .
            "COLUMN_NAME,SEQ_IN_INDEX,NON_UNIQUE,INDEX_TYPE FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = Database() AND TABLE_NAME = " . cf_assql($cTable) . " ORDER BY INDEX_NAME, SEQ_IN_INDEX";
    $aAux = array();
    cf_mysqlExecToArray($cStr, $nConn, $aAux, $cRefErro);
    if (!cfEmpty($cRefErro))
        return false;
    foreach ($aAux as $row) {
        $idx = trim($row[2]);
        if ($idx === 'PRIMARY')
            continue;
        if (!cfEmpty($cIndex)) {
            if ($idx === $cIndex)
                $aRefKeys[] = array($idx, trim($row[3]));
        } else {
            $aRefKeys[] = array($idx, trim($row[3]));
        }
    }
    return !empty($aRefKeys);
}

function cf_table2Sql($cTable) {
    $cTable = trim($cTable);
    foreach (array(':', '\\', '/', ' ') as $x) {
        $p = strrpos($cTable, $x);
        if ($p !== false)
            $cTable = substr($cTable, $p + 1);
    }
    $cTable = substr(strtoupper(trim($cTable)), 0, 12);
    if (substr($cTable, -4) === '.DBF')
        $cTable = substr($cTable, 0, -4);
    if (substr($cTable, -1) === '.')
        $cTable = substr($cTable, 0, -1);
    return array($cTable, file2Sql($cTable));
}

function cf_date($nConn) {
    $a = array(cf_mysqlSelVal2('select current_date()', 'D', $nConn), cf_mysqlSelVal2('select current_time()', 'C', $nConn), 0);
    $a[2] = time2Sec($a[1]);
    return $a;
}

function cf_data($nConn) {
    $a = cf_date($nConn);
    return $a[0];
}

function cf_hora($nConn) {
    $a = cf_date($nConn);
    return $a[1];
}

function cf_fileSql($nConn, $cTabSql, &$aRefTables = array(), &$cRefErro = '', $lFormatoShowTables = false) {
    $cRefErro = '';
    $aRefTables = array();
    if (cfEmpty($cTabSql)) {
        cfRaise('Sem tabela', $cTabSql);
        return false;
    }
    $cStr = 'SELECT table_name FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name like ' . cf_assql($cTabSql);
    $a = array();
    if (cf_mysqlExecToArray($cStr, $nConn, $a, $cRefErro)) {
        foreach ($a as $r)
            $aRefTables[] = $r[0];
    }
    if ($lFormatoShowTables) {
        $tmp = $aRefTables;
        $aRefTables = array();
        foreach ($tmp as $x)
            $aRefTables[] = array($x);
    }
    return !empty($aRefTables);
}

function cf_file($nConn, $cTable, &$cRefErro = '', $nTipoArq = 0) {
    $cRefErro = '';
    if (cfEmpty($cTable)) {
        cfRaise('Sem tabela', $cTable);
        return false;
    }veConn($nConn, true);
    if ((int) $nTipoArq === 0) {
        $a = cf_table2Sql($cTable);
        $cTable = $a[0];
        $cTabSql = $a[1];
        $cStr = 'select TAB_NAME1 FROM CLP_TABLES WHERE TAB_CLP_NAME=' . cf_assql($cTable);
        $cRet = cf_mysqlSelVal2($cStr, 'C', $nConn);
        if (cfEmpty($cRet)) {
            $cRefErro = 'Tabela não existe ' . $cStr . $cRet;
            return false;
        }
        $cStr = 'SELECT table_name FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name = ' . cf_assql($cTabSql);
        $cRet = cf_mysqlSelVal2($cStr, 'C', $nConn);
        if (cfEmpty($cRet)) {
            $cRefErro = 'Tabela não existe no Mysql';
            return false;
        }
        if (cf_hasMemo($nConn, $cTable, $cRefErro)) {
            $cStr = 'SELECT table_name FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name = ' . cf_assql($cTabSql . '_MEMO');
            $cRet = cf_mysqlSelVal2($cStr, 'C', $nConn);
            if (cfEmpty($cRet)) {
                $cRefErro = 'Tabela MEMO não existe no Mysql';
                return false;
            }
        }
    } else {
        $cTable = strtoupper(trim($cTable));
        $cStr = 'select BAG_CLP_NAME,TAB_CLP_NAME from CLP_TAB_COLS WHERE BAG_CLP_NAME=' . cf_assql($cTable) . ' AND !ISNULL(BAG_CLP_NAME) GROUP BY TAB_CLP_NAME,BAG_CLP_NAME';
        $cRet = cf_mysqlSelVal2($cStr, 'C', $nConn);
        if (cfEmpty($cRet)) {
            $cRefErro = 'Tabela não existe';
            return false;
        }
    }
    return true;
}

function cf_dbStruct($nConn, $cTable, &$cRefErro = '', $lIdx = false, $aCampos = null) {
    $aEstru = array();
    $aAux = array();
    $cRefErro = '';
    if (!$lIdx) {
        $cStr = "select COL_NAME,COL_CLP_TYPE,COL_CLP_LEN,if(isnull(COL_CLP_DEC),0,COL_CLP_DEC) AS COL_CLP_DEC FROM CLP_TAB_COLS WHERE COL_NAME!='RECNO' AND COL_NAME!='IS_DELETED' AND COL_NAME NOT LIKE 'IE$%' AND TAB_CLP_NAME=" . cf_assql(cf_table2Sql($cTable)[0]);
        if (!cfEmpty($aCampos)) {
            $cStr .= ' and COL_NAME IN (';
            $q = array();
            foreach ($aCampos as $x)
                $q[] = "'" . strtoupper(trim($x)) . "'";$cStr .= implode(',', $q) . ')';
        }
        $cStr .= ' ORDER BY COL_ORD';
          cf_mysqlExecToArray($cStr, $nConn, $aAux, $cRefErro);
        foreach ($aAux as $r) {
            $t = $r[1] == 65 ? 'M' : (($r[1] == 2 || $r[1] == 2048) ? 'N' : ($r[1] == 4 ? 'L' : ($r[1] == 8 ? 'D' : 'C')));
            $len = $r[1] == 65 ? 10 : ($r[1] == 4 ? 1 : ($r[1] == 8 ? 8 : $r[2]));
            $aEstru[] = array(trim($r[0]), $t, $len, $r[3]);
        }
    } else {
        $cStr = "select COL_NAME,COL_CLP_TYPE,COL_CLP_LEN,if(isnull(COL_CLP_DEC),0,COL_CLP_DEC) AS COL_CLP_DEC FROM CLP_TAB_COLS WHERE COL_NAME LIKE 'IE$%' AND TAB_CLP_NAME=" . cf_assql(cf_table2Sql($cTable)[0]) . ' ORDER BY COL_NAME';
        cf_mysqlExecToArray($cStr, $nConn, $aAux, $cRefErro);
        foreach ($aAux as $r)
            $aEstru[] = array(trim($r[0]), 'C', $r[2], 0);
    }
    return $aEstru;
}

function cf_hasMemo($nConn, $cTable, &$cRefErro = '') {
    foreach (cf_dbStruct($nConn, $cTable, $cRefErro)as $r)
        if ($r[1] === 'M')
            return true;return false;
}

function cf_medgetFile($nConn, $cFileName, $nFileType, &$cFileNameArray = null, &$cTableNameArray = null) {
    $cFileName = strtoupper(trim($cFileName));
    if (substr($cFileName, -3) === '*.*')
        $cFileName = substr($cFileName, 0, -2);if (substr($cFileName, -2) === '*.')
        $cFileName = substr($cFileName, 0, -1);$a = array();
    cf_mysqlExecToArray("select TAB_CLP_NAME,TAB_NAME1 FROM CLP_TABLES WHERE TAB_CLP_NAME LIKE '" . str_replace('*', '%', $cFileName) . "'", $nConn, $a, $e);
    foreach ($a as $i => $r) {
        if (is_array($cFileNameArray))
            $cFileNameArray[$i] = $r[0];if (is_array($cTableNameArray))
            $cTableNameArray[$i] = $r[1];
    }return count($a);
}

function cf_medgetFile1($nConn, $cFileName, $nFileType, &$cFileNameArray = array(), &$cTableNameArray = array()) {
    $cFileNameArray = array();
    $cTableNameArray = array();
    $cFileName = strtoupper(trim($cFileName));
    if (substr($cFileName, -3) === '*.*')
        $cFileName = substr($cFileName, 0, -2);if (substr($cFileName, -2) === '*.')
        $cFileName = substr($cFileName, 0, -1);$a = array();
    cf_mysqlExecToArray("select TAB_CLP_NAME,TAB_NAME1 FROM CLP_TABLES WHERE TAB_CLP_NAME LIKE '" . str_replace('*', '%', $cFileName) . "'", $nConn, $a, $e);
    foreach ($a as $r) {
        $cFileNameArray[] = $r[0];
        $cTableNameArray[] = $r[1];
    }return count($a);
}

function cf_indexes($nConn, $cTable) {
    $aTable = cf_table2Sql($cTable);
    $cSql = "Select COL_NAME,COL_TYPE,BAG_CLP_NAME,BAG_CLP_ORD,IND_CLP_NAME,IND_CLP_EXP,IND_EXP,IND_TYPE,IND_NAME,IND_EXP_TYPE,COL_CLP_LEN from CLP_TAB_COLS WHERE TAB_CLP_NAME='" . $aTable[0] . "' AND !ISNULL(IND_NAME) AND IND_IN_USE='Y' ORDER BY BAG_CLP_NAME,BAG_CLP_ORD";
    $aAux = array();
    cf_mysqlExecToArray($cSql, $nConn, $aAux, $e);
    $aIndexes = array();
    $i = 0;
    foreach ($aAux as $r) {
        $i++;
        while ($i < (int) $r[3]) {
            $aIndexes[] = array('', false, 0, '', '', '', '', 0);
            $i++;
        }$aIndexes[] = array(trim($r[0]), $r[1] == 4, $r[3], trim($r[4]), trim($r[5]), trim($r[6]), trim($r[8]), $r[10]);
    }return $aIndexes;
}

function cf_index_create($nConn, $cTable, $cBag, $cKey, $lForce = false) {
    $cBag = strtoupper(trim($cBag));
    $cKey = strtoupper(trim($cKey));
    $aIndexes = cf_indexes($nConn, $cTable);
    foreach ($aIndexes as $r)
        if ($r[3] === $cBag)
            return true;$lComposto = !(cf_limpaRg($cKey, false, '_') === $cKey);
    $cTableSql = cf_table2Sql($cTable)[1];
    if (!$lComposto) {
        $cStr = 'alter table `' . $cTableSql . '` add index `' . $cTableSql . '_IDX_' . $cBag . '` (`' . $cKey . '`,`RECNO`)';
        cf_mysqlExec($cStr, $nConn, $e);
        $nOrd = 0;
        foreach ($aIndexes as $r)
            $nOrd = max((int) $r[2], $nOrd);$nOrd++;
        $cStr = "update CLP_TAB_COLS SET COL_TYPE=3,BAG_CLP_NAME='IDX',BAG_CLP_ORD=" . myTrim($nOrd) . ",IND_CLP_NAME='" . $cBag . "',IND_CLP_EXP='" . $cKey . "',IND_EXP='" . $cKey . "',IND_TYPE=1,IND_NAME='" . $cTableSql . "_IDX_" . $cBag . "',IND_IN_USE='Y' WHERE TAB_CLP_NAME='" . $cTableSql . "' AND COL_NAME='" . $cKey . "'"; //* original monta a consulta mas não a executa 
        return true;
    }return true;
}

function cf_index_del($nConn, $cTable, $cBag = '', $lNaoDeletarComposto = false) {
    $cBag = strtoupper(trim($cBag));
    $aIndexes = cf_indexes($nConn, $cTable);
    $nAux = -1;
    foreach ($aIndexes as $i => $r)
        if ($r[3] === $cBag) {
            $nAux = $i;
            break;
        }if ($nAux < 0)
        return false;$aTable = cf_table2Sql($cTable);
    $cComposto = trim(cf_mysqlSelVal("select col_name from CLP_TAB_COLS WHERE TAB_CLP_NAME='" . $aTable[0] . "' and IND_CLP_NAME='" . $cBag . "'", 'C', $nConn));
    cf_mysqlExec('alter table ' . $aTable[1] . ' drop index `' . $aIndexes[$nAux][6] . '`', $nConn, $e);
    if (strpos($cComposto, 'IE$') !== false) {
        if (!$lNaoDeletarComposto) {
            cf_mysqlExec('alter table ' . $aTable[1] . ' drop `' . $cComposto . '`', $nConn, $e);
            cf_mysqlExec("delete from CLP_TAB_COLS WHERE TAB_CLP_NAME='" . $aTable[1] . "' AND COL_NAME='" . $cComposto . "'", $nConn, $e);
        } else {
            cf_mysqlExec("update CLP_TAB_COLS SET COL_TYPE=0,BAG_CLP_NAME='',BAG_CLP_ORD=NULL,IND_CLP_NAME='',IND_CLP_EXP='',IND_CLP_FOR=NULL,IND_TYPE=NULL,IND_NAME='',IND_IN_USE='',IND_EXP_TYPE=NULL,IND_EXP_LEN=NULL WHERE TAB_CLP_NAME='" . $aTable[0] . "' and IND_CLP_NAME='" . $cBag . "' AND COL_EXP=3", $nConn, $e);
        }
    } else {
        cf_mysqlExec("update CLP_TAB_COLS SET BAG_CLP_NAME='',BAG_CLP_ORD=NULL,IND_CLP_NAME='',IND_CLP_EXP='',IND_CLP_FOR=NULL,IND_TYPE=NULL,IND_NAME='',IND_IN_USE='N',IND_EXP_LEN=NULL WHERE TAB_CLP_NAME='" . $aTable[0] . "' and IND_CLP_NAME='" . $cBag . "' AND COL_EXP=4", $nConn, $e);
    }return true;
}

function cf_leMemo($nConn, $cTable, $nRecord, $cMemo) {
    $cTableSql = cf_table2Sql($cTable)[1];
    $cSql = 'select convert(memo,CHAR) as memo from ' . $cTableSql . '_MEMO where recno=' . ltrim(sprintf('%10d', $nRecord)) . " and col_name='" . strtoupper($cMemo) . "'";
    return cf_mysqlSelVal2($cSql, 'C', $nConn);
}

function cf_getIdxs($nConn, $cTable, &$aRefIdx = array(), &$cRefErro = '') {
    if (is_numeric($cTable))
        $cTable = cfAreaToTable($cTable);if (!cf_file($nConn, $cTable, $cRefErro)) {
        cfRaise('Tabela não existe', $cTable);
        return -1;
    }$aAux = array();
    cf_mysqlExecToArray('select bag_clp_name from CLP_TAB_COLS where IND_IN_USE=\'Y\' AND tab_clp_name=' . cf_assql(cf_table2Sql($cTable)[0]) . ' group by BAG_CLP_NAME ORDER BY BAG_CLP_NAME', $nConn, $aAux, $cRefErro);
    $aRefIdx = $aAux;
    foreach ($aRefIdx as &$r)
        $r[0] = trim($r[0]);return count($aRefIdx);
}

function cf_getIdxs1($nConn, $nArea, &$aRefIdx = array(), &$cRefErro = '') {
    $cTable = cfAreaToTable($nArea);
    return cf_getIdxs($nConn, $cTable, $aRefIdx, $cRefErro);
}

function cf_ordname($nConn, $cTable, $cIdx = '', $nOrd = 1, &$cRefErro = '') {
    if (!cf_file($nConn, $cTable, $cRefErro)) {
        cfRaise('Tabela não existe', $cTable);
        return '';
    }if (cfEmpty($cIdx)) {
        $a = array();
        cf_getIdxs($nConn, $cTable, $a, $cRefErro);
        if (count($a) === 0)
            cfRaise('Sem índices', $cTable);$cIdx = $a[0][0];
    }return cf_mysqlSelVal2('select ind_clp_name from CLP_TAB_COLS where IND_IN_USE=\'Y\' AND tab_clp_name=' . cf_assql(cf_table2Sql($cTable)[1]) . ' and bag_clp_name=' . cf_assql($cIdx) . ' and bag_clp_ord=' . cf_assql($nOrd), 'C', $nConn);
}

function cf_createTable($nConn, $cTable, $aEstru, &$cRefErro = '') {
    $cRefErro = '';
    $lRet = false;
    if (cfEmpty($cTable)) {
        cfRaise('Sem tabela', $cTable);
        return false;
    }$a = cf_table2Sql($cTable);
    $cTable = $a[0];
    $cTabSql = $a[1];
    $cRet = cf_mysqlSelVal2('select TAB_NAME1 FROM CLP_TABLES WHERE TAB_CLP_NAME=' . cf_assql($cTable), 'C', $nConn);
    if (cf_file($nConn, $cTable, $cRefErro))
        cf_dropFile($nConn, $cTable, $cRefErro, true);
    $cRet = cf_mysqlSelVal2('SELECT table_name FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name = ' . cf_assql($cTabSql), 'C', $nConn);
    if (!cfEmpty($cRet)) {
        cfRaise('Tabela existe no mysql', $cTable);
        return false;
    }
    if (cfEmpty($aEstru)) {
        cfRaise('Sem Campos', $cTable);
        return false;
    }
    $aEstru1 = $aEstru;
    foreach ($aEstru as $i => &$f) {
        if (count($f) < 4) {
            cfRaise('Campo com dados incompativeis' . (isset($f[0]) ? $f[0] : ''), $cTable);
            return false;
        }if (cfEmpty($f[0])) {
            cfRaise('Campo vazio', $cTable);
            return false;
        }
        $f[0] = strtoupper(trim($f[0]));
        $f[1] = strtoupper(trim($f[1]));
        if (cf_limpaRg($f[0], false, '$_') !== $f[0])
            cfRaise('Caracteres inválidos no Campo => ' . $f[0], $cTable);if (strlen($f[0]) > 10)
            cfRaise('Nome do campo ultrapassa 10 caracteres => ' . $f[0], $cTable);if (!in_array($f[1], array('C', 'N', 'L', 'D', 'M'), true))
            cfRaise('Tipo inválido no Campo => ' . $f[0] . ',' . $f[1], $cTable);if ($f[2] < 1 || $f[3] < 0)
            cfRaise('Tamanho inválido no Campo => ' . $f[0] . ',' . $f[1] . ',' . myTrim($f[2]) . ',' . myTrim($f[3]), $cTable);if ($f[1] === 'N' && $f[3] > 0 && $f[3] + 1 >= $f[2])
            cfRaise('Decimais inválidos no Campo => ' . $f[0] . ',' . $f[1] . ',' . myTrim($f[2]) . ',' . myTrim($f[3]), $cTable);
    }
    $cstr = 'insert CLP_TABLES (TAB_CLP_NAME,TAB_LOCKED,TAB_COUNT,TAB_NAME1,TAB_NAME2,TAB_NAME3,TAB_NAME4) values (' . cf_assql($cTable) . ",'N',1," . cf_assql($cTabSql) . ',NULL,NULL,NULL)';
    cf_mysqlExec($cstr, $nConn, $cRefErro);
    $cMysql = 'CREATE TABLE `' . $cTabSql . '` (`RECNO` int(10) NOT NULL auto_increment primary key,`IS_DELETED` char(1) NOT NULL DEFAULT \'N\'';
    $lMemo = false;

    //recno e is_deleted

    $cStr = "insert CLP_TAB_COLS (TAB_CLP_NAME,COL_NAME,COL_ORD,TAB_NAME,COL_TYPE,COL_CLP_TYPE,COL_CLP_LEN) " .
            "values (" . cf_assql($cTable) . ",'RECNO',10000," . cf_assql($cTabSql) . ",1,2,10)";
    cf_mysqlExec($cStr, $nConn, $cRefErro);
    if (!cfEmpty($cRefErro))
        return false;

    $cStr = "insert CLP_TAB_COLS (TAB_CLP_NAME,COL_NAME,COL_ORD,TAB_NAME,COL_TYPE,COL_CLP_TYPE) " .
            "values (" . cf_assql($cTable) . ",'IS_DELETED',10001," . cf_assql($cTabSql) . ",2,4)";
    cf_mysqlExec($cStr, $nConn, $cRefErro);
    if (!cfEmpty($cRefErro))
        return false;



    foreach ($aEstru1 as $i => $f) {
        $clp = cfClpType($f[1], $f[2]);
        $dec = ((int) $f[3] === 0) ? 'NULL' : cf_assql($f[3]);
        $cStr = 'insert CLP_TAB_COLS (TAB_CLP_NAME,COL_NAME,COL_ORD,TAB_NAME,COL_CLP_TYPE,COL_CLP_LEN,COL_CLP_DEC) values (' . cf_assql($cTable) . ',' . cf_assql($f[0]) . ',' . cf_assql($i + 1) . ',' . cf_assql($cTabSql) . ',' . $clp . ',' . ($f[1] === 'L' || $f[1] === 'D' || $f[1] === 'M' ? 'NULL' : cf_assql($f[2])) . ',' . ($f[1] === 'N' ? $dec : 'NULL') . ')';
        cf_mysqlExec($cStr, $nConn, $cRefErro);
        $cMysql .= ',`' . $f[0] . '` ' . cfSqlColumnDefinition($f[1], $f[2], $f[3], 254);
        if ($f[1] === 'M')
            $lMemo = true;
    }
    $cMysql .= ') ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci';
    cf_mysqlExec($cMysql, $nConn, $cRefErro);
    if (!cfEmpty($cRefErro))
        return false;

    if ($lMemo) {
        $cMysqlMemo = 'CREATE TABLE `' . $cTabSql . '_MEMO` (`RECNO` int(10) NOT NULL,`COL_NAME` varchar(11) NOT NULL,`MEMO` mediumblob DEFAULT NULL, PRIMARY KEY (`RECNO`,`COL_NAME`), CONSTRAINT `' . $cTabSql . '_MEMO_FK` FOREIGN KEY (`RECNO`) REFERENCES `' . $cTabSql . '` (`RECNO`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci';
        cf_mysqlExec($cMysqlMemo, $nConn, $cRefErro);
        if (!cfEmpty($cRefErro))
            return false;
    }

    return true;
}

function cf_colAdd($nConn, $cTable, $aEstru, &$cRefErro = '') {
    $cRefErro = '';
    if (!cf_file($nConn, $cTable, $cRefErro)) {
        cfRaise('Tabela não existe', $cTable);
        return false;
    }$aAux = cf_dbStruct($nConn, $cTable, $cRefErro);
    foreach ($aEstru as &$f) {
        $f[0] = strtoupper(trim($f[0]));
        $f[1] = strtoupper(trim($f[1]));
        foreach ($aAux as $r)
            if ($r[0] === $f[0]) {
                cfRaise('Campo ' . $f[0] . ' já existe no arquivo', $cTable);
                return false;
            }
    }
    $a = cf_table2Sql($cTable);
    $cTable = $a[0];
    $cTabSql = $a[1];
    $nColOrd = cf_mysqlSelVal2('select max(COL_ORD) FROM CLP_TAB_COLS WHERE COL_ORD<10000 AND TAB_CLP_NAME=' . cf_assql($cTable), 'N', $nConn);
    foreach ($aEstru as $f) {
        $nColOrd++;
        $lMemo = $f[1] === 'M';
        $clp = cfClpType($f[1], $f[2]);
        $cStr = 'insert CLP_TAB_COLS (TAB_CLP_NAME,COL_NAME,COL_ORD,TAB_NAME,COL_CLP_TYPE,COL_CLP_LEN,COL_CLP_DEC) values (' . cf_assql($cTable) . ',' . cf_assql($f[0]) . ',' . cf_assql($nColOrd) . ',' . cf_assql($cTabSql) . ',' . $clp . ',' . ($f[1] === 'C' || $f[1] === 'N' ? cf_assql($f[2]) : 'NULL') . ',' . ($f[1] === 'N' && $f[3] != 0 ? cf_assql($f[3]) : 'NULL') . ')';
        cf_mysqlExec($cStr, $nConn, $cRefErro);
        if (!cfEmpty($cRefErro))
            return false;$cMysql = 'ALTER TABLE `' . $cTabSql . '` ADD `' . $f[0] . '` ' . cfSqlColumnDefinition($f[1], $f[2], $f[3], 255);
        cf_mysqlExec($cMysql, $nConn, $cRefErro);
        if (!cfEmpty($cRefErro))
            return false;if ($lMemo && !cf_hasMemo($nConn, $cTable, $cRefErro)) {
            $memo = 'CREATE TABLE `' . $cTabSql . '_MEMO` (`RECNO` int(10) NOT NULL,`COL_NAME` varchar(11) NOT NULL,`MEMO` mediumblob DEFAULT NULL, PRIMARY KEY (`RECNO`,`COL_NAME`), CONSTRAINT `' . $cTabSql . '_MEMO_FK` FOREIGN KEY (`RECNO`) REFERENCES `' . $cTabSql . '` (`RECNO`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci';
            cf_mysqlExec($memo, $nConn, $cRefErro);
            if (!cfEmpty($cRefErro))
                return false;
        }
    }
    return true;
}

function cf_colRes($nConn, $cTable, $aEstru, &$cRefErro = '') {
    $cRefErro = '';
    if (cfEmpty($aEstru))
        return false;if (!cf_file($nConn, $cTable, $cRefErro)) {
        cfRaise('Tabela não existe', $cTable);
        return false;
    }$aAux = cf_dbStruct($nConn, $cTable, $cRefErro);
    $aNew = array();
    if (count($aEstru[0]) === 3) {
        foreach ($aEstru as $f) {
            $f[0] = strtoupper(trim($f[0]));
            $pos = -1;
            foreach ($aAux as $i => $r)
                if ($r[0] === $f[0]) {
                    $pos = $i;
                    break;
                }if ($pos < 0) {
                cfRaise('Campo ' . $f[0] . ' não existe no arquivo', $cTable);
                return false;
            }$aNew[] = array($f[0], $aAux[$pos][1], $f[1], $f[2]);
        }$aEstru = $aNew;
    } else {
        foreach ($aEstru as &$f) {
            $f[0] = strtoupper(trim($f[0]));
            $f[1] = strtoupper(trim($f[1]));
            $ok = false;
            foreach ($aAux as $r)
                if ($r[0] === $f[0]) {
                    $ok = true;
                    break;
                }if (!$ok) {
                cfRaise('Campo ' . $f[0] . ' não existe no arquivo', $cTable);
                return false;
            }
        }
    }
    $a = cf_table2Sql($cTable);
    $cTable = $a[0];
    $cTabSql = $a[1];
    foreach ($aEstru as $f) {
        $nColOrd = cf_mysqlSelVal2('select COL_ORD FROM CLP_TAB_COLS WHERE COL_NAME=' . cf_assql($f[0]) . ' AND TAB_CLP_NAME=' . cf_assql($cTable), 'N', $nConn);
        $aIndex = array();
        $cStr = 'select col_type,bag_clp_name,bag_clp_ord,ind_clp_name,ind_clp_exp,ind_exp,ind_type,ind_name,ind_in_use FROM CLP_TAB_COLS WHERE COL_NAME=' . cf_assql($f[0]) . ' AND TAB_CLP_NAME=' . cf_assql($cTable) . ' and !isnull(ind_name)';
        cf_mysqlExecToArray($cStr, $nConn, $aIndex, $e);
        $clp = cfClpType($f[1], $f[2]);
        $meta = 'REPLACE CLP_TAB_COLS (TAB_CLP_NAME,COL_NAME,COL_ORD,TAB_NAME,COL_CLP_TYPE,COL_CLP_LEN,COL_CLP_DEC) values (' . cf_assql($cTable) . ',' . cf_assql($f[0]) . ',' . cf_assql($nColOrd) . ',' . cf_assql($cTabSql) . ',' . $clp . ',' . ($f[1] === 'C' || $f[1] === 'N' ? cf_assql($f[2]) : 'NULL') . ',' . ($f[1] === 'N' && $f[3] != 0 ? cf_assql($f[3]) : 'NULL') . ')';
        cf_mysqlExec($meta, $nConn, $cRefErro);
        if (!cfEmpty($cRefErro))
            return false;cf_mysqlExec('ALTER TABLE `' . $cTabSql . '` MODIFY `' . $f[0] . '` ' . cfSqlColumnDefinition($f[1], $f[2], $f[3], 255), $nConn, $cRefErro);
        if (!cfEmpty($cRefErro))
            return false;if (!empty($aIndex)) {
            $r = $aIndex[0];
            $upd = 'update CLP_TAB_COLS SET COL_TYPE=' . cf_assql($r[0], false, false, true) . ',BAG_CLP_NAME=' . cf_assql($r[1], false, false, true) . ',BAG_CLP_ORD=' . cf_assql($r[2], false, false, true) . ',IND_CLP_NAME=' . cf_assql($r[3], false, false, true) . ',IND_CLP_EXP=' . cf_assql($r[4], false, false, true) . ',IND_EXP=' . cf_assql($r[5], false, false, true) . ',IND_TYPE=' . cf_assql($r[6], false, false, true) . ',IND_NAME=' . cf_assql($r[7], false, false, true) . ',IND_IN_USE=' . (!cfEmpty($r[8]) ? "'Y'" : "'N'") . ' WHERE COL_NAME=' . cf_assql($f[0]) . ' AND TAB_CLP_NAME=' . cf_assql($cTable);
            cf_mysqlExec($upd, $nConn, $cRefErro);
            if (!cfEmpty($cRefErro))
                return false;
        }if ($f[1] === 'M' && !cf_hasMemo($nConn, $cTable, $cRefErro)) {
            $memo = 'CREATE TABLE `' . $cTabSql . '_MEMO` (`RECNO` int(10) NOT NULL,`COL_NAME` varchar(11) NOT NULL,`MEMO` mediumblob DEFAULT NULL, PRIMARY KEY (`RECNO`,`COL_NAME`), CONSTRAINT `' . $cTabSql . '_MEMO_FK` FOREIGN KEY (`RECNO`) REFERENCES `' . $cTabSql . '` (`RECNO`)) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci';
            cf_mysqlExec($memo, $nConn, $cRefErro);
            if (!cfEmpty($cRefErro))
                return false;
        }
    }
    return true;
}

function cf_checkTable($nConn, $cTable, &$cRefErro = '', &$aRefErro = array()) {
    $cRefErro = '';
    $aRefErro = array();
    $aAux = array();
    $aEstru = array();
    $cStr = 'select COL_NAME,COL_CLP_TYPE,COL_CLP_LEN,if(isnull(COL_CLP_DEC),0,COL_CLP_DEC) AS COL_CLP_DEC,IND_IN_USE FROM CLP_TAB_COLS WHERE TAB_CLP_NAME=' . cf_assql(cf_table2Sql($cTable)[0]) . ' ORDER BY COL_ORD';
    cf_mysqlExecToArray($cStr, $nConn, $aAux, $e);
    if (empty($aAux)) {
        $cRefErro .= "Sem descrição no CLP_TAB_COLS\n";
        $aRefErro[] = 'Sem descrição no CLP_TAB_COLS';
    }
    $cStr = 'SELECT COLUMN_NAME,COLUMN_TYPE,IS_NULLABLE,COLUMN_KEY,COLUMN_DEFAULT,EXTRA FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = database() AND TABLE_NAME = ' . cf_assql(cf_table2Sql($cTable)[1]) . ' ORDER BY ORDINAL_POSITION';
    cf_mysqlExecToArray($cStr, $nConn, $aEstru, $e);
    if (empty($aEstru)) {
        $cRefErro .= "Tabela inexistente no MySql\n";
        $aRefErro[] = 'Tabela inexistente no MySql';
    }if (!empty($aRefErro))
        return false;
    foreach ($aAux as $r) {
        $campo = trim($r[0]);
        $p = cfFindRowByFirstColumn($aEstru, $campo);
        if ($p < 0) {
            $m = "Campo '" . $campo . "' inexistente no MySql";
            $cRefErro .= $m . "\n";
            $aRefErro[] = $m;
            continue;
        }$sql = $aEstru[$p];
        if ($campo === 'RECNO' && ($sql[1] !== 'int(10)' || $sql[3] !== 'PRI' || $sql[5] !== 'auto_increment')) {
            $m = "Campo '" . $campo . "' inválido no MySql";
            $cRefErro .= $m . "\n";
            $aRefErro[] = $m;
            continue;
        }$tipo = $r[1] == 65 ? 'M' : (($r[1] == 2 || $r[1] == 2048) ? 'N' : ($r[1] == 4 ? 'L' : ($r[1] == 8 ? 'D' : 'C')));
        $ok = true;
        $st = trim($sql[1]);
        if ($tipo === 'L')
            $ok = ($st === 'char(1)' || $st === 'varchar(1)');elseif ($tipo === 'N')
            $ok = (substr($st, 0, 8) === 'decimal(' || substr($st, 0, 4) === 'int(');elseif ($tipo === 'D')
            $ok = ($st === 'date');elseif ($tipo === 'M')
            $ok = ($st === 'decimal(10,0)');elseif ($tipo === 'C')
            $ok = (substr($st, 0, 8) === 'varchar(' || substr($st, 0, 5) === 'char(' || substr($st, 0, 4) === 'text' || substr($st, 0, 10) === 'mediumtext');if (!$ok) {
            $m = 'Tipo ' . $tipo . " '" . $campo . "' inválido no MySql";
            $cRefErro .= $m . "\n";
            $aRefErro[] = $m;
        }
    }
    foreach ($aEstru as $r) {
        $campo = trim($r[0]);
        if (cfFindRowByFirstColumn($aAux, $campo) < 0) {
            $m = "Campo '" . $campo . "' apenas no MySql";
            $cRefErro .= $m . "\n";
            $aRefErro[] = $m;
        }
    }
    return cfEmpty($cRefErro);
}

function cf_dropFile($nConn, $cTable, &$cRefErro = '', $lSilent = false) {
    $cRefErro = '';
    $a = cf_table2Sql($cTable);
    $cTable = $a[0];
    $cTableSql = $a[1];
    if (!cf_file($nConn, $cTable, $cRefErro)) {
        if (!$lSilent)
            cfRaise('Erro Deletando Arquivo', $cTable);return false;
    }$locks = array();
    $lock = '';
    mysqlLock(1, CF_LOCK_FILE, $cTable, null, null, $lock, $locks);
    if (count($locks) > 0)
        cfRaise('Tentativa de deletar arquivo Aberto', $cTable);
    $sql = array('delete from CLP_TAB_COLS WHERE TAB_CLP_NAME=' . cf_assql($cTable),
        'delete from CLP_TABLES WHERE TAB_CLP_NAME=' . cf_assql($cTable),
        'delete from CLP_TAB_IDX WHERE TAB_CLP_NAME=' . cf_assql($cTable),
        'drop table if exists ' . $cTableSql . '_MEMO', 'drop table if exists ' . $cTableSql);
    foreach ($sql as $s) {
        if (!cf_mysqlExec($s, $nConn, $cRefErro)) {
            if (!$lSilent)
                cfRaise('Erro deletando Arquivo ' . $cRefErro, $cTable);return false;
        }
    }return true;
}

function cf_renameTable($nConn, $cOrigem, $cDestino, $lClone = false, &$cRefErro = '') {
    $cRefErro = '';
    if (!cf_file($nConn, $cOrigem, $e))
        cfRaise('Origem não existe', $cOrigem);if (cf_file($nConn, $cDestino, $e))
        cfRaise('Destino já existe', $cOrigem);$o = cf_table2Sql($cOrigem);
    $d = cf_table2Sql($cDestino);
    $create = cf_mysqlSelVal2('show create table ' . $o[1], 'C', $nConn, 2);
    $create = str_replace($o[1], $d[1], $create);
    $sql = array($create);
    $cols = '';
    foreach (cf_dbStruct($nConn, $o[0], $e, false)as $f)
        $cols .= ',`' . $f[0] . '`';foreach (cf_dbStruct($nConn, $o[0], $e, true)as $f)
        $cols .= ',`' . $f[0] . '`';$sql[] = 'set foreign_key_checks=0';
    $sql[] = 'replace ' . $d[1] . '(`recno`,`is_deleted`' . $cols . ') select `recno`,`is_deleted`' . $cols . ' from ' . $o[1] . ' order by recno';
    $sql[] = 'create temporary table tmp_rename select * from CLP_TABLES WHERE TAB_CLP_NAME=' . cf_assql($o[0]);
    $sql[] = 'update tmp_rename set TAB_CLP_NAME=' . cf_assql($d[0]) . ',tab_name1=' . cf_assql($d[1]);
    $sql[] = 'insert CLP_TABLES SELECT * FROM tmp_rename';
    $sql[] = 'drop temporary table tmp_rename';
    $sql[] = 'create temporary table tmp_rename select * from CLP_TAB_COLS WHERE TAB_CLP_NAME=' . cf_assql($o[0]);
    $sql[] = 'update tmp_rename set TAB_CLP_NAME=' . cf_assql($d[0]) . ',tab_name=' . cf_assql($d[1]);
    $sql[] = 'insert CLP_TAB_COLS SELECT * FROM tmp_rename';
    $sql[] = 'drop temporary table tmp_rename';
    if (cf_hasMemo($nConn, $o[0], $e)) {
        $m = cf_mysqlSelVal2('show create table ' . $o[1] . '_MEMO', 'C', $nConn, 2);
        $m = str_replace($o[1], $d[1], $m);
        $sql[] = $m;
        $sql[] = 'replace ' . $d[1] . '_MEMO (recno,col_name,memo) select recno,col_name,memo from ' . $o[1] . '_MEMO';
        if (!$lClone)
            $sql[] = 'drop table ' . $o[1] . '_MEMO';
    }if (!$lClone) {
        $sql[] = 'drop table ' . $o[1];
        $sql[] = 'delete from CLP_TABLES WHERE TAB_CLP_NAME=' . cf_assql($o[0]);
        $sql[] = 'delete from CLP_TAB_COLS WHERE TAB_CLP_NAME=' . cf_assql($o[0]);
    }$sql[] = 'set foreign_key_checks=1';
    foreach ($sql as $s) {
        cf_mysqlExec($s, $nConn, $cRefErro);
        if (!cfEmpty($cRefErro))
            cfRaise($s . "\n" . $cRefErro, $cOrigem);
    }return true;
}

function mysqlLock($nConn, $nModo, $cTable, $uPar = null, $nWa = null, &$cRefLock = '', &$aRefLocks = array(), $cAlias = 'WEB') {
    veConn($nConn, true, $oConn);

    $cRefLock = '';
    $aRefLocks = array();
    $cAlias = strtoupper(trim($cAlias));
    if (cfEmpty($nWa))
        $nWa = 0;

    $db = cfDbName($nConn);
    $id = cfMysqlId($nConn);
    if ($nModo == CF_LOCK_FILE) {
        $cTable = cf_table2Sql($cTable)[1];
        if ($uPar === null)
            $uPar = '';
        //if (cfEmpty($cAlias))
        //    $cAlias = $cTable;$uPar = strtoupper(trim($uPar));
        $sql = "select TABLE_SCHEMA FROM INFORMATION_SCHEMA.METADATA_LOCK_INFO WHERE TABLE_SCHEMA LIKE '" . $db . ".F." . $cTable . ".%'";
        $rows = array();
        cf_mysqlExecToArray($sql, $nConn, $rows, $e);
echo "Lock: ";var_dump($rows);
echo "<br><br>";        
        foreach ($rows as $r) {
            $a = cf_token2array($r[0], '.');
            $aRefLocks[] = array(isset($a[0]) ? $a[0] : '', isset($a[2]) ? $a[2] : '', isset($a[3]) ? $a[3] : '', isset($a[4]) ? (int) $a[4] : 0, isset($a[5]) ? (int) $a[5] : 0);
        }
        if (cfEmpty($uPar))
            return false;
        if ($uPar === 'X' && count($rows) > 0)
            return false;
        if ($uPar === 'S') {
            foreach ($aRefLocks as $l)
                if (isset($l[CF_LOCK_F_MODE - 1]) && $l[CF_LOCK_F_MODE - 1] === 'X')
                    return false;
        }
        $cRefLock = $db . '.F.' . $cTable . '.' . $uPar . '.' . myTrim($nWa) . '.' . myTrim($id) . '.' . strtoupper($cAlias);
        mysqli_query($oConn, "select get_lock('" . $cRefLock . "',1)");
        //cf_mysqlExecToArray("select get_lock('" . $cRefLock . "',1)", $nConn, $tmp, $e);
    }
    if ($nModo == CF_LOCK_RECNO) {
        $cTable = cf_table2Sql($cTable)[1];
        if ($uPar === null)
            $uPar = 0;
        //if (cfEmpty($cAlias))
        //    $cAlias = $cTable;
        $sql = "select TABLE_SCHEMA FROM INFORMATION_SCHEMA.METADATA_LOCK_INFO WHERE TABLE_SCHEMA LIKE '" . $db . ".R." . $cTable . "." . ($uPar == 0 ? "%'" : myTrim(abs($uPar)) . ".%'");
        $rows = array();
        cf_mysqlExecToArray($sql, $nConn, $rows, $e);
        foreach ($rows as $r) {
            $a = cf_token2array($r[0], '.');
            $aRefLocks[] = array(isset($a[0]) ? $a[0] : '', isset($a[2]) ? $a[2] : '', isset($a[3]) ? (int) $a[3] : 0, isset($a[4]) ? (int) $a[4] : 0, isset($a[5]) ? (int) $a[5] : 0);
        }if (cfEmpty($uPar) || $uPar < 0 || count($rows) > 0)
            return false;$cRefLock = $db . '.R.' . $cTable . '.' . myTrim($uPar) . '.' . myTrim($nWa) . '.' . myTrim($id) . '.' . strtoupper($cAlias);
        mysqli_query($oConn, "select get_lock('" . $cRefLock . "',1)");
        //cf_mysqlExecToArray("select get_lock('" . $cRefLock . "',1)", $nConn, $tmp, $e);
    }
    if ($nModo == CF_LOCK_TERMINAL) {
        $uPar = strtoupper(trim(asString($uPar)));
        if (cfEmpty($uPar))
            return false;$sql = "select TABLE_SCHEMA FROM INFORMATION_SCHEMA.METADATA_LOCK_INFO WHERE TABLE_SCHEMA LIKE '" . $db . ".T." . myTrim($uPar) . ".%'";
        $rows = array();
        cf_mysqlExecToArray($sql, $nConn, $rows, $e);
        foreach ($rows as $r) {
            $a = cf_token2array($r[0], '.');
            $aRefLocks[] = array(isset($a[0]) ? $a[0] : '', isset($a[2]) ? $a[2] : '', isset($a[2]) ? (int) $a[2] : 0);
        }if (count($rows) > 0)
            return false;$cRefLock = $db . '.T.' . $cTable . '.' . myTrim($uPar) . '.' . myTrim($id);
        mysqli_query($oConn, "select get_lock('" . $cRefLock . "',1)");
        //cf_mysqlExecToArray("select get_lock('" . $cRefLock . "',1)", $nConn, $tmp, $e);
    }
    return true;
}

function mysqlRelease($nConn, $nModo, $cTable, $uPar = null, $nWa = null, $cAlias = 'WEB') {
    veConn($nConn, true, $oConn);
    $db = cfDbName($nConn);
    $id = cfMysqlId($nConn);
    $cAlias = strtoupper(trim($cAlias));
    if (cfEmpty($nWa))
        $nWa = 0;
    if ($nModo == CF_LOCK_FILE) {
        $cTable = cf_table2Sql($cTable)[1];
        if ($uPar === null)
            $uPar = 'S';
        //if (cfEmpty($cAlias))
        //$cAlias = cfAreaAlias($nWa, $cTable);$cAlias = strtoupper($cAlias);
        $uPar = strtoupper(trim($uPar));
        mysqli_query($oConn, "select release_lock('" . $db . '.F.' . $cTable . '.' . $uPar . '.' . myTrim($nWa) . '.' . myTrim($id) . '.' . $cAlias . "')");
        $sql = "select TABLE_SCHEMA FROM INFORMATION_SCHEMA.METADATA_LOCK_INFO WHERE TABLE_SCHEMA LIKE '" . $db . '.R.' . $cTable . '.%.' . myTrim($nWa) . '.' . myTrim($id) . ".%'";
        $rows = array();
        cf_mysqlExecToArray($sql, $nConn, $rows, $e);

        foreach ($rows as $r)
            mysqli_query($oConn, "select release_lock('" . $r[0] . "')");
        //cf_mysqlExecToArray("select release_lock('" . $r[0] . "')", $nConn, $tmp, $e);
    }
    if ($nModo == CF_LOCK_RECNO) {
        $cTable = cf_table2Sql($cTable)[1];
        if ($uPar === null)
            $uPar = 0;if (cfEmpty($uPar))
            return false;
        //if (cfEmpty($cAlias))
        //$cAlias = cfAreaAlias($nWa, $cTable);$cAlias = strtoupper($cAlias);
        mysqli_query($oConn, "select release_lock('" . $db . '.R.' . $cTable . '.' . myTrim($uPar) . '.' . myTrim($nWa) . '.' . myTrim($id) . '.' . $cAlias . "')");
        //cf_mysqlExecToArray("select release_lock('" . $db . '.R.' . $cTable . '.' . myTrim($uPar) . '.' . myTrim($nWa) . '.' . myTrim($id) . '.' . $cAlias . "')", $nConn, $tmp, $e);
    }
    if ($nModo == CF_LOCK_TERMINAL) {
        $uPar = strtoupper(trim(asString($uPar)));
        if (cfEmpty($uPar))
            return false;
//        cf_mysqlExecToArray("select release_lock('" . $db . '.T.' . $cTable . '.' . myTrim($uPar) . '.' . myTrim($id) . "')", $nConn, $tmp, $e);
        mysqli_query($oConn, "select release_lock('" . $db . '.T.' . $cTable . '.' . myTrim($uPar) . '.' . myTrim($id) . "')");
    }
    return true;
}

function cf_dbconn($nConn, &$aRefConn = array()) {
    $aRefConn = array(0, 0, 0);
    $aRefConn[0] = cf_mysqlSelVal('SELECT COUNT(*) AS total FROM information_schema.processlist', 'N', $nConn);
    $aRefConn[1] = cf_mysqlSelVal("select count(*) as quant FROM INFORMATION_SCHEMA.METADATA_LOCK_INFO WHERE TABLE_SCHEMA LIKE concat(database(),'.CONN%')", 'N', $nConn);
    $aRefConn[2] = cfMysqlId($nConn);
    return $aRefConn[1];
}

function cf_fechaMysql($nConn) {
    return cf_dbmysqlclearconnection($nConn);
}

function veConn($nConn = 1, $lQuit = false, &$oConn = null) {
    
    $ok = is_array($GLOBALS['s_aConn']) && isset($GLOBALS['s_aConn'][$nConn]);
    if (!$ok && $lQuit)
        cfRaise('Conexão não existe => ' . myTrim($nConn), 'CFRDD/9999');
    $oConn = $GLOBALS['s_aConn'][$nConn];
    return $ok;
}
