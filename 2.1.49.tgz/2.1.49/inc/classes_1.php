<?php
 
class celula1 {

    var $cbuffer = "";
    var $str = "";
    var $pos = "";
    var $neg = "";
    var $tamfon = "";
    var $colspn = "";
    var $rowspn = "";
    var $cor = "";
    var $corfun = "";
    var $align = "";
    var $lgr = "";
    var $lLinAberta = false;
    var $lCelAberta = false;
    var $ntableaberta = 0;
    var $link = "";
    var $div = "";
    var $fechalink = false;
    var $fechadiv = false;
    var $cabecalho = "";
    var $rodape = "";
    var $classe = "";
    var $style = "";
    var $fontepadrao="9";

    function celula() {
        $this->limpa();
    }

    function limpa() {
        $this->str = "";
        $this->pos = "";
        $this->neg = "";
        $this->tamfon = "";
        $this->colspn = "";
        $this->rowspn = "";
        $this->cor = "";
        $this->corfun = "";
        $this->align = "";
        $this->lgr = "";
        $this->link = "";
        $this->link = "";
        $this->div = "";
        $this->classe = "";
        $this->fechalink = false;
        $this->fechadiv = false;
        $this->style = "";
    }

    function linhadiv($nspan) {
        $this->abrelinha(true);
        $this->pos = "h2";
        if ($nspan)
            $this->colspn = $nspan;
        $this->abrecelula("&nbsp;");
        $this->fechalinha();
    }

    function abretable($nborder='', $npad='', $nspace='', $cwidth='', $class = '', $cid = "", $cheight='') {
        MyDefault($nborder, 0);
        MyDefault($npad, 0);
        MyDefault($nspace, 0);
        MyDefault($cwidth, "100%");
        if ($nborder > 998)
            $this->cbuffer.="</table>
	";

        $this->cbuffer.="<table border=\"" . $nborder . "\" cellpadding=\"" . $npad . "\" cellspacing=\"" . $nspace . "\" width=\"" . $cwidth . "\"";
        if ($cheight)
            $this->cbuffer.=" height=\"" . $cheight . "\"";

        if ($cid)
            $this->cbuffer.= " id=\"" . $cid . "\"";
        if ($class)
            $this->cbuffer.=" class=\"" . $class . "\"";
        $this->cbuffer.="> ";

        $this->ntableaberta = $this->ntableaberta + 1;
    }

    function fechatable() {
        $this->fechalinha();
        $this->cbuffer.="</table>";
        //$this->cbuffer.=htmltableoff();
        $this->ntableaberta = $this->ntableaberta - 1;
    }

    function abrelinha($llimpa = false, $cclass = '', $cstyle='', $cid='',$cstr='') {
        if ($llimpa)
            $this->limpa();
        $this->fechalin();
        $this->lLinAberta = true;
        if ($cclass) {
            $this->cbuffer .= "\r$cstr <tr class=\"" . $cclass . "\"";
        } else {
            $this->cbuffer .= "\r$cstr <tr";
        }
        if ($cstyle) {
            $this->cbuffer.=" style=\"" . $cstyle . "\"";
        }
        if ($cid) {
            $this->cbuffer.=" id=\"" . $cid . "\"";
        }
        $this->cbuffer.=">";
    }

    function abrecelula($cstr = '', $cclass = '', $align = '', $neg = '', $cor = '', $corfundo = '', $tam = '', $largura='', $colspan = '', $rowspan = '', $link = '', $divid = '', $cstyle='') {
        $this->fechacel();

        if (!$this->lLinAberta)
            $this->abrelinha();

        $this->lCelAberta = true;
        $this->cbuffer.="\r  <td class=\"";


        if (!$cclass)
            $cclass = $this->classe;

        if (strtoupper($cclass) == "D") {
            $cclass = "right";
        } elseif (strtoupper($cclass) == "C") {
            $cclass = "center";
        } elseif (strtoupper($cclass) == "H") {
            $cclass = "header";
        } elseif (strtoupper($cclass) == "H1") {
            $cclass = "header1";
        } elseif (strtoupper($cclass) == "H2") {
            $cclass = "header2";
        } elseif (strtoupper($cclass) == "H3") {
            $cclass = "header3";
        } elseif (strtoupper($cclass) == "H4") {
            $cclass = "header4";
        } elseif (strtoupper($cclass) == "H5") {
            $cclass = "header5";
        } elseif (strtoupper($cclass) == "H6") {
            $cclass = "header6";
        } elseif (strtoupper($cclass) == "H7") {
            $cclass = "header7";
        } elseif (strtoupper($cclass) == "H8") {
            $cclass = "header8";
        } elseif ($this->classe == '') {
            $cclass = "left";
        }
        $this->classe = $cclass;
        $this->cbuffer.=$cclass;

        $this->cbuffer.="\" ";

        if (!$colspan)
            $colspan = $this->colspn;
        if ($colspan > 1)
            $this->cbuffer.=" colspan=\"" . $colspan . "\" ";

        if (!$rowspan)
            $rowspan = $this->rowspn;
        if ($rowspan > 1)
            $this->cbuffer.=" rowspan=\"" . $rowspan . "\" ";

        if (!$largura)
            $largura = $this->lgr;
        if ($largura)
            $this->cbuffer.=" width=\"" . $largura . "\" ";


        if (!$cstyle)
            $cstyle = "";
        if ($this->style)
            $cstyle.=$this->style;
        $calign='';
        if ($this->align)
            $calign.=$this->align;
        if ($align)
            $calign.=$align;


        if ($calign) {
            $calign = strtoupper(substr($calign, 0, 1));
            if ($calign == "E" || $calign == "L") {
                $cstyle.= "text-align: left;";
            } elseif ($calign == "R" || $calign == "D") {
                $cstyle.= "text-align: right;";
            } elseif ($calign == "J") {
                $cstyle.= "text-align: justify;";
            } else {
                $cstyle.= "text-align: center;";
            }
        }


        if (!$neg)
            $neg = $this->neg;
        if ($neg)
            $cstyle.="font-weight: bold;";

        if (!$corfundo)
            $corfundo = $this->corfun;
        if ($corfundo) {
            $cstyle.="background-color: " . $corfundo . ";";
        }

        if (!$tam)
            $tam = $this->tamfon;
        if ($tam)
            $cstyle.="font-size: " . $tam . ";";

        if (!$cor)
            $cor = $this->cor;
        if ($cor)
            $cstyle.="color: " . $cor . ";";

        if ($cstyle)
            $this->cbuffer.=" style=\"" . $cstyle . "\"";

        $this->cbuffer.=">";

        if (!$link)
            $link = $this->link;

        if ($link) {
            $this->cbuffer.="<a";
            if ($cclass)
                $this->cbuffer.=" class=\"$cclass\"";
            $this->cbuffer.=" href=\"" . $link . "\">";
            $this->fechalink = true;
        }
        if ($divid) {
            $this->cbuffer.="<div id=\"" . $divid . "\">";
            $this->fechadiv = true;
        }

        if ($cstr)
            $this->cbuffer.=$cstr;
    }

    function imp($cstr) {
        $this->imprime($cstr);
    }

    function impcel($cstr) {
        $this->imprime($cstr);
    }

    function imprime($cstr = '', $cclass = '', $neg = '', $cor = '', $corfundo = '', $tam = '', $link = '') {
        if (!$this->lCelAberta)
            $this->abrecelula();
        if (!$cstr)
            return;

        if ($link)
            $this->cbuffer.="<a href=\"" . $link . "\">";

        $cstyle = "";

        if ($neg)
            $cstyle.="font-weight: bold;";

        if ($corfundo) {
            $cstyle.="background-color: " . $corfundo . ";";
        }

        if ($tam)
            $cstyle.="font-size: " . $tam . ";";

        if ($cor)
            $cstyle.="color: " . $cor . ";";


        if ($cstyle || $cclass) {
            $this->cbuffer.="<spam ";
            if ($cclass)
                $this->cbuffer.=" class=\"" . $cclass . "\"";
            if ($cstyle)
                $this->cbuffer.=" style=\"" . $cstyle . "\"";

            $this->cbuffer.=">";
        }

        $this->cbuffer.=$cstr;

        if ($cstyle || $cclass)
            $this->cbuffer.="</spam>";

        if ($link)
            $this->cbuffer.="</a>";
    }

    function fechacel() {
        $this->fechacelula();
    }

    function fechacelula() {
        if ($this->lCelAberta) {
            if ($this->fechalink)
                $this->cbuffer.="</a>";
            if ($this->fechadiv)
                $this->cbuffer.="</div>";
            $this->cbuffer.="\r  </td>";
        }
        $this->lCelAberta = false;
    }

    function fechalin() {
        $this->fechalinha();
    }

    function fechalinha($cstr='') {
        $this->fechacel();
        if ($this->lLinAberta)
            $this->cbuffer.="\r</tr>$cstr";
        $this->lLinAberta = false;
    }

    function mostra($llimpa = '', $lretornacar=false, $lsemcabecalho=false, $lsemrodape=false) {
        $this->fechalin();
        $cret = "";
        while ($this->ntableaberta) {
            $this->fechatable();
        }
        if (!$lsemcabecalho)
            $cret.=$this->cabecalho;

        $cret.=$this->cbuffer;
        if (!$lsemrodape)
            $cret.=$this->rodape;

        if (!$lretornacar) {
            echo $cret;
        }
        $this->cbuffer = "";
        if ($llimpa)
            $this->limpa();
        return $cret;
    }

    function HtmlCabOn($ctitulo = '', $cjava = '', $cform = '', $cform_action = '', $conload = '', $consubmit = '', $chead = '', $ccss = '', $nrefresh = '', $lgraph = '', $nfont = 0, $ntamfonte = "9") {

        $this->fontepadrao=$ntamfonte;
        $cstr = mobilecabecalho();

        $cstr.='<!DOCTYPE html>
        <html><head>';
        if ($nrefresh) {
            $cstr.='<meta http-equiv="refresh" content="' . $nrefresh . '" >';
        }
        $cstr.='<meta http-equiv="Content-Language" content="pt-br">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        ' . $chead . '
        <title>' . $ctitulo . '</title>
        ';
        if (!$ccss) {

            $caux = '<style  type="text/css" >
        @font-Face {
            font-family: SourceSansPro;
            src: url(SourceSansPro-Regular.ttf);
        }
        body {
            font-family: ';
            if ($nfont == 0) {
                $caux.='SourceSansPro, Arial, Helvetica, sans-serif;';
            } elseif ($nfont == 1) {
                $caux.='"Trebuchet MS", Arial, Helvetica, sans-serif;';
            } elseif ($nfont == 2) {
                $caux.='"Times New Roman", Arial, Helvetica, sans-serif;';
            } elseif ($nfont == 3) {
                $caux.='Colibri, Arial, Helvetica, sans-serif;';
            } elseif ($nfont == 4) {
                $caux.='Verdana, Arial, Helvetica, sans-serif;';
            } elseif ($nfont == 5) {
                $caux.='Georgia, Arial, Helvetica, sans-serif;';
            }
            $caux.='    font-size: ' . $ntamfonte . 'pt; 
            background-color: #002E5C ; 
            color: black; 
            text-decoration: none
        }

        table {
            width:100%;border-collapse:collapse;
        }
        td, th{
            Color:#000000;
            font-size:1em;
            border:1px solid #ffffff;
            padding:0px 2px 0px 2px;
            background-color: #C2E0ff;
        }
        td.header, th.header{
            Color:#000000;
            font-size:1.4em;
            border:1px solid #ffffff;
            padding:0px 2px 0px 2px;
            background-color: #5c5c9d;
            text-align: center;
        }
        td.header1, th.header1{
            font-size:1.1em;
            background-color: #bebed8;
            text-align: center;
            color: #000066;
            font-weight: bold;
        }
        td.header2, th.header2{
            background-color: #bebed8;
            text-align: center;
            color: #000066;
        }
        td.header3, th.header3{
            background-color: #cccc00;
            text-align: center;
        }
        td.header4, th.header4{
            background-color: #E6B800;
            text-align: center;
        }
        td.header5, th.header5{
            background-color: #000099;
            color: #ffffff;
            text-align: center;
        }
        td.header6, th.header6{
            background-color: #006200;
            color: #ffffff;
            text-align: center;
        }
        td.header7, th.header7{
            background-color: #cc2900;
            color: #FFFF00;
            text-align: center;
        }
        a.header7 {
            color: #ffff00 ;
        }
        td.header8, th.header8{
            background-color: #b2248f;
            color: #FFFFFF;
            text-align: center;
        }
        td.left {
            text-align: left;
        }
        td.center {
            text-align: center;
        }
        td.right {
            text-align: right;
        }
        td.justify {
            text-align: justify;
        }

        th{
            font-size:1.2em;
            text-align:center;
            padding-top:1px;
            padding-bottom:1px;
            color:#000000;
            background-color:#99c2ff;
        } 
        tr.alt td{
            color:#000000;
            background-color:#DaE9Ff;
        }

	</style>';
            $caux = str_replace("\n", " ", $caux);
            $caux = str_replace("    ", " ", $caux);
            $caux = str_replace("   ", " ", $caux);
            $caux = str_replace("  ", " ", $caux);

            $cstr.=$caux;
        } else {
            $cstr.='<style  type="text/css" >' . $ccss . '</style>
                ';
        }
        $cstr.='<script language="JavaScript" src="./consoft.js" type="text/javascript" >
        </script>';
        $cstr.='<link rel="stylesheet" type="text/css" media="all" href="./inc/jsDatePick_ltr.css" />
<script type="text/javascript" src="./inc/jsDatePick.full.1.3.js"></script>';

        if ($lgraph) {
            $cstr.='<script type="text/javascript" src="./RGraph.common.core.js" ></script>
            <script type="text/javascript" src="./RGraph.bar.js" ></script>
            <!--[if lt IE 9]><script src="./excanvas.js"></script><![endif]-->
            <script src="./RGraph.common.dynamic.js" ></script>
            <script src="./RGraph.common.tooltips.js" ></script>
            <script src="./RGraph.pie.js" ></script>
            <script src="./RGraph.common.key.js" ></script>
            <script src="./RGraph.line.js" ></script>';
        }
        if ($cjava) {
            $cstr.='  <script language="JavaScript">
                <!--
            ';
            $cstr.=$cjava . '
                -->
            </script>';
        }
        $cstr.='</head>
        <body style="font-size: '.$ntamfonte.'pt; "';
        if ($conload)
            $cstr.=' onload="' . $conload . '" ';
        $cstr.='>';
        if ($cform) {
            $cstr.='<form method="post" name="' . $cform . '" ';
            if ($cform_action)
                $cstr.='  action="' . $cform_action . '" ';
            if ($consubmit)
                $cstr.=' onSubmit="' . $consubmit . '"; ';
            $cstr.='>';
        }
        $cstr.='<div align="center"> <center>';
        $this->cabecalho = $cstr;
    }

    function HtmlCabOff($cjava='', $chtml='') {
        $caux = "</center></div></form></body>";
        if ($chtml)
            $caux.=$chtml;
        if ($cjava)
            $caux.="<script language=\"JavaScript\" >" . $cjava . "</script>";
        $caux.="</html>";
        $this->rodape = $caux;
    }

    function imagem($cimagem, $nborder = 0, $nwidth = '', $nheight = '', $calt = '', $clink = '') {
        $caux = "<img src=\"" . $cimagem . "\" border=\"" . $nborder . "\"";
        if ($nwidth)
            $caux.=" width=\"" . $nwidth . "\"";
        if ($nheight)
            $caux.=" height=\"" . $nheight . "\"";
        if ($calt)
            $caux.=" alt=\"" . $calt . "\"";
        $caux.=">";
        if ($clink)
            $caux = "<a href=\"" . $clink . "\">" . $caux . "</a>";
        $this->imprime($caux);
    }

}

?>