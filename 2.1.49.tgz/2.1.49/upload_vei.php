<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

session_start();

require_once 'inc/config.php';
if (0 < $_FILES['file']['error']) {
    echo '99-Error: ' . $_FILES['file']['error'] . '<br>';
    return;
}

$cstr = base64_encode(file_get_contents($_FILES['file']['tmp_name'], FILE_BINARY));
/*

  $aaux1 = array();
  $aaux1[] = "\\";
  $aaux1[] = chr(0);
  $aaux1[] = chr(13);
  $aaux1[] = chr(10);
  $aaux1[] = '"';
  $aaux1[] = "'";
  $aaux1[] = "`";
  $aaux1[] = chr(9);
  $aaux1[] = chr(141);
  $aaux1[] = chr(8);
  $aaux1[] = chr(26);
  $aaux1[] = "%";
  $aaux1[] = "_";



  $aaux = array();

  $i = 0;
  while (true) {
  $caux = substr($cstr, $i, 50000);
  if (strlen($caux) == 0) {
  break;
  }
  for ($k = 0; $k < count($aaux1); $k++) {
  $caux = str_replace($aaux1[$k], "/chr" . ($k + 1) . "/", $caux);
  }

  $aaux[] = $caux;
  $i+=50000;
  }

 */

$caux = $_FILES['file']['name'];
$caux = explode("_", $caux);
$ncli = $caux[1];
$cplaca = $caux[0];

if (!$db) {
    $db = conecta();
}
if (!$db) {
    echo "99-Erro acessando SQL ";
    return;
}


if ($lCfRdd) {
    $omedv = new Mediator4("VEIIMG.CAR", W_CRIAR, '', '', $db);
} else {
    $omedv = new Mediator3("VEIIMG.CAR", W_CRIAR, '', '', $db);
}
$omedv->aadd("placa", $cplaca);
$omedv->aadd("cliente", $ncli);
$omedv->aadd("obs", "");
$omedv->aadd("imagem", "1");
if (!$omedv->grava()) {
    echo "98-Erro acessando SQL " . $omedv->cerro;
    return;
}


mysqli_query($db, "update VEIIMG_CAR_MEMO SET MEMO='$cstr' WHERE COL_NAME='IMAGEM' AND RECNO=" . $omedv->nrecno);
mysqli_query($db, "update VEIIMG_CAR i,VEIIMG_CAR_MEMO m SET i.imagem=length(m.memo) WHERE m.COL_NAME='IMAGEM' AND m.RECNO=" . $omedv->nrecno . " and i.recno=" . $omedv->nrecno);

mysqli_close($db);

echo "00-Cliente: $ncli \nOrdem: $nord \nArray: " . count($aaux);
return;
