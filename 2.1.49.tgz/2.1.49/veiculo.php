<?php

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$csid = pegavar("sid");
$cmodo = pegavar("modo");
$cplaca = pegavar("placa");
$nnota = pegavar("nota");
$lorc = pegavar("orc");
$nmodelo = pegavar("modelo");
$nimpressora = pegavar("impressora");
$nrecno = pegavar("recno");

$dbi = new mysqli($server, $user, $password, $database, $port);

if ($dbi->connect_errno) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor - " . $dbi->connect_error);
    echo json_encode($aret);
    return;
}

/*
  if ($result = $mysqli -> query($sql)) {
  while ($obj = $result -> fetch_object()) {
  printf("%s (%s)\n", $obj->Lastname, $obj->Age);
  }
  $result -> free_result();
  }

  $mysqli -> close();


  $db = conecta();
  if (!$db) {
  $aret["erro"] = "99";
  $aret["cerro"] = _tr("Erro acessando servidor");
  echo json_encode($aret);
  return;
  }
 */
require_once 'inc/sid.php';
if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("Erro acessando servidor") . ".\n" . $caux;
    echo json_encode($aret);
    return;
}

if ($cmodo == "VEPLACA") {
    $avei = array("placa" => "");
    $csql = "select ano,classe,cor,kilomet,modelo,placa,tipo,cliente,marca from VEICULO_CAR where is_deleted='N' and placa='$cplaca'";
    $otpla = $dbi->query($csql);
    if ($otpla->num_rows) {
        $olpla = $otpla->fetch_object();
        $avei = array("ano" => $olpla->ano, "classe" => $olpla->classe, "cor" => $olpla->cor, "kilomet" => $olpla->kilomet, "modelo" => $olpla->modelo, "placa" => $olpla->placa, "tipo" => $olpla->tipo
            , "cliente" => $olpla->cliente, "marca" => $olpla->marca);
        $otpla->free_result();
    }
    $aret["vei"] = $avei;
    echo json_encode($aret);
    return;
}
if ($cmodo == "VEmarca") {
    $adados = array();
    $csql = "select marca as nome from VEICULO_CAR where is_deleted='N' group by marca order by marca";
    $otpla = $dbi->query($csql);
    while ($olpla = $otpla->fetch_object()) {
        $adados[] = $olpla->nome;
    }
    $otpla->free_result();
    $aret["dados"] = $adados;
    echo json_encode($aret);
    return;
}
if ($cmodo == "VEmodelo") {
    $adados = array();
    $csql = "select modelo as nome from VEICULO_CAR where is_deleted='N' and marca= '" . pegavar("marca") . "' group by modelo order by modelo";
    $otpla = $dbi->query($csql);
    while ($olpla = $otpla->fetch_object()) {
        $adados[] = $olpla->nome;
    }
    $otpla->free_result();
    $aret["dados"] = $adados;
    echo json_encode($aret);
    return;
}
if ($cmodo == "VEcor") {
    $adados = array();
    $csql = "select cor as nome from VEICULO_CAR where is_deleted='N' group by cor order by cor";
    $otpla = $dbi->query($csql);
    while ($olpla = $otpla->fetch_object()) {
        $adados[] = $olpla->nome;
    }
    $otpla->free_result();
    $aret["dados"] = $adados;
    echo json_encode($aret);
    return;
}

if ($cmodo == "VEIMG") {
    $aret["img"]="";
    if ($cplaca) {
        $aimg = array();
        $onot = $dbi->query("select i.recno,i.cliente,m.memo as imagem,i.obs  from VEIIMG_CAR i,VEIIMG_CAR_MEMO m WHERE i.imagem>0 and i.IS_DELETED='N' AND i.PLACA='$cplaca' and m.recno=i.recno and m.col_name='IMAGEM' ");
        while ($olnot = $onot->fetch_object()) {
            $oimg = imagecreatefromstring(base64_decode($olnot->imagem));
            $onew = imagescale($oimg, 50);
            ob_start();
            imagepng($onew);
            $cimage = ob_get_clean();
            $aimg[] = array($olnot->cliente, $olnot->obs, base64_encode($cimage), $olnot->recno);
            imagedestroy($onew);
            imagedestroy($oimg);
        }
        $aret["img"] = $aimg;
    }
    echo json_encode($aret);
    return;
}
if ($cmodo == "VEIMGRECNO" && $nrecno) {
    $aimg = array();
    $onot = $dbi->query("select i.cliente,m.memo as imagem,i.obs  from VEIIMG_CAR i,VEIIMG_CAR_MEMO m WHERE i.imagem>0 and i.IS_DELETED='N' AND i.recno='$nrecno' and m.recno=i.recno and m.col_name='IMAGEM' ");
    $olnot = $onot->fetch_object();
    $aret["img"] = $olnot->imagem;
    $aret["obs"] = $olnot->obs;
    echo json_encode($aret);
    return;
}
if ($cmodo == "VEIMGDEL" && $nrecno) {
    $aimg = array();
    $dbi->query("update VEIIMG_CAR set is_deleted='Y' where recno='$nrecno' ");
    echo json_encode($aret);
    return;
}

$aret["erro"] = "98";
$aret["cerro"] = _tr("Erros de parâmetros") . $cmodo;
echo json_encode($aret);
return;

