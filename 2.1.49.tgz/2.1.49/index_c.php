<?php

session_start();

$cmodo = '';
if (isset($_GET["modo"])) {
    $cmodo = $_GET["modo"];
} else if (isset($_POST["modo"])) {
    $cmodo = $_POST["modo"];
}
if ($cmodo == "signal") {
    //VeSession("idioma",$_REQUEST["idioma"]);//$_SESSION["idioma"] = $_REQUEST["idioma"];
    return true;
}
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";
require_once 'inc/config.php';

$cuser = strtoupper(trim(PegaVar("user")));
$csid = pegavar("sid");
$loja = PegaVar("loja");
$vendedor = pegavar("vendedor");
$moeda = pegavar("moeda");
$cambio = pegavar("cambio");
$modo = pegavar("modo");

if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}
/*
  $nlojapre = "";

  $otimp = mysqli_query($db, "select loja_pre from CONFIMP_IMP where is_deleted='N' and terminal=998");
  if (mysqli_num_rows($otimp) > 0) {
  $nlojapre = mysqli_fetch_row($otimp)[0];
  if ($nlojapre == "" || $nlojapre == "NULL" || $nlojapre == "NUL" || $nlojapre == "NIL" || substr($nlojapre, 0, 3) == "LPT") {
  $nlojapre = "";
  }
  }
 */
$nlojapre = pegavar("lj_preco");
if ($modo == "VE_VOUCHER") {
    $cvoucher = strtoupper(pegavar("voucher"));
    if (!$cvoucher) {
        $aret["erro"] = 01;
        $aret["cerro"] = "Voucher vazio";
        echo json_encode($aret);
        return;
    }
    $cstr = "select CLIENTE ,CODIGO, DATA,DATAD,DESCONTO,NOTA,NOTAD,NOTAS,SERIE,USUARIO,USUARIOD,VALORD from VOUCHER_DET where  is_deleted='N' and serie=" . assql($cvoucher);
    $otab = mysqli_query($db, $cstr);

    if (mysqli_num_rows($otab) == 0) {
        $aret["erro"] = 02;
        $aret["cerro"] = "Voucher não localizado";
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);
    if ($olin["DATAD"]) {
        $aret["erro"] = 03;
        $aret["cerro"] = "Voucher já utilizado";
        echo json_encode($aret);
        return;
    }
    $cstr = "select * from VOUCHER_PRM WHERE IS_DELETED='N' AND CODIGO=" . $olin["CODIGO"];
    $ovou = mysqli_fetch_array(mysqli_query($db, $cstr));

    if ($ovou["DIAS"]) {
        $dini = Unix2Date($olin["DATA"])[1];
        $datu = Unix2Date(Date2Unix())[1];

        $data1 = "30/01/2026";
        $data2 = "15/01/2026";

        $d1 = DateTime::createFromFormat('d/m/Y', $datu);
        $d2 = DateTime::createFromFormat('d/m/Y', $dini);

        $diferenca = $d1->diff($d2);

        if ($ovou["DIAS"] < $diferenca->days) {
            $aret["erro"] = 06;
            $aret["cerro"] = "Voucher já Expirado";
            echo json_encode($aret);
            return;
        }
    } else {
        if ($ovou["INICIOV"] > Date2Unix()) {
            $aret["erro"] = 04;
            $aret["cerro"] = "Voucher ainda não vigente";
            echo json_encode($aret);
            return;
        }
        if ($ovou["FINALV"] < Date2Unix()) {
            $aret["erro"] = 05;
            $aret["cerro"] = "Voucher já expirado";
            echo json_encode($aret);
            return;
        }
    }
    $caux = MostraVoucher($cvoucher);

    $aret["voucher"] = $caux;
    echo json_encode($aret);

    return;
}
if ($modo == "VE_CONFIG") {
    $olin = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM CONFIG WHERE RECNO=1"));
    $aConfig = array();
    foreach ($olin as $key => $value) {
        $aConfig[$key] = iconv('cp850', 'utf8', $value);
    }
    $olin = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM CONFIG2 WHERE RECNO=1"));
    foreach ($olin as $key => $value) {
        $aConfig[$key] = iconv('cp850', 'utf8', $value);
    }
    //$aConfig=array();
    $aret["config"] = $aConfig;
    //config tablet
    if (!$lweb) {
        $olin = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM CONFIG_TBL WHERE RECNO=1"));
    } else {
        $olin = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM CONFIGVG_WEB WHERE RECNO=1"));
    }
    $aConfig = array();
    foreach ($olin as $key => $value) {
        $aConfig[$key] = iconv('cp850', 'utf8', $value);
    }
    $aret["configtbl"] = $aConfig;

    if (!$lweb) {
        $olin = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM TABLET_CFG WHERE IS_DELETED='N' AND vendedor=" . VeSession("vendedor")));
        $aConfig = array();
        foreach ($olin as $key => $value) {
            $aConfig[$key] = iconv('cp850', 'utf8', $value);
        }
    } else {
        $olin = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM CONFIGVD_WEB WHERE IS_DELETED='N' AND vendedor=" . VeSession("vendedor")));
        $aConfig = array();
        foreach ($olin as $key => $value) {
            if (!is_numeric($key)) {
                $aConfig[$key] = iconv('cp850', 'utf8', $value);
            }
        }
    }
    $aret["tabletcfg"] = $aConfig;
    $aret["serial_cec"] = gera_ser();

    echo json_encode($aret);
    return;
}
if ($modo == "CONFIG") {

    $olin = mysqli_fetch_array(mysqli_query($db, "SELECT * FROM CONFIG WHERE RECNO=1"));
    $aret["carga"] = $olin["CARGAS"];
    $acarga = array();
    if ($olin["CARGAS"] == "S") {
        $otcar = mysqli_query($db, "select codcar as codigo,date_format(datcar,'%d/%m') as data from 
            CARGAS_CAR where IS_DELETED='N' AND impcar!='S' order by datcar,recno");
        while ($olcar = mysqli_fetch_array($otcar)) {
            $acarga[] = array($olcar["codigo"], $olcar["data"]);
        }
    }
    $aret["acarga"] = $acarga;

    echo json_encode($aret);
    return;
}
if ($modo == 81 || PegaVar("modo") == "CLI_LOAD" || PegaVar("modoc") == "CLI_LOAD") {

    mysqli_query($db, "create table if not exists tablet" . $lweb . "_cfg (
 cl_1 int(1) not null default 0
,cl_2 int(1) not null default 0
,cl_3 int(1) not null default 0
,cl_4 int(1) not null default 0
,cl_5 int(1) not null default 0
,cl_6 int(1) not null default 0
,cl_7 int(1) not null default 0
,cl_8 int(1) not null default 0
,cl_9 int(1) not null default 0
,cl_10 int(1) not null default 0
,cl_11 int(1) not null default 0
,cl_12 int(1) not null default 0
,cl_13 int(1) not null default 0
,cl_14 int(1) not null default 0
,cl_15 int(1) not null default 0
,cl_16 int(1) not null default 0
,cl_17 int(1) not null default 0
,cl_18 int(1) not null default 0
,cl_19 int(1) not null default 0
,cl_20 int(1) not null default 0
)");
    /*
      preço atacado	= preatac
      preço c			= PREMIN
      preço b			= preco3
      preço a			= preven
     */


    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'venda'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add venda char(1) not null default 'A'");
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add minimo char(1) not null default 'C'");
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add mostraa int(1) not null default 1");
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add mostrab int(1) not null default 1");
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add mostrac int(1) not null default 1");
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add mostrat int(1) not null default 1");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'imgext'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add imgext varchar(100) not null default ''");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'nmnt_imp'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add nmnt_imp char(1) not null default 'N'");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'mostra_cot'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add mostra_cot int(1) not null default '0'");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'loc_ini'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add loc_ini int(1) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add loc_fin int(1) not null default '0'");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'loc_obr'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add loc_obr int(1) not null default '0'");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'limitefoto'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add limitefoto decimal(15,2) not null default '0'");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'veiculo'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add veiculo int(1) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add impauto int(3) not null default '0'");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'loc_temp'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add loc_temp int(10) not null default '0'");
    }
    $otab = mysqli_query($db, "select * from tablet" . $lweb . "_cfg");
    if (mysqli_num_rows($otab) == 0) {
        mysqli_query($db, "insert tablet" . $lweb . "_cfg set 
               cl_1=1,cl_2=1,cl_3=1,cl_4=1,cl_5=1,cl_6=1,cl_7=1,cl_8=1,cl_9=1,cl_10=1,cl_11=1,cl_12=1,cl_13=1,cl_14=1,cl_15=1,cl_16=1,cl_17=1,cl_18=1,cl_19=1,cl_20=1
               ");
        $otab = mysqli_query($db, "select * from tablet" . $lweb . "_cfg");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cfg 'refer'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cfg add refer int(10) not null default '0'");
    }
    $olin = mysqli_fetch_array($otab);
    $olin["FAT_SFOTO"] = mysqli_fetch_row(mysqli_query($db, "select fat_sfoto from CONFIG WHERE RECNO=1"))[0];
    $aret["cli"] = $olin;
    echo json_encode($aret);
    return;
}
if ($modo == "CLI_MARCA") {

    $otab = mysqli_query($db, "SELECT CODMARC,NOMMARC FROM MARCAS_MAR WHERE IS_DELETED='N' ORDER BY NOMMARC");
    $amar = array();
    while ($olin = mysqli_fetch_row($otab)) {
        $amar[] = array($olin[0], $olin[1]);
    }
    $aret['marca'] = $amar;

    echo json_encode($aret);
    return;
}
if ($modo == "CLI_GRUPO") {

    $otab = mysqli_query($db, "SELECT codigo,NOMe FROM GRADE_WEB WHERE IS_DELETED='N' ORDER BY NOME");
    $amar = array();
    while ($olin = mysqli_fetch_row($otab)) {
        $amar[] = array($olin[0], $olin[1]);
    }
    $aret['grupo'] = $amar;

    echo json_encode($aret);
    return;
}
if ($modo == 82 || $modo == "CLI_SAVE") {
    $aaux = explode(",", pegavar("cliente"));
    $caux = "";
    for ($i = 0; $i < count($aaux); $i++) {
        $caux .= ",cl_" . ($i + 1) . "='" . $aaux[$i] . "'";
    }
    $caux .= ",venda='" . pegavar('venda') . "'";
    $caux .= ",minimo='" . pegavar('minimo') . "'";
    $caux .= ",mostraa='" . pegavar('mostraa') . "'";
    $caux .= ",mostrab='" . pegavar('mostrab') . "'";
    $caux .= ",mostrac='" . pegavar('mostrac') . "'";
    $caux .= ",mostrat='" . pegavar('mostrat') . "'";
    $caux .= ",imgext='" . pegavar('imgext') . "'";
    $caux .= ",nmnt_imp='" . pegavar('nmnt_imp') . "'";
    $caux .= ",mostra_cot='" . pegavar('lmostra_cot') . "'";
    $caux .= ",loc_ini='" . pegavar('lloc_ini') . "'";
    $caux .= ",loc_obr='" . pegavar('lloc_obr') . "'";
    $caux .= ",loc_fin='" . pegavar('lloc_fin') . "'";
    $caux .= ",loc_temp='" . pegavar('nloc_temp') . "'";
    $caux .= ",limitefoto='" . pegavar('limitefoto') . "'";
    $caux .= ",refer='" . pegavar('refer') . "'";
    /*
      $i=0;
      foreach ($aaux as $value) {
      $i++;
      $caux.=",cl_".$i."=".$value;
      }
     */
    $caux = "update tablet" . $lweb . "_cfg set " . substr($caux, 1);
//    echo $caux."<br>";



    mysqli_query($db, $caux);
    //$aret["cerro"]= mysqli_error($db);
    echo $caux + "/\n" . mysqli_error($db);
    echo json_encode($aret);
    return;
}

require_once 'inc/sid.php';

if ($modo == 49) {
    mysqli_query($db, "insert tablet" . $lweb . "_ver set versao=" . PegaVar("versao") . ",date=date2unix(now()),operador='" . VeSession("usuario") . "'");
    echo json_encode($aret);
    return;
}
$nmodo = pegavar("nmodo") + 0;
if ($modo == 51 || $modo == "FECHA_SID") {
    FechaSidVendas($nmodo);
    echo json_encode($aret);
    return;
}
if ($modo == 50 || $modo == "LOG_IN") {
    mysqli_query($db, "create function if not exists arre_pre(npreco decimal(15,2))
returns decimal(15,2)
begin
	declare nresto int(2);
	declare nsoma int(2);
	set nresto=round(npreco*100,0)%10;
	if nresto > 7 then
		set nsoma= 10-nresto;
	elseif nresto >=5 and nresto <=7 then
		set nsoma= (nresto - 5)*-1;
	elseif nresto < 5 and nresto >=3 then
		set nsoma= 5 - nresto ;
	elseif nresto <3 then
		set nsoma= nresto*-1 ;
	else
		set nsoma = 0;
	end if;
 	return convert(npreco+(nsoma/100),decimal(15,2));
end;

");

    //PIX
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_pix (
         ordem int(10) not null primary key auto_increment
        ,operador int(10) not null default 0
        ,data_ini int(10) not null default 0
        ,conta int(10) not null default 0
        ,hist int(10) not null default 0
        ,banco int(10) not null default 0
        ,moeda int(1) not null default 0
        ,documento varchar(10) not null default ''
        ,key operador (operador)
        )");
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_pix_not (
         ordem int(10) not null primary key auto_increment
        ,operador int(10) not null default 0
        ,nota int(10) not null default 0
        ,valor decimal(15,2) not null default 0
        ,cliente int(10) not null default 0
        ,ccliente varchar(60) not null default ''
        ,key operador (operador)
        )");
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_not (
         ordem int(10) not null primary key auto_increment
        ,nota int(10) not null default 0
        ,corpo mediumblob
        ,cridata int(10) not null default 0
        ,impdata int(10) not null default 0
        ,impressora int(3) not null default 1
        ,key cridata (cridata)
        ,key impdata (impdata)
        )");
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_ver (
        date int(10) not null default 0
        ,operador int(10) not null default 0
        ,versao   int(10) not null default 0
        ,key versao (versao)
        )");
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_imp (
        ordem int(10) not null default 0
        ,linha varchar(100) not null default ''
        ,tipo enum('C','R') not null default 'C'
        )");
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_cab (
 vendedor decimal(10,0) not null default 0
,cliente  decimal(10,0) not null default 0
,data_ini decimal(10,0) not null default 0
,nacional decimal(10,0) not null default 0
,pagament decimal(10,0) not null default 0
,voucher  varchar(20) not null default ''
,loja     decimal(10,0) not null default 0
,guia     decimal(10,0) not null default 0
,moeda    decimal(10,0) not null default 0
,itens    decimal(10,0) not null default 0
,total    decimal(20,10) not null default 0
,seguro   decimal(10,0) not null default 0
,PRIMARY KEY (vendedor)
,key data_ini (data_ini)
)
");
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_pro(
 vendedor decimal(10,0) not null default 0
,codigo   decimal(10,0) not null default 0
,quant    decimal(10,0) not null default 0
,valor    decimal(20,10) not null default 0
,grade    decimal(10,0) not null default 0
,autoriza decimal(10,0) not null default 0
,seguro   decimal(10,0) not null default 0
,key vendedor (vendedor,codigo)
)");
    //GARANTIA PITZI

    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_pro 'seg_pitd'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_pro add seg_pitd decimal(10,0) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_pro add seg_pito decimal(10,0) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_orc_pro add seg_pitd decimal(10,0) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_orc_pro add seg_pito decimal(10,0) not null default '0'");
    }
    mysqli_query($db, "create table if not exists tablet" . $lweb . "_gra(
 vendedor decimal(10,0) not null default 0
,codigo   decimal(10,0) not null default 0
,quant    decimal(10,0) not null default 0
,seq1     decimal(10,0) not null default 0
,seq2     decimal(10,0) not null default 0
,key vendedor (vendedor,codigo,seq1,seq2)
)");
    /*     * ************************************ */
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'desco'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add desco decimal(20,10) not null default 0");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'notaalt'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add notaalt decimal(10,0) not null default 0");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'orcamento'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add orcamento decimal(10,0) not null default 0");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'finalizado'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add finalizado decimal(10,0) not null default 0");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'operador'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add operador decimal(10,0) not null default 0");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'ordem'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add ordem int(10) not null auto_increment primary key");
    }

    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'prazo'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add prazo decimal(10,0) not null default 0");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'prazo'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add prazo decimal(10,0) not null default 0");
    }

    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'loc_ini'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add loc_ini varchar(200) not null default ''");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add loc_fin varchar(200) not null default ''");
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'placa'")) == 0) {
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add prisma int(2) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add placa varchar(10) not null default ''");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add marca varchar(15) not null default ''");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add modelo varchar(15) not null default ''");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add cor varchar(15) not null default ''");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add ano int(4) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add classe int(2) not null default '0'");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add tipo varchar(30) not null default ''");
        mysqli_query($db, "alter table tablet" . $lweb . "_cab add kilomet int(7) not null default '0'");
    }

    /*     * ************************************ */
    /*     * ************************************ */
    $csql = mysqli_fetch_row(mysqli_query($db, "show create table tablet" . $lweb . "_pro"))[1];
    $csql = str_replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS", $csql);
    $csql = str_replace("tablet" . $lweb . "_pro", "tablet" . $lweb . "_orc_pro", $csql);
    mysqli_query($db, $csql);

    $aaux = array("", "_orc");
    foreach ($aaux as $value) {
        if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "" . $value . "_pro 'nomepromo'")) == 0) {
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add desco decimal(20,10) not null default 0");
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add tabela decimal(20,10) not null default 0");
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add codpromo decimal(10,0) not null default 0");
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add nomepromo varchar(30) not null default ''");
        }
        if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "" . $value . "_pro 'kit'")) == 0) {
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add kit decimal(10,0) not null default 0");
        }
        if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "" . $value . "_pro 'loja'")) == 0) {
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add loja decimal(10,0) not null default 0");
        }
        if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "" . $value . "_pro 'iva'")) == 0) {
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add iva decimal(10,2) not null default 1");
        }
        if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "" . $value . "_pro 'autz_preco'")) == 0) {
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add AUTZ_PRECO decimal(4,0) DEFAULT '0'");
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add AUTZ_QUANT decimal(4,0) DEFAULT '0'");
        }
        // segurro
        if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "" . $value . "_pro 'seg_pro'")) == 0) {
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add seg_pro decimal(10,0) DEFAULT '0'");
            mysqli_query($db, "alter table tablet" . $lweb . "" . $value . "_pro add seg_cod decimal(10,0) DEFAULT '0'");
        }
    }
    /*     * ************************************ */
    /*     * ************************************ */


    $csql = mysqli_fetch_row(mysqli_query($db, "show create table tablet" . $lweb . "_gra"))[1];
    $csql = str_replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS", $csql);
    $csql = str_replace("tablet" . $lweb . "_gra", "tablet" . $lweb . "_orc_gra", $csql);
    mysqli_query($db, $csql);

    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'serie'")) == 0) {
        $aexec = array();
        $aexec[] = "alter table tablet" . $lweb . "_cab add serie int(10) not null default 0";
        $aexec[] = "alter table tablet" . $lweb . "_cab drop primary key";
        $aexec[] = "alter table tablet" . $lweb . "_cab add  primary key(codigo,serie)";
        $aexec[] = "alter table tablet" . $lweb . "_pro add serie int(10) not null default 0";
        $aexec[] = "alter table tablet" . $lweb . "_orc_pro add serie int(10) not null default 0";
        $aexec[] = "alter table tablet" . $lweb . "_gra add serie int(10) not null default 0";
        $aexec[] = "alter table tablet" . $lweb . "_orc_gra add serie int(10) not null default 0";
        foreach ($aexec as $value) {
            mysqli_query($db, $value);
        }
    }
    if (mysqli_num_rows(mysqli_query($db, "desc tablet" . $lweb . "_cab 'lojacor'")) == 0) {
        $aexec = array();
        $aexec[] = "alter table tablet" . $lweb . "_cab add lojacor int(10) not null default 0";
        foreach ($aexec as $value) {
            mysqli_query($db, $value);
        }
    }





    FechaSidVendas($nmodo);

    /*
      $otable = mysqli_query($db, "select v.codven,v.nomven,t.senha,t.usuario,t.inativo as limite
      from VENDEDOR_VEN v
      inner join TABLET_CFG t on t.is_deleted='N' and t.vendedor=v.codven
      where v.is_deleted='N' and (v.codven='$cuser' or v.nomven='$cuser' or t.email='$cuser')
      ");
     */
    /*
      $otable = mysqli_query($db, "select if(isnull(v.codven),0,v.codven) as codven,if(isnull(v.codven),'',v.nomven) as nomven,o.senha,o.codigo as usuario,60 as limite
      ,lojas_ven as lojas
      from OPERADOR_OPE o
      left JOIN VENDEDOR_VEN v on v.is_deleted='N' and v.codven=o.vende_ope
      where o.is_deleted='N' and (o.codigo='$cuser' or upper(o.nome)='$cuser' or upper(o.mail)='$cuser')
      ");
     */
    if ($nmodo == 0) {
        if (!$lweb) {
            $cstr = "select if(isnull(v.codven),0,v.codven) as codven,if(isnull(v.codven),'',v.nomven) as nomven,o.senha,o.codigo as usuario,60 as limite
            ,o.lojas_ven as lojas,c.lojascor
            from OPERADOR_OPE o
            inner join TABLET_CFG c on c.is_deleted='N' and c.usuario=o.codigo 
            left JOIN VENDEDOR_VEN v on v.is_deleted='N' and v.codven=c.vendedor
            where o.is_deleted='N' and (o.codigo='$cuser' or upper(o.nome)='$cuser' or upper(o.mail)='$cuser')";
        } else {
            $cstr = "select if(isnull(v.codven),0,v.codven) as codven,if(isnull(v.codven),'',v.nomven) as nomven,o.senha,o.codigo as usuario,60 as limite
            ,o.lojas_ven as lojas,c.lojascor,c.inatividad
            from OPERADOR_OPE o
            inner join CONFIGVD_WEB c on c.is_deleted='N' and c.operador=o.codigo 
            left JOIN VENDEDOR_VEN v on v.is_deleted='N' and v.codven=c.vendedor
            where o.is_deleted='N' and (o.codigo='$cuser' or upper(o.nome)='$cuser' or upper(o.mail)='$cuser')";
        }
//            where o.bloq_vdas!='S' and o.is_deleted='N' and (o.codigo='$cuser' or upper(o.nome)='$cuser' or upper(o.mail)='$cuser')";
        $otable = mysqli_query($db, $cstr);
        if (mysqli_num_rows($otable) == 0) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Operador não localizado") . "..";
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $cuser);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }
        $olinha = mysqli_fetch_array($otable);

        if (trim(cifra($olinha["senha"])) !== strtoupper(pegavar("senha"))) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Senha inválida"); // - ".pegavar("senha")." - ".$olinha["senha"];
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"]);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }
        if (!$olinha["codven"]) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Vendedor não cadastrado para o usuário"); // - ".pegavar("senha")." - ".$olinha["senha"];
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"]);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }
        $alojas = explode("-", $olinha["lojas"]);
        if (!$alojas || !$alojas[0]) {
            $aret["erro"] = "89";
            $aret["cerro"] = _tr("Sem loja cadastrada para o usuário"); // - ".pegavar("senha")." - ".$olinha["senha"];
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"], $olinha["codven"]);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }
        $aret["codigo"] = $olinha[0];
        $aret["nome"] = iconv('cp850', 'utf8', $olinha[1]);
        $carq = "vendas";
        $cstr = "create table if not exists " . $carq . "tablet" . $lweb . "_sid (usuario int(10),sid varchar(100),data_ini int(10),data_atu int(10),data_sai int(10), index usuario (usuario),index sid (sid),index data_sai (data_sai)  )";
        mysqli_query($db, $cstr);

        mysqli_query($db, "update " . $carq . "tablet" . $lweb . "_sid set data_sai=date2unix(now()) where usuario=" . $olinha[0]);
        $sid = str_pad($olinha[0], 3, '0', STR_PAD_LEFT) . GeraSenha(57);
        mysqli_query($db, "insert " . $carq . "tablet" . $lweb . "_sid set usuario=" . $olinha[0] . ",sid='$sid',data_ini=date2unix(now()),data_atu=date2unix(now())");

        $aret["sid"] = $sid;
        $aret["usuario"] = $olinha["usuario"];
        $aret["codigo"] = $olinha["codven"];
        $aret["nome"] = iconv('cp850', 'utf8', $olinha["nomven"]);

        $_POST["sid"] = $sid;
        VeSession("sid", $sid); //$_SESSION["sid"] = $sid;

        VeSession("vendedor", $olinha["codven"]); //$_SESSION["vendedor"] = $olinha["codven"];
        VeSession("usuario", $olinha["usuario"]); //$_SESSION["usuario"] = $olinha["usuario"];
        if (!$lweb) {
            VeSession("tempolimite", $olinha["limite"]); //$_SESSION["tempolimite"] = $olinha["limite"];
        } else {
            VeSession("tempolimite", $olinha["inatividad"]); //$_SESSION["tempolimite"] = $olinha["limite"];
        }
        VeSession("modo", 0); //$_SESSION["modo"]=0;
        if (PegaVar("senha1") && pegavar("senha2") && PegaVar("senha1")== PegaVar("senha2")){
            $cstr="update OPERADOR_OPE SET SENHA=cifra('". padr(strtoupper(PegaVar("senha1")), 10)."') where codigo=".$olinha["usuario"];
            mysqli_query($db,$cstr);
        }
    } elseif ($nmodo == 1) {
        $cstr = "select o.senha,o.codigo as usuario,o.nome,60 as limite,c.ips
            ,o.lojas_ven as lojas,c.inativo,c.ini_" . (date("w") + 1) . " as ini,c.fim_" . (date("w") + 1) . " as fim
            from OPERADOR_OPE o
            inner join tablet" . $lweb . "_cax c on c.codigo=o.codigo 
            where o.is_deleted='N' and (o.codigo='$cuser' or upper(o.nome)='$cuser' or upper(o.mail)='$cuser') ";
//            where o.bloq_vdas!='S' and o.is_deleted='N' and (o.codigo='$cuser' or upper(o.nome)='$cuser' or upper(o.mail)='$cuser') ";
        $otable = mysqli_query($db, $cstr);
        if (mysqli_num_rows($otable) == 0) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Operador não localizado") . "...";
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $cuser);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }
        $olinha = mysqli_fetch_array($otable);

        if (trim(cifra($olinha["senha"])) !== strtoupper(pegavar("senha"))) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Senha inválida"); // - ".pegavar("senha")." - ".$olinha["senha"];
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"]);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }

        if ($olinha["inativo"]) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Operador inativo para CAIXA"); // - ".pegavar("senha")." - ".$olinha["senha"];
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"]);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }
        $ctime = date("H:i:s");
        if ($olinha["ini"] > $ctime || $olinha["fim"] < $ctime) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("Horário de trabalho não permitido"); // - ".pegavar("senha")." - ".$olinha["senha"];
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"]);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }
        $aips = explode(",", trim($olinha["ips"]));
        $lok = true;
        if ($aips && $aips[0]) {
            $meuip = $_SERVER["REMOTE_ADDR"] . ".";
            $lok = false;
            foreach ($aips as $value) {
                $value = trim($value);
                if (!$value) {
                    continue;
                }
                if (substr($value, -1) != '.') {
                    $value .= '.';
                }
                if ($value == substr($meuip, 0, strlen($value))) {
                    $lok = true;
                    break;
                }
            }
        }
        if (!$lok) {
            $aret["erro"] = "99";
            $aret["cerro"] = _tr("IP não permitido") . "\n => $meuip"; // - ".pegavar("senha")." - ".$olinha["senha"];
            GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"]);
            echo json_encode($aret);
            mysqli_close($db);
            return;
        }

        $aret["codigo"] = $olinha["usuario"];
        $aret["nome"] = iconv('cp850', 'utf8', $olinha["nome"]);
        $carq = "caixa";
        $cstr = "create table if not exists " . $carq . "tablet" . $lweb . "_sid (usuario int(10),sid varchar(100),data_ini int(10),data_atu int(10),data_sai int(10), index usuario (usuario),index sid (sid),index data_sai (data_sai)  )";
        mysqli_query($db, $cstr);

        mysqli_query($db, "update " . $carq . "tablet" . $lweb . "_sid set data_sai=date2unix(now()) where usuario=" . $olinha["usuario"]);
        $sid = str_pad($olinha["usuario"], 3, '0', STR_PAD_LEFT) . GeraSenha(57);
        mysqli_query($db, "insert " . $carq . "tablet" . $lweb . "_sid set usuario=" . $olinha["usuario"] . ",sid='$sid',data_ini=date2unix(now()),data_atu=date2unix(now())");

        $aret["sid"] = $sid;
        $aret["usuario"] = $olinha["usuario"];
        $aret["codigo"] = $olinha["usuario"];
        $aret["nome"] = iconv('cp850', 'utf8', $olinha["nome"]);
        $aret["cusuario"] = iconv('cp850', 'utf8', $olinha["nome"]);

        $_POST["sid"] = $sid;
        VeSession("sid", $sid, $sid); //$_SESSION["sid"] = $sid;
        VeSession("vendedor", 0, $sid); //$_SESSION["vendedor"] = 0;
        VeSession("usuario", $olinha["usuario"], $sid); //$_SESSION["usuario"] = $olinha["usuario"];
        VeSession("cusuario", $olinha["nome"], $sid); //$_SESSION["cusuario"] = $olinha["nome"];
        VeSession("tempolimite", 60, $sid); //$_SESSION["tempolimite"] = 60; //$olinha["limite"];
        VeSession("modo", 1, $sid); //$_SESSION["modo"]=1;
    }


    if ($caux = VeSidVendas($nmodo, '', $sid)) {
        $aret["erro"] = "33";
        $aret["cerro"] = _tr("Erro acessando servidor") . ".\n" . $caux;
        GravaLogTablet("LOG_IN", $aret["cerro"], '', $olinha["usuario"], $olinha["codven"]);
        echo json_encode($aret);
        return;
    }
    GravaLogTablet("LOG_IN", "Login Ok", '', $olinha["usuario"], $olinha["codven"]);

    //versao
    $aret["versao"] = (mysqli_fetch_row(mysqli_query($db, "select max(versao) as versao from tablet" . $lweb . "_ver"))[0]) + 0;
    echo json_encode($aret);
    mysqli_close($db);
    return;
}



if ($caux = VeSidVendas($nmodo)) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("Erro acessando servidor") . ".\n" . $caux;
    echo json_encode($aret);
    return;
}


if (PegaVar("modo") == 36 || PegaVar("modo") == "DEL_DOUBLE") {
    $vendedor = pegavar("vendedor");
    $nserie = pegavar('serie') + 0;

    $lorc = mysqli_fetch_row(mysqli_query($db, "select orcamento from tablet" . $lweb . "_cab where serie=$nserie and vendedor=$vendedor"))[0];
    mysqli_query($db, "delete from tablet" . $lweb . "_cab where vendedor=$vendedor");
    mysqli_query($db, "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where vendedor=$vendedor");
    mysqli_query($db, "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where vendedor=$vendedor");

    echo json_encode($aret);
    return;
}
if (PegaVar("modo") == 35 || PegaVar("modo") == "VE_DOUBLE") {
    $vendedor = pegavar("vendedor");
    $nserie = pegavar('serie') + 0;

    $otab = mysqli_query($db, "select n.recno from SAIDAS_SAI n
inner join tablet" . $lweb . "_cab t on t.serie=$nserie  and  t.vendedor=$vendedor and n.placasai=concat('TBL',lpad(t.ordem,7,'0'))");
    if (mysqli_num_rows($otab) > 0) {
        $olin = mysqli_fetch_array($otab);
        $aret["erro"] = "99";
        $aret["cerro"] = _tr("Nota já finalizada no CEC\n sob nº") . " " . $olin["recno"] . '-' . digito($olin['recno']) . "";
        $aret["nota"] = $olin["recno"];
        $aret["digito"] = digito($olin["recno"]);
    }
    echo json_encode($aret);
    return;
}


if (PegaVar("modo") == 26 || PegaVar("modoc") == "HIST_VEND") {
    $cliente = pegavar("cliente");
    $loja = PegaVar("loja");
    $cstr = "select p.codpro codigo,p.nompro nome,d.qusai quant,d.cusai preco,date_format(n.datasai,'%d-%m-%y') data,n.horasai hora,n.recno nota,p.kitpro
    from PROSAI_SAI d
    inner join SAIDAS_SAI  n on n.is_deleted='N' and n.recno=d.nfsai " . ($loja ? "and n.lojasai=$loja" : "") . " 
    inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=d.prsai
    where d.is_deleted='N' and n.cliesai=$cliente and n.sitsai='S'
    order by n.datasai desc,n.horasai desc
    limit 200";

    $otab = mysqli_query($db, $cstr);
    $aprod = array();
    while ($olin = mysqli_fetch_array($otab)) {
        $aprod[] = array($olin["codigo"], LimpaChar($olin["nome"]), $olin["quant"], $olin["preco"], $olin["data"], $olin["nota"]);
    }
    $aret["prod"] = $aprod;
    echo json_encode($aret);
    return;
}
if (PegaVar("modo") == 25) {
    $cliente = pegavar("cliente");
    $npais = mysqli_fetch_row(mysqli_query($db, "select paiscli from CLIENTE_CLI where is_deleted='N' and codcli=$cliente"))[0];
    if ($npais == 1) {
        $aret["foto"] = 2;
        echo json_encode($aret);
        return;
    }
    $aret["foto"] = mysqli_fetch_row(mysqli_query($db, "select if(isnull(ordem),0,ordem) as ordem from (select max(ordem) as ordem from CEDULA_CLI where is_deleted='N' and codigo=$cliente) c"))[0];
    echo json_encode($aret);
    return;
}

if (PegaVar("modo") == 20 || PegaVar("modoc") == "VE_CEP") {
    $cep = pegavar("cep");
    $aret["lok"] = 0;
    if (mysqli_num_rows(mysqli_query($db, "show tables like 'cep'")) == 0) {
        echo json_encode($aret);
        return;
    }


    $otab = mysqli_query($db, "select * from cep where cep='$cep' ");
    if (mysqli_num_rows($otab) == 0) {
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);
    $i = 0;
    foreach ($olin as $key => $value) {
        $i++;
        if ($i % 2 == 0) {
            $aret[$key] = $value;
        }
    }
    $aret["lok"] = 1;
    echo json_encode($aret);
    return;
}









if (PegaVar("modo") == 10 || PegaVar('modoc') == "CLI_ALT") {
    $vendedor = pegavar("vendedor");
    $loja = pegavar("loja");
    $codigo = pegavar("codigo");
    $rg = limparg(pegavar("rg"));
    $cpf = limparg(pegavar("cpf"));
    $mail = pegavar("mail");
    $fantasia = pegavar("fantasia");
    $nome = strtoupper(pegavar("nome"));
    $nasc = pegavar("nasc");
    $pais = pegavar("pais");
    $cep = pegavar("cep");
    $endereco = strtoupper(pegavar("endereco"));
    $complemento = strtoupper(pegavar("complemento"));
    $bairro = strtoupper(pegavar("bairro"));
    $uf = pegavar("uf");
    $cidade = strtoupper(pegavar("cidade"));
    $telefone = pegavar("telefone");
    $celular = pegavar("celular");
    $whats = pegavar("whats");
    $sexo = pegavar("sexo");
    $tipo = pegavar("tipo");
    $publicidade = pegavar("publicidade");
    $lforcename = pegavar("forcename") == "true";
    $lpreferencial = pegavar("preferencial") == "Y";
    $nzona = pegavar("zona");
    $amarca = pegavar("marca");
    $agrupo = pegavar("grupo");

    $cmarca = '';
    $cgrupo = '';

    foreach ($amarca as $value) {
        $cmarca .= "-$value";
    }
    $cmarca = substr($cmarca, 1);
    foreach ($agrupo as $value) {
        $cgrupo .= "-$value";
    }
    $cgrupo = substr($cgrupo, 1);

    if (!$lforcename) {
        $otab = mysqli_query($db, "select codcli from CLIENTE_CLI where is_deleted='N' AND codcli!=0 and nomcli='$nome'" . ($codigo ? " and codcli!=$codigo" : ""));
        if (mysqli_num_rows($otab) > 0) {
            $aret["erro"] = '50';
            $aret["cerro"] = _tr("Nome de cliente já existe me outro código") . " => " . mysqli_fetch_row($otab)[0];
            echo json_encode($aret);
            return;
        }
    }
    if ($mail) {
        $otab = mysqli_query($db, "select codcli from CLIENTE_CLI where is_deleted='N' AND codcli!=0 and upper(mail)='" . strtoupper($mail) . ($codigo ? " and codcli!=$codigo" : ""));
        if (mysqli_num_rows($otab) > 0) {
            $aret["erro"] = '99';
            $aret["cerro"] = _tr("E-mail de cliente já existe em outro código") . " => " . mysqli_fetch_row($otab)[0];
            echo json_encode($aret);
            return;
        }
    }
    if ($codigo == 0) {
        $otab = mysqli_query($db, "select codcli from CLIENTE_CLI where is_deleted='N' AND codcli!=0 and ruccli='$rg'");
        if (mysqli_num_rows($otab) > 0) {
            $aret["erro"] = '99';
            $aret["cerro"] = _tr("RG de cliente já existe em outro código") . " => " . mysqli_fetch_row($otab)[0];
            echo json_encode($aret);
            return;
        }
        //criar deletado
        if ($lCfRdd) {
            $omed = new Mediator4("CLIENTE.CLI", W_CRIAR_DEL, '', '', $db);
        } else {
            $omed = new Mediator3("CLIENTE.CLI", W_CRIAR_DEL, '', '', $db);
        }
        $omed->aadd("cpfcli", $cpf);
        $omed->aadd("ruccli", $rg);
        $omed->aadd("rucres", $rg);
        $omed->aadd("e_mail", $mail);
        $omed->aadd("fancli", $fantasia);
        $omed->aadd("nomcli", LimpaChar($nome));
        $omed->aadd("nascli", $nasc);
        $omed->aadd("paiscli", ($pais == "PRY" ? 1 : 2));
        $omed->aadd("cepcli", $cep);
        $omed->aadd("endcli", $endereco);
        $omed->aadd("baicli", $bairro);
//        $omed->aadd("cidcli", $cidade . '-' . $uf);
        $omed->aadd("cidcli", $cidade);
        $omed->aadd("ufcli", $uf);
        $omed->aadd("foncli", $telefone);
        $omed->aadd("celcli", $celular);
        $omed->aadd("web1", $whats);
        $omed->aadd("BLKCLI", "N");
        $omed->aadd("BLOCLI", "N");
        $omed->aadd("CDNCLI", 1);
        $omed->aadd("CLIVIS", "S");
        $omed->aadd("CODCID", 1);
        $omed->aadd("GRUCLI", 1);
        $omed->aadd("FATCLI", "N");
        $omed->aadd("OBSCLI", "CADASTRADO VIA CECVEN");
        $omed->aadd("VENCLI", "N");
        $omed->aadd("ZONCLI", $nzona);
        $omed->aadd("EMIFAT", "S");
        $cdata = date('Y-m-d');
        $omed->aadd("CADCLI", $cdata);
        $omed->aadd("DATA_ALT", $cdata);
        $omed->aadd("OPERCAD", VeSession("usuario"));

//        $omed->aadd("CODCLI", "RECNO");

        if (!$omed->grava()) {
            $aret["erro"] = '99';
            $aret["cerro"] = _tr("Erro no sql. 1 ") . $omed->cerro;
            echo json_encode($aret);
            return;
        }
//        $codigo = $omed->ncodigo;
        $nrecno = $omed->nrecno;
        $codigo = $omed->nrecno;

        //C;odigo é recno
        $naux = mysqli_fetch_row(mysqli_query($db, "select PROX_CLI from PROXICAD_CAD WHERE RECNO=1"))[0];
        if ($naux && $naux > 0) {
            if ($lCfRdd) {
                $omed = new Mediator4("PROXICAD.CAD", W_INCREMENT, '', 0, $db, "PROX_CLI");
            } else {
                $omed = new Mediator3("PROXICAD.CAD", W_INCREMENT, '', 0, $db, "PROX_CLI");
            }
            while (!$omed->grava()) {
                sleep(2);
            }
            $codigo = $omed->recno;
        }
        if ($lCfRdd) {
            $omed = new Mediator3("CLIENTE.CLI", W_ALTERAR, '', $nrecno, $db);
        } else {
            $omed = new Mediator3("CLIENTE.CLI", W_ALTERAR, '', $nrecno, $db);
        }
        $omed->aadd("CODCLI", $codigo);
        $omed->grava();
        mysqli_query($db, "update CLIENTE_CLI SET IS_DELETED='N' WHERE RECNO=$nrecno");
    } else {
        $cstr = "UPDATE CLIENTE_CLI SET e_mail='$mail',fancli='$fantasia',nomcli='" . limpachar($nome) . "',nascli='$nasc',paiscli='" . ($pais == "PRY" ? 1 : 2) . "',cepcli='$cep',endcli='$endereco',baicli='$bairro',cidcli='$cidade' 
        ,ufcli='$uf' ,foncli='$telefone',celcli='$celular',zoncli='$nzona',DATA_ALT=REPLACE(REPLACE(REPLACE(NOW(),' ',''),'-',''),':',''),cpfcli='$cpf' where is_deleted='N' and codcli=$codigo
        ";
        mysqli_query($db, $cstr);
        if (mysqli_error($db)) {
            $aret["erro"] = '99';
            $aret["cerro"] = _tr("Erro no sql. 2 ") . mysqli_error($db);
            echo json_encode($aret);
            return;
        }
    }
    $cadicional = "";
    if (mysqli_num_rows(mysqli_query($db, "select codigo from CLIENTE_PFC where is_deleted='N' and codigo=$codigo")) == 0) {
        if ($lCfRdd) {
            $omedp = new Mediator4("CLIENTE.PFC", W_CRIAR, '', '', $db);
        } else {
            $omedp = new Mediator3("CLIENTE.PFC", W_CRIAR, '', '', $db);
        }
        $omedp->aadd("codigo", $codigo);
        if (!$omedp->grava()) {
            $aret["erro"] = '99';
            $aret["cerro"] = _tr("Erro adicionando no arquivo") . " CLIENTE.PFC => " . $omedp->cerro;
            echo json_encode($aret);
            return;
        }
        $cadicional = ",forcesen='Y',cforcesen='" . GeraSenha(6) . "'";
    }

    $cstr = "UPDATE CLIENTE_PFC SET nascimento='$nasc',sexo='$sexo',endereco='$endereco',cidade='$cidade',estado='$uf',pais='$pais',bairro='$bairro',cep='$cep',complemen='$complemento'
        ,telefone='$telefone',celular='$celular',whatsapp='$whats',rg='$rg',tipocli='$tipo',aceitamail='$publicidade',marca='$cmarca',categoria='$cgrupo' $cadicional  where is_deleted='N' and codigo=$codigo
        ";
    mysqli_query($db, $cstr);
    if (mysqli_error($db)) {
        $aret["erro"] = '99';
        $aret["cerro"] = _tr("Erro no sql. 3 ") . mysqli_error($db);
        echo json_encode($aret);
        return;
    }
    $aret["codigo"] = $codigo;
    echo json_encode($aret);
    return;
}
if ($vendedor && $moeda) {
//    $cloja = trim(mysqli_linha("select lojas from TABLET_CFG where is_deleted='N' and vendedor=$vendedor")[0]);
    $cloja = trim(mysqli_linha("select lojas_ven as lojas from OPERADOR_OPE where is_deleted='N' and CODIGO=" . VeSession("usuario"))[0]);
//    $cloja = trim(mysqli_linha("select lojas_ven as lojas from OPERADOR_OPE where bloq_vdas!='S' and is_deleted='N' and CODIGO=" . VeSession("usuario"))[0]);

    $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l where l.is_deleted='N' ";

    if ($cloja) {
        $aloja = explode("-", $cloja);
        $cloja = '';
        foreach ($aloja as $value) {
            if ($value) {
                $cloja .= "," . ($value + 0);
            }
        }
        $cloja = substr($cloja, 1);
        if ($cloja) {
            $cstr .= " and find_in_set(l.codemp,'$cloja')";
        }
    }
    $otab = mysqli_query($db, $cstr);
    $aloja = array();
    while ($olin = mysqli_fetch_row($otab)) {
        $aloja[] = array($olin[0], $olin[1]);
    }
    $aret["aloja"] = $aloja;

    /* LOJA CORRELATIVA */
    if (!$lweb){
        $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l INNER JOIN TABLET_CFG c on c.is_deleted='N' and c.vendedor=$vendedor  where l.is_deleted='N' and find_in_set(l.codemp,c.lojascor) ";
    }else{
        $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l INNER JOIN CONFIGVD_WEB c on c.is_deleted='N' and c.vendedor=$vendedor  where l.is_deleted='N' and find_in_set(l.codemp,c.lojascor) ";
    }
    $otab = mysqli_query($db, $cstr);
    $aloja = array();
    while ($olin = mysqli_fetch_row($otab)) {
        $aloja[] = array($olin[0], $olin[1]);
    }
    $aret["alojacor"] = $aloja;

    /**/

    $olin = mysqli_fetch_array(mysqli_query($db, "select simb1,simb2,simb3,simb4
        ,upper(nome1),upper(nome2),upper(nome3),upper(nome4)
        ,if(deci1='S',2,0),if(deci2='S',2,0),if(deci3='S',2,0),if(deci4='S',2,0)
        from CAMBIO_NOM"));
    $olincam = mysqli_fetch_row(mysqli_query($db, "select moeda1,moeda2,moeda3,moeda4 from CAMBIO_CAM where is_deleted='N' and datcam<=current_date() order by datcam desc,recno desc limit 1 "));
    //var_dump($olincam);
    $aret["amoeda"] = array(
        array($olin[0], $olin[4], $olin[8], $olincam[0] / $olincam[0], $olincam[0], $olincam[0])
        , array($olin[1], $olin[5], $olin[9], $olincam[1] / $olincam[0], $olincam[1], $olincam[0])
        , array($olin[2], $olin[6], $olin[10], $olincam[2] / $olincam[0], $olincam[2], $olincam[0])
        , array($olin[3], $olin[7], $olin[11], $olincam[3] / $olincam[0], $olincam[3], $olincam[0])
    );
    echo json_encode($aret);
    return;
}


if (pegavar("cambio") == "true") {
    //atual
    $olin = mysqli_fetch_array(mysqli_query($db, "select simb1,simb2,simb3,simb4
        ,upper(nome1),upper(nome2),upper(nome3),upper(nome4)
        ,if(deci1='S',2,0),if(deci2='S',2,0),if(deci3='S',2,0),if(deci4='S',2,0)
        from CAMBIO_NOM"));
    $olincam = mysqli_fetch_row(mysqli_query($db, "select 
          convert(moeda1,decimal(15,3)) as moeda1
         ,convert(moeda2,decimal(15,3)) as moeda2
         ,convert(moeda3,decimal(15,3)) as moeda3
         ,convert(moeda4,decimal(15,3)) as moeda4
         from CAMBIO_CAM where is_deleted='N' and datcam<=current_date() order by datcam desc,recno desc limit 1 "));
    $aret["amoeda"] = array(
        array($olin[0], $olin[4], $olin[8], $olincam[0] / $olincam[0])
        , array($olin[1], $olin[5], $olin[9], $olincam[1] / $olincam[0])
        , array($olin[2], $olin[6], $olin[10], $olincam[2] / $olincam[0])
        , array($olin[3], $olin[7], $olin[11], $olincam[3] / $olincam[0])
    );
    //anterior
    $ocam = mysqli_query($db, "select 
        datcam
         ,convert(moeda1,decimal(15,3)) as moeda1
         ,convert(moeda2,decimal(15,3)) as moeda2
         ,convert(moeda3,decimal(15,3)) as moeda3
         ,convert(moeda4,decimal(15,3)) as moeda4
         from CAMBIO_CAM where is_deleted='N' and datcam<=current_date() order by datcam desc,recno desc limit 10 ");
    $aaux = array();
    while ($olcam = mysqli_fetch_row($ocam)) {
        $aaux[] = array($olcam[1], $olcam[2], $olcam[3], $olcam[4], $olcam[0]);
    }
    $aret["amoedaant"] = $aaux;
    echo json_encode($aret);
    return;
}

/*
  if (pegavar("cliente") || pegavar("rg")) {
  $ncod = pegavar("cliente");
  $crg = LimpaRg(strtoupper(pegavar("rg")));

  $cstr = "select
  c.ruccli as rg
  ,c.codcli as codigo
  ,c.e_mail as mail
  ,c.nomcli as nome
  ,if(isnull(p.nascimento) OR p.nascimento='1000-01-01',c.nascli,p.nascimento) as nasc
  ,if(isnull(p.sexo),1,p.sexo)   as sexo
  ,if(isnull(p.tipocli),1,p.tipocli) as tipo
  ,c.paiscli as paiscli
  ,if(isnull(p.pais),if(c.paiscli=1,'PRY','BRA'),p.pais)   as pais
  ,if(isnull(p.cep),'',p.cep)	  as cep
  ,if(!isnull(p.codigo) and p.endereco!='',p.endereco,c.endcli) as endereco
  ,if(isnull(p.codigo),'',p.complemen) as complemen
  ,if(!isnull(p.bairro) and p.bairro!='',p.bairro,c.baicli) as bairro
  ,if(!isnull(p.estado) and p.estado!='',p.estado,c.ufcli) as uf
  ,if(!isnull(p.cidade) and p.cidade!='',p.cidade,c.cidcli) as cidade
  ,if(isnull(p.aceitamail),'N', p.aceitamail) as aceitamail
  ,if(!isnull(p.telefone) and p.telefone!='',p.telefone,c.foncli) as telefone
  ,if(!isnull(p.celular) and p.celular!='',p.celular,c.celcli) as celular
  ,if(isnull(p.codigo),'',p.whatsapp) as whatsapp
  ,if(isnull(i1.codigo),'0','1') as imagem1
  ,if(isnull(i2.codigo),'0','1') as imagem2

  from CLIENTE_CLI c
  left join CLIENTE_PFC p on p.is_deleted='N' and p.codigo=c.codcli
  left join CEDULA_CLI  i1 on i1.is_deleted='N' and i1.codigo=c.codcli and i1.ordem=1
  left join CEDULA_CLI  i2 on i2.is_deleted='N' and i2.codigo=c.codcli and i2.ordem=2
  where c.is_deleted='N'
  ";
  if ($ncod) {
  $cstr .= " and c.codcli=$ncod";
  } else {
  $cstr .= " and c.ruccli='$crg'";
  }
  $cstr .= " group by c.codcli ";
  $otabcli = mysqli_query($db, $cstr);
  if (mysqli_num_rows($otabcli) == 0) {
  $aret["erro"] = "1";
  $aret["cerro"] = "Cliente não localizado";
  echo json_encode($aret);
  return;
  }
  $olincli = mysqli_fetch_array($otabcli);
  foreach ($olincli as $key => $value) {
  $aret[$key] = $value;
  }
  echo json_encode($aret);
  return;
  }
 */
if ($vendedor && pegavar("carrega") == "true") {
    $nserie = pegavar("serie") + 0;
    //cancelar autorizacoes anteriores
    $nusuario = VeSession("usuario"); //$_SESSION["usuario"];
    mysqli_query($db, "update AUTORIZA_AUT SET AUTORIZADO='Abortado pelo requerente',is_deleted='Y' WHERE is_deleted='N' and OPER_SOL=$nusuario and data_aut='1000-01-01' and term_sol=" . assql(1000 + $vendedor));

    $lorc = mysqli_fetch_row(mysqli_query($db, "select orcamento from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor"))[0];
    $otabcab = mysqli_query($db, "select t.vendedor,v.nomven as cvendedor
        ,unix2date(t.data_ini) as data,t.nacional,t.pagament,t.voucher
        ,t.cliente,if(isnull(c.nomcli),'',c.nomcli) as ccliente
        ,t.loja
        ,if(isnull(l.nomemp),'',l.nomemp) as cloja
        ,t.guia   ,if(isnull(f.nomfor),'',f.nomfor) as cguia
        ,t.moeda
        ,sum(if(isnull(d.quant),0,d.quant)) as itens
        ,sum(if(isnull(d.valor),0,d.valor)) as total
        ,count(d.codigo) as codigos
        ,t.seguro
        ,t.notaalt
        ,t.orcamento
        ,t.prazo
        ,t.placa
        ,t.marca
        ,t.modelo
        ,t.cor
        ,t.classe
        ,t.tipo
        ,t.ano
        ,t.kilomet
        ,t.prisma
        ,t.lojacor
        
        from tablet" . $lweb . "_cab t 
        left  join tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro d on d.vendedor=t.vendedor and d.serie='$nserie'
        left  join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=t.cliente  AND c.codcli!=0
        left  join EMPRESA_EMP l on l.is_deleted='N' and l.codemp=t.loja 
        inner join VENDEDOR_VEN v on v.is_deleted='N' and v.codven=t.vendedor 
        left join FORNEC_FOR  f on f.is_deleted='N' and f.codfor=t.guia 
        where t.vendedor=$vendedor and t.serie='$nserie' 
    ");

    if (mysqli_num_rows($otabcab) == 0) {
        $aret["erro"] = "1";
        $aret["cerro"] = _tr("Nota zerada");
        echo json_encode($aret);
        return;
    }
    $olincab = mysqli_fetch_array($otabcab);
    $aret["vendedor"] = $olincab["vendedor"];
    $aret["cvendedor"] = LimpaChar($olincab["cvendedor"]);
    $aret["cliente"] = $olincab["cliente"];
    $aret["ccliente"] = limpachar($olincab["ccliente"]);
    $aret["data"] = $olincab["data"];
    $aret["nacional"] = $olincab["nacional"];
    $aret["pagament"] = $olincab["pagament"];
    $aret["voucher"] = $olincab["voucher"];
    $aret["loja"] = $olincab["loja"];
    $aret["cloja"] = $olincab["cloja"];
    $aret["guia"] = $olincab["guia"];
    $aret["cguia"] = $olincab["cguia"];
    $aret["moeda"] = $olincab["moeda"];
    $aret["itens"] = $olincab["itens"];
    $aret["total"] = $olincab["total"];
    $aret["codigos"] = $olincab["codigos"];
    $aret["seguro"] = $olincab["seguro"];
    $aret["notaalt"] = $olincab["notaalt"];
    $aret["orcamento"] = $olincab["orcamento"];
    $aret["prazo"] = $olincab["prazo"];

    $aret["prisma"] = $olincab["prisma"];
    $aret["placa"] = $olincab["placa"];
    $aret["marca"] = $olincab["marca"];
    $aret["modelo"] = $olincab["modelo"];
    $aret["cor"] = $olincab["cor"];
    $aret["classe"] = $olincab["classe"];
    $aret["tipo"] = $olincab["tipo"];
    $aret["ano"] = $olincab["ano"];
    $aret["kilomet"] = $olincab["kilomet"];
    $aret["lojacor"] = $olincab["lojacor"];

    //produtos
    $prod = array();
    $otabpro = mysqli_query($db, "select 
        t.codigo
        ,if(p.nomelong='',p.nompro,p.nomelong) as nome
        ,t.quant
        ,t.valor
        ,t.autoriza
        ,o.nome as cautoriza
        ,p.kitpro
    ,convert(0,decimal(20,10)) as desco        
    ,if(isnull(w.codigo) or w.nomeweb='',0,1) as detalhe
    ,if(isnull(w.codigo),0,w.nimagem) as imagem
    ,convert(0,decimal(20,10)) as desco
    ,t.iva
    ,t.seg_cod
    ,t.seg_pro
    ,t.seg_pito
    ,t.seg_pitd
    
    
    
    from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro t
    inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=t.codigo
    left  join OPERADOR_OPE o on o.is_deleted='N' and o.codigo=t.autoriza
    left  join PRODUTOS_WEB w on w.is_deleted='N' and w.codigo=p.codpro 
    where t.vendedor=$vendedor and t.serie='$nserie'
        group by p.codpro,t.seg_cod,t.seg_pro
    order by nome
    ");
//    left  join OPERADOR_OPE o on o.bloq_vdas!='S' and o.is_deleted='N' and o.codigo=t.autoriza
    $ndesco = 0;

    $apromoqua = array();
    while ($olinpro = mysqli_fetch_array($otabpro)) {


        //produto em promocao
        $otabp = mysqli_query($db, "select p.preco5,gp.codgpm
            from PRODUTO_PRO p , GRUPROMO_GPM gp
            where p.kitpro!='S' and p.is_deleted='N' and p.codpro=" . $olinpro["codigo"] . "
            and gp.is_deleted='N' and p.codpromo=gp.codgpm and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set(" . $aret["loja"] . ",replace(gp.excljgpm,'-',','))");
        if (mysqli_num_rows($otabp) > 0) {
            $olinp = mysqli_fetch_row($otabp);
//*************             porue mudei aqui ???????????? 
            //$olinpro["valor"] = $olinp[0];
            mysqli_query($db, "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set codpromo=" . $olinpro[1] . " where serie='$nserie' and vendedor=$vendedor and codigo=" . $olinpro["codigo"]);
        }
        // promoção por quantidade
        $cstr = "select gp.codgpm,gp.nomgpm,gq.perqua1,gq.perqua2,gq.perqua3,gq.perqua4,gq.perqua5,gq.perqua6,gq.perqua7,gq.perqua8,gq.perqua9,gq.perqua10,gq.perqua11,gq.perqua12,gq.perqm10 as perqua13
            ,concat(if(gq.marca>0  ,'/MARCA','') ,if(gq.grupo>0    ,'/GRUPO','') ,if(gq.sgrupo>0   ,'/SUBGRUPO' ,'') ,if(gq.produto>0  ,'/PRODUTO' ,'') ) as nome ";
        if (!$nlojapre) {
            $cstr .= " ,if(gp.tipogpm=1,p.preven,if(gp.tipogpm=2,p.preco3,if(gp.tipogpm=3,p.premin,p.preatac))) as tabela
from PRODUTO_PRO p , GRUPROMO_GPM gp ";
        } else {
            $cstr .= " ,if(gp.tipogpm=1,if(isnull(lc.proloc) or lc.preven=0,p.preven,lc.preven) ,if(gp.tipogpm=2,if(isnull(lc.preco3) or lc.preco3=0,p.preco3,lc.preco3),if(gp.tipogpm=3,if(isnull(lc.proloc) or lc.premin=0,p.premin,lc.premin),if(isnull(lc.proloc) or lc.preatac=0,p.preatac,lc.preatac)))) as tabela
from PRODUTO_PRO p 
left join LOCAL_LOC lc on lc.is_deleted='N' and lc.locloc=$nlojapre and proloc=p.codpro
, GRUPROMO_GPM gp     
                    ";
        }

        $cstr .= " inner join PROMOQUA_PRO gq on gq.is_deleted='N' and gq.grugpm=gp.codgpm
            where p.kitpro!='S' and p.is_deleted='N' and p.codpro=" . $olinpro["codigo"] . "
            and gp.is_deleted='N' and current_date()>=gp.inigpm and current_date()<=gp.fimgpm and gp.ativa='S' and !find_in_set(" . $aret["loja"] . ",replace(gp.excljgpm,'-',','))
            and (     if(gq.grupo>0  ,gq.grupo  =p.grupro ,1) and if(gq.marca>0  ,gq.marca  =p.marcpro,1) and if(gq.produto>0,gq.produto=p.codpro ,1) and if(gq.sgrupo>0 ,gq.sgrupo =p.sgrupro,1) and if(gq.gruesp>0 ,gq.gruesp =p.gruesp,1) )
            ";
        $otabp = mysqli_query($db, $cstr);
        if (mysqli_num_rows($otabp) > 0) {
            $olinp = mysqli_fetch_array($otabp);
            $nquant = $olinpro["quant"];
            if ($nquant > 12)
                $nquant = 12;

            if ($olinp["perqua$nquant"] > 0) {
//                $olinpro["desco"] = $olinp["tabela"] - $olinpro["valor"] * ((100 - $olinp["perqua$nquant"]) / 100);
                $olinpro["desco"] = round($olinp["tabela"] * $olinp["perqua$nquant"] / 100, 2);
// *************************** porque mudei aqui ????
                $olinpro["valor"] = $olinp["tabela"];
                $cstr1 = "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set codpromo=" . $olinp["codgpm"] . ",valor=" . $olinp["tabela"] . ",tabela=" . $olinp["tabela"] . ",desco=" . $olinpro["desco"] . ",nomepromo='" . $olinp["nomgpm"] . "' where serie='$nserie' and vendedor=$vendedor and codigo=" . $olinpro["codigo"];
                mysqli_query($db, $cstr1);
                $ndesco += $olinpro["quant"] * $olinpro["desco"];
                if (!array_key_exists($olinp["codgpm"], $apromoqua)) {
                    $apromoqua[$olinp["codgpm"]] = 0;
                }
                $apromoqua[$olinp["codgpm"]] += $nquant;
            }
        }

//            , LimpaChar($olinpro["nome"])

        $prod[] = array(
            $olinpro["codigo"]              //0
            , Conv850($olinpro["nome"])     //1
            , $olinpro["quant"]             //2 
            , $olinpro["valor"]             //3
            , $olinpro["autoriza"]          //4    
            , $olinpro["cautoriza"]         //5
            , $olinpro["detalhe"]           //6
            , $olinpro["imagem"]            //7
            , $olinpro["desco"]             //8
            , $olinpro["seg_cod"]           //9
            , $olinpro["seg_pro"]           //10
            , $olinpro["seg_pito"]          //11 pitzi origem
            , $olinpro["seg_pitd"]          //12 pitzi destino
        );
        mysqli_query($db, "update tablet" . $lweb . "_pro set valor=" . $olinpro["valor"] . ",desco=" . $olinpro["desco"] . " where vendedor=$vendedor and serie=$nserie and codigo=" . $olinpro['codigo']);
    }
    foreach ($apromoqua as $key => $value) {
        $olpr = mysqli_fetch_array(mysqli_query($db, "select * from PROMOQUA_PRO where is_deleted='N' and grugpm=$key"));

        $cstr = "update tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro set 
                desco=tabela*((" . $olpr["PERQ" . ($value > 12 ? "M10" : "UA" . $value)] . ")/100)";
        $cstr .= " where serie='$nserie' and vendedor=$vendedor and codpromo=$key";
        mysqli_query($db, $cstr);
    }
    $ndesco = mysqli_fetch_row(mysqli_query($db, "select sum(quant*desco) from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor"))[0];

    for ($i = 0; $i < count($prod); $i++) {
        $prod[$i][8] = mysqli_fetch_row(mysqli_query($db, "select desco from tablet" . $lweb . "_pro where vendedor=$vendedor and serie=$nserie and codigo=" . $prod[$i][0]))[0];
    }
    $aret["prod"] = $prod;
    $aret["desco"] = $ndesco;
//grade
    $prod = array();
    $otabpro = mysqli_query($db, "select t.codigo,if(p.nomelong='',p.nompro,p.nomelong) as nome,t.quant,t.valor,t.autoriza,o.nome as cautoriza,p.kitpro
,if(isnull(w.codigo) or w.nomeweb='',0,1) as detalhe
,if(isnull(w.codigo),0,w.nimagem) as imagem
,g.quant as quantg,g.seq1,g.seq2
,s1.tipogrd as val1,s2.tipogrd as val2
from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro t
inner join tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra g   on g.codigo=t.codigo and g.vendedor=t.vendedor and g.serie=t.serie
inner join GRADESEQ_PRO s1 on s1.is_deleted='N' and s1.recno=g.seq1
inner join GRADESEQ_PRO s2 on s2.is_deleted='N' and s2.recno=g.seq2
inner join PRODUTO_PRO p  on p.is_deleted='N' and p.codpro=t.codigo
left  join OPERADOR_OPE o on o.is_deleted='N' and o.codigo=t.autoriza
left  join PRODUTOS_WEB w on w.is_deleted='N' and w.codigo=p.codpro 
where t.vendedor=$vendedor and t.serie='$nserie'
    group by p.codpro,val1,val2
order by nome
");
//left  join OPERADOR_OPE o on o.bloq_vdas!='S' and o.is_deleted='N' and o.codigo=t.autoriza

    while ($olinpro = mysqli_fetch_array($otabpro)) {
        $prod[] = array(
            $olinpro["codigo"]
            , $olinpro["seq1"]
            , $olinpro["seq2"]
            , $olinpro["quantg"]
            , $olinpro["valor"]
            , $olinpro["val1"]
            , $olinpro["val2"]
        );
    }
    $aret["grade"] = $prod;
    echo json_encode($aret);
    return;
}
if ($vendedor && pegavar("zerar") == "true") {
    $lorc = pegavar("orcamento") == "true";
    $nserie = pegavar("serie") + 0;
    $otabcab = mysqli_query($db, "select * from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor");
    if (mysqli_num_rows($otabcab) == 0) {
        $aret["erro"] = "1";
        $aret["cerro"] = _tr("Nada a zerar");
        echo json_encode($aret);
        return;
    }

    //limpar produtos
    $olincab = mysqli_fetch_array($otabcab);
    $otabpro = mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor");
    if (!$lorc) {
        while ($olinpro = mysqli_fetch_array($otabpro)) {
            $cstr = "update PRODUTO_PRO SET ESTOQUE=ESTOQUE+" . $olinpro["quant"] . "
            ,FPGPRO=FPGPRO-" . $olinpro["quant"] . "
            where is_deleted='N' and codpro=" . $olinpro["codigo"];
            mysqli_query($db, $cstr);
            if (mysqli_error($db)) {
                $aret["erro"] = "99";
                $aret["cerro"] = mysqli_error($db) . "\n" . $cstr;
                echo json_encode($aret);
                return;
            }
            $cstr = "update LOCAL_LOC SET QUALOC=QUALOC+" . $olinpro["quant"] . "
            ,FPGLOC=FPGLOC-" . $olinpro["quant"] . "
            where is_deleted='N' and proloc=" . $olinpro["codigo"] . "
                AND LOCLOC=" . $olincab["loja"];
            mysqli_query($db, $cstr);
            if (mysqli_error($db)) {
                $aret["erro"] = "99";
                $aret["cerro"] = mysqli_error($db) . "\n" . $cstr;
                echo json_encode($aret);
                return;
            }
        }
    }

    //limpar grades
    //$olincab = mysqli_fetch_array($otabcab);
    $otabpro = mysqli_query($db, "select * from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor");
    if (!$lorc) {
        while ($olinpro = mysqli_fetch_array($otabpro)) {
            $cstr = "update ESTLJGRA_PRO SET ESTOQUE=ESTOQUE+" . $olinpro["quant"] . ",fpgloc=fpgloc-" . $olinpro["quant"] . "
            where is_deleted='N' and prograde=" . $olinpro["codigo"] . "
                AND LOjgrade=" . $olincab["loja"] .
                    " and seqgrade1=" . $olinpro["seq1"] .
                    " and seqgrade2=" . $olinpro["seq2"];
            mysqli_query($db, $cstr);

            if (mysqli_error($db)) {
                $aret["erro"] = "99";
                $aret["cerro"] = mysqli_error($db) . "\n" . $cstr;
                echo json_encode($aret);
                return;
            }
        }
    }


    mysqli_query($db, "delete from tablet" . $lweb . "_cab where serie='$nserie' and vendedor=$vendedor");
    mysqli_query($db, "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_pro where serie='$nserie' and vendedor=$vendedor");
    mysqli_query($db, "delete from tablet" . $lweb . "" . ($lorc ? "_orc" : "") . "_gra where serie='$nserie' and vendedor=$vendedor");
    //bloqter
    mysqli_query($db, "update BLOQTER_PRO set is_deleted='Y' where is_deleted='N' and termbloq='" . "T" . $nserie . str_pad($vendedor, 4, "0", STR_PAD_LEFT) . "'");

    $aret["erro"] = "00";
    $aret["cerro"] = _tr("Nota zerada");
    echo json_encode($aret);
    return;
}
if ($vendedor && $loja == "true") {
//    $cloja = trim(mysqli_linha("select lojas from TABLET_CFG where is_deleted='N' and vendedor=$vendedor")[0]);
    $clojaven = trim(mysqli_fetch_row(mysqli_query($db, "select lojas_ven as lojas from OPERADOR_OPE where is_deleted='N' and CODIGO=" . VeSession("usuario")))[0]);
//    $clojaven = trim(mysqli_fetch_row(mysqli_query($db, "select lojas_ven as lojas from OPERADOR_OPE where bloq_vdas!='S' and is_deleted='N' and CODIGO=" . VeSession("usuario")))[0]);

    $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l where l.is_deleted='N' ";
    if ($clojaven) {
        $cloja = "";
        $aloja = explode("-", $clojaven);
        foreach ($aloja as $value) {
            $cloja .= "," . ($value + 0);
        }
        if ($cloja) {
            $cstr .= " and find_in_set(l.codemp,'$cloja')";
        }
    }
    $otab = mysqli_query($db, $cstr);
    $aloja = array();
    while ($olin = mysqli_fetch_row($otab)) {
        $aloja[] = array($olin[0] + 0, LimpaChar($olin[1]));
    }
    $aret["aloja"] = $aloja;
//    $aret["aloja"] = $cloja;
    //carrega zona

    $cstr = "select z.codzon,z.nomzon from ZONCLI_ZON z where z.is_deleted='N' order by nomzon";
    $otab = mysqli_query($db, $cstr);
    $azona = array();
    while ($olin = mysqli_fetch_row($otab)) {
        $azona[] = array($olin[0] + 0, LimpaChar($olin[1]));
    }
    $aret["azona"] = $azona;

    $olin = mysqli_fetch_array(mysqli_query($db, "select simb1,simb2,simb3,simb4
        ,upper(nome1),upper(nome2),upper(nome3),upper(nome4)
        ,if(deci1='S',2,0),if(deci2='S',2,0),if(deci3='S',2,0),if(deci4='S',2,0)
        from CAMBIO_NOM"));
    $olincam = mysqli_fetch_row(mysqli_query($db, "select moeda1,moeda2,moeda3,moeda4 from CAMBIO_CAM where is_deleted='N' and datcam<=current_date() order by datcam desc,recno desc limit 1 "));
    $aret["amoeda"] = array(
        array($olin[0], $olin[4], $olin[8], $olincam[0] / $olincam[0])
        , array($olin[1], $olin[5], $olin[9], $olincam[1] / $olincam[0])
        , array($olin[2], $olin[6], $olin[10], $olincam[2] / $olincam[0])
        , array($olin[3], $olin[7], $olin[11], $olincam[3] / $olincam[0])
    );
    $aret["modpedi"] = mysqli_fetch_row(mysqli_query($db, "select MODPEDI FROM CONFIG LIMIT 1"))[0];

    $olin = mysqli_fetch_row(mysqli_query($db, "select semesto,semeger from CONFIG LIMIT 1"));
    $aret["semesto"] = $olin[0];
    $aret["semeger"] = $olin[1];

    /* LOJA CORRELATIVA */
    if (!$lweb){
        $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l INNER JOIN TABLET_CFG c on c.is_deleted='N' and c.vendedor=$vendedor  where l.is_deleted='N' and find_in_set(l.codemp,c.lojascor) ";
    }else{
        $cstr = "select l.codemp,l.nomemp from EMPRESA_EMP l INNER JOIN CONFIGVD_WEB  c on c.is_deleted='N' and c.vendedor=$vendedor  where l.is_deleted='N' and find_in_set(l.codemp,c.lojascor) ";
    }
    $otab = mysqli_query($db, $cstr);
    $aloja = array();
    while ($olin = mysqli_fetch_row($otab)) {
        $aloja[] = array($olin[0], $olin[1]);
    }
    $aret["alojacor"] = $aloja;

    echo json_encode($aret);
    return;
}

$aret["erro"] = "98";
$aret["cerro"] = _tr("Erros de parâmetros");
echo json_encode($aret);
return;

function MostraVoucher($cVoucher) {
    global $db;

    $cSaida = '<table class="table" style="font-size:.9em;">';

    $cVoucher = Trim(strtoupper($cVoucher));
    $oDet = mysqli_fetch_array(mysqli_query($db, "select * from VOUCHER_DET WHERE IS_DELETED='N' AND SERIE='$cVoucher'"));
    $oVou = mysqli_fetch_array(mysqli_query($db, "select * from VOUCHER_PRM WHERE IS_DELETED='N' AND CODIGO=" . $oDet["CODIGO"]));

    $cSaida .= '<tr><th class="text-center" colspan="2"><h4>';
    if ($oVou["PROMOCAO"]) {
        $cSaida .= "<strong>" . $oVou["PROMOCAO"] . '</strong><br>';
    }
    $cSaida .= 'VOUCHER: ' . $cVoucher . '</h4></th></tr>';
    if ($oDet["NOTAD"] > 0) {
        $cSaida .= '<tr><th class="text-center" colspan="2">**** JÁ UTILIZADO ****</th></tr>';
    }
    $cSaida .= '<tr><th class="text-right">Emissão: </th><td>' . Unix2Date($oDet["DATA"])[0] . '</td></tr>';

    if ($oVou["DIAS"] == 0) {
        $cSaida .= '<tr><th class="text-right">Validade: </th><td> ' . Unix2Date($oVou["INICIOV"])[1] . " a " . Unix2Date($oVou["FINALV"])[1] . '</td></tr>';
    } else {
        $cSaida .= '<tr><th class="text-right">Validade Até: </th><td>' . DateAddDays($oDet["DATA"], $oVou["DIAS"], TRUE) . '</td></tr>';
    }

    if ($oDet["NOTA"]) {
        $cSaida .= '<tr><th class="text-right">Nota de compra: </th><td>' . $oDet["NOTA"] . "-" . Digito($oDet["NOTA"]) . '</td></tr>';
    }
    if ($oVou["MODO"] == 0 && $oDet["NOTAD"]) {
        $cSaida .= '<tr><th class="text-right">Utilizado nota: </th><td>' . $oDet["NOTQAD"] . "-" . Digito($oDet["NOTA"]) . '</td></tr>';
    }

    if ($oVou["MODO"] > 1) {
        $cSaida .= '<tr><th class="text-right">Origem Voucher: </th><td>' . ( $oVou["MODO"] == 1 ? "Internet" : ( $oVou["MODO"] == 2 ? "Promoção" : ( $oVou["MODO"] == 3 ? "Evento" : "" ) ) ) . '</td></tr>';
    }
    if (trim($oVou["PRODUTOS"])) {
        $cSaida .= '<tr><th class="text-center" colspan="2">Utilizável nos Produtos: ' . '</td></tr>';
        $otpro = mysqli_query($db, "select codpro,nompro from PRODUTO_PRO WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codpro,'-'),'-" . Trim($oVou["PRODUTOS"]) . "-')");
        //aAux := MedDbf2Array( "select codpro,nompro from PRODUTO_PRO WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codpro,'-'),'-" + AllTrim( $oVou["produtos ) + "-')" )
        $aPro = explode('-', trim($oVou["PRODUTOS"]));
        $aQua = explode('-', trim($oVou["PRODUTOQS"]));

        while ($olpro = mysqli_fetch_row($otpro)) {
            //$cSaida += "    " + Str( Poe_Digito( aAux[ i, 1 ] ), 8, 0 ) + "-" + ( AllTrim( aAux[ i, 2 ] ) ) .'</td></tr>';
            $npos = array_search($olpro[0], $aPro);
            if (count($aQua) > 0 && $aQua[$npos] > 1) {
                $cSaida .= '<tr><td class="text-center" colspan="2">' . poedigito($olpro[0]) . "-" . $olpro[1];
                $cSaida .= ( ' <br><span style="font-size:0.9em;">(na compra de ' . $aQua[$npos] . " unidades ou acima)</span>" ) . '</td></tr>';
            } else {
                $cSaida .= '<tr><td class="text-center" colspan="2">' . poedigito($olpro[0]) . "-" . $olpro[1] . '</td></tr>';
            }
            /*
              nAux := AScan( aPro, { | x | x == aAux[ i, 1 ] } )
              IF nAux > 0 .AND. Len( aQua ) > 0 .AND. aQua[ nAux ] > 1
              cSaida += ( "    na compra de " + MyTrim( aQua[ nAux ] ) + " unidades ou acima" ) .'</td></tr>';
              ENDIF
             * 
             */
        }
    }
    if (trim($oVou["LOJAS"])) {
        $cSaida .= '<tr><th class="text-center" colspan="2">Utilizável nas Lojas: </td></tr>';
        $otloj = mysqli_query($db, "select codemp,nomemp from EMPRESA_EMP WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codemp,'-'),'-" . Trim($oVou["LOJAS"]) . "-')");
        while ($olloj = mysqli_fetch_row($otloj)) {
            $cSaida .= '<tr><td class="text-center"  colspan="2">' . $olloj[0] . "-" . $olloj[1] . '</td></tr>';
        }
    }
    if (trim($oVou["GRUPOS"])) {
        $cSaida .= '<tr><th class="text-center" colspan="2">Utilizável nos Grupos: </td></tr>';
        $otloj = mysqli_query($db, "select codgru,nomgru from GRUPO_GRU WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codgru,'-'),'-" . Trim($oVou["GRUPOS"]) . "-')");
        while ($olloj = mysqli_fetch_row($otloj)) {
            $cSaida .= '<tr><td class="text-center"  colspan="2">' . $olloj[0] . "-" . $olloj[1] . '</td></tr>';
        }
    }
    if (trim($oVou["SGRUPOS"])) {
        $cSaida .= '<tr><th class="text-center" colspan="2">Utilizável nos Sub-Grupos: </td></tr>';
        $otloj = mysqli_query($db, "select codSgru,nomSgru from SGRUPO_SGR WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codSgru,'-'),'-" . Trim($oVou["SGRUPOS"]) . "-')");
        while ($olloj = mysqli_fetch_row($otloj)) {
            $cSaida .= '<tr><td class="text-center"  colspan="2">' . $olloj[0] . "-" . $olloj[1] . '</td></tr>';
        }
    }
    if (trim($oVou["MARCAS"])) {
        $cSaida .= '<tr><th class="text-center" colspan="2">Utilizável nas Marcas: </td></tr>';
        $otloj = mysqli_query($db, "select codMARC,nomMARC from MARCAS_MAR WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codMARC,'-'),'-" . Trim($oVou["MARCAS"]) . "-')");
        while ($olloj = mysqli_fetch_row($otloj)) {
            $cSaida .= '<tr><td class="text-center"  colspan="2">' . $olloj[0] . "-" . $olloj[1] . '</td></tr>';
        }
    }
    if ($oVou["DESCONTO"] > 0) {
        $cSaida .= '<tr><th class="text-right">  % Desconto......: </th><td>' . number_format($oVou["DESCONTO"], 2) . " %" . '</td></tr>';
    }
    if ($oVou["VALOR"] > 0) {
        $cSaida .= '<tr><th class="text-right">Valor Desconto..: </th><td>' . VeMoeSim(1) . " " . VeMoeFormat($oVou["VALOR"], 1) . '</td></tr>';
    }
    if ($oVou["ACIMA"] > 0) {
        $cSaida .= '<tr><th class="text-right"> Compras acima de: </th><td>' . VeMoeSim(1) . " " . VeMoeFormat($oVou["ACIMA"], 1) . '</td></tr>';
    }

    $cSaida .= "</table>";

    $cRefVoucher = $cSaida;

    return $cSaida;
}
