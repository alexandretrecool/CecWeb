<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

/*
$modo = PegaVar("modo");
$vendedor = PegaVar("vendedor");
if (!$vendedor) {
}
*/

if (!$db){
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor");
    echo json_encode($aret);
    return;
}
/*
require_once 'inc/sid.php';


if ($caux = VeSidVendas()) {
    $aret["erro"] = "33";
    $aret["cerro"] = "Erro acessando servidor.\n" . $caux;
    echo json_encode($aret);
    return;
}
*/

$cRefErro='';
$nRefGuia=0;
$nRefLista=0;
echo VeListaGuia(pegavar("nota"));
echo "<br>";
echo $cRefErro."<br>";
return;

function  VeListaGuia($nNota,&$cRefErro='',&$nRefGuia=0,&$nRefLista=0){
    global $db;
    $nDiasAnteriores= mysqli_fetch_row(mysqli_query($db,"select guia_d_ant from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];
    $nDiasPosteriores=mysqli_fetch_row(mysqli_query($db,"select guia_d_pos from CONFIG_PFC where is_deleted='N' and recno=1 "))[0];

    $nDiasAnteriores+=0;
    $nDiasPosteriores+=0;
    $dData=mysqli_fetch_row(mysqli_query($db,"select current_date()"))[0];

    if (!$nNota){
        $cRefErro=_tr("Nota não passada");
        return -1;
    }

    $cRefErro="";
    $nRefGuia=0;
    $nRefLista=0;

    $olnot= mysqli_fetch_array(mysqli_query($db, "select * from SAIDAS_SAI WHERE RECNO=$nNota" ));
    if (!$olnot || $olnot["IS_DELETED"]=='Y' ){
        $cRefErro=_tr("Nota Deletada");
        return -1;
    }
    $nCliente=$olnot["CLIESAI"];

    $olcli= mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_CLI WHERE IS_DELETED='N' AND CODCLI=$nCliente" ));

    $cRg= strtoupper(LimpaRg($olcli["RUCCLI"]));

    if (!$cRg){
        $cRefErro=_tr("Cliente sem RUC/RG");
        return -1;
    }

    $dIni=date2unix($dData,"00:00:00",TRUE)-($nDiasAnteriores*24*60*60);
    $dFim=date2unix($dData,"23:59:59",TRUE)+($nDiasPosteriores*24*60*60);

    $cSql="Select d.rg,d.nome,d.codigo AS lista,l.guia,d.recno as reg,d.presente 
     from LISTADET_GUI d 
     inner join LISTA_GUI l ON l.is_deleted='N' and l.codigo=d.codigo 
     where d.is_deleted='N' and d.rg='$cRg' 
     and l.data>=$dIni and l.data<=$dFim
     order by d.data";

    $otab= mysqli_query($db, $cSql);
    if (mysqli_num_rows($otab)==0){
        $cRefErro=_tr("Nada presente na lista");
        return -1;
    }
    $olis= mysqli_fetch_array($otab);


    $nRefGuia=$olis["guia"];
    $nRefLista=$olis["lista"];
    
    if ($olis["presente"]!=='Y'){
    /*
    (cDet)->(DBGoTo((cSql)->reg),RegLock())
    (cLis)->(DBSeek((cDet)->codigo))
    (cDet)->codcli:=ncliente
    IF Empty((cDet)->presente)
        AbreArq("entrada.ent",cEnt,FALSE,FALSE,"idx")
        AbreArq("duplicat.for",cDup,FALSE,FALSE,"idx")
        (cEnt)->(ApLock())
        (cEnt)->notaent        :=(cDet)->(RecNo())+7000000
        (cEnt)->fornent        :=(cLis)->guia
        (cEnt)->valpent        :=selval("select guiapremio from CONFIG_PFC WHERE RECNO=1","N")
        (cEnt)->ATUAENT        :="N" ///???
        (cEnt)->baseent        :=1
        (cEnt)->cambent        :=1
        (cEnt)->cxunent        :="C" ///???
        (cEnt)->emisent        :=meddate()
        (cEnt)->entrent        :=meddate()
        (cEnt)->lojaent        :=1 ///???
        (cEnt)->moeent         :=1
        (cEnt)->nrdup          :=1
        (cEnt)->obsent         :="Premio Lista Guia "+mytrim((cLis)->guia)+" - RG Cliente : "+(cDet)->rg
        (cEnt)->sitent         :="S" ///???
        (cEnt)->valdesm        :=(cEnt)->valpent
        (cEnt)->vencto         :=meddate()+1
        (cEnt)->viprent        :="P" ///???
        (cent)->despesa        :="S"

        (cDup)->(ApLock())
        (cDup)->numedupf       :=Str((cent)->notaent,7,0)+" 1"
        (cDup)->valodupf       :=(cent)->valpent
        (cDup)->vencdupf       :=(cent)->vencto
        (cDup)->forndupf       :=(cEnt)->fornent
        (cDup)->obsedupf       :=(cent)->obsent
        (cDup)->moedupf        :=(cent)->moeent
        (cDup)->cambdupf       :=(cEnt)->cambent
        (cDup)->basedupf       :=(cEnt)->baseent
        (cDup)->despdupf       :="S" ///???
        (cDup)->desmdupf       :="S" ///???
        (cDup)->AUTZPAG        :=1

        (cDup)->(DBCommit(),DBCloseArea())
        (cEnt)->(DBCommit(),DBCloseArea())
        (cDet)->presente:=true
        (cDet)->DATA:=date2unix()
        (cDet)->premio_reg:=(cdup)->(RecNo())
        (cDet)->premio_mod:=1
    ENDIF
     */
    }


    $cStr="select convert(sum((s.cumoe*s.qusai*g.per_guia/100)),decimal(13,2)) as comissao 
                ,convert(sum((s.cumoe*s.qusai*g.per_guia/100))/n.valosai*100,decimal(13,2)) as pcom 
                from PROSAI_SAI s 
                inner join SAIDAS_SAI     n on n.is_deleted='N' and n.recno =s.nfsai 
                inner join PRODUTO_PRO     p on p.is_deleted='N' and p.codpro=s.prsai 
                inner join GRUPO_GRU     g on g.is_deleted='N' and g.codgru=p.grupro 
                where s.is_deleted='N' and s.nfsai=$nNota ";
    $otcom= mysqli_query($db, $cStr);
    if (mysqli_num_rows($otcom)==0){
        $cRefErro=_tr("Sem comissão a lançar");
        return -1;
    }
    
    $olcom=mysqli_fetch_array($otcom);
    if ($olcom["comissao"]==0 && $olcom["pcom"]==0){
        $cRefErro=_tr("Sem comissão a lançar");
        return -1;
    }
    
    mysqli_query($db, "update SAIDAS_SAI set guiasai=$nRefGuia ,valcomgui=".$olcom["comissao"].",comgui=".$olcom["pcom"]." where recno=$nNota");
  
    /*
    
    aComissao:=CalcComissaoGuiaNota(nnota,(cLis)->guia)
    IF !empty(aComissao) .AND. selval("select nota from NOTA_GUI where is_deleted='N' and nota="+AsSql(nNota)+" and codigo="+AsSql((cDet)->codigo),"N")==0
        (cNot)->(DBGoTo((cNot)->(RecNo())))
        (cDet)->venda   +=(cNot)->valosai
        (cDet)->comissao+=(cNot)->valcomgui
        (cNtg)->(ApLock())
        (cNtg)->codigo  :=(cDet)->codigo
        (cNtg)->lista   :=(cDet)->(RecNo())
        (cNtg)->nota    :=nNota
        (cNtg)->comissao:=(cNot)->valcomgui

    ENDIF

    (cDet)->(DBCommit())
    (cNtg)->(DBCommit())

    (cSql)->(DBCloseArea())

    oArq:close()
*/
    return $nRefGuia;
}