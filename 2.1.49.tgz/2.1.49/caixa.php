<?php

//marcara em guarani
//consulta preço apenas cliente
//local

/*
  AUTORIZACAO GERAL
  html=>vd_modal_aut
  js=>vd_modal_aut_sol
  php=>vendas.php modo=PEDE_AUT_TUDO
  js=>AutorizaTotal
  html=>pd_autoriza
  js=>pd_autoriza_inc
  js=>AutorizaIncG
  php=>vendas.php modo=PED_AUT_GERAL_1
  js=>EsperaAutG
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);

session_start();

require_once 'inc/config.php';
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

$modo = PegaVar("modo");
$noperador = VeSession("usuario");//$_SESSION["usuario"];
$aret["operador"] = array(VeSession("usuario"),VeSession("cusuario"));//array($_SESSION["usuario"], $_SESSION["cusuario"]);
$aret["sid"] = pegavar("sid");//$_SESSION["sid"];

if (!$db){
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("X0.Erro acessando servidor");
    echo json_encode($aret);
    return;
}

require_once 'inc/sid.php';

//if ($caux = VeSidVendas(PegaVar("sid"))) {
if ($caux = VeSidVendas(1)) {
    $aret["erro"] = "33";
    $aret["cerro"] = _tr("X1.Erro acessando servidor") . ".\n" . $caux;
    echo json_encode($aret);
    return;
}
if ($modo == "VECLIENTENF") {
    $ncliente = pegavar("cliente");
    $olincfg = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG WHERE RECNO=1"));
    if ($olincfg["SIFEN"] !== "S") {
        echo json_encode($aret);
        return;
    }
    $otabcli = mysqli_query($db, "select * from CLIENTE_PGY WHERE IS_DELETED='N' AND CODIGO='$ncliente'");
    if (mysqli_num_rows($otabcli) == 0) {
        $aret["erro"] = "20";
        $aret["cerro"] = _tr("Cliente não cadastrado para emitir NFE");
        echo json_encode($aret);
        return;
    }


    if ($olincfg["CLIECON2"] == $ncliente) {
        echo json_encode($aret);
        return;
    }
    $olincli = mysqli_fetch_array($otabcli);
    if ($olincli["EMITIR"] == "N") {
        $aret["erro"] = "21";
        $aret["cerro"] = _tr("Cliente não AUTORIZADO EMITIR DE");
        echo json_encode($aret);
        return;
    }


    if ($olincli["PAIS_NUM"] == 0 || !$olincli["PAIS_NOM"]) {
        $aret["erro"] = "22";
        $aret["cerro"] = _tr("País inválido no CLIENTE");
        echo json_encode($aret);
        return;
    }

    if (trim($olincli["IDEN_NUM"]) !== LimpaRg($olincli["IDEN_NUM"])) {
        $aret["erro"] = "23";
        $aret["cerro"] = _tr("Caracteres inválidos na CÉDULA do cliente");
        echo json_encode($aret);
        return;
    }

    if (!TRIM($olincli["EMAIL"]) && TRIM($olincli["EMAIL"]) !== "CLIENTE NO TIENE CORREO ELECTRONICO" && filter_var($olincli["EMAILS"], FILTER_VALIDATE_EMAIL)) {
        $aret["erro"] = "24";
        $aret["cerro"] = _tr("Email do cliente inválido");
        echo json_encode($aret);
        return;
    }
    $lRet = true;
    $creferro = "";
    if (strlen(Trim($olincli["NOME"])) < 4) {
        $lRet = false;
        $creferro .= "NOME do cliente inválido \n";
    }

    if (!empty(Trim($olincli["FANTASIA"])) && strlen(Trim($olincli["FANTASIA"])) < 4) {
        $lRet = false;
        $creferro .= "NOME de FANTASIA do cliente inválido \n";
    }


    if ($olincli["PAIS_NUM"] == 600) {
        if ($olincli["NATUREZA"] < 1 || $olincli["NATUREZA"] > 2) {
            $lRet = false;
            $creferro .= "NATUREZA DO CLIENTE deve ser entre 1 e 2\n";
        }
        if ($olincli["OPE_TIPO"] < 1 || $olincli["OPE_TIPO"] > 4) {
            $lRet = false;
            $creferro .= "Erro: TIPO de OPERAÇÃO deve ser entre 1 e 4\n";
        }
        if ($olincli["CONT_TIPO"] < 1 || $olincli["CONT_TIPO"] > 2) {
            $lRet = false;
            $creferro .= "Erro: TIPO de CONTRIBUINTE deve ser entre 1 e 2\n";
        }
        if ($olincli["CONT_TIPO"] == 2 && !TRIM($olincli["RUCC"])) {
            $lRet = false;
            $creferro .= "Erro: RUC Vazio para pessoa jurÍdica\n";
        }
        if (TRIM($olincli["RUCC"]) && VeDigitoRuc(TRIM($olincli["RUCC"]) . $olincli["RUC_DV"])) {
            $lRet = false;
            $creferro .= "Erro: RUC inválido\n";
        }

        if ($olincli["NATUREZA"] == 1 && ( $olincli["CODCID"] == 0 || STRLen(Trim($olincli["CIDADE"])) < 1 )) {
            $lRet = false;
            $creferro .= "Erro: CIDADE inválida\n";
        }
        if ($olincli["NATUREZA"] == 1 && (!trim($olincli["ENDERECO"]) || !TRIM($olincli["NUMERO"]) )) {
            $lRet = false;
            $creferro .= "Erro: ENDEREÇO inválido\n";
        }
//exterior
        if ($olincli["OPE_TIPO"] == 4) {
            $lRet = false;
            $creferro .= "Erro: Operação B2F (exterior) não pode ser usada para Paraguayo\n";
        }

//TELEFONE PY
        if ((!Empty($olincli["TELEFONE"]) && strlen($olincli["TELEFONE"]) < 9 ) || (!Empty($olincli["CELULAR"]) && STRLen($olincli["CELULAR"]) < 9 )) {
            $lRet = false;
            $creferro .= "Erro: Telefone PARAGUAYO deve conter ao menos 9 numeros\n";
        }
    } else {
        if ($olincli["OPE_TIPO"] == 1) {
            $lRet = false;
            $creferro .= "Erro: Operação B2B (Comercio) não pode ser usada para Extrangeiro\n";
        }
        if ($olincli["NATURAZA"] == 1) {
            $lRet = false;
            $creferro .= "Erro: NATUREZA CONTRINUINTE apenas para clientes Paraguayos\n";
        }

        if (strLen(Trim($olincli["CIDADE"])) < 1) {
            $lRet = false;
            $creferro .= "Erro: CIDADE inválida\n";
        }
        if ($olincli["PAIS_NUM"] == 76) {
            if (strlen(Trim($olincli["ESTADO"])) < 2) {
                $lRet = false;
                $creferro .= "Erro: ESTADO inválido\n";
            }
        }
        if (Empty($olincli["ENDERECO"])) {
            $lRet = false;
            $creferro .= "Erro: ENDEREÇO inválido\n";
        }
        if ($olincli["DOC_TIPO"] != 2 && $olincli["DOC_TIPO"] != 3 && $olincli["DOC_TIPO"] != 5 && $olincli["DOC_TIPO"] != 6) {
            $lRet = false;
            $creferro = "Erro: TIPO de DOCUMENTO inválido\n";
        }
        if (strLen(Trim($olincli["IDEN_NUM"])) < 6) {
            $lRet = false;
            $creferro .= "Erro: DOCUMENTO inválido\n";
        }
//TELEFONE
        if ((!Empty(trim($olincli["TELEFONE"])) && STRLen(trim($olincli["TELEFONE"])) < 9 ) || (!Empty(trim($olincli["CELULAR"])) && STRLen(trim($olincli["CELULAR"])) < 9 )) {
            $lRet = false;
            $creferro = "Erro: Telefone EXTRANGEIRO deve conter ao menos 9 numeros\n";
        }
    }

    if (!$lRet) {
        $aret["erro"] = "23";
        $aret["cerro"] = $creferro;
    }
    echo json_encode($aret);
    return;
}
if ($modo == "POS_VEPIX") {
    $aestado = array();
    $aestado[0] = "Erro indeterminado";
    $aestado[1] = "Venda ainda não gerou qrCode"; //started	sales that have not yet been generated the qrcode
    $aestado[2] = "Aguardando o pagamento do PIX"; // waiting response	sale awaiting payment of the pix
    $aestado[3] = "Pagamento recebido"; // paid	payed sale
    $aestado[4] = "Venda Cancelada"; // canceled	canceled sale
    $aestado[5] = "Tempo para pagamento expirado"; //- expired payment	exceeded payment deadline
    $aestado[6] = "Venda cancelada sem pagamento"; //- sale canceled without pix	exceeded payment deadline
    $aestado[7] = "Venda paga após ser cancelada"; //- sale timeout	sale paid after being canceled
    $aestado[8] = "Venda cancelada por CPF do pagador ser difente do emissor"; //pagamento ser  - sale canceled by different CPF	payer CPF is different than buyer's
    $aestado[9] = "CPF pagador excedeu o limite"; //- exceeded payment limit	cpf payer limit exceeded
    $aestado[10] = "Pagamento por este CPF está restrito"; //- restrictive payer CPF	cpf payer with restricted

    $cterminal = "w" . $noperador;
    if (pegavar("inicio") == "true") {
        $ncliente = mysqli_fetch_row(mysqli_query($db, "select cliente from tablet_pix_not where operador=" . $noperador . " order by ordem limit 1"))[0];
        $nvalor = mysqli_fetch_row(mysqli_query($db, "select sum(valor) as valor from tablet_pix_not where operador=" . $noperador))[0];
        $otabnota = mysqli_query($db, "select nota from tablet_pix_not where operador=" . $noperador);
        $cnotas = '';
        while ($olinnota = mysqli_fetch_array($otabnota)) {
            $cnotas .= "-" . trim(poedigito($olinnota["nota"]));
        }
        $cnotas = substr($cnotas, 1);
        mysqli_query($db, "replace rendix_token_cec set data_sol=date2unix(now()),ativo=1,estado=1,cliente=$ncliente,valor=$nvalor,terminal='$cterminal',notas='$cnotas'");
    }
    $otab = mysqli_query($db, "select estado,chave,saleid from rendix_token_cec where terminal='$cterminal'");
    $olin = mysqli_fetch_array($otab);

    $aret["id"] = $olin["saleid"];
    $aret["estado"] = $olin["estado"] + 0;
    $aret["cestado"] = $aestado[$aret["estado"]];
    echo json_encode($aret);
    return;
}
if ($modo == "VENOTA") {
    $nnota = pegavar("nota");
    if (is_numeric($nnota)) {
        if (!vedigito($nnota)) {
            $aret["erro"] = "88";
            $aret["cerro"] = "Nota Inválida $nnota";
            echo json_encode($aret);
            return;
        }
        $nnota = tiradigito($nnota);
        $csql = "select if(n.datarec=current_date(),1,0) as isdata, n.datarec,n.horarec,n.cliesai,c.nomcli,n.lojasai,e.nomemp,e.entrega,n.valosai,n.sitsai,n.is_deleted,n.retisai
            from SAIDAS_SAI n
            inner join EMPRESA_EMP e on e.is_deleted='N' and e.codemp=n.lojasai
            inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai
            where n.recno=$nnota
            ";
        $otabnot = mysqli_query($db, $csql);
        if (mysqli_num_rows($otabnot) == 0) {
            $aret["erro"] = "88";
            $aret["cerro"] = "Nota não existe";
            echo json_encode($aret);
            return;
        }
        $olinnot = mysqli_fetch_array($otabnot);
        if ($olinnot["is_deleted"] == "Y") {
            $aret["erro"] = "88";
            $aret["cerro"] = "Nota está deletada";
            echo json_encode($aret);
            return;
        }
        if ($olinnot["sitsai"] !== "S") {
            $aret["erro"] = "88";
            $aret["cerro"] = "Nota não está paga";
            echo json_encode($aret);
            return;
        }
        if ($olinnot["retisai"] == "S") {
            $aret["erro"] = "88";
            $aret["cerro"] = "Nota já foi entregue";
            echo json_encode($aret);
            return;
        }
        if ($olinnot["isdata"] + 0 !== 1) {
            $aret["erro"] = "88";
            $aret["cerro"] = "Nota não é desta data";
            echo json_encode($aret);
            return;
        }
        $aret["lnota"] = 0;
        $aret["nota"] = array("nnota" => $nnota, "data" => $olinnot["datarec"], "hora" => $olinnot["horarec"],
            "cliente" => $olinnot["cliesai"], "ccliente" => $olinnot["nomcli"], "loja" => $olinnot["lojasai"], "cloja" => $olinnot["nomemp"],
            "entrega" => $olinnot["entrega"], "valor" => $olinnot["valosai"],
            "barra" => substr("000000000000" . $value, -12) . digito($value), "nota" => $value . "-" . digito($value),
            "produtos" => $aprod);
        $aret["notas"] = array();
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array(mysqli_query($db, "select * from tablet_cax where codigo=" . $noperador));
    $date = date_create();
    date_sub($date, date_interval_create_from_date_string($olin["dias"] . " days"));
    $data = date_format($date, "Y-m-d");

    $nnota = trim(strtoupper($nnota));
    $csql = "select n.recno,n.valosai,c.nomcli
            from SAIDAS_SAI n
            inner join EMPRESA_EMP e on e.is_deleted='N' and e.codemp=n.lojasai
            inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai 
            where n.is_deleted='N' and n.sitsai='S' and n.retisai!='S' and n.datarec>=current_date() and c.nomcli like '%$nnota%'
            order by n.datasai desc";
    $anotas = array();
    $otab = mysqli_query($db, $csql);
    while ($olin = mysqli_fetch_array($otab)) {
        $anotas[] = array("nota" => $olin["recno"], "valor" => $olin["valosai"], "ccliente" => $olin["nomcli"]);
    }
    $aret["lnota"] = 1;
    $aret["notas"] = $anotas;
    echo json_encode($aret);
    return;
}
if ($modo == "IMPRIME") {
    $anotas = pegavar("anotas");
    $anotasret = array();
    foreach ($anotas as $value) {
        $olinnot = mysqli_fetch_array(mysqli_query($db, "select n.datarec,n.horarec,n.cliesai,c.nomcli,n.lojasai,e.nomemp,e.entrega,n.valosai 
            ,z.codzon,z.nomzon
            from SAIDAS_SAI n
            inner join EMPRESA_EMP e on e.is_deleted='N' and e.codemp=n.lojasai
            inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai
            left join ZONCLI_ZON z on z.is_deleted='N' and z.codzon=c.zoncli
            where n.is_deleted='N' and n.recno=$value
            "));
        $aprod = array();
        
        $otabpro = mysqli_query($db, "select p.codpro,p.nomelong,s.qusai,s.cusai,p.pacote from PROSAI_SAI s
            inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai 
            where s.is_deleted='N' and s.nfsai=$value order by s.regsai
            ");
        $npacote=0;
        while ($olinpro = mysqli_fetch_array($otabpro)) {
            $aprod[] = array("codigo" => $olinpro["codpro"], "digito" => digito($olinpro["codpro"]), "nome" => $olinpro["nomelong"], "quant" => $olinpro["qusai"], "preco" => $olinpro["cusai"],"pacote" => $olinpro["pacote"]);
            $npacote=$olinpro["pacote"];
        }
        $anotasret[] = array("data" => $olinnot["datarec"], "hora" => $olinnot["horarec"],
            "cliente" => $olinnot["cliesai"], "ccliente" => $olinnot["nomcli"], "loja" => $olinnot["lojasai"], "cloja" => $olinnot["nomemp"],
            "zona" => $olinnot["codzon"],"czona" => $olinnot["nomzon"],"pacote" => $npacote,
            "entrega" => $olinnot["entrega"], "valor" => $olinnot["valosai"],
            "barra" => substr("000000000000" . $value, -12) . digito($value), "nota" => $value . "-" . digito($value),
            "produtos" => $aprod);
    }
    $aret["notas"] = $anotasret;
    echo json_encode($aret);
    return;
}
if ($modo == "DEL_NOTA") {
    $nnota = pegavar("nota");

    mysqli_query($db, "update SAIDAS_SAI set time_rec='' where recno=$nnota");
    mysqli_query($db, "delete from tablet_pix_not where operador=" . $noperador . " and nota=$nnota");
    $anotas = array();
    $otab = mysqli_query($db, "select * from tablet_pix_not where operador=" . $noperador . " order by ordem desc");
    $ntotal = 0;
    while ($olin = mysqli_fetch_array($otab)) {
        $ntotal += $olin["valor"];
        $anotas[] = array("nota" => $olin["nota"], "valor" => $olin["valor"], "cliente" => $olin["cliente"], "ccliente" => iconv("cp850", "utf-8", $olin["ccliente"]));
    }
    $aret["notas"] = $anotas;
    $aret["total"] = CalcTotal();
    echo json_encode($aret);
    return;
}
if ($modo == "VER_NOTA") {
    $nnota = pegavar("nota");
    $csql = "select 
 concat(p.codpro,'-',digito(p.codpro)) as codigo
,p.nomelong as nome
,s.qusai as quant
,s.cusai as valor
,s.cusai*s.qusai as total
from PROSAI_SAI s
inner join PRODUTO_PRO p on p.codpro=s.prsai and p.is_deleted='N'
where s.is_deleted='N' and s.nfsai=$nnota 
order by s.regsai";
    $otab = mysqli_query($db, $csql);
    $csaida = '<table class="table">
        <tr>
        <th class="text-right">Código</th>
        <th class="text-left">Descrição</th>
        <th class="text-right">Qt</th>
        <th class="text-right">Unt</th>
        <th class="text-right">Tot</th>
        </tr>
        ';
    $nitens = 0;
    $nvalor = 0;
    $i = 0;
    while ($olin = mysqli_fetch_array($otab)) {
        $i++;
        $csaida .= '<tr>
        <td class="text-right">' . $olin["codigo"] . '</td>
        <td class="text-left">' . $olin["nome"] . '</td>
        <td class="text-right">' . number_format($olin["quant"], 0, ",", ".") . '</th>
        <td class="text-right">' . number_format($olin["valor"], 2, ",", ".") . '</td>
        <td class="text-right">' . number_format($olin["total"], 2, ",", ".") . '</td>
        </tr>
        ';
        $nitens += $olin["quant"];
        $nvalor += $olin["total"];
    }
    $csaida .= '<tr>
        <th class="text-center" colspan="2"></th>
        <th class="text-right">' . number_format($nitens, 0, ",", ".") . '</th>
        <th class="text-right"></th>
        <th class="text-right">' . number_format($nvalor, 2, ",", ".") . '</th>
        </tr>
        </table>
        ';
    $aret["tabela"] = $csaida;
    echo json_encode($aret);
    return;
}
if ($modo == "ADD_NOTA") {
    $nnota = pegavar("nota");
    $ncliente = mysqli_fetch_row(mysqli_query($db, "select cliente from tablet_pix_not where operador=" . $noperador . " limit 1"))[0];

    $otab = mysqli_query($db, "select n.time_rec,n.datasai,n.cliesai,c.nomcli,n.valosai/n.cambsai as valosai,n.is_deleted from SAIDAS_SAI n 
        inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai
        WHERE n.recno=$nnota");
    if (mysqli_num_rows($otab) == 0) {
        $aret["erro"] = "50";
        $aret["cerro"] = _tr("Nota não existe") . ".\n $nnota" . "-" . digito($nnota);
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array($otab);
    if ($olin["is_deleted"] == 'Y') {
        $aret["erro"] = "51";
        $aret["cerro"] = _tr("Nota está deletada") . ".\n $nnota" . "-" . digito($nnota);
        echo json_encode($aret);
        return;
    }
    $cterminal = substr($olin["time_rec"], -4);
    $cterminal_local = "w" . substr("000" . $noperador, -3);
    $ctime = substr($olin["time_rec"], 0, 10);
    $ctime_local = Date2Unix();
    if ($cterminal !== $cterminal_local && $ctime_local - $ctime <= 60) { //abalisa 1 minuto para bloqueio
        $aret["erro"] = "52";
        $aret["cerro"] = _tr("Nota sendo recebida no terminal") . ":\n => $cterminal";
        echo json_encode($aret);
        return;
    }

    if ($ncliente && $ncliente != $olin["cliesai"]) { //cliente diferente
        $aret["erro"] = "51";
        $aret["cerro"] = _tr("Cliente tem de ser o mesmo para as notas");
        echo json_encode($aret);
        return;
    }


    $omed = new Mediator3("SAIDAS.SAI", W_BLOQUEAR, '', $nnota, $db);
    if (!$omed->grava()) {
        $aret["erro"] = "52";
        $aret["cerro"] = _tr("Erro bloqueando nota") . ".\n => $nnota-" . digito($nnota);
        echo json_encode($aret);
        return;
    }
    mysqli_query($db, "update SAIDAS_SAI set time_rec='" . $ctime_local . $cterminal_local . "' where recno=$nnota");
    mysqli_query($db, "insert tablet_pix_not set operador=" . $noperador . ",nota=$nnota,valor=" . $olin["valosai"] . ",cliente=" . $olin["cliesai"] . ",ccliente=" . assql($olin["nomcli"]));
    $anotas = array();
    $otab = mysqli_query($db, "select * from tablet_pix_not where operador=" . $noperador . " order by ordem desc");

    $ntotal = 0;
    while ($olin = mysqli_fetch_array($otab)) {
        $ntotal += $olin["valor"];
        $anotas[] = array("nota" => $olin["nota"], "valor" => $olin["valor"], "cliente" => $olin["cliente"], "ccliente" => iconv("cp850", "utf-8", $olin["ccliente"]));
    }
    $aret["notas"] = $anotas;
    $aret["total"] = CalcTotal();

    echo json_encode($aret);

    return;
}
if ($modo == "AJUSTALOCK") {
    $csql = "update SAIDAS_SAI s,tablet_pix_not p set s.time_rec=concat(date2unix(now()),'w',lpad(p.operador,3,'0')) where p.operador=" . $noperador . " and s.recno=p.nota";
    mysqli_query($db, $csql);
    return;
}
if ($modo == "CLIENTE") {
    $ccli = trim(strtoupper(PegaVar("cliente")));
    if (is_numeric($ccli) && !vedigito($ccli)) {
        $aret["notas"] = array();
        $aret["erro"] = 110;
        $aret["cerro"] = "Nota inválida";
        echo json_encode($aret);
        return;
    }
    $olin = mysqli_fetch_array(mysqli_query($db, "select * from tablet_cax where codigo=" . $noperador));
    $date = date_create();
    date_sub($date, date_interval_create_from_date_string($olin["dias"] . " days"));
    $data = date_format($date, "Y-m-d");
    $csql = "select c.codcli,c.nomcli,n.recno as nota,n.valosai/n.cambsai as valosai,if(isnull(x.nota),0,1) as jaexiste
        from SAIDAS_SAI n
        inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai
        inner join tablet_pix p on p.operador=" . $noperador . " 
        left join tablet_pix_not x on p.operador=x.operador and x.nota=n.recno 
        where n.is_deleted='N' and n.sitsai!='S' and n.datasai>='$data' ";
    if ($olin["loja"]) {
        $csql .= " and find_in_set(n.lojasai,'" . $olin["loja"] . "') ";
    }

    if ($ccli && !is_numeric($ccli)) {
        $csql .= " and c.nomcli like '%$ccli%'";
    } elseif ($ccli && is_numeric($ccli)) {
        $csql .= " and n.recno=" . tiradigito($ccli);
    }
    $csql .= " order by n.datasai desc,n.horasai desc ";
    $otab = mysqli_query($db, $csql);

    $anotas = array();
    while ($olinnot = mysqli_fetch_array($otab)) {
        if ($olinnot["jaexiste"]) {
            continue;
        }
        $anotas[] = array(
            "cliente" => $olinnot["codcli"],
            "ccliente" => iconv("cp850", "utf-8", $olinnot["nomcli"]),
            "nota" => $olinnot["nota"],
            "valor" => $olinnot["valosai"]
        );
    }
    $aret["notas"] = $anotas;
    echo json_encode($aret);
    return;
}
if ($modo == "ALTERA") {
    $csql = "UPDATE tablet_pix set banco='" . pegavar("banco") . "',documento='" . pegavar("documento") . "' where operador=" . $noperador;
    mysqli_query($db, $csql);
    $nmoedabanco = mysqli_fetch_row(mysqli_query($db, "select moeban from BANCOS_BAN WHERE IS_DELETED='N' AND CODBAN='" . PegaVar("banco") . "'"))[0];
    $nmoedabanco = ($nmoedabanco == 0 ? 1 : $nmoedabanco);
    $aret["ban_moeda"] = $nmoedabanco;

    $aret["total"] = CalcTotal();
    echo json_encode($aret);
    return;
}
if ($modo == "INICIO") {
    $otab = mysqli_query($db, "select ordem from tablet_pix where operador=" . $noperador);
    if (mysqli_num_rows($otab) > 0) {
        $olin = mysqli_fetch_row($otab);
        $csql = "delete from tablet_pix where operador=" . $noperador;
        mysqli_query($db, $csql);
        $csql = "delete from tablet_pix_not where operador=" . $noperador;
        mysqli_query($db, $csql);
    }
    $csql = "insert tablet_pix set operador=" . $noperador . ",conta=" . pegavar("conta") . ",hist=" . pegavar("hist") . ",data_ini=" . Date2Unix();
    mysqli_query($db, $csql);
    echo json_encode($aret);
    return;
}
if ($modo == "RESET") {
    $olin = mysqli_fetch_array(mysqli_query($db, "select * from tablet_cax where codigo=$noperador"));
    $acontas = array();
    $otabcon = mysqli_query($db, "select codcon,nomcon from CONTAS_CAX where is_deleted='N' and find_in_set(codcon,'" . $olin["conta"] . "')");
    while ($olincon = mysqli_fetch_row($otabcon)) {
        $acontas[] = $olincon;
    }
    $aret["conta"] = $acontas;

    $ahist = array();
    $otabhis = mysqli_query($db, "select codhis,nomhis from HISTOR_CAX where is_deleted='N' and find_in_set(codhis,'" . $olin["historic"] . "')");
    while ($olinhis = mysqli_fetch_row($otabhis)) {
        $ahist[] = $olinhis;
    }
    $aret["hist"] = $ahist;

    $abanco = array();
    $otabban = mysqli_query($db, "select codban,nomban,bco_com from BANCOS_BAN where is_deleted='N' and find_in_set(codban,'" . $olin["banco"] . "')");
    while ($olinban = mysqli_fetch_row($otabban)) {
        $abanco[] = $olinban;
    }
    $aret["banco"] = $abanco;
    $csql = "update SAIDAS_SAI s,tablet_pix_not p set s.time_rec='' where p.operador=" . $noperador . " and s.recno=p.nota";
    mysqli_query($db, $csql);
    mysqli_query($db, "delete from tablet_pix where operador=" . $noperador);
    mysqli_query($db, "delete from tablet_pix_not where operador=" . $noperador);

    echo json_encode($aret);
    return;
}

function CalcTotal() {
    global $db;
    global $noperador;
    $ntaxa = (mysqli_fetch_row(mysqli_query($db, "select b.taxa from BANCOS_BAN b inner join tablet_pix p on p.banco=b.codban and p.operador=" . $noperador . " and b.is_deleted='N' "))[0]) + 0;
    $ntotal = (mysqli_fetch_row(mysqli_query($db, "select sum(valor) as valor from tablet_pix_not where operador=" . $noperador))[0]) + 0;
    $olincamb = mysqli_fetch_row(mysqli_query($db, "select moeda1,moeda2,moeda3,moeda4 from CAMBIO_CAM where is_deleted='N' order by recno desc limit 1"));

    $nnota = mysqli_fetch_row(mysqli_query($db, "select n.AUM_TJ from tablet_pix_not x inner join SAIDAS_SAI n on n.is_deleted='N' and n.notasai=x.nota where x.operador=" . $noperador . " order by x.nota limit 1"))[0];
    if ($nnota > 0) {
        $ntaxa = 0;
    }

    return array(
        array($ntotal * $olincamb[0], ($ntotal + ($ntotal * $ntaxa / 100)) * $olincamb[0])
        , array($ntotal * $olincamb[1], ($ntotal + ($ntotal * $ntaxa / 100)) * $olincamb[1])
        , array($ntotal * $olincamb[2], ($ntotal + ($ntotal * $ntaxa / 100)) * $olincamb[2])
        , array($ntotal * $olincamb[3], ($ntotal + ($ntotal * $ntaxa / 100)) * $olincamb[3])
    );
}

/*
  ++ nli
  @ ++ nli, nci + 1 say "Tipo de Tarjeta.....: " Get nTipo Pict "99" Valid Sobe() .OR. COMBOBOX( @nTipo, aTar,,,, TRUE )
  @ ++ nli, nci + 1 say "Bandeira............: " Get nTarjeta Pict "99" Valid Sobe() .OR. COMBOBOX( @nTarjeta, DE_TARJETA,,,, TRUE ) .AND. ;
  IF( nTarjeta == DE_TARJ_OTRO, ( cTipo := Space( 20 ), TRUE ), ( cTipo := Eval( DE_BLOCO, DE_TARJETA , nTarjeta, TRUE ), __keyboard( K_ENTER ) , TRUE ) )
  @ ++ nli, nci + 1 say "Nome Bandeira.......: " Get cTipo Valid Sobe() .OR. Len( AllTrim( cTipo ) ) >= 4
  READ
 */
if ($modo == "FINALIZA") {
    if (mysqli_num_rows(mysqli_query($db, "show tables like 'NOTASPIX_CAX'")) == 0) {
        $aestru = array();
        $aestru[] = array("NOTA", "N", 10, 0);
        $aestru[] = array("OPERADOR", "N", 10, 0);
        $aestru[] = array("INICIO", "N", 10, 0);
        $aestru[] = array("FINAL", "N", 10, 0);
        $aestru[] = array("DATA", "D", 8, 0);
        $aestru[] = array("OPERACAO", "N", 10, 0);
        $aestru[] = array("TIPO", "N", 10, 0);
        $aestru[] = array("TARJETA", "N", 10, 0);
        $aestru[] = array("CBANDEIRA", "C", 20, 0);

        $omed = new Mediator3("NOTASPIX.CAX", W_CRIAR_ARQUIVO, $aestru);

        if (!$omed->grava()) {
            $aret["erro"] = 99;
            $aret["cerro"] = "Erro criando arquivo NOTASPIX.CAX";
            echo json_encode($aret);
            return;
        }
    }

//deleta dois dias anterioes
    mysqli_query($db, "delete from NOTASPIX_CAX WHERE data<date_add(current_date(),interval -2 day) and data!='1000-01-01'");

    $csql = "update tablet_pix set documento=" . assql(pegavar("documento")) . " where operador=" . $noperador;
    mysqli_query($db, $csql);
    $ocfgcec = mysqli_fetch_array(mysqli_query($db, "select * from CONFIG where recno=1 "));

    $csql = "select * from CAMBIO_CAM where IS_DELETED='N' AND DATCAM=CURRENT_DATE() ORDER BY RECNO DESC LIMIT 1";
    $olcam = mysqli_fetch_array(mysqli_query($db, $csql));
    if (!$olcam) {
        $aret["erro"] = 99;
        $aret["cerro"] = "Cambio da data atual não atribuido";
        echo json_encode($aret);
        return;
    }
    $csql = "select * from CAMBIO_NOM where RECNO=1";
    $olnom = mysqli_fetch_array(mysqli_query($db, $csql));

    $csql = "select * from tablet_pix where operador=" . $noperador;
    $olpix = mysqli_fetch_array(mysqli_query($db, $csql));

    $csql = "select * from BANCOS_BAN WHERE IS_DELETED='N' AND CODBAN=" . $olpix["banco"];
    $olban = mysqli_fetch_array(mysqli_query($db, $csql));

    $csql = "select * from CONTAS_CAX WHERE IS_DELETED='N' AND CODCON=" . $olpix["conta"];
    $olcon = mysqli_fetch_array(mysqli_query($db, $csql));
    if (!$olcon) {
        $aret["erro"] = 99;
        $aret["cerro"] = "Erro na conta caixa " . $olpix["conta"];
        echo json_encode($aret);
        return;
    }
    $csql = "select * from HISTOR_CAX WHERE IS_DELETED='N' AND CODHIS=" . $olpix["hist"];
    $olhis = mysqli_fetch_array(mysqli_query($db, $csql));

    $csql = "select * from tablet_pix_not where operador=" . $noperador;
    $otnot = mysqli_query($db, $csql);
    $anotas = array();
    $linicio = true;
    /*
      $oope = new Mediator3("OPERACAX.CAX", W_ALTERAR, '', 1, $db);
      $oope->aadd("NUMOPE", "NUMOPE+1", TRUE);
      $oope->grava();
      $nnumope = mysqli_fetch_row(mysqli_query($db, "select numope from OPERACAX_CAX where RECNO=1"))[0];

     */
    mysqli_query($db, "set @numope=0");
    mysqli_query($db, "update OPERACAX_CAX SET NUMOPE=(@numope:=NUMOPE+1) WHERE RECNO=1");
    $nnumope = mysqli_fetch_row(mysqli_query($db, "select @numope"))[0];

    $nTvalor_base = 0;
    $nTvalor_moeda = 0;
    $nTvalor_acrescimo = 0;
    $nmoedaban = ($olban["MOEBAN"] == 0 ? 1 : $olban["MOEBAN"]);

//tenta bloquear as notas
    $anotasrec = array();
    while ($olnot = mysqli_fetch_array($otnot)) {
        $anotasrec[] = $olnot["nota"];
        $onotsai = new Mediator3("SAIDAS.SAI", W_BLOQUEAR, '', $olnot["nota"], $db);

        if (!$onotsai->grava()) {
            $aret["erro"] = 99;
            $aret["cerro"] = "Erro bloqueando NOTA " . $olnot["nota"];
            echo json_encode($aret);
            return;
        }

        $olinhanota = mysqli_fetch_row(mysqli_query($db, "select sitsai,is_deleted from SAIDAS_SAI WHERE notasai=" . $olnot["nota"]));
        if ($olinhanota[0] == "S") {
            $aret["erro"] = 99;
            $aret["cerro"] = "NOTA " . $olnot["nota"] . " já foi recebida";
            echo json_encode($aret);
            return;
        }
        if ($olinhanota[1] == "Y") {
            $aret["erro"] = 99;
            $aret["cerro"] = "NOTA " . $olnot["nota"] . " foi deletada";
            echo json_encode($aret);
            return;
        }
    }


    $anotaspix = array();
    foreach ($anotasrec as $nnotarec) {

        $anotas[] = $nnotarec;

        $nped = $nnotarec;

        if (!$nped) {
            $aret[0]["estatus"] = 40;
            $aret[0]["cestatus"] = "Pedido vazio";
            echo json_encode($aret);
            return;
        }
        $otablenot = mysqli_query($db, "select * from SAIDAS_SAI WHERE RECNO=$nped");
        $olinhanot = mysqli_fetch_array($otablenot);

        if (mysqli_num_rows($otablenot) == 0) {
            $aret[0]["estatus"] = 71;
            $aret[0]["cestatus"] = "Pedido não existe";
            echo json_encode($aret);
            return;
        }

        if ($olinhanot["SITSAI"] == "S") {
            $aret[0]["estatus"] = 80;
            $aret[0]["cestatus"] = "Pedido ja faturado no CEC";
            echo json_encode($aret);
            return;
        }


        if ($olinhanot["IS_DELETED"] == "Y") {
            $aret[0]["estatus"] = 72;
            $aret[0]["cestatus"] = "Pedido deletado ";
            echo json_encode($aret);
            return;
        }
        if ($linicio) {
//LOTE
            $olotn = new Mediator3("LOTES.CLI", W_CRIAR, '', '', $db);
            $olotn->aadd("NUMELOTE", "RECNO", TRUE);
            $olotn->grava();
            $nlote = $olotn->nrecno;

            $olot = new Mediator3("LOTESDOC.CLI", W_CRIAR, '', '', $db);
            $olot->aadd("BANCLOTE", $olpix["banco"]);
            $olot->aadd("CAIXA", $olpix["conta"]);
            $olot->aadd("CHEQLOTE", strtoupper(pegavar("documento")));
            $olot->aadd("CLIELOTE", $olinhanot["CLIESAI"]);
            $olot->aadd("DATALOTE", 'current_date()', true);
            $olot->aadd("LOJALOTE", $olinhanot["LOJASAI"]);
            $olot->aadd("MOEDLOTE", $nmoedaban);
            $olot->aadd("NRLOTE", $nlote);
            $olot->aadd("VALOLOTE", 0);
            $olot->aadd("TAXABANC", $olban["TAXA"]);
            $olot->aadd("VENLOTE", date('Y-m-d', strtotime("+" . $olban["DIASBAN"] . " days")));
            $olot->aadd("BASELOTE", $olcam["MOEDA1"]);
            $olot->aadd("CAMBLOTE", $olcam["MOEDA" . $nmoedaban]);
            $olot->aadd("NUMOPE", $nnumope);
            $olot->aadd("OPERLOTE", $nnumope);
            $olot->grava();
            $omoe = new Mediator3("MOEDAS.CAX", W_CRIAR, '', '', $db);
            $omoe->aadd("OPERMOE", $nnumope);
//        $omoe->aadd("OPCXMOE", $olinhanot["MOEDA"]);
            $omoe->aadd("OPCXMOE", $noperador);
            $omoe->aadd("HORAMOE", "current_time()", true);
            $omoe->aadd("CONTMOE", $olpix["conta"]);
//$omoe->aadd("CONTMOE", $olcfg["CONTA"]);
            $omoe->aadd("DATAMOE", "current_date()", true);
            $omoe->aadd("SINAL", "N");
            $omoe->aadd("CAMB01", $olcam["MOEDA1"]);
            $omoe->aadd("CAMB02", $olcam["MOEDA2"]);
            $omoe->aadd("CAMB03", $olcam["MOEDA3"]);
            $omoe->aadd("CAMB04", $olcam["MOEDA4"]);
            $omoe->grava();
        }



        $nvalor_base = Valosai2Base($olinhanot["VALOSAI"], 1, 1, '', '', $olinhanot["CAMBSAI"], $olinhanot["BASESAI"]);
        $nvalor_moeda = Base2Valosai($nvalor_base, 1, $nmoedaban, $olcam);
        $nvalor_acrescimo = $nvalor_moeda * (1 + ($olban["TAXA"] / 100));

        $nTvalor_base += $nvalor_base;
        $nTvalor_moeda += $nvalor_moeda;
        $nTvalor_acrescimo += $nvalor_acrescimo;

//        mysqli_query($db,"update LOTESDOC_CLI set valolote=valolote+".assql($nvalor_acrescimo)." where recno="+assql($olot->nrecno) );
        $linicio = false;

        mysqli_query($db, "update SAIDAS_SAI n,CONFIG c 
        SET n.SITSAI='S'
        ,n.HORAREC=CURRENT_TIME()
        ,n.DATAREC=if(c.CUSRECE='N',CURRENT_DATE(),'1000-01-01')
        ,n.OPEREC=" . $noperador . "
        ,n.VDUPSAI=n.VALOSAI
        ,n.NRDUP=1
        ,n.TIPOSAI='P'
        ,n.TARJBCO=" . assql($olpix["banco"]) . "
        ,n.lotesai=" . assql($nlote) . " 
        WHERE c.RECNO=1 and n.RECNO=$nped");
        $otablenot = mysqli_query($db, "select * from SAIDAS_SAI WHERE RECNO=$nped");
        $olinhanot = mysqli_fetch_array($otablenot);

//$nvalor_base=$olinhanot["VALOSAI"]/$olinhanot["CAMBSAI"]*$olinhanot["BASESAI"];

        $odup = new Mediator3("DUPLICAT.CLI", W_CRIAR, '', '', $db);
        $odup->aadd("NUMEDUP", padl($olinhanot["NOTASAI"], 7) . padl("1", 2));
        $odup->aadd("VENCDUP", date('Y-m-d', strtotime("+" . $olban["DIASBAN"] . " days")));
        $odup->aadd("MOEDUP", $olinhanot["MOEDA"]);
        $odup->aadd("VALODUP", $olinhanot["VALOSAI"]);
        $odup->aadd("CLIEDUP", $olinhanot["CLIESAI"]);
        $odup->aadd("BANCDUP", $olban["CODBAN"]); //$ocfgcec["BCO_PAGARE"]);
        $odup->aadd("BASEDUP", $olinhanot["BASESAI"]);
        $odup->aadd("CAMBDUP", $olinhanot["CAMBSAI"]);

//$odup->aadd("MOEDUP", $nmoedaban);
//$odup->aadd("VALODUP", $nvalor_moeda);
//$odup->aadd("BASEDUP", $olcam["MOEDA1"]);
//$odup->aadd("CAMBDUP", $olcam["MOEDA".$nmoedaban]);
        $odup->aadd("EMISDUP", $olinhanot["DATASAI"]);
        $odup->aadd("FATDUP", "current_date()", true);
        $odup->aadd("DATODUP", "current_date()", true);
        $odup->aadd("HORADUP", "current_time()", true);
        $odup->aadd("RECEDUP", "current_date()", true);
        $odup->aadd("LOTEDUP", $nlote);
        $odup->grava();

        $ocax = new Mediator3("CAIXA.CAX", W_CRIAR, '', '', $db);
        $ocax->aadd("CODCAX", $olpix["conta"]);
        $ocax->aadd("DOCCAX", $olinhanot["NOTASAI"]);
        $olinhadis = mysqli_linha("DISTRIB_CAX", "HISDIS", "RECNO=11", '', $db);
//$olinhadis = mysqli_fetch_array(mysqli_query($db,"select HISDIS from DISTRIB_CAX where RECNO=11"));
        $ocax->aadd("CODHIS", $olinhadis["HISDIS"]);
        $ocax->aadd("HORACAX", "CURRENT_TIME()", TRUE);
        $ocax->aadd("TERCAX", substr("W" + "000" . $noperador, -3));
        $ocax->aadd("NUMOPE", $nnumope);
        $ocax->aadd("OPECAX", $noperador);
        $ocax->aadd("DATCAX", "current_date()", true);
        $ocax->aadd("EMICAX", "current_date()", true);
        $ocax->aadd("VALCAX", $olinhanot["VALOSAI"]);
        $ocax->aadd("VALMCAX", $olinhanot["VALOSAI"]);
        $ocax->aadd("MOECAX", $olinhanot["MOEDA"]);
        $ocax->aadd("BASECAX", $olinhanot["BASESAI"]);
        $ocax->aadd("CAMBCAX", $olinhanot["CAMBSAI"]);
        $ocax->aadd("LOJCAX", $olinhanot["LOJASAI"]);
        $ocax->aadd("EXTCAX", "S");

        $ocax->aadd("TIPCAX", "N");
        $olincli = mysqli_linha("CLIENTE_CLI", "NOMCLI", "CODCLI=" . $olinhanot["CLIESAI"], '', $db);
        $ocax->aadd("NOMCAX", $olincli["NOMCLI"] . "/ Plazo-TBL");
        $ocax->aadd("CPLCAX", "TBL BAIXA POT LOTE NR: " . $nlote);
        $ocax->grava();

//$olincam = mysqli_fetch_array(mysqli_query($db, "select * from CAMBIO_CAM where is_deleted='N' order by datcam desc limit 1"));


        $onotpix = new Mediator3("NOTASPIX.CAX", W_CRIAR, '', '', $db);
        $onotpix->aadd("NOTA", $nped);
        $onotpix->aadd("OPERADOR", $noperador);
        $onotpix->aadd("DATA", "current_date()", true);
        $onotpix->aadd("OPERACAO", $nnumope);
        $onotpix->aadd("INICIO", 9999999999);
        $ntipo = PegaVar("tipo") + 0;
        if ($ntipo != 0) {

            $abandeira = array("1" => "Visa", "2" => "Mastercard", "3" => "American Express", "4" => "Maestro", "5" => "Panal", "6" => "Cabal", "99" => "Otro");
            $onotpix->aadd("TIPO", $ntipo);
            $nbandeira = pegavar("bandeira");
            $onotpix->aadd("TARJETA", $nbandeira);
            $onotpix->aadd("CBANDEIRA", $nbandeira == 99 ? PegaVar("outro") : $abandeira[$nbandeira]);
        }
        $onotpix->grava();
        $anotaspix[] = $onotpix->nrecno;
// atualzia arquivo saida
        $onotsai = new Mediator3("SAIDAS.SAI", W_COMMIT, '', '', $db);
        $onotsai->grava();

//baixa os pendentes
        $csql = "UPDATE PRODUTO_PRO p, 
        (select s.prsai,s.qusai from PROSAI_SAI s where s.is_deleted='N' and s.nfsai=" . $nped . ") n
        set p.fpgpro=fpgpro+n.qusai
        where p.is_deleted='N' and p.codpro=n.prsai";
        mysqli_query($db, $csql);

        $csql = "UPDATE LOCAL_LOC l, 
        (select s.prsai,s.qusai,n.lojasai from SAIDAS_SAI n inner join PROSAI_SAI s on s.is_deleted='N' and s.nfsai=n.notasai  where n.is_deleted='N' and n.notasai=" . $nped . ") n
        set l.fpgloc=fpgloc+n.qusai
        where l.is_deleted='N' and l.proloc=n.prsai and l.locloc=n.lojasai";
        mysqli_query($db, $csql);
    }
    $csql = "update LOTESDOC_CLI SET valolote=valolote+$nTvalor_acrescimo,baselote=" . $olcam["MOEDA1"] . ",camblote=" . $olcam["MOEDA" . $nmoedaban] . " where recno=" . $olot->nrecno;

    mysqli_query($db, $csql);

    mysqli_query($db, "update NOTASPIX_CAX SET INICIO=0 where find_in_set(recno,'" . implode(",", $anotaspix) . "') ");

    //verifica promoção 300
    $nrows = 0;
    $apromo = array();
    if (medfile("NOTASPRM.PRM", $db, $nrows)) {
        $ltem = false;
        foreach ($anotasrec as $value) {
            $ltem = mysqli_num_rows(mysqli_query($db, "select p.recno from NOTASPRM_PRM p,SAIDAS_SAI n where n.notasai=$value and p.recno=1 and !find_in_set(n.lojasai,replace(p.exclojas,'-',','))")) > 0;
            if ($ltem) {
                break;
            }
        }
        if ($ltem) {
            $olinprm = mysqli_fetch_array(mysqli_query($db, "select * from NOTASPRM_PRM WHERE RECNO=1"));
            if ($olinprm["MAXNOTA"] > $olinprm["QUANOTA"]) {
                mysqli_query($db, "update NOTASPRM_PRM set quanota=quanota+1,hora=current_time() where recno=1");
                $i = 0;
                foreach ($anotasrec as $value) {
                    if ($i == 0) {
                        $csql = "select '" . ($olinprm["QUANOTA"] + 1) . "' as numero,date_format(current_date(),'%d/%m/%y') as data,current_time() as hora,concat(n.notasai,'-',digito(n.notasai)) as nota,c.codigo as cliente,c.nome as ccliente
                        ,c.endereco,c.cidade,c.estado,if(trim(c.celular)!='',c.celular,c.telefone) as telefone
                        from SAIDAS_SAI n
                        inner join CLIENTE_PGY c on c.is_deleted='N' and c.codigo=n.cliesai
                        where n.notasai=" . $value;
                        $apromo = mysqli_fetch_array(mysqli_query($db, $csql));
                    }
                    $i++;
                    $onot = new Mediator3("NOTASCAB.PRM", W_CRIAR, '', '', $db);
                    $onot->aadd("dataven", "current_date()", true);
                    $onot->aadd("datagrav", "current_date()", true);
                    $onot->aadd("horagrav", "current_time()", true);
                    $onot->aadd("notaven", $value);
                    $onot->grava();
                }
            }
        }
    }

    if ($ocfgcec["PACOTE_WEB"] == "S") {
        $creferro='';
        GeraEntrega($anotasrec,$creferro);
    }

    $aVoucherRef = array();
    /* GeraVoucherNota($anotasrec, $aVoucherRef);
      $aret["voucher"] = $aVoucherRef;
      $aret["voucherimp"] = array();
      foreach ($aVoucherRef as $value) {
      $cimp = "";
      ImprimeVoucher($value, $cimp);
      $aret["voucherimp"][] = $cimp;
      }
     */
    $acupons = array();
    $acuponsimp = array();
    $cerro = '';
    foreach ($anotasrec as $value) {
        $acup = array();
        EmiteCupomPromo($value, $cerro, $acup);
        foreach ($acup as $value1) {
            $acupons[] = $value1;
        }
        $acup = array();
        ImprimeCupom($value, $acup);
        foreach ($acup as $value1) {
            $acuponsimp[] = $value1;
        }
    }
    $aret["promo"] = $apromo;
    $aret["acupons"] = $acupons;
    $aret["acuponsimp"] = $acuponsimp;
    echo json_encode($aret);
    return;
}

function Valosai2Base($nvalosai = 0, $nmoedabase = 1, $nmoedacambio = 1, $acambio = '', $ddata = '', $ncambsai = 0, $nbasesai = 0) {
    global $db;
    global $noperador;
    if ($ddata) {
        $date = date_create();
        $ddata = date_format($date, "Y-m-d");
    }
    if (!$acambio) {
        $acambio = mysqli_fetch_array(mysqli_query($db, "select * from CAMBIO_CAM where is_deleted='N' and datcam='$ddata'"));
    }
    if (!$ncambsai) {
        $ncambsai = $acambio["MOEDA" . $nmoedacambio];
    }
    if (!$nbasesai) {
        $nbasesai = $acambio["MOEDA" . $nmoedabase];
    }
    return $nvalosai / $ncambsai * $nbasesai;
}

function Base2Valosai($nbase = 0, $nmoedabase = 1, $nmoedacambio = 1, $acambio = '', $ddata = '', $ncambsai = 0, $nbasesai = 0) {
    global $db;
    global $noperador;
    if ($ddata) {
        $date = date_create();
        $ddata = date_format($date, "Y-m-d");
    }
    if (!$acambio) {
        $acambio = mysqli_fetch_array(mysqli_query($db, "select * from CAMBIO_CAM where is_deleted='N' and datcam='$ddata'"));
    }
    if (!$ncambsai) {
        $ncambsai = $acambio["MOEDA" . $nmoedacambio];
    }
    if (!$nbasesai) {
        $nbasesai = $acambio["MOEDA" . $nmoedabase];
    }
    return $nbase / $nbasesai * $ncambsai;
}

function GeraVoucherNota($aNota, &$aVoucherRef) {
    global $db;
    global $noperador;
    $aVoucherRef = array();

    if (empty($aNota)) {
        //NOTA VAZIA
        return 1;
    }
    Sort($aNota);

//    IF SelVal( "select count(*) from VOUCHER_DET WHERE IS_DELETED='N' AND NOTA=" + AsSql( nNota ), "N" ) > 0
    $cStr = "select count(*) from VOUCHER_DET WHERE IS_DELETED='N' AND (0 ";
    foreach ($aNota as $value) {
        $cStr .= " or nota=" . $value . " or find_in_set($value,notas) ";
    }
    $cStr .= ") ";

    //IF MedSelVal( cStr,, "N" ) > 0
    if (mysqli_fetch_row(mysqli_query($db, $cStr))[0] > 0) {
        //VOUCHER JÁ EMITIDO
        return 2;
    }

    $cStr = "select p.codpro  as codigo,sum(s.qusai) as quant,sum(s.cusai*s.qusai) as preco,p.grupro  as grupo,p.sgrupro as sgrupo,p.forpro  as fornecedor,p.marcpro as marca from PROSAI_SAI s inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai 
             where s.is_deleted='N' and (0";
    foreach ($aNota as $value) {
        $olinnot = mysqli_fetch_array(mysqli_query($db, "select sitsai,is_deleted,lojasai from SAIDAS_SAI WHERE NOTASAI=$value"));
        if ($olinnot["sitsai"] !== "S" || $olinnot["is_deleted"] == "Y") {
            return 3;
        }
        $cStr .= " or s.nfsai=$value";
        $nlojasai = $olinnot["lojasai"];
    }
    $cStr .= ") group by codpro";
    $cStr = "select codigo,quant,preco/quant as preco,grupo,sgrupo,fornecedor,marca from (" . $cStr . ") p order by codigo ";

    $otabpro = mysqli_query($db, $cStr);

    $cVou = "select * from VOUCHER_PRM 
            where inicio<=date2unix(now())  and final>=date2unix(now()) and suspenso='N' and is_deleted='N' 
            and if(loja='',1,locate('-" . $nlojasai . "-',concat('-',loja,'-'))>0 )
            and modo=0 ";
    $otabvou = mysqli_query($db, $cVou);

    if (mysqli_num_rows($otabvou) == 0) {
        //NENHUM VOUCHER ATIVO
        return 5;
    }

    $aVoucher = array();
    $osql = array();
    while ($olinvou = mysqli_fetch_array($otabvou)) {
        $osql[] = $olinvou;
        $aVoucher[$olinvou["CODIGO"]] = array($olinvou["CODIGO"], FALSE, FALSE, FALSE, FALSE);
    }
//    $apro = array();
//    while ($olinpro = mysqli_fetch_array($otabpro)) {
//        $apro[] = $olinpro;
//    }
    //produto
    $i = 0;
    $apro = array();
    while ($olinpro = mysqli_fetch_array($otabpro)) {
        $apro[] = $olinpro;
        $otabvou = mysqli_query($db, $cVou);
        while ($olinvou = mysqli_fetch_array($otabvou)) {
            //quantidade emitida
            if ($olinvou["QUANTIDEMI"] >= $olinvou["QUANTIDADE"]) {
                continue;
            }

            // se é por produto
            if (!(strpos("-" . $olinvou["PRODUTO"] . "-", "-" . $olinpro["codigo"] . "-") === false)) {
                $aAux = explode("-", $olinvou["PRODUTO"]);
                $npos = array_search($olinpro["codigo"], $aAux);
                $aAux = explode("-", $olinvou["PRODUTOQ"]);
                $nQua = $aAux[$npos];
                //quantidade não atinge o minimo necessário
                if ($nQua > $olinpro["quant"]) {
                    continue;
                }
                //valor não atinge o mínimo necessário
                if ($olinvou["MINIMO"] != 0) {
                    if ($olinvou["MINIMO"] <= $olinpro["quant"] * $olinpro["preco"]) {
                        //AAdd(aVoucher,{(osql)->codigo,1})
                        $aVoucher[$olinvou["CODIGO"]][1] = TRUE;
                        $aVoucher[$olinvou["CODIGO"]][2] = TRUE;
                        $aVoucher[$olinvou["CODIGO"]][3] = TRUE;
                        $aVoucher[$olinvou["CODIGO"]][4] = TRUE;
                    }
                } else {
                    //                    AAdd(aVoucher,{(osql)->codigo,aPro[i,2]})
                    $aVoucher[$olinvou["CODIGO"]][1] = TRUE;
                    $aVoucher[$olinvou["CODIGO"]][2] = TRUE;
                    $aVoucher[$olinvou["CODIGO"]][3] = TRUE;
                    $aVoucher[$olinvou["CODIGO"]][4] = TRUE;
                }
            }
        }
    }



    $aposicoes = array("GRUPO", "SGRUPO", "FORNEC", "MARCA");
    //grupo
    $ncount = 0;
    foreach ($aposicoes as $xvalue) {
        $aAux1 = array();
        for ($i = 0; $i < count($apro); $i++) {
            $naux = $apro[$i][4 - 1 + $ncount];

            if (!$aAux1[$naux]) {
                $aAux1[$naux] = array("qua" => 0, "val" => 0);
            }
            $aAux1[$naux]["qua"] += $apro[$i][2 - 1];
            $aAux1[$naux]["val"] += $apro[$i][2 - 1] * $apro[$i][3 - 1];
        }
        foreach ($aAux1 as $key => $value) {
            foreach ($osql as $ovou) {
                if ($ovou["QUANTIDEMI"] >= $ovou["QUANTIDADE"]) {
                    continue;
                }
                // se é por xvalue
                if (trim($ovou[$xvalue]) == '') {
                    $aVoucher[$ovou["CODIGO"]][1 + $ncount] = TRUE;
                } elseif (!(strpos("-" . $key . "-", "-" . $ovou[$xvalue] . "-") === false)) {
                    //valor não atinge o mínimo necessário
                    if ($ovou["MINIMO"] != 0) {
                        if ($ovou["MINIMO"] <= $value["val"]) {
                            //AAdd(aVoucher,{(osql)->codigo,1})
                            $aVoucher[$ovou["CODIGO"]][1 + $ncount] = TRUE;
                        }
                    } else {
                        $aVoucher[$vou["CODIGO"]][1 + $ncount] = TRUE;
                    }
                }
            }
        }
        $ncount += 1;
    }

    /*

      //subgrupo
      aAux1 := { }
      FOR i := 1 TO Len( aPro )
      IF ( nAux := AScan( aAux1, { | x | x[ 1 ] == aPro[ i, 5 ] } ) ) == 0
      AAdd( aAux1, { aPro[ i, 5 ], 0, 0 } )
      nAux := Len( aAux1 )
      ENDIF
      aAux1[ nAux, 2 ] += aPro[ i, 2 ]
      aAux1[ nAux, 3 ] += aPro[ i, 2 ] * aPro[ i, 3 ]
      NEXT

      FOR i := 1 TO Len( aAux1 )
      ( oSql ) ->( DBGoTop() )
      WHILE ! ( oSql ) ->( Eof() )
      //quantidade emitida
      IF ( oSql ) ->quantidemi >= ( oSql ) ->quantidade
      ( oSql ) ->( DBSkip() )
      LOOP
      ENDIF
      // se é por subgrupo
      IF Empty( ( oSql ) ->sgrupo )
      nAux := AScan( aVoucher, { | x | x[ 1 ] == ( oSql ) ->codigo } )
      aVoucher[ nAux, 3 ] := TRUE
      ELSEIF "-" + MyTrim( aAux1[ i, 1 ] ) + "-" $ "-" + AllTrim( ( oSql ) ->sgrupo ) + "-"
      //valor não atinge o mínimo necessário
      nAux := AScan( aVoucher, { | x | x[ 1 ] == ( oSql ) ->codigo } )
      IF ( oSql ) ->minimo != 0
      IF ( oSql ) ->minimo <= aAux1[ i, 3 ]
      //AAdd(aVoucher,{(osql)->codigo,1})
      aVoucher[ nAux, 3 ] := TRUE
      ENDIF
      ELSE
      aVoucher[ nAux, 3 ] := TRUE
      ENDIF
      ENDIF
      ( oSql ) ->( DBSkip() )
      ENDDO
      NEXT





      //fornecedor
      aAux1 := { }
      FOR i := 1 TO Len( aPro )
      IF ( nAux := AScan( aAux1, { | x | x[ 1 ] == aPro[ i, 6 ] } ) ) == 0
      AAdd( aAux1, { aPro[ i, 6 ], 0, 0 } )
      nAux := Len( aAux1 )
      ENDIF
      aAux1[ nAux, 2 ] += aPro[ i, 2 ]
      aAux1[ nAux, 3 ] += aPro[ i, 2 ] * aPro[ i, 3 ]
      NEXT

      FOR i := 1 TO Len( aAux1 )
      ( oSql ) ->( DBGoTop() )
      WHILE ! ( oSql ) ->( Eof() )
      //quantidade emitida
      IF ( oSql ) ->quantidemi >= ( oSql ) ->quantidade
      ( oSql ) ->( DBSkip() )
      LOOP
      ENDIF
      // se é por fornecedor
      IF Empty( ( oSql ) ->fornec )
      nAux := AScan( aVoucher, { | x | x[ 1 ] == ( oSql ) ->codigo } )
      aVoucher[ nAux, 4 ] := TRUE
      ELSEIF "-" + MyTrim( aAux1[ i, 1 ] ) + "-" $ "-" + AllTrim( ( oSql ) ->fornec ) + "-"
      //valor não atinge o mínimo necessário
      nAux := AScan( aVoucher, { | x | x[ 1 ] == ( oSql ) ->codigo } )
      IF ( oSql ) ->minimo != 0
      IF ( oSql ) ->minimo <= aAux1[ i, 3 ]
      //AAdd(aVoucher,{(osql)->codigo,1})
      aVoucher[ nAux, 4 ] := TRUE
      ENDIF
      ELSE
      aVoucher[ nAux, 4 ] := TRUE
      ENDIF
      ENDIF
      ( oSql ) ->( DBSkip() )
      ENDDO
      NEXT





      //marcas
      aAux1 := { }
      FOR i := 1 TO Len( aPro )
      IF ( nAux := AScan( aAux1, { | x | x[ 1 ] == aPro[ i, 7 ] } ) ) == 0
      AAdd( aAux1, { aPro[ i, 7 ], 0, 0 } )
      nAux := Len( aAux1 )
      ENDIF
      aAux1[ nAux, 2 ] += aPro[ i, 2 ]
      aAux1[ nAux, 3 ] += aPro[ i, 2 ] * aPro[ i, 3 ]
      NEXT

      FOR i := 1 TO Len( aAux1 )
      ( oSql ) ->( DBGoTop() )
      WHILE ! ( oSql ) ->( Eof() )
      //quantidade emitida
      IF ( oSql ) ->quantidemi >= ( oSql ) ->quantidade
      ( oSql ) ->( DBSkip() )
      LOOP
      ENDIF
      // se é por marca
      IF Empty( ( oSql ) ->marca )
      nAux := AScan( aVoucher, { | x | x[ 1 ] == ( oSql ) ->codigo } )
      aVoucher[ nAux, 5 ] := TRUE
      ELSEIF "-" + MyTrim( aAux1[ i, 1 ] ) + "-" $ "-" + AllTrim( ( oSql ) ->marca ) + "-"
      //valor não atinge o mínimo necessário
      nAux := AScan( aVoucher, { | x | x[ 1 ] == ( oSql ) ->codigo } )
      IF ( oSql ) ->minimo != 0
      IF ( oSql ) ->minimo <= aAux1[ i, 3 ]
      //AAdd(aVoucher,{(osql)->codigo,1})
      aVoucher[ nAux, 5 ] := TRUE
      ENDIF
      ELSE
      aVoucher[ nAux, 5 ] := TRUE
      ENDIF
      ENDIF
      ( oSql ) ->( DBSkip() )
      ENDDO
      NEXT


     */

    $nAux = 0;
    foreach ($aVoucher as $value) {
        $nAux += $value[1] && $value[2] && $value[3] && $value[4] ? 1 : 0;
    }

    if ($nAux == 0) {
        //NENHUM VOUCHER ATIVO
        return 5;
    }
    //AbreArq( "voucher.prm", oVou, FALSE, FALSE, "idx" )
    //AbreArq( "voucher.det", oDet, FALSE, FALSE, "idx" )
    foreach ($aVoucher as $value) {
        mysqli_query($db, "update VOUCHER_PRM set quantiemi=quantiemi+1 where codigo=" . $value[0]);
        if ($value[1] && $value[2] && $value[3] && $value[4]) {
            $cSerie = GeraVoucher();
            $ovou = new Mediator3("VOUCHER.DET", W_CRIAR, '', '', $db);
            $ovou->aadd("codigo", $value[0]);
            $ovou->aadd("serie", $cSerie);
            $ovou->aadd("nota", $aNota[0]);
            $ovou->aadd("notas", implode(",", $aNota));
            $ovou->aadd("usuario", $noperador);
            $ovou->aadd("data", Date2Unix());
            $ovou->grava();
            $aVoucherRef[] = $cSerie;
        }
    }
    /*
      FOR i := 1 TO Len( aVoucher )
      IF aVoucher[ i, 2 ] .AND. aVoucher[ i, 3 ] .AND. aVoucher[ i, 4 ] .AND. aVoucher[ i, 5 ]
      ( oVou ) ->( DBSeek( aVoucher[ i, 1 ] ) )
      ( oVou ) ->( RegLock() )
      ( oVou ) ->quantidemi += 1
      ( oVou ) ->( DBCommit() )

      ( oDet ) ->( ApLock() )
      ( oDet ) ->codigo     := aVoucher[ i, 1 ]
      ( oDet ) ->serie         := GeraVoucher()
      ( oDet ) ->nota         := $aNota[ 1 ]
      ( oDet ) ->notas         := array2token( aNota, "," )

      ( oDet ) ->usuario     := IF( Type( "usuario" ) == "A" .AND. Len( m->usuario ) > 0, m->Usuario[ 1 ], 1 )
      ( oDet ) ->DATA         := Date2Unix(,, TRUE )
      ( oDet ) ->( DBCommit() )
      AAdd( aVoucherRef, ( oDet ) ->serie )
      ENDIF
      NEXT
      ( oVou ) ->( DBCloseArea() )
      ( oDet ) ->( DBCloseArea() )

      DBSelectArea( nArea )
      RETURN 0
     */
    return 0;
}

function GeraVoucher() {
    global $db;
    global $noperador;
    while (true) {
        $cserie = strtoupper(randString(10));
        if (mysqli_fetch_row(mysqli_query($db, "select recno from VOUCHER_DET where serie='$cserie'"))[0] + 0 == 0) {
            break;
        }
    }
    return $cserie;
}

function ImprimeVoucher($cVoucher, &$cRefVoucher) {

    global $db;
    global $noperador;
    $cSaida = "";
    $cRefVoucher = "";

    define("P_NEG_ON", chr(27) . chr(69) . '1'); // = String.fromCharCode(27, 69, 1); //ESC E 1
    define("P_NEG_OFF", chr(27) . chr(69) . '0'); // = String.fromCharCode(27, 69, 0); //ESC E 0

    $cVoucher = Trim(strtoupper($cVoucher));
    $otabdet = mysqli_query($db, "select * from VOUCHER_DET WHERE IS_DELETED='N' AND SERIE='$cVoucher' ");
    if (mysqli_num_rows($otabdet) == 0) {
        return false;
    }
    $olindet = mysqli_fetch_array($otabdet);

    $otabvou = mysqli_query($db, "select * from VOUCHER_PRM WHERE IS_DELETED='N' AND CODIGO=" . $olindet["CODIGO"]);
    if (mysqli_num_rows($otabvou) == 0) {
        return false;
    }
    $olinvou = mysqli_fetch_array($otabvou);

    $olincfg = mysqli_fetch_array(mysqli_query($db, "select * from VOUCHER_CFG WHERE IS_DELETED='N' AND recno=1"));

    $cAux = Trim($olincfg["CABECALHO"]);
    $cAux = str_replace(chr(141), "\n" . $cAux);
    $cAux = str_replace("\r\n", "\n" . $cAux);

    if (!Empty($cAux)) {
        $cAux = StrTran($cAux, "<B>", Chr(27) + "E");
        $cAux = StrTran($cAux, "</B>", Chr(27) + "F");
        $cAux = StrTran($cAux, "<D>", "");
        $cAux = StrTran($cAux, "</D>", "");
        $cSaida .= $cAux . "\n";
    }




    $cSaida .= "VOUCHER: " . P_NEG_ON . $cVoucher . P_NEG_OFF . "\n";
    if ($olindet["NOTAD"] > 0) {
        $cSaida .= "**** JÁ UTILIZADO ****\N";
    }
    $cSaida .= "Emissão: " . Unix2Date($olindet["DATA"])[0] . "\n";
    if ($olinvou["DIAS"] == 0) {
        $cSaida .= "Validade:" . Unix2Date($olinvou["INICIOV"])[1] . " a " . Unix2Date($olinvou["FINALV"])[1] . "\n";
    } else {
        $cSaida .= "Validade Até:" . Unix2Date($olindet["DATA"] + $olinvou["DIAS"] * 24 * 60 * 60)[1] . "\n";
    }

    if (!Empty($olindet["NOTA"])) {
        $cSaida .= "Nota de compra:" . $olindet["NOTA"] . "-" . Digito($olindet["NOTA"]) . "\n";
    }
    //IF ( oVou ) ->modo == 0 .AND. ! Empty( ( oDet ) ->notad )
    //    cSaida += Chr( 27 ) + "E" + ( "Utilizado na nota:" ) + Chr( 27 ) + "F" + MyTrim( ( oDet ) ->notad ) + "-" + MyTrim( Digito( ( oDet ) ->NOTA ) ) + CR
    //ENDIF

    if ($olinvou["MODO"] > 1) {
        $cSaida .= "Origem do Voucher:" . ($olinvou["MODO"] == 1 ? "Internet" : ($olinvou["MODO"] == 2 ? "Promoção" : ($olinvou["MODO"] == 3 ? "Evendo" : "")) ) . "\n";
    }
    if (!Empty(trim($olinvou["PROMOCAO"]))) {
        $cSaida .= "Utilizável em:" . $olinvou["PROMOCAO"] . "\n";
    }
    if (!Empty(TRIM($olinvou["PRODUTOS"]))) {
        $cSaida .= "Utilizável nos Produtos:\n";
        $aPro = explode("-", $olinvou["PRODUTOS"]);
        $aQua = EXPLODE("-", $olinvou["PRODUTOQS"]);

        for ($i = 0; $i < count($aPro); $i++) {
            $olinpro = mysqli_fetch_row(mysqli_query($db, "select codpro,nompro from PRODUTO_PRO WHERE IS_DELETED='N' AND codpro=" . $aPro[$i]));
            $cSaida .= poedigito($olinpro[0]) . "-" . $olinpro[1] . "\n";
            if ($aQua[$i] + 0 > 0) {
                $cSaida .= "  na compra de " . $aQua[$i] . " unidades ou acima\n";
            }
        }
    }
    if (!Empty(trim($olinvou["LOJAS"]))) {
        $cSaida .= "Utilizável nas Lojas:\n";
        $otab = mysqli_query($db, "select codemp,nomemp from EMPRESA_EMP WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codemp,'-'),'-" . trim($olinvou["LOJAS"]) . "-')");
        while ($olin = mysqli_fetch_array($otab)) {
            $cSaida .= " " . $olin[0] . "-" . $olin[1] . "\n";
        }
    }
    if (!Empty(trim($olinvou["GRUPOS"]))) {
        $cSaida .= "Utilizável nos Grupos:\n";
        $otab = mysqli_query($db, "select codgru,nomgru from GRUPO_GRU WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codgru,'-'),'-" . trim($olinvou["GRUPOS"]) . "-')");
        while ($olin = mysqli_fetch_array($otab)) {
            $cSaida .= " " . $olin[0] . "-" . $olin[1] . "\n";
        }
    }
    if (!Empty(trim($olinvou["SGRUPOS"]))) {
        $cSaida .= "Utilizável nos SubGrupos:\n";
        $otab = mysqli_query($db, "select codsgru,nomsgru from SGRUPO_SGR WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codsgru,'-'),'-" . trim($olinvou["SGRUPOS"]) . "-')");
        while ($olin = mysqli_fetch_array($otab)) {
            $cSaida .= " " . $olin[0] . "-" . $olin[1] . "\n";
        }
    }
    if (!Empty(trim($olinvou["MARCAS"]))) {
        $cSaida .= "Utilizável nas Marcas:\n";
        $otab = mysqli_query($db, "select codmarc,nommarc from MARCAS_MAR WHERE IS_DELETED='N' AND LOCATE(CONCAT('-',codmarc,'-'),'-" . trim($olinvou["MARCAS"]) . "-')");
        while ($olin = mysqli_fetch_array($otab)) {
            $cSaida .= " " . $olin[0] . "-" . $olin[1] . "\n";
        }
    }
    if ($olinvou["DESCONTO"] > 0) {
        $cSaida .= "Desconto:" . number_format($olinvou["DESCONTO"], 2, ",", ".") . " %\n";
    }
    if ($olinvou["VALOR"] > 0) {
        $cSaida .= "Valor Desconto: U$ " . number_format($olinvou["VALOR"], 2, ",", ".") . "\n";
    }
    if ($olinvou["ACIMA"] > 0) {
        $cSaida .= "Compras acima de: U$ " . number_format($olinvou["ACIMA"], 2, ",", ".") . "\n";
    }

    //barra ?
    //    cSaida+=CR+_chr(29)+_chr(72)+_chr(0)+      _chr(29)+_chr(107)+_chr(2)+StrZero( 123,12,0)  +_chr(0)
    //    cSaida+=CR+CHR(29)+CHR(107)+CHR(72)+CHR(Len(cVoucher))+cVoucher+CR
    // cSaida += CR + Chr( 29 ) + Chr( 107 ) + Chr( 73 ) + Chr( Len( cVoucher ) ) + cVoucher + CR

    $cAux = Trim($olincfg["RODAPE"]);
    $cAux = str_replace(chr(141), "\n" . $cAux);
    $cAux = str_replace("\r\n", "\n" . $cAux);

    if (!Empty($cAux)) {
        $cAux = StrTran($cAux, "<B>", Chr(27) + "E");
        $cAux = StrTran($cAux, "</B>", Chr(27) + "F");
        $cAux = StrTran($cAux, "<D>", "");
        $cAux = StrTran($cAux, "</D>", "");
        $cSaida .= $cAux . "\n";
    }



    $cSaida .= "\n\n\n\n";

    $cRefVoucher = $cSaida;

    return true;
}

function EmiteCupomPromo($nNota, &$cRefErro = '', &$acupom = '', &$aEmitidos = '', $lTesta = false) {
    define("CUP_CODIGO", 1 - 1);
    define("CUP_FORNEC", 11 - 1);
    define("CUP_GRUPO", 9 - 1);
    define("CUP_ITENS", 13 - 1);
    define("CUP_ITOTAL", 14 - 1);
    define("CUP_LIMITE", 6 - 1);
    define("CUP_LOJA", 8 - 1);
    define("CUP_MARCA", 12 - 1);
    define("CUP_NCUPOMVTOTAL", 16 - 1);
    define("CUP_NOME", 2 - 1);
    define("CUP_PRODUTO", 7 - 1);
    define("CUP_QUANT", 5 - 1);
    define("CUP_SGRUPO", 10 - 1);
    define("CUP_SORTEIO", 3 - 1);
    define("CUP_VALOR", 4 - 1);
    define("CUP_VTOTAL", 15 - 1);
    define("CUP_TIPOCLI", 17 - 1);
    define("CUP_UNICA_DIA", 18 - 1);
    define("CUP_UNICA_NOT", 19 - 1);

    global $db;
    if (!medFile("CUPOM.PRM") || !medFile("CUPOMDET.PRM")) {
        $cRefErro = "Arquivo CUPOM nao existe";
        return false;
    }
    $acupom = array();
    $aEmitidos = array();

    $cRefErro = "";
    if (Empty($nNota)) {
        $cRefErro = "Nota nao passada";
        return false;
    }

    if (mysqli_fetch_row(mysqli_query($db, "select count(*) as total from CUPOMDET_PRM WHERE IS_DELETED='N' AND NOTA=" . assql($nNota)))[0] + 0 > 0) {
        $cRefErro = "Cupons ja emitidos para esta nota";
        return false;
    }

    $ncliente = 0;
    $cStr = "select p.codpro,convert(if(n.datarec>'1001-01-01',n.datarec,n.datasai),date) as data,if(n.datarec>'1000-01-01',n.horarec,n.horasai) as hora,n.cliesai as cliente,n.sitsai as paga,n.retisai as retirada,n.valosai as valor,n.lojasai as loja 
            ,s.prsai as produto,s.cusai as preco,s.qusai as quant,s.qusai*s.cusai as total 
            ,p.grupro as grupo,p.sgrupro as sgrupo,p.forpro as fornec,p.marcpro as marca,c.grucli 
            from SAIDAS_SAI n 
            inner join PROSAI_SAI s on s.is_deleted='N' and s.nfsai=n.recno 
            inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=s.prsai
            inner join CLIENTE_CLI c on c.is_deleted='N' and c.codcli=n.cliesai
            where n.is_deleted='N' and n.recno=" . AsSql($nNota);
    $onot = mysqli_query($db, $cStr);
    if (mysqli_num_rows($onot) == 0) {
        $cRefErro = "Nota nao localizada";
        return false;
    }

    $anot = array();
    while ($olnot = mysqli_fetch_array($onot)) {
        $anot[] = $olnot;
        $ncliente = $olnot["cliente"];
    }

    if ($anot[0]["paga"] == "N") {
        $cRefErro = "Nota nao paga";
        return false;
    }
    /*
      IF ! AbreArq( "cupom.prm", oCup, FALSE, TRUE )
      cRefErro := "Erro abrindo Arquivo de cupom"
      ( oNot ) ->( DBCloseArea() )
      DBSelectArea( nArea )
      RETURN FALSE
      ENDIF
      aAux := ( oCup ) ->( DBStruct() )
      ( oCup ) ->( DBCloseArea() )
      IF AScan( aAux, { | x | x[ 1 ] == "TIPOCLI" } ) == 0
      cRefErro := "Arquivo de cupom falta campo"
      ( oNot ) ->( DBCloseArea() )
      DBSelectArea( nArea )
      RETURN FALSE
      ENDIF
     */

    $w_cup = mysqli_fetch_row(mysqli_query($db, "select count(*) from CUPOM_PRM"))[0] + 0;
    if (Empty($w_cup)) {
        return true;
    }
    $cStr = "select c.codigo,c.nome,c.sorteio,c.valor,c.quant,c.limite,c.produto,c.loja,c.grupo,c.sgrupo,c.fornec,c.marca,c.tipocli,convert(if(c.unica_dia='Y',1,0),decimal(5,0)) as unica_dia,convert(if(c.unica_not='Y',1,0),decimal(5,0)) as unica_not 
            from CUPOM_PRM c 
            where c.is_deleted='N' and c.suspensa='N' and c.inicio<=Date2Unix(concat(" . AsSql($anot[0]["data"]) . ",' '," . AsSql($anot[0]["hora"]) .
            ")) and c.final>=Date2Unix(concat(" . AsSql($anot[0]["data"]) . ",' '," . AsSql($anot[0]["hora"]) . ")) 
            order by c.codigo ";

    $otabcup = mysqli_query($db, $cStr);
    if (mysqli_num_rows($otabcup) == 0) {
        return true;
    }
    //oCup:=MedServerSql{,cStr}
    $acupom = array();
    while ($olincup = mysqli_fetch_array($otabcup)) {
        $acupom[] = array(
            $olincup["codigo"], $olincup["nome"], $olincup["sorteio"], $olincup["valor"], $olincup["quant"]
            , $olincup["limite"], $olincup["produto"], $olincup["loja"], $olincup["grupo"], $olincup["sgrupo"]
            , $olincup["fornec"], $olincup["marca"], 0, 0, 0
            , 0, $olincup["tipocli"], $olincup["unica_dia"], $olincup["unica_not"]);
        //$acupom[] = $olincup;
    }
    /*
      WHILE ! ( oCup ) ->( Eof() )
      AAdd( aCupom, { ( oCup ) ->codigo, ( oCup ) ->nome, ( oCup ) ->sorteio, ( oCup ) ->valor, ( oCup ) ->quant, ( oCup ) ->limite, ( oCup ) ->produto, Token2Array( ( oCup ) ->loja, ",", TRUE, TRUE ), Token2Array( ( oCup ) ->grupo, ",", TRUE, TRUE ), Token2Array( ( oCup ) ->sgrupo, ",", TRUE, TRUE ), Token2Array( ( oCup ) ->fornec, ",", TRUE, TRUE ), Token2Array( ( oCup ) ->marca, ",", TRUE, TRUE ), 0, 0, 0, 0, Token2Array( ( oCup ) ->tipocli, ",", TRUE, TRUE ), ( oCup ) ->unica_dia, ( oCup ) ->unica_not } )
      ( oCup ) ->( DBSkip() )
      ENDDO
      ( oCup ) ->( DBCloseArea() )
     */

    foreach ($anot as $not) {
        $i = -1;
        foreach ($acupom as $cup) {
            $i++;

            //unica dia
            if ($cup[CUP_UNICA_DIA] > 0) {
                $naux = mysqli_fetch_array(mysqli_query($db, "select count(*) as total from CUPOMDET_PRM WHERE IS_DELETED='N' AND CLIENTE=" . $not["cliente"] . " and data>=" . Date2Unix() . " and data<=" . Date2Unix()))[0];
                if ($naux > 0) {
                    continue;
                }
            }

            //loja
            if (!Empty(trim($cup[CUP_LOJA])) && strpos("," . trim($cup[CUP_LOJA]) . ",", "," . $not["loja"] . ",") === false) {
                continue;
            }
            //tipo cliente
            if (!Empty(trim($cup[CUP_TIPOCLI])) && strpos("," . trim($cup[CUP_TIPOCLI]) . ",", "," . $not["grucli"] . ",") === false) {
                continue;
            }
            /*
              IF ! Empty( aCupom[ i, CUP_TIPOCLI ] ) .AND. AScan( aCupom[ i, CUP_TIPOCLI ], ( oNot ) ->GRUCLI ) == 0
              LOOP
              ENDIF
             */
            //produto
            if (!Empty(trim($cup[CUP_PRODUTO]))) {
                if ($not["produto"] == $cup[CUP_PRODUTO]) {
                    $acupom[$i][CUP_ITENS] += 1;
                    $acupom[$i][CUP_ITOTAL] += $not["quant"];
                    $acupom[$i][CUP_VTOTAL] += $not["total"];
                }
                continue;
            }
            //grupo
            if (!Empty(trim($cup[CUP_GRUPO])) && strpos("," . trim($cup[CUP_GRUPO]) . ",", "," . $not["grupo"] . ",") === false) {
                continue;
            }
            /*
              IF ! Empty( aCupom[ i, CUP_GRUPO ] ) .AND. AScan( aCupom[ i, CUP_GRUPO ], ( oNot ) ->grupo ) == 0
              LOOP
              ENDIF
             */
            //Sgrupo
            if (!Empty(trim($cup[CUP_SGRUPO])) && strpos("," . trim($cup[CUP_SGRUPO]) . ",", "," . $not["sgrupo"] . ",") === false) {
                continue;
            }
            /*
              IF ! Empty( aCupom[ i, CUP_SGRUPO ] ) .AND. AScan( aCupom[ i, CUP_SGRUPO ], ( oNot ) ->sgrupo ) == 0
              LOOP
              ENDIF
             */
            //FORNECEDOR
            if (!Empty(trim($cup[CUP_FORNEC])) && strpos("," . trim($cup[CUP_FORNEC]) . ",", "," . $not["fornec"] . ",") === false) {
                continue;
            }
            /*
              IF ! Empty( aCupom[ i, CUP_FORNEC ] ) .AND. AScan( aCupom[ i, CUP_FORNEC ], ( oNot ) ->fornec ) == 0
              LOOP
              ENDIF
             * 
             */
            //marca
            if (!Empty(trim($cup[CUP_MARCA])) && strpos("," . trim($cup[CUP_MARCA]) . ",", "," . $not["marca"] . ",") === false) {
                continue;
            }
            /*
              IF ! Empty( aCupom[ i, CUP_MARCA ] ) .AND. AScan( aCupom[ i, CUP_MARCA ], ( oNot ) ->marca ) == 0
              LOOP
              ENDIF
             * 
             */
            $acupom[$i][CUP_ITENS] += 1;
            $acupom[$i][CUP_ITOTAL] += $not["quant"];
            $acupom[$i][CUP_VTOTAL] += $not["total"];
        }
    }

    for ($i = 0; $i < count($acupom); $i++) {
        if ($acupom[$i][CUP_QUANT] > 0) {
            $naux = floor($acupom[$i][CUP_ITOTAL] / $acupom[$i][CUP_QUANT]);
            $acupom[$i][CUP_NCUPOMVTOTAL] = $naux;
        } else {
            $naux = floor($acupom[$i][CUP_VTOTAL] / $acupom[$i][CUP_VALOR]);
            $acupom[$i][CUP_NCUPOMVTOTAL] = $naux;
        }
    }

    /*
      AbreArq( "cupomdet.prm", odet, FALSE, FALSE, "idx" )
      ( odet ) ->( DBSetOrder( "TOKEN" ) )
     */


    for ($i = 0; $i < count($acupom); $i++) {
        if ($acupom[$i][CUP_NCUPOMVTOTAL] == 0) {
            continue;
        }

        $aaux = MedDbf2Array("select quant_i,quant_f,quant_r from CUPOMQNT_PRM WHERE IS_DELETED='N' AND CODIGO=" . AsSql($acupom[$i][CUP_CODIGO]) . " order by quant_i ");
        $nfinal = $acupom[$i][CUP_NCUPOMVTOTAL];

        if (count($aaux) > 0) {
            for ($k = 0; $k < count($aaux); $k++) {
                if ($nfinal >= $aaux[$k][1 - 1] && $nfinal <= $aaux[$k][2 - 1]) {
                    $nfinal = $aaux[$k][3 - 1];
                    break;
                }
            }
        }
        if ($acupom[$i][CUP_UNICA_NOT] > 0) {
            $nfinal = 1;
        }


        for ($k = 1; $k <= $nfinal; $k++) { //aCupom[ i, CUP_NCUPOMVTOTAL ]
            if (!$lTesta) {
                $ctoken = GeraToken(6, true);
                while (mysqli_fetch_row(mysqli_query($db, "select count(*) from CUPOMDET_PRM where is_delted='N' and token='$ctoken'"))[0] + 0 > 0) {
                    $ctoken = GeraToken(6, true);
                }
                $otok = new Mediator3("CUPOMDET.PRM", W_CRIAR, '', '', $db);
                $otok->aadd("codigo", $acupom[$i][CUP_CODIGO]);
                $otok->aadd("data", Date2Unix());
                $otok->aadd("ordem", $k);
                $otok->aadd("cliente", $ncliente);
                $otok->aadd("nota", $nNota);
                $otok->aadd("valor", $acupom[$i][CUP_VALOR]);
                $otok->aadd("TOKEN", $ctoken);
                $otok->aadd("impressora", $noperador);
                $otok->grava();

                $aEmitidos[] = array(aCupom[$i][CUP_CODIGO], date('Y-m-d'), date('H:i:s'), $k, $ncliente, $nNota, $acupom[$i][CUP_VALOR], $ctoken);
//                $aEmitidos[]=, { ( odet ) ->codigo, Unix2Date( ( odet ) ->DATA )[ 1 ], Unix2Date( ( odet ) ->DATA )[ 2 ], ( odet ) ->ordem, ( odet ) ->cliente, nNota, ( odet ) ->valor, ( odet ) ->Token } )
            } else {
                $aEmitidos[] = array(aCupom[$i][CUP_CODIGO], date('Y-m-d'), date('H:i:s'), $k, $ncliente, $nNota, $acupom[$i][CUP_VALOR], "XXXXXXX");
            }
        }
    }
    return true;
}

function GeraToken($nTam = 10, $lDigito = false) {
    $cAux = "ABTUVWXYZaCDEFNO45678PQRSbcdefghijklmnopGHIJKLMqrwxyz012stuv39";
    $nAux = Date2Unix();
    $cRet = '';
    for ($i = 1; $i <= $nTam; $i++) {
        $nAux = RanD(1, 100000000) + $nAux;

        $nPos = ( floor($nAux * 1000) ) % 62 + 1;
        $cRet .= SubStr($cAux, $nPos - 1, 1);
    }
    if (lDigito) {
        $nAux1 = 0;
        for ($i = 1; $i <= strlen($cRet); $i++) {
            $nAux1 += ord(SubStr($cRet, $i - 1, 1));
        }
        $nPos = $nAux1 % 62 + 1;
        $cRet .= SubStr($cAux, $nPos - 1, 1);
    }
    return $cRet;
}

function ImprimeCupom($nNota, &$aRefCupom = array(), &$cRefErro = '') {
    global $db;
    global $noperador;
    $cRefErro = "";

    define("P_NEG_ON", chr(27) . chr(69) . '1'); // = String.fromCharCode(27, 69, 1); //ESC E 1
    define("P_NEG_OFF", chr(27) . chr(69) . '0'); // = String.fromCharCode(27, 69, 0); //ESC E 0
    define("P_LEFT", chr(27) . chr(97) . "0"); //ESC a 0
    define("P_CENTER", chr(27) . chr(97) . "1"); //ESC a 1
    define("P_RIGHT", chr(27) . chr(97) . "2"); //ESC a 2
    define("P_INVERT_ON", chr(29) . chr(66) . "1"); //
    $aRefCupom = array();

    if (!$nNota) {
        $nREfErro = 1;
        $cRefErro = "Nota nao informada";
        return false;
    }

    if (!medFile("CUPOMDET.PRM")) {
        return false;
    }
    /*
      oArq := AbreArqS():Inicio()
      oArq:Adiciona( "cupom.prm", oCup, FALSE, TRUE, "idx", "codigo" )
      oArq:Adiciona( "cupomdet.prm", oDet, FALSE, FALSE, "idx", "nota" )
      oArq:Adiciona( "cliente.cli", oCli, FALSE, TRUE, "idx", "clicod" )
      oArq:Adiciona( "saidas.sai", oSai, FALSE, TRUE, "idx", "sainota" )
     */

    if (mysqli_fetch_row(mysqli_query($db, "select count(*) from CUPOMDET_PRM where is_deleted='N' and nota=$nNota"))[0] + 0 == 0) {
        $nREfErro = 0;
        $cRefErro = "Sem cupons para a nota";
        return false;
    }

    $i = 0;
    $nQuant = mysqli_fetch_row(mysqli_query($db, "select count(*) as quant from CUPOMDET_PRM where is_deleted='N' and nota=" . AsSql($nNota)))[0];
    $anot = mysqli_fetch_array(mysqli_query($db, "select * from SAIDAS_SAI where notasai=$nNota"));
    $otabcup = mysqli_query($db, "select * from CUPOMDET_PRM WHERE IS_DELETED='N' AND NOTA=$nNota");
    $olincli = mysqli_fetch_array(mysqli_query($db, "select * from CLIENTE_PGY where is_deleted='N' and codigo=" . $anot["CLIESAI"]));

    while ($olincup = mysqli_fetch_array($otabcup)) {
        $i++;
        $olinprm = mysqli_fetch_array(mysqli_query($db, "select * from CUPOM_PRM where is_deleted='N' and codigo=" . $olincup["CODIGO"]));

        $cSaida = '';
        $cSaida .= P_CENTER . P_NEG_ON . "** Este e seu Cupom**" . P_NEG_OFF . "\r\n\r\n";
        $cSaida .= P_LEFT . "Cliente: " . P_NEG_ON . (explode(" ", $olincli["NOME"])[0]) . "(xxxx-" . substr($olincli["CELULAR"] ? $olincli["CELULAR"] : $olincli["TELEFONE"], -4) . ")" . P_NEG_OFF . "\n";
        $cSaida .= "SORTEIO: " . P_NEG_ON . $olinprm["NOME"] . P_NEG_OFF . "\n";
        $cSaida .= "Concorra ate o dia: " . P_NEG_ON . Unix2Date($olinprm["FINAL"])[1] . P_NEG_OFF . "\n";
        $cSaida .= "Sorteio no dia: " . P_NEG_ON . Unix2Date($olinprm["SORTEIO"])[1] . P_NEG_OFF . "\r\n\r\n";
        $cSaida .= P_CENTER . "TOKEN:  " . P_NEG_ON . $olincup["TOKEN"] . "\r\n";
        $cSaida .= "\n\n\n\n";
        $aRefCupom[] = $cSaida;
    }
    return true;
}

function GeraEntrega($nNota, &$cRefErro = '') {
    global $db;
    global $noperador;
    $nRet = 0;
    $aProdutos = array();
    $nPacote = 0;
    $cNotas = "";

    $cRefErro = "";

    if (!$nNota) {
        $cRefErro = "1-Falta o parametro Nota";
        return 1;
    }
    if (is_array($nNota)) {
        $aNotas = $nNota;
    } else if (is_null($nNota)) {
        $aNotas = array($nNota);
    } else {
        $cRefErro = "1-Falta o parametro Nota";
        return 1;
    }

    $cRefErro = "";
    foreach ($aNotas as $nNota) {
        $cSql = "select n.is_deleted,n.sitsai,n.retisai,if(isnull(e.nota),0,1 ) as entrega FROM SAIDAS_SAI n left join ENTREGA_ETG e on e.is_deleted='N' and e.nota=n.notasai where n.is_deleted='N' and notasai=" . AsSql($nNota);
        $otab = mysqli_query($db, $cSql);

        if (mysqli_num_rows($otab) == 0) {
            $cRefErro .= "3-Nota " . $nNota . " não existe;";
            continue;
        }
        $aSql = mysqli_fetch_array($otab);
        if ($aSql[0] !== "N") {
            $cRefErro .= "4-Nota " . $nNota . " Está deletada;";
            continue;
        }

        if ($aSql[1] !== "S") {
            $cRefErro .= "5-Nota " . $nNota . " não paga;";
            continue;
        }
        if ($aSql[2] !== "N") {  //IF ( cSai ) ->retisai == "S"
            $cRefErro .= "6-Nota " . $nNota . " já entregue;";
            continue;
        }
        //( cEtg ) ->( DBSeek( nNota ) )
        if ($aSql[3] == 1) { //IF ( cEtg ) ->( Found() )
            $cRefErro .= "7-Nota " . $nNota . " Já na entrega;";
            continue;
        }
    }
    if ($cRefErro) {
        return 8;
    }
    foreach ($aNotas as $nNota) {
        $cNotas .= $nNota . "-" . Digito($nNota) . ";";
        $cSql = "select * from (select if(l.pacoemp>0,l.pacoemp,p.pacote) as pacote,d.prsai,d.qusai,d.cusai,d.regsai,n.lojasai,date2unix(concat(n.datarec,' ',n.horarec)) as datacax 
        from SAIDAS_SAI n 
        inner join EMPRESA_EMP l on l.is_deleted='N' and l.codemp=n.lojasai
        inner join PROSAI_SAI  d on d.is_deleted='N' and d.nfsai=n.notasai
        inner join PRODUTO_PRO p on p.is_deleted='N' and p.codpro=d.prsai
        where n.is_deleted='N' and n.notasai=" . AsSql($nNota) . "
        ) x order by pacote,regsai";
        $otab = mysqli_query($db, $cSql);

        $nItensT = 0;
        $nValort = 0;
        $aProdutos = array();
        $nLoja = 0;
        $nData = 0;

        while ($aSql = mysqli_fetch_array($otab)) {
            $nLoja = $aSql[5];
            $nData = $aSql[6];
            $aProdutos[$aSql[0]][] = array($aSql[1], $aSql[2], $aSql[3]);
        }
        $i = 0;
        foreach ($aProdutos as $nPacote => $aPro) {
            ++$i;
            $nItens = 0;
            $nValor = 0;
            foreach ($aPro as $value) {
                $opro = new Mediator3("ENT_DETP.ETG", W_CRIAR, '', '', $db);
                $opro->aadd("nota", $nNota);
                $opro->aadd("parte", $i);
                $opro->aadd("produto", $value[0]); // := aProdutos[ i ][ 2 ][ k ][ 1 ]
                $opro->aadd("quant", $value[1]); //   := aProdutos[ i ][ 2 ][ k ][ 2 ]
                $opro->aadd("valor", $value[2] * $value[1]); //   := aProdutos[ i ][ 2 ][ k ][ 2 ] * aProdutos[ i ][ 2 ][ k ][ 3 ]
                $nItens += $value[1]; //aProdutos[ i ][ 2 ][ k ][ 2 ]
                $nItensT += $value[1]; //aProdutos[ i ][ 2 ][ k ][ 2 ]
                $nValor += $value[2] * $value[1]; // aProdutos[ i ][ 2 ][ k ][ 2 ] * aProdutos[ i ][ 2 ][ k ][ 3 ]
                $nValort += $value[1] * $value[1]; // aProdutos[ i ][ 2 ][ k ][ 2 ] * aProdutos[ i ][ 2 ][ k ][ 3 ]
                $opro->grava();
            }
            $odet = new Mediator3("ENT_DET.ETG", W_CRIAR, '', '', $db);
            $odet->aadd("nota", $nNota);
            $odet->aadd("parte", $i);
            $odet->aadd("pacote", $nPacote); //      := aProdutos[ i ][ 1 ]
            $odet->aadd("itens", $nItens);
            $odet->aadd("valor", $nValor);
            $odet->grava();
        }
        $oetg = new Mediator3("ENTREGA.ETG", W_CRIAR, '', '', $db);
        $oetg->aadd("nota", $nNota);
        $oetg->aadd("datacax", "Date2Unix(now())", true); //nData
        $oetg->aadd("partes", count($aProdutos));
        $oetg->aadd("itens", $nItensT);
        $oetg->aadd("valor", $nValort);
        $oetg->aadd("loja", $nLoja);
        $oetg->grava();
    }
    return 0;
}
