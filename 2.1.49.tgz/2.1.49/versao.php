<?php



define("versaomin", "2.1.49");
define("versaomax", "2.1.49");
define("versaocec","9.90");
define("versaocomp","");







 





 























session_start();

$aret = array();
$aret["erro"] = "00"; 
$aret["cerro"] = "";


require_once 'inc/config.php';


if (!$db) {
    $db = conecta();
}
if (!$db) {
    $aret["erro"] = "99";
    $aret["cerro"] = _tr("Erro acessando servidor"). " - ".mysqli_connect_error();
    echo json_encode($aret);
    return;
}



$aret["min"]=versaomin;
$aret["max"]=versaomax;
$aret["cec_need"]=versaocec;
$aret["cec_inst"]=mysqli_fetch_row(mysqli_query($db, "select max(versao) from VERSAO"))[0];
echo json_encode($aret);
return;
