<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_erros', 0);
session_start();
$aret = array();
$aret["erro"] = "00";
$aret["cerro"] = "";

define("OCR_SITE", "https://ibiza.consoft.srv.br:444/IA/ocr_up.php");

require_once 'inc/config.php';
if (0 < $_FILES['file']['error']) {
    $aret["erro"] = "98";
    $aret["cerro"] = $_FILES['file']['error'];
    echo json_encode($aret);
    return;
}

$ncliente = pegavar("client");
$nord = pegavar("ord");
if (!is_dir("ocr")) {
    mkdir('ocr', 0755, true);
}
$cstr = base64_encode(file_get_contents($_FILES['file']['tmp_name'], FILE_BINARY));
$cname = "ocr/" . $ncliente . "_" . $nord . ".jpg";

$cstr = file_get_contents($_FILES['file']['tmp_name'], FILE_BINARY);
if ($nord == "1") {
    $aret["erro"] = "01";
    $aret["cerro"] = "";
    echo json_encode($aret);
    return;
}

$filesToUpload = array("formFileF" => "ocr/" . $ncliente . "_1.jpg");
if ($nord == 2) {
    $filesToUpload["formFileV"] = "ocr/" . $ncliente . "_2.jpg";
}
if ($nord == 3) {
    $filesToUpload["formFileF"] = "ocr/" . $ncliente . "_3.jpg";
}

// Initialize an array to hold the POST data, including the files
$postData = array();

// Add other form fields if needed
$postData['cliente'] = $ncliente;

// Prepare each file for upload using curl_file_create()
$caux='';
foreach ($filesToUpload as $index => $filePath) {
    // Ensure the file exists before attempting to upload
    $caux.=$index."|".$filePath."\n";
    if (file_exists($filePath)) {
        $postData['files[' . $index . ']'] = curl_file_create(
                realpath($filePath),
                mime_content_type($filePath), // Get the MIME type
                basename($filePath)           // Get the original filename
        );
    } else {
        //error_log("File not found: " . $filePath);
        $aret["erro"] = "98";
        $aret["cerro"] = "File not found: " . $filePath;
        echo json_encode($aret);
        return;
    }
}

// Initialize cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, OCR_SITE); // Replace with your upload script URL
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the transfer as a string
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable peer verification
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // Disable host verification
curl_setopt($ch, CURLOPT_TIMEOUT_MS, 75000);
// Execute the cURL request
$response = curl_exec($ch);
// Check for cURL errors
if (curl_errno($ch)) {
    $aret["erro"] = "98";
    $aret["cerro"] = curl_error($ch);
    echo json_encode($aret);
    return;
}

// Close the cURL session
curl_close($ch);

// Process the response (e.g., echo it or log it)
$aret= json_decode($response,true);
if (!$aret["regi"] || $aret["regi"]=="-"){
    $aret["erro"] = "98";
    $aret["cerro"] = "Dados não interpretados";
    echo json_encode($aret);
    return;
    
}
$db= conecta();

$otab=mysqli_query($db,"select * from CLIENTE_PGY WHERE IS_DELETeD='N' and IDEN_NUM='".trim($aret["regi"])."'");
$aret["lpgy"]= false;
if (mysqli_num_rows($otab)>0){
    $aret["lpgy"]=true;
    $aret["lpnom"]=true;
}
$otab=mysqli_query($db,"select * from CLIENTE_CLI WHERE IS_DELETeD='N' and RUC_RES='".trim($aret["regi"])."'");
$aret["lcli"]= false;
if (mysqli_num_rows($otab)>0){
    $aret["lcli"]=true;
    $aret["lcnom"]=true;
}
echo json_encode($aret);
return;
/*

$cname = $_FILES['file']['name'];

if (!$db){
    $db = conecta();
}
if (!$db) {
    echo "99-Erro acessando SQL ";
    return;
}


if ($ccommit_web) {
    $omedv = new Mediator3("VEIIMG.CAR",W_CRIAR,'','',$db);
    $omedv->aadd("placa", $cplaca);
    $omedv->aadd("cliente", $ncli);
    $omedv->aadd("obs", "");
    $omedv->aadd("imagem", "1");
    if (!$omedv->grava()) {
        echo "98-Erro acessando SQL ".$omedv->cerro;
        return;
    }
} else {
    $omedv = new Mediator1();
    $omedv->init($db, "VEIIMG.CAR");
    $omedv->aadd("placa", $cplaca);
    $omedv->aadd("cliente", $ncli);
    $omedv->aadd("obs", "");
    $omedv->aadd("imagem", "1");
    if (!$omedv->grava()) {
        echo "98-Erro acessando SQL ";
        return;
    }
}


mysqli_query($db, "update VEIIMG_CAR_MEMO SET MEMO='$cstr' WHERE COL_NAME='IMAGEM' AND RECNO=" . $omedv->nrecno);
mysqli_query($db, "update VEIIMG_CAR i,VEIIMG_CAR_MEMO m SET i.imagem=length(m.memo) WHERE m.COL_NAME='IMAGEM' AND m.RECNO=" . $omedv->nrecno . " and i.recno=" . $omedv->nrecno);

mysqli_close($db);

echo "00-Cliente: $ncli \nOrdem: $nord \nArray: " . count($aaux);
return;
*/